from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .serializers import ArtistSerializer

# Create your views here.
@api_view(['POST'])
def artist_list_or_create(request):
    serializer = ArtistSerializer(data=request.data)

    if serializer.is_valid(raise_exception=True):
        serializer.save()
        return Response(
            serializer.data,
            status=status.HTTP_201_CREATED,
        )