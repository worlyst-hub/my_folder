from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import status

from django.shortcuts import get_object_or_404, get_list_or_404
from django.db.models import Count

from .models import Article, Comment
from .serializers import ArticleListSerializer, ArticleSerializer, CommentSerializer


@api_view(['GET', 'POST'])
def article_list(request):
    if request.method == 'GET':
        articles = get_list_or_404(Article)
        # serializer = ArticleListSerializer(articles)
        # 1. 하나만 불러오는게 아닌 id, title, content 여러개를 불러와야하기 때문에
        serializer = ArticleListSerializer(articles, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        serializer = ArticleSerializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            # return Response(serializer.data)
            # 2. 200 OK로 응답되는 것을 201 Created로 응답되도록 변경
            return Response(serializer.data, status=status.HTTP_201_CREATED)


@api_view(['GET', 'DELETE', 'PUT', 'PATCH'])
def article_detail(request, article_pk):
    # article = Article.objects.annotate(num_of_comments=Count('comment')).get(pk=article_pk)
    # 3. 존재하지 않는 게시글을 요청하면 404 Not Found로 응답되도록 수정
    article = get_object_or_404(Article, pk=article_pk)
    if request.method == 'GET':
        serializer = ArticleSerializer(article)
        return Response(serializer.data)

    elif request.method == 'DELETE':
        # 삭제만 진행할 경우
        article.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

        # 삭제 후 데이터 응답 시
        """
        pk = article.pk
        title = article.title
        data = {
            'message': f'{pk}번 게시글 "{title}"이 삭제되었습니다.'
        }
        return Response(data, status=status.HTTP_200_OK)
        """

    elif request.method == 'PUT':
        serializer = ArticleSerializer(article, data=request.data) # 수정했는데 새로 만들어지는 경우는 instance를 안넣은 경우에 그럼
        if serializer.is_valid(raise_exception=True):
            # 
            # 9. 수정 내용 반영되게 save 추가
            serializer.save()
            return Response(serializer.data)

    elif request.method == 'PATCH':
        # serializer = ArticleSerializer(article, data=request.data)
        # 5. 부분만 수정해도 들어오도록 수정
        serializer = ArticleSerializer(article, data=request.data, partial=True)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return Response(serializer.data)


@api_view(['GET'])
def comment_list(request):
    comments = get_list_or_404(Comment)

    serializer = CommentSerializer(comments, many=True)
    return Response(serializer.data)


# @api_view(['GET', 'PUT'])
# 8. 삭제 기능인 'DELETE'가 빠져있어 추가
@api_view(['GET', 'PUT', 'DELETE'])
def comment_detail(request, comment_pk):
    comment = get_object_or_404(Comment, pk=comment_pk)

    if request.method == 'GET':
        serializer = CommentSerializer(comment)
        return Response(serializer.data)
    
    elif request.method == 'PUT':
        serializer = CommentSerializer(comment, data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return Response(serializer.data)

    elif request.method == 'DELETE':
        comment.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


@api_view(['POST'])
def comment_create(request, article_pk):
    article = get_object_or_404(Article, pk=article_pk)
    
    serializer = CommentSerializer(data=request.data)
    if serializer.is_valid(raise_exception=True):
        serializer.save(article=article)
        return Response(serializer.data, status=status.HTTP_201_CREATED)


