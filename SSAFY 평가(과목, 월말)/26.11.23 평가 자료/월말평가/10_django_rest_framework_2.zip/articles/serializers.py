from rest_framework import serializers
from .models import Article, Comment


class ArticleListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Article
        fields = ('id', 'title', 'content', )


class ArticleSerializer(serializers.ModelSerializer):
    class CommentDetailSerializer(serializers.ModelSerializer):
        class Meta:
            model = Comment
            fields = ('id', 'content',)

    num_of_comments = serializers.SerializerMethodField()
    # 
    # 4. 댓글도 반환되도록 수정
    comment_set = CommentDetailSerializer(many=True, read_only=True)

    class Meta:
        model = Article
        fields = '__all__'

    def get_num_of_comments(self, obj):
        if hasattr(obj, 'num_of_comments'):
            return obj.num_of_comments
        return obj.comment_set.count()



class CommentSerializer(serializers.ModelSerializer):
    class ArticleTitleSerializer(serializers.ModelSerializer):
        class Meta:
            model = Article
            # fields = '__all__'
            # 6. article 필드에 제목만 응답되도록 수정
            fields = ('title',)
    # article = ArticleTitleSerializer()
    # 7. article이 없어도 되도록 수정
    article = ArticleTitleSerializer(read_only=True)

    class Meta:
        model = Comment
        fields = '__all__'
        
