"""검색된 법령 Child만 근거로 필요서류/신고사항을 간결하게 정리한다.

LLM_MODE=live이면 Ollama에 한 번의 JSON 요청으로 Child들을 요약한다. 모델 응답은
검색 Child에 실제로 등장하는 문서명/조문만 허용하도록 후처리한다. Mock 모드나
LLM 오류 시에도 일반 지식을 넣지 않고 Child 문자열에서만 추출하는 grounded
fallback을 사용한다.
"""

from __future__ import annotations

import json
import re
from collections import OrderedDict
from typing import Iterable

from config.settings import get_settings
from schemas.analysis import (
    RegulationArticleSummary,
    RegulationGuidance,
    RegulationMatch,
    RequiredDocumentItem,
    RequiredDocumentsResult,
)
from schemas.reason_code import ReasonCode
from utils.logging import get_logger

logger = get_logger(__name__)

_DOC_MARKERS = (
    "신고서", "계약서", "증명서", "확인서", "등본", "사본", "허가서", "승인서",
    "계획서", "내역서", "명세서", "고지서", "인보이스", "증빙서류", "첨부서류",
    "제출서류", "서류",
)
_FILING_MARKERS = ("신고", "신고수리", "제출", "첨부", "확인", "보고", "보관")
_FILING_ACTION_RE = re.compile(
    r"(?:신고(?:하여|해야|한다|할|를|가|수리)|제출(?:하여|해야|한다|할|을|하는)|"
    r"첨부(?:하여|해야|한다|할|할 것)|보고(?:하여|해야|한다|할)|보관(?:하여|해야|한다|할)|"
    r"확인(?:하여|해야|한다|할))"
)
_GENERIC_DOC_WORDS = {
    "서류", "제출서류", "첨부서류", "증빙서류", "관련서류", "기타서류", "필요서류",
}
_TOKEN_RE = re.compile(r"[0-9A-Za-z가-힣]{2,}")
_DOC_PHRASE_RE = re.compile(
    r"([0-9A-Za-z가-힣·()/'\- ]{2,55}(?:"
    r"신고서|계약서|증명서|확인서|등본|사본|허가서|승인서|계획서|내역서|명세서|고지서|"
    r"인보이스|증빙서류|첨부서류|제출서류))"
)


def _dedupe(values: Iterable[str]) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for value in values:
        value = re.sub(r"\s+", " ", str(value or "")).strip(" -•·,.;:")
        if value and value not in seen:
            seen.add(value)
            result.append(value)
    return result


def _evidence_text(matches: list[RegulationMatch]) -> str:
    return "\n".join(match.content for match in matches)


def _distinctive_tokens(value: str) -> list[str]:
    return [
        token for token in _TOKEN_RE.findall(value)
        if token not in _GENERIC_DOC_WORDS and token not in {"제출", "첨부", "확인", "관련", "필요"}
    ]


def _is_supported_phrase(value: str, evidence: str) -> bool:
    compact_value = re.sub(r"\s+", "", value)
    compact_evidence = re.sub(r"\s+", "", evidence)
    if compact_value and compact_value in compact_evidence:
        return True
    tokens = _distinctive_tokens(value)
    # 모델이 표현을 짧게 정리한 경우에도 핵심 문서명이 원문에 있어야 허용한다.
    return bool(tokens) and any(token in evidence for token in tokens)


def _clean_document_name(value: str) -> str:
    value = re.sub(r"^\s*(?:[①-⑳]|\d+(?:-\d+)?[.)]|[가-하][.)])\s*", "", value)
    value = re.sub(r"^(?:다음의?|해당|관련)\s+", "", value)
    value = re.sub(r"\s+", " ", value).strip(" -•·,.;:")
    return value[:80].strip()


def _fallback_documents(reason_code: ReasonCode, matches: list[RegulationMatch]) -> list[str]:
    evidence = _evidence_text(matches)
    values: list[str] = []

    # 기존 사유코드 목록을 사실 근거로 쓰지는 않는다. 다만 그 문서명이 실제 검색
    # Child에도 그대로 존재할 때만 정확한 짧은 라벨로 재사용한다.
    for document in reason_code.required_documents:
        if _is_supported_phrase(document, evidence):
            values.append(document)

    for line in evidence.splitlines():
        if not any(marker in line for marker in _DOC_MARKERS):
            continue
        for phrase in _DOC_PHRASE_RE.findall(line):
            candidate = _clean_document_name(phrase)
            if candidate and candidate not in _GENERIC_DOC_WORDS and _is_supported_phrase(candidate, evidence):
                values.append(candidate)

    return _dedupe(values)[:8]




def _is_filing_line(value: str) -> bool:
    value = str(value or "").strip()
    if not value:
        return False
    return bool(_FILING_ACTION_RE.search(value))

def _trim_summary(text: str, limit: int = 230) -> str:
    text = re.sub(r"^제\s*\d+(?:-\d+)?\s*조(?:의\s*\d+)?(?:\([^)]*\))?\s*", "", text.strip())
    text = re.sub(r"\[상위(?:항|호)\][^\n]*\n?", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) <= limit:
        return text
    clipped = text[:limit].rsplit(" ", 1)[0].strip() or text[:limit]
    return clipped + "…"


def _fallback_guidance(reason_code: ReasonCode, matches: list[RegulationMatch]) -> RegulationGuidance:
    evidence = _evidence_text(matches)
    documents = _fallback_documents(reason_code, matches)

    filing_points: list[str] = []
    for match in matches:
        for line in match.content.splitlines():
            cleaned = line.strip()
            if cleaned.startswith("[상위항]"):
                cleaned = cleaned.replace("[상위항]", "", 1).strip()
            elif cleaned.startswith("[상위호]"):
                cleaned = cleaned.replace("[상위호]", "", 1).strip()
            if not _is_filing_line(cleaned):
                continue
            filing_points.append(_trim_summary(cleaned, 180))
    filing_points = _dedupe(filing_points)[:5]

    grouped: OrderedDict[tuple[str, str | None], list[RegulationMatch]] = OrderedDict()
    for match in matches:
        grouped.setdefault((match.law_name, match.article), []).append(match)

    summaries: list[RegulationArticleSummary] = []
    for (law_name, article), group in list(grouped.items())[:4]:
        # 하위 호 Child에는 [상위항] 문맥이 붙어 있으므로, 먼저 그 상위항의
        # 신고/제출 문장을 짧은 조문 요약으로 사용한다. 문맥이 없으면 Child 본문에서
        # 실무 행동 문장을 고르고, 그것도 없을 때만 가장 관련 높은 Child를 축약한다.
        summary = ""
        for candidate in group:
            for line in candidate.content.splitlines():
                if line.startswith("[상위항]"):
                    context_line = line.replace("[상위항]", "", 1).strip()
                    if _is_filing_line(context_line):
                        summary = _trim_summary(context_line)
                        break
            if summary:
                break
        if not summary:
            for candidate in group:
                for line in candidate.content.splitlines():
                    if not line.startswith("[상위") and _is_filing_line(line):
                        summary = _trim_summary(line)
                        break
                if summary:
                    break
        if not summary:
            best = max(
                group,
                key=lambda m: sum(1 for marker in (*_DOC_MARKERS, *_FILING_MARKERS) if marker in m.content),
            )
            summary = _trim_summary(best.content)
        if summary:
            summaries.append(
                RegulationArticleSummary(
                    law_name=law_name,
                    article=article,
                    summary=summary,
                    source_url=group[0].source_url,
                )
            )

    articles = _dedupe(
        f"{m.law_name} {m.article or ''}".strip() for m in matches
    )
    return RegulationGuidance(
        required_documents=documents,
        filing_points=filing_points,
        article_summaries=summaries,
        source_note=(
            "국가법령정보 공동활용 API의 검색 Child만 근거로 정리 · "
            + ", ".join(articles[:5])
        ),
        generation_mode="grounded_fallback",
    )


def _build_prompt(reason_code: ReasonCode, matches: list[RegulationMatch], transaction_context: str) -> str:
    evidence_blocks = []
    for idx, match in enumerate(matches, 1):
        evidence_blocks.append(
            f"[CHILD {idx}]\n"
            f"법령명: {match.law_name}\n"
            f"조문: {match.article or '-'}\n"
            f"내용:\n{match.content}"
        )

    return f"""거래 사유: {reason_code.name}\n사유 설명: {reason_code.description}\n거래 문맥: {transaction_context or '-'}\n\n아래 CHILD들은 국가법령정보 API 원문에서 검색된 법령 Child이다.\n이 CHILD들만 근거로 은행원이 빠르게 확인할 수 있도록 정리하라.\n\n엄격한 규칙:\n1. Parent 전체를 추정하거나 일반 법률지식을 추가하지 말 것.\n2. required_documents에는 CHILD에 실제로 명시된 신고서/계약서/증명서/확인서 등 문서만 넣을 것.\n3. CHILD에 없는 문서명은 절대 만들어내지 말 것. 불명확하면 제외할 것.\n4. 정의 조항은 해당 거래의 신고·제출 절차에 직접 필요하지 않으면 article_summaries에서 제외할 것.\n5. filing_points는 신고 시점, 제출, 보고, 확인 등 실무 행동만 1문장씩 간결하게 작성할 것.\n6. article_summaries의 law_name/article은 반드시 아래 CHILD에 나온 값만 사용할 것.\n7. 순수 JSON 객체 하나만 출력할 것.\n\n출력 스키마:\n{{\n  \"required_documents\": [\"문서명\"],\n  \"filing_points\": [\"간결한 신고/확인 사항\"],\n  \"article_summaries\": [\n    {{\"law_name\": \"외국환거래규정\", \"article\": \"제9-39조\", \"summary\": \"1~2문장의 간결한 업무 안내\"}}\n  ]\n}}\n\n검색된 CHILD:\n\n{chr(10).join(evidence_blocks)}\n"""


def _live_guidance(
    reason_code: ReasonCode,
    matches: list[RegulationMatch],
    transaction_context: str,
) -> RegulationGuidance:
    settings = get_settings()
    # ollama 패키지는 live 모드에서만 필요하도록 지연 import한다.
    from services.ollama_client import build_ollama_client

    client = build_ollama_client(settings)
    response = client.chat(
        model=settings.ollama_model,
        messages=[
            {
                "role": "system",
                "content": (
                    "당신은 외환업무 RAG 결과 정리기다. 제공된 법령 CHILD 외의 지식을 "
                    "사용하지 않으며 반드시 요청된 JSON만 출력한다."
                ),
            },
            {"role": "user", "content": _build_prompt(reason_code, matches, transaction_context)},
        ],
        format="json",
        options={"temperature": 0},
    )
    parsed = json.loads(response["message"]["content"])

    evidence = _evidence_text(matches)
    allowed_articles = {(m.law_name, m.article): m for m in matches}
    documents = [
        _clean_document_name(value)
        for value in parsed.get("required_documents", [])
        if isinstance(value, str)
    ]
    documents = [
        value for value in _dedupe(documents)
        if value not in _GENERIC_DOC_WORDS and _is_supported_phrase(value, evidence)
    ][:8]

    filing_points = [
        str(value).strip() for value in parsed.get("filing_points", []) if isinstance(value, str)
    ]
    # 신고/제출 관련 핵심 단어가 전혀 없는 자유 생성 문장은 제외한다.
    filing_points = [
        value for value in _dedupe(filing_points)
        if _is_filing_line(value)
        and _is_supported_phrase(value, evidence)
    ][:5]

    summaries: list[RegulationArticleSummary] = []
    for item in parsed.get("article_summaries", []):
        if not isinstance(item, dict):
            continue
        law_name = str(item.get("law_name") or "").strip()
        article = str(item.get("article") or "").strip() or None
        key = (law_name, article)
        match = allowed_articles.get(key)
        summary = re.sub(r"\s+", " ", str(item.get("summary") or "")).strip()
        if match is None or not summary:
            continue
        summaries.append(
            RegulationArticleSummary(
                law_name=law_name,
                article=article,
                summary=summary[:360],
                source_url=match.source_url,
            )
        )
    summaries = summaries[:4]

    # 모델이 지나치게 보수적으로 빈 결과를 냈으면 근거 기반 fallback의 해당 필드만 보충한다.
    fallback = _fallback_guidance(reason_code, matches)
    if not documents:
        documents = fallback.required_documents
    if not filing_points:
        filing_points = fallback.filing_points
    if not summaries:
        summaries = fallback.article_summaries

    articles = _dedupe(f"{m.law_name} {m.article or ''}".strip() for m in matches)
    return RegulationGuidance(
        required_documents=documents,
        filing_points=filing_points,
        article_summaries=summaries,
        source_note=(
            "국가법령정보 공동활용 API Child → LLM 근거 정리 · "
            + ", ".join(articles[:5])
        ),
        generation_mode="llm",
    )


def build_regulation_guidance(
    reason_code: ReasonCode,
    matches: list[RegulationMatch],
    *,
    transaction_context: str = "",
) -> RegulationGuidance:
    """검색 Child를 짧은 필요서류/신고 안내로 변환한다."""

    if not matches:
        return RegulationGuidance(
            source_note="검색된 법령 Child가 없어 필요서류를 정리하지 못했습니다."
        )

    settings = get_settings()
    if settings.llm_mode == "live":
        try:
            return _live_guidance(reason_code, matches, transaction_context)
        except Exception:  # noqa: BLE001 - RAG 화면 전체를 막지 않고 근거 기반 fallback 사용
            logger.exception("법령 Child LLM 정리 실패 - grounded fallback으로 전환")

    return _fallback_guidance(reason_code, matches)


def required_documents_from_guidance(guidance: RegulationGuidance) -> RequiredDocumentsResult:
    """프론트 체크리스트에서 기존 RequiredDocumentsResult를 계속 쓸 수 있게 변환한다."""

    return RequiredDocumentsResult(
        items=[RequiredDocumentItem(name=name, checked=False) for name in guidance.required_documents],
        is_sample=False,
        source_note=guidance.source_note,
    )
