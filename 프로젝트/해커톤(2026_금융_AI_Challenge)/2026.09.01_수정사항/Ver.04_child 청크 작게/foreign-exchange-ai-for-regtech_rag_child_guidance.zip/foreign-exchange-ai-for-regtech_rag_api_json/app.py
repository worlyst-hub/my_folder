"""FIXAR(ForeIgn eXchange AI for RegTech) - Streamlit 진입점 (섹션 25).

은행원 업무 화면을 Wizard 방식(① 업로드 → ② OCR 확인 → ③ 거래 문맥 분석 →
④ 법령/필요서류 → ⑤ SWIFT 조회 → ⑥ 최종 처리 요약)으로 구성하고,
⑦ 처리 로그 / ⑧ 고객 데이터 / ⑨ 사유코드 / ⑩ 지정목적코드에서 DB에 쌓인
이력과 각종 코드 마스터를 조회한다.

이 시스템은 은행원의 업무를 지원하는 도구이며, AI가 법률적 최종 판단이나
실제 송금 승인 여부를 자동으로 결정하지 않는다.
"""

from __future__ import annotations

import streamlit as st

from config.settings import get_settings
from database.connection import init_db
from frontend import (
    customer_data,
    ocr_result,
    processing_log,
    purpose_codes,
    reason_codes,
    regulation,
    summary,
    swift,
    theme,
    transaction_analysis,
    upload,
)
from utils.logging import get_logger

logger = get_logger(__name__)

STEPS: list[tuple[int, str]] = [
    (1, "신청서 업로드"),
    (2, "OCR 결과 확인"),
    (3, "거래 문맥 분석"),
    (4, "법령 · 필요서류"),
    (5, "SWIFT 조회"),
    (6, "최종 처리 요약"),
    (7, "처리 로그"),
    (8, "고객 데이터"),
    (9, "사유코드"),
    (10, "지정목적코드"),
]

_STEP_RENDERERS = {
    1: upload.render,
    2: ocr_result.render,
    3: transaction_analysis.render,
    4: regulation.render,
    5: swift.render,
    6: summary.render,
    7: processing_log.render,
    8: customer_data.render,
    9: reason_codes.render,
    10: purpose_codes.render,
}

_MODE_LABELS = {
    "mock": "Mock",
    "api": "법령 API",
}


def _model_mode_label(mode: str, model_name: str) -> str:
    """LLM/OCR 모드 배지 라벨.

    ``live``/``vision``이면 실제 사용 중인 모델명을 함께 보여준다
    (예: ``qwen2.5vl (Ollama)``) - 그냥 "Live(Ollama)"라고만 나오면 어떤
    모델을 쓰는지 화면만 봐서는 알 수 없다는 점을 개선했다.
    """
    if mode in ("live", "vision"):
        return f"{model_name} (Ollama)"
    return _MODE_LABELS.get(mode, mode)


def _rag_mode_label(rag_mode: str, llm_mode: str, embed_model: str) -> str:
    """RAG 모드 배지 라벨.

    RAG_MODE=api에서는 국가법령정보 공동활용 API(JSON) 원문을 색인하고,
    검색 자체는 임베딩(텍스트→벡터 변환)과 ChromaDB가 담당한다
    (``chromadb.PersistentClient``, 벡터 저장/검색)다.

    다만 임베딩 쪽은 ``OLLAMA_EMBED_MODEL``이 아니라 **``LLM_MODE``**에
    따라 갈린다(``services/embedding_client.py``가 ``llm_mode == "live"``
    일 때만 Ollama를 시도하고, 아니면 곧장 경량 해시 임베딩으로
    폴백한다 - ``RAG_MODE``와는 무관). 그래서 배지도 ``llm_mode``를 보고
    "bge-m3 + ChromaDB (법령 API)" 또는 "해시 임베딩 + ChromaDB (법령 API)"처럼
    실제로 쓰일 임베딩 방식을 반영한다. (Ollama가 설정상 live여도 연결
    실패 시 런타임에 해시로 폴백하는 경우까지는 배지가 반영하지 못한다 -
    그건 화면별 폴백 경고 문구가 담당한다.)
    """
    embedding = f"{embed_model} + ChromaDB" if llm_mode == "live" else "해시 임베딩 + ChromaDB"
    return f"{embedding} ({_MODE_LABELS.get(rag_mode, rag_mode)})"


def _init_state() -> None:
    defaults = {
        "step": 1,
        # 사이드바에서 실제로 완료(제출/확정)한 가장 마지막 단계 번호. 사이드바
        # 목차를 눌러 자유롭게 이동해도 이 값은 안 바뀌고, 각 화면의 "다음"류
        # 액션이 실제로 성공했을 때만 갱신된다 - "✅ 완료" 표시가 단순히
        # 지금 보고 있는 단계보다 번호가 작다는 이유만으로 뜨지 않게 하기 위함.
        "max_step_reached": 1,
        "uploaded_file_path": None,
        "ocr_result": None,
        "customer_profile": None,
        "transaction_request": None,
        "system_lookup": None,
        "analysis": None,
        "reason_code_candidates": [],
        "reason_code_embedding_backend": None,
        "confirmed_reason_code": None,
        "regulation_matches": [],
        "regulation_matches_for_code": None,
        "regulation_guidance": None,
        "regulation_guidance_for_code": None,
        "regulation_embedding_backend": None,
        "payment_procedure_citations": None,
        "required_documents": None,
        "required_documents_for_code": None,
        "swift_result": None,
        "swift_queried_code": None,
        "db_customer_id": None,
        "db_transaction_id": None,
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def main() -> None:
    st.set_page_config(
        page_title="FIXAR",
        page_icon="🏦",
        layout="wide",
    )
    theme.inject_theme()

    init_db()
    _init_state()

    settings = get_settings()
    mode_badges = [
        ("LLM", _model_mode_label(settings.llm_mode, settings.ollama_model)),
        ("OCR", _model_mode_label(settings.ocr_mode, settings.ollama_vision_model)),
        ("RAG", _rag_mode_label(settings.rag_mode, settings.llm_mode, settings.ollama_embed_model)),
    ]
    theme.render_sidebar(STEPS, st.session_state.step, st.session_state.max_step_reached, mode_badges)

    theme.render_page_header(st.session_state.step)
    theme.render_notice()

    renderer = _STEP_RENDERERS.get(st.session_state.step, upload.render)
    renderer()


if __name__ == "__main__":
    main()
