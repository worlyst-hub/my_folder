# API JSON RAG - 구조형 Child 검색 + 필요서류 정리

이 버전은 국가법령정보 공동활용 API JSON을 다음 3개 문서에 대해 사용합니다.

- 외국환거래법 (`target=law`)
- 외국환거래법 시행령 (`target=law`)
- 외국환거래규정 (`target=admrul`)

## RAG 흐름

1. 법령명으로 검색하여 ID/MST/LID를 자동 취득
2. 상세 JSON 조회
3. JSON의 조/항/호/목 경계를 줄 단위로 복원
4. Parent = 조 전체
5. Child = 항/호/목 중심의 작은 단위
6. Child 임베딩 및 ChromaDB 색인
7. 사유코드 `regulation_tags`를 한국어 법령 키워드로 확장해 검색/재랭킹
8. 정의 조항보다 신고/제출/증빙 관련 Child를 우선
9. 같은 Parent에서도 최대 3개의 관련 Child를 반환
10. 검색된 Child들만 LLM에 전달하여 필요서류·신고사항·짧은 조문 안내 생성

LLM에 Parent 전체를 전달하지 않습니다. 하위 호/목의 의미 보존을 위해 같은 Parent의 직전 상위 항/호에서 짧은 문맥만 Child에 포함할 수 있습니다.

## 프론트 표시

현재 단계에서는 긴 Child 원문을 화면에 직접 펼쳐 보여주지 않습니다.

- 필요서류: 검색 Child에 실제로 근거가 있는 문서명만 체크리스트로 표시
- 관련 법령: 조문별 1~2문장 요약만 표시
- 신고·확인 포인트: 제출/신고/보고 등 실무 행동만 간결하게 표시

Child 원문 펼쳐보기/스크롤 UI는 후속 단계에서 추가할 수 있습니다.

## 중요 설정

`.env`의 기존 양식은 유지하며 아래 API 인증값이 필요합니다.

```env
RAG_MODE=api
LAW_API_KEY=
LAW_API_BASE_URL=https://www.law.go.kr/DRF
LAW_API_TIMEOUT=30
```

`LLM_MODE=live`이면 Ollama LLM이 검색 Child를 JSON으로 정리합니다. Mock 모드 또는 LLM 호출 실패 시에는 외부 지식을 사용하지 않고 검색 Child 문자열에서만 문서명/신고 문장을 추출하는 grounded fallback을 사용합니다.
