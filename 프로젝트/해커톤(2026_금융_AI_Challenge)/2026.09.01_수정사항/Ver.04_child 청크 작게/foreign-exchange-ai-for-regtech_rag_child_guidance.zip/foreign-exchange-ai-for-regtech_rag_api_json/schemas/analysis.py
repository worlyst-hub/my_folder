"""LLM 거래 문맥 분석 및 RAG 검색 결과 스키마 (섹션 11, 16~18)."""

from __future__ import annotations

from pydantic import BaseModel, Field


class TransactionAnalysisInput(BaseModel):
    """LLM 거래 문맥 분석에 들어가는 입력 (섹션 11)."""

    raw_transaction_purpose: str
    remittance_currency: str | None = None
    remittance_amount: str | None = None
    recipient_name: str | None = None
    recipient_country: str | None = None
    recipient_type: str | None = None
    beneficiary_bank_name: str | None = None
    customer_type: str | None = None
    residence_status: str | None = None


class TransactionAnalysis(BaseModel):
    """Ollama LLM이 자연어 송금 목적을 구조화한 결과.

    LLM은 법률적 최종 판단을 내리지 않으며, 검색에 활용할 문맥 정리만
    수행한다.
    """

    transaction_category: str = Field(description="거래 유형 (예: 해외부동산)")
    transaction_action: str = Field(description="거래 행위 (예: 취득)")
    transaction_nature: str = Field(description="거래 성격 (예: 자본거래, 경상거래)")
    normalized_purpose: str = Field(description="정규화된 거래 목적 (예: 해외부동산 취득)")
    country: str | None = Field(default=None, description="관련 국가 (ISO 코드 또는 국가명)")
    important_facts: list[str] = Field(default_factory=list, description="핵심 키워드/사실")


class RegulationMatch(BaseModel):
    """RAG로 검색된 관련 법령/조문 1건."""

    law_name: str = Field(description="법령명 (예: 외국환거래규정)")
    article: str | None = Field(default=None, description="조문 (예: 제5-11조)")
    content: str = Field(description="검색된 본문 발췌")
    file_name: str = Field(description="출처 표시명 (API 버전에서는 국가법령정보 공동활용 API)")
    page_number: int | None = None
    is_sample: bool = Field(default=False, description="샘플/Mock 데이터 여부")
    source_url: str | None = Field(default=None, description="법령 원문 출처 URL")
    score: float = Field(default=0.0, description="검색 재랭킹 점수 (참고용)")
    parent_id: str | None = Field(default=None, description="조문 Parent 연결 ID")
    child_index: int | None = Field(default=None, description="Parent 내부 Child 순번")


class RequiredDocumentItem(BaseModel):
    name: str
    checked: bool = False


class RequiredDocumentsResult(BaseModel):
    """RAG가 안내하는 필요서류 목록. 실제 확인/체크는 은행원이 수행한다."""

    items: list[RequiredDocumentItem] = Field(default_factory=list)
    is_sample: bool = False
    source_note: str | None = Field(
        default=None, description="근거가 된 법령/조문 등 참고 출처 설명"
    )


class RegulationArticleSummary(BaseModel):
    """검색된 Child만 근거로 만든 조문별 짧은 업무 안내."""

    law_name: str
    article: str | None = None
    summary: str
    source_url: str | None = None


class RegulationGuidance(BaseModel):
    """RAG Child들을 LLM(또는 근거 기반 fallback)로 간결하게 정리한 결과."""

    required_documents: list[str] = Field(default_factory=list)
    filing_points: list[str] = Field(default_factory=list)
    article_summaries: list[RegulationArticleSummary] = Field(default_factory=list)
    source_note: str | None = None
    generation_mode: str = Field(default="grounded_fallback")
