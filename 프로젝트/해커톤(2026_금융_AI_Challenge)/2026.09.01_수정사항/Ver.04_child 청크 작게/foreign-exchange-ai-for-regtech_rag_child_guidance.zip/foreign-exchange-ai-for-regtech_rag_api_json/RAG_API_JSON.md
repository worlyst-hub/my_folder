# RAG API JSON 전환 버전

이 버전은 법령 RAG 원문을 PDF가 아니라 **국가법령정보 공동활용 API의 JSON**에서 가져옵니다.

## 대상 문서

1. 외국환거래법 — `target=law`
2. 외국환거래법 시행령 — `target=law`
3. 외국환거래규정 — `target=admrul`

## .env

기존 Ollama/OCR/Embedding 설정 형식은 유지하고 아래 항목을 사용합니다.

```env
RAG_MODE=api
LAW_API_KEY=
LAW_API_BASE_URL=https://www.law.go.kr/DRF
LAW_API_TIMEOUT=30
```

`LAW_API_KEY=` 오른쪽에 국가법령정보 공동활용에서 발급받은 API 인증값을 입력하세요.

## RAG 흐름

```text
국가법령정보 공동활용 API
  -> lawSearch.do (정확한 현행 문서 검색)
  -> lawService.do (JSON 본문 조회)
  -> 조문 텍스트 정리
  -> 조문 전체 Parent
  -> 항/호/목 중심 Child
  -> Child Embedding / ChromaDB
  -> 검색된 Child를 LLM과 화면에 전달
```

PDF/Mock RAG 폴백은 제거했습니다. 기존 PDF 버전은 별도 이전 ZIP을 사용하세요.

## 구조형 Child 검색 업데이트

최신 수정본에서는 1200자 단위로 여러 항/호를 합치지 않고, 조문 Parent 안에서 항·호·목을 독립 Child로 유지합니다. `regulation_tags`를 실제 검색 재랭킹에 반영하고, 필요서류 검색 시 정의 조항을 낮추며 같은 조문의 관련 Child 여러 개를 LLM에 전달합니다. 프론트에는 Child 원문 대신 검색 Child만 근거로 만든 필요서류/신고사항/짧은 조문 안내를 표시합니다. 자세한 내용은 `RAG_API_CHILD_GUIDANCE.md`를 참고하세요.
