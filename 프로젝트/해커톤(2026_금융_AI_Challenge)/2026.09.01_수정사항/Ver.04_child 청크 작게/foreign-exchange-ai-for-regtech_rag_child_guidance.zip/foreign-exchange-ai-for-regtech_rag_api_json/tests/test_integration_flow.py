"""전체 업무 흐름 통합 테스트 (섹션 40 최종 시연 시나리오).

OCR → 은행원 확인 → 시스템 조회 → LLM 분석 → 사유코드 → RAG → SWIFT 조회까지,
UI가 호출하는 것과 동일한 순서로 서비스 계층을 그대로 통해 파이프라인이
끊김 없이 연결되는지 검증한다.

OCR 단계는 ``.env``의 OCR_MODE(예: vision)와 무관하게 항상 Mock을 직접
사용한다 - 실제 Vision 엔진은 무겁고(모델 다운로드/실행 시간) 실제 이미지
파일이 필요해 결정론적인 단위 테스트에 적합하지 않다. Vision OCR 자체의
동작은 수동으로 확인했다(services/ocr/vision_ocr.py 참고).
"""

from __future__ import annotations

from schemas.analysis import TransactionAnalysisInput
import config.settings as config_settings
from services import embedding_client as embedding_client_module
from rag import retriever as retriever_module
from rag.law_api import LawApiDocument
from services.llm import get_llm_service
from services.ocr.mock_ocr import MockOCRService
from rag.retriever import RagRetriever
from services.reason_code.mapper import ReasonCodeMapper
from services.regulation_guidance import (
    build_regulation_guidance,
    required_documents_from_guidance,
)
from services.swift.service import SwiftService
from services.system_lookup import get_system_lookup_service
from .conftest import make_isolated_get_session


def test_end_to_end_real_estate_scenario(monkeypatch, tmp_path):
    # ① 신청서 업로드 → OCR
    ocr_result = MockOCRService().extract("외화송금신청서_홍길동.png")
    customer = ocr_result.customer_profile
    transaction = ocr_result.transaction_request

    # ② 은행원 확인 (프로토타입에서는 OCR 결과를 그대로 확정한다고 가정)
    assert customer.name_ko and transaction.recipient_info.swift_bic

    # ③ Mock System Lookup
    system_lookup = get_system_lookup_service().get_customer_data(
        customer.identification_no, customer.account_number
    )
    assert system_lookup is not None

    # ④ Ollama(Mock) 거래 문맥 분석
    analysis = get_llm_service().analyze_transaction(
        TransactionAnalysisInput(
            raw_transaction_purpose=transaction.raw_transaction_purpose or "",
            remittance_currency=transaction.remittance_currency,
            remittance_amount=str(transaction.remittance_amount),
            recipient_name=transaction.recipient_info.recipient_name,
            recipient_country=transaction.recipient_info.recipient_country,
            recipient_type=(
                transaction.recipient_info.recipient_type.value
                if transaction.recipient_info.recipient_type
                else None
            ),
            beneficiary_bank_name=transaction.recipient_info.beneficiary_bank_name,
            customer_type=customer.customer_type.value,
            residence_status=customer.residence_status.value,
        )
    )
    assert analysis.transaction_category == "해외부동산"

    # ⑤ 사유코드 후보 검색 → 은행원 확인
    candidates = ReasonCodeMapper().search(
        f"{analysis.normalized_purpose} {transaction.raw_transaction_purpose}", top_k=5
    )
    assert candidates
    confirmed_reason_code = candidates[0].reason_code

    # ⑥ RAG - 실제 실행에서는 국가법령정보 API를 호출한다. 통합 테스트에서는
    # 외부 네트워크/개인 API 키에 의존하지 않도록 동일한 API 문서 스키마를 주입한다.
    fake_settings = config_settings.Settings(
        chroma_persist_dir=str(tmp_path / "integration_rag_chroma"),
        rag_mode="api",
        law_api_key="test-key",
        llm_mode="mock",
    )
    monkeypatch.setattr(retriever_module, "get_settings", lambda: fake_settings)
    monkeypatch.setattr(embedding_client_module, "get_settings", lambda: fake_settings)
    monkeypatch.setattr(retriever_module, "get_session", make_isolated_get_session(tmp_path))
    monkeypatch.setattr(
        retriever_module,
        "load_target_regulations",
        lambda: [
            LawApiDocument(
                law_name="외국환거래규정",
                target="admrul",
                text=(
                    "제9-39조(신고수리절차)\n"
                    "① 거주자가 외국에 있는 부동산을 취득하는 경우 신고하여야 한다.\n"
                    "② 신고 시 다음 서류를 제출하여야 한다.\n"
                    "1. 부동산 매매계약서\n"
                    "2. 자금출처 확인서\n"
                    "3. 등기부등본"
                ),
                source_url="https://www.law.go.kr",
                identifier="TEST",
            )
        ],
    )

    regulation_matches = RagRetriever().search(
        f"{confirmed_reason_code.name} 관련 신고 절차 필요서류 제출서류 계약서 확인서",
        top_k=5,
        regulation_tags=confirmed_reason_code.regulation_tags,
    )
    guidance = build_regulation_guidance(confirmed_reason_code, regulation_matches)
    required_documents = required_documents_from_guidance(guidance)
    assert regulation_matches
    assert required_documents.items

    # ⑦ SWIFT 조회
    swift_result = SwiftService().lookup(transaction.recipient_info.swift_bic)

    # ⑧ 최종 요약에 필요한 데이터가 모두 갖춰졌는지 확인
    assert regulation_matches or True  # 샘플 데이터 환경에 따라 0건일 수 있어 존재 여부만 참고
    assert swift_result is not None
    assert confirmed_reason_code.code.startswith("FX-")


def test_end_to_end_sanctioned_bank_scenario():
    """제재 은행 케이스: SWIFT 조회에서 제재 데이터 등재 경고가 표시되어야 한다."""

    ocr_result = MockOCRService().extract("sanction_case.jpg")
    transaction = ocr_result.transaction_request

    swift_result = SwiftService().lookup(transaction.recipient_info.swift_bic)
    assert swift_result.is_sanctioned is True
