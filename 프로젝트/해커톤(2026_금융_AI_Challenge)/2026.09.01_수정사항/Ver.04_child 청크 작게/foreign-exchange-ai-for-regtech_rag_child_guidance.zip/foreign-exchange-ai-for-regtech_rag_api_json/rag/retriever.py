"""국가법령정보 공동활용 API 기반 Child RAG 검색 Pipeline.

색인은 Parent=조 / Child=항·호·목으로 구성하며 검색과 LLM 입력에는 Child만
사용한다. 사유코드의 regulation_tags는 API 원문 자체의 메타데이터가 아니므로
한국어 업무 키워드로 확장하여 질의와 재랭킹에 실제 반영한다.
"""

from __future__ import annotations

import json
import re
from collections import defaultdict
from pathlib import Path
from types import SimpleNamespace

import chromadb

from config.settings import get_settings
from database.connection import get_session
from database.models import RagChunk, RagDocument
from rag.chunker import chunk_pages
from rag.embedder import ChunkEmbedder
from rag.law_api import load_target_regulations
from schemas.analysis import RegulationMatch
from utils.logging import get_logger

logger = get_logger(__name__)

_SOURCE_LABEL = "국가법령정보 공동활용 API"

# 사유코드 태그를 실제 법령 문구와 가까운 한국어 검색어로 바꿔 질의 확장과
# 재랭킹에 사용한다. API 원문을 임의로 분류해 하드 필터링하는 방식보다,
# 관련 실무 조항을 우선시키면서도 다른 법령의 중요한 근거를 놓치지 않는다.
_TAG_QUERY_TERMS: dict[str, tuple[str, ...]] = {
    "TRADE": ("수출", "수입", "무역", "물품", "계약서", "인보이스", "선하증권", "수출입신고"),
    "CURRENT_TRANSACTION": ("경상거래", "지급", "지급등", "증빙서류", "지급사유"),
    "SERVICE": ("용역", "서비스", "용역계약서", "사용료", "수수료"),
    "STUDY_ABROAD": ("유학", "연수", "등록금", "입학허가서", "재학증명서", "체재비"),
    "TRAVEL": ("여행", "출장", "체재비", "여행경비"),
    "IP_ROYALTY": ("사용료", "특허", "상표", "저작권", "라이선스", "계약서"),
    "FINANCE_COST": ("이자", "수수료", "차입", "금융계약", "약정서"),
    "INVESTMENT_INCOME": ("배당", "이자", "투자소득", "수취"),
    "REAL_ESTATE": (
        "해외부동산", "외국부동산", "부동산취득", "부동산처분", "신고수리",
        "매매계약서", "자금출처", "등기",
    ),
    "CAPITAL_TRANSACTION": ("자본거래", "신고", "신고수리", "허가", "취득", "투자"),
    "FDI": ("해외직접투자", "직접투자", "투자신고", "사업계획서", "현지법인"),
    "SECURITIES_INVESTMENT": (
        "해외증권", "증권취득", "증권투자", "주식", "채권", "펀드", "투자중개업자", "신고",
    ),
    "LOAN": ("금전대차", "대출", "차입", "대여", "상환", "금전소비대차계약서"),
    "IMMIGRATION_GIFT_INHERITANCE": ("해외이주", "이주비", "증여", "상속", "재산반출"),
}

_DOCUMENT_INTENT_TERMS = (
    "필요서류", "제출서류", "첨부서류", "증빙서류", "신고서", "계약서",
    "증명서", "확인서", "제출", "첨부", "신고", "신고수리",
)
_DEFINITION_PHRASES = ("이라 함은", "이란", "뜻은 다음", "를 말한다", "을 말한다")
_TOKEN_RE = re.compile(r"[0-9A-Za-z가-힣]{2,}")
_GENERIC_QUERY_TERMS = {
    "관련", "거래", "외환거래", "필요", "확인", "법령", "규정", "사항", "대한", "경우",
}


def _unique(values: list[str]) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for value in values:
        value = str(value or "").strip()
        if value and value not in seen:
            seen.add(value)
            result.append(value)
    return result


def _tag_terms(tags: list[str] | None) -> list[str]:
    values: list[str] = []
    for tag in tags or []:
        values.extend(_TAG_QUERY_TERMS.get(tag, ()))
    return _unique(values)


def _augment_query(query_text: str, tags: list[str] | None) -> str:
    terms = _tag_terms(tags)
    if not terms:
        return query_text
    return f"{query_text}\n거래유형 관련어: {' '.join(terms)}"


def _is_document_intent(query_text: str) -> bool:
    return any(term in query_text for term in _DOCUMENT_INTENT_TERMS)


def _definition_penalty(article: str, document: str) -> float:
    header = document.splitlines()[0] if document else ""
    if "(정의)" in header or "(용어" in header:
        return 0.24
    phrase_hits = sum(1 for phrase in _DEFINITION_PHRASES if phrase in document)
    # 긴 정의 조항에서 여러 정의가 한 Child에 남아 있는 경우를 강하게 억제한다.
    if phrase_hits >= 2:
        return 0.18
    if phrase_hits == 1 and article in {"제2조", "제3조", "제5조"}:
        return 0.10
    return 0.0


def _lexical_overlap(query_text: str, document: str) -> int:
    terms = {
        token for token in _TOKEN_RE.findall(query_text)
        if token not in _GENERIC_QUERY_TERMS and len(token) >= 2
    }
    return sum(1 for term in terms if term in document)


class RagRetriever:
    def __init__(self) -> None:
        settings = get_settings()
        self._settings = settings
        self._embedder = ChunkEmbedder()
        chroma_client = chromadb.PersistentClient(path=settings.chroma_persist_dir)
        # 청킹/재랭킹 방식이 바뀌었으므로 이전 API 색인을 잘못 재사용하지 않게 v2로 분리한다.
        self._collection = chroma_client.get_or_create_collection(
            name=f"rag_chunks_law_api_structural_v2_{self._embedder.backend_name}",
            metadata={"hnsw:space": "cosine"},
        )
        self._parent_store_path = Path(settings.chroma_persist_dir) / (
            f"rag_parents_law_api_structural_v2_{self._embedder.backend_name}.json"
        )
        self._parents = self._load_parent_store()

    @property
    def embedding_backend(self) -> str:
        return self._embedder.backend_name

    def _load_parent_store(self) -> dict[str, dict]:
        if not self._parent_store_path.is_file():
            return {}
        try:
            with self._parent_store_path.open("r", encoding="utf-8") as f:
                data = json.load(f)
            return data if isinstance(data, dict) else {}
        except Exception:
            logger.exception("RAG Parent 저장소 읽기 실패: %s", self._parent_store_path)
            return {}

    def _save_parent_store(self) -> None:
        self._parent_store_path.parent.mkdir(parents=True, exist_ok=True)
        temp_path = self._parent_store_path.with_suffix(self._parent_store_path.suffix + ".tmp")
        with temp_path.open("w", encoding="utf-8") as f:
            json.dump(self._parents, f, ensure_ascii=False, indent=2)
        temp_path.replace(self._parent_store_path)

    def _register_parent(
        self,
        *,
        parent_id: str | None,
        content: str,
        law_name: str,
        article: str | None,
        source_url: str,
    ) -> str:
        resolved_id = parent_id or f"{law_name}:{article or 'generic'}:{len(self._parents)}"
        self._parents[resolved_id] = {
            "content": content,
            "law_name": law_name,
            "article": article or "",
            "source": _SOURCE_LABEL,
            "source_url": source_url,
        }
        return resolved_id

    def build_index(self, force: bool = False) -> int:
        if self._collection.count() > 0:
            if not force and self._parents:
                logger.info("RAG API 인덱스가 이미 존재합니다 (force=True로 재생성 가능)")
                return self._collection.count()
            existing_ids = self._collection.get()["ids"]
            if existing_ids:
                self._collection.delete(ids=existing_ids)

        self._parents = {}
        with get_session() as session:
            session.execute(RagChunk.__table__.delete())
            session.execute(RagDocument.__table__.delete())

        chunk_rows = self._build_source_chunks()
        if not chunk_rows:
            logger.warning("국가법령정보 API에서 색인할 RAG 문서를 얻지 못했습니다.")
            return 0

        texts = [row["content"] for row in chunk_rows]
        embeddings = self._embedder.embed(texts)
        self._collection.add(
            ids=[str(row["chunk_id"]) for row in chunk_rows],
            embeddings=embeddings,
            documents=texts,
            metadatas=[
                {
                    "law_name": row["law_name"],
                    "article": row["article"] or "",
                    "source": row["source"],
                    "source_url": row["source_url"],
                    "api_target": row["api_target"],
                    "api_identifier": row["api_identifier"],
                    "parent_id": row.get("parent_id") or "",
                    "child_index": row.get("child_index", 0),
                    "child_count": row.get("child_count", 1),
                }
                for row in chunk_rows
            ],
        )
        self._save_parent_store()
        logger.info(
            "RAG API Child %d건 / Parent %d건 인덱싱 완료 (embedding backend=%s)",
            len(chunk_rows), len(self._parents), self._embedder.backend_name,
        )
        return len(chunk_rows)

    def _build_source_chunks(self) -> list[dict]:
        return self._store_api_chunks(load_target_regulations())

    def _store_api_chunks(self, documents) -> list[dict]:
        rows: list[dict] = []
        with get_session() as session:
            for api_doc in documents:
                doc = RagDocument(
                    file_name=api_doc.law_name,
                    title=api_doc.law_name,
                    source_path=api_doc.source_url,
                    is_sample=False,
                )
                session.add(doc)
                session.flush()

                source = SimpleNamespace(page_number=None, text=api_doc.text)
                chunks = chunk_pages([source], source_name=api_doc.law_name)
                for i, chunk in enumerate(chunks):
                    row = RagChunk(
                        document_id=doc.id,
                        chunk_index=i,
                        page_number=None,
                        article=chunk.article,
                        content=chunk.content,
                    )
                    session.add(row)
                    session.flush()

                    parent_id = self._register_parent(
                        parent_id=chunk.parent_id,
                        content=chunk.parent_content or chunk.content,
                        law_name=api_doc.law_name,
                        article=row.article,
                        source_url=api_doc.source_url,
                    )
                    rows.append(
                        {
                            "chunk_id": row.id,
                            "content": row.content,
                            "law_name": api_doc.law_name,
                            "article": row.article,
                            "source": _SOURCE_LABEL,
                            "source_url": api_doc.source_url,
                            "api_target": api_doc.target,
                            "api_identifier": api_doc.identifier,
                            "parent_id": parent_id,
                            "child_index": chunk.child_index,
                            "child_count": chunk.child_count,
                        }
                    )
        return rows

    def search(
        self,
        query_text: str,
        top_k: int = 5,
        regulation_tags: list[str] | None = None,
        max_children_per_parent: int = 3,
    ) -> list[RegulationMatch]:
        """관련 Child를 검색하고 업무 태그/서류 의도로 재랭킹한다.

        이전 버전처럼 Parent당 하나만 남기지 않는다. 같은 조문에 신고서·계약서·
        확인서가 서로 다른 호에 있을 수 있으므로 한 Parent에서 최대 3개 Child까지
        반환할 수 있다. 반환 content는 항상 Child이며 Parent 전체는 반환하지 않는다.
        """

        if self._collection.count() == 0:
            self.build_index()
        count = self._collection.count()
        if count == 0 or top_k <= 0:
            return []

        expanded_query = _augment_query(query_text, regulation_tags)
        query_embedding = self._embedder.embed([expanded_query])[0]
        result = self._collection.query(query_embeddings=[query_embedding], n_results=count)

        doc_intent = _is_document_intent(query_text)
        tag_terms = _tag_terms(regulation_tags)
        candidates: list[tuple[float, float, dict, str]] = []

        for distance, metadata, document in zip(
            result["distances"][0], result["metadatas"][0], result["documents"][0]
        ):
            base_similarity = max(0.0, min(1.0, 1.0 - float(distance)))
            rank_score = base_similarity

            # 사유코드 태그에 해당하는 실제 법령 어휘가 Child에 있을수록 가산한다.
            tag_hits = sum(1 for term in tag_terms if term in document)
            rank_score += min(0.20, tag_hits * 0.025)

            overlap_hits = _lexical_overlap(query_text, document)
            rank_score += min(0.10, overlap_hits * 0.015)

            if doc_intent:
                intent_hits = sum(1 for term in _DOCUMENT_INTENT_TERMS if term in document)
                rank_score += min(0.15, intent_hits * 0.025)
                # 필요서류/신고 절차 화면에서는 실제 업무 세부기준인 외국환거래규정을
                # 약하게 우선하되 법/시행령을 완전히 배제하지 않는다.
                if metadata.get("law_name") == "외국환거래규정":
                    rank_score += 0.06
                rank_score -= _definition_penalty(metadata.get("article") or "", document)

            candidates.append((rank_score, base_similarity, metadata, document))

        candidates.sort(key=lambda item: (item[0], item[1]), reverse=True)

        matches: list[RegulationMatch] = []
        parent_counts: dict[str, int] = defaultdict(int)
        seen_documents: set[str] = set()
        for rank_score, base_similarity, metadata, document in candidates:
            if document in seen_documents:
                continue
            parent_key = metadata.get("parent_id") or (
                f"{metadata.get('law_name', '')}:{metadata.get('article', '')}"
            )
            if parent_counts[parent_key] >= max(1, max_children_per_parent):
                continue

            seen_documents.add(document)
            parent_counts[parent_key] += 1
            matches.append(
                RegulationMatch(
                    law_name=metadata.get("law_name") or "",
                    article=metadata.get("article") or None,
                    content=document,  # 중요: LLM에 넘어가는 것은 Parent가 아닌 검색 Child.
                    file_name=metadata.get("source") or _SOURCE_LABEL,
                    page_number=None,
                    is_sample=False,
                    score=round(max(0.0, min(1.0, rank_score)), 4),
                    source_url=metadata.get("source_url") or None,
                    parent_id=parent_key,
                    child_index=int(metadata.get("child_index") or 0),
                )
            )
            if len(matches) >= top_k:
                break

        return matches
