"""법령 RAG용 구조 인식 Parent-Child Chunking.

API JSON에서 복원한 법령 텍스트를 다음 원칙으로 나눈다.

- Parent: 조(Article) 전체
- Child: 항 → 호 → 목 경계를 우선한 작은 검색 단위
- 검색/LLM 입력: Child만 사용
- Parent 원문: parent_id 연결 및 추적용으로만 보존

하위 호/목만 떼면 의미가 약해지는 경우가 있으므로 해당 Child에는 직전 상위
항/호의 *짧은 문맥*만 붙인다. Parent 전체를 다시 넣지는 않는다.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from typing import Iterable, Sequence

_ARTICLE_RE = re.compile(r"제\s*\d+(?:-\d+)?\s*조(?:의\s*\d+)?")
_ARTICLE_START_RE = re.compile(
    r"^(제\s*\d+(?:-\d+)?\s*조(?:의\s*\d+)?)(?:\s*\(([^)]*)\))?"
)
_CHAPTER_RE = re.compile(r"^제\s*\d+\s*장(?:\s+.*)?$")
_SECTION_RE = re.compile(r"^제\s*\d+\s*절(?:\s+.*)?$")

_PARAGRAPH_RE = re.compile(r"^(?:[①-⑳]|제\s*\d+\s*항)")
_ITEM_RE = re.compile(r"^\d+(?:-\d+)?\s*[.)]")
_SUBITEM_RE = re.compile(r"^[가-하]\s*[.)]")
_STRUCTURE_RE = re.compile(
    r"^(?:[①-⑳]|제\s*\d+\s*항|\d+(?:-\d+)?\s*[.)]|[가-하]\s*[.)])"
)

# 이전 1200자 Child는 하나의 Child 안에 서로 다른 항/호가 너무 많이 섞였다.
# 이제 구조 경계를 우선하고, 구조 단위 자체가 긴 경우에만 이 한도를 사용한다.
_DEFAULT_MAX_CHARS = 650
_DEFAULT_MIN_CHARS = 100
_DEFAULT_OVERLAP = 60
_CONTEXT_MAX_CHARS = 150


@dataclass
class Chunk:
    content: str
    page_number: int | None
    article: str | None
    parent_content: str | None = None
    parent_id: str | None = None
    child_index: int = 0
    child_count: int = 1
    chapter: str | None = None
    section: str | None = None


@dataclass(frozen=True)
class _SourceLine:
    text: str
    page_number: int | None


@dataclass
class _Parent:
    content: str
    article: str | None
    chapter: str | None
    section: str | None
    page_number: int | None
    lines: list[_SourceLine]
    parent_id: str


@dataclass(frozen=True)
class _RawUnit:
    text: str
    page_number: int | None
    level: int  # 0=일반본문, 1=항, 2=호, 3=목


def _normalize_text(text: str) -> str:
    text = str(text or "")
    text = text.replace("\r\n", "\n").replace("\r", "\n").replace("\x00", "")
    lines = [line.rstrip() for line in text.splitlines()]
    return re.sub(r"\n{3,}", "\n\n", "\n".join(lines)).strip()


def _detect_article(text: str) -> str | None:
    match = _ARTICLE_RE.search(text)
    return match.group(0) if match else None


def _stable_id(*values: object) -> str:
    raw = "|".join(str(value) for value in values)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _sliding_window(text: str, max_chars: int, overlap: int) -> list[str]:
    text = text.strip()
    if not text:
        return []
    if len(text) <= max_chars:
        return [text]

    overlap = max(0, min(overlap, max_chars - 1))
    step = max(max_chars - overlap, 1)
    chunks: list[str] = []
    for start in range(0, len(text), step):
        piece = text[start : start + max_chars].strip()
        if piece:
            chunks.append(piece)
        if start + max_chars >= len(text):
            break
    return chunks


def _recursive_split(
    text: str,
    max_chars: int,
    overlap: int,
    separators: Sequence[str] | None = None,
) -> list[str]:
    """구조 단위 하나가 너무 긴 경우에만 문장/공백 기준으로 더 나눈다."""

    text = text.strip()
    if not text:
        return []
    if len(text) <= max_chars:
        return [text]

    if separators is None:
        separators = ("\n\n", "\n", ". ", "다. ", " ")
    if not separators:
        return _sliding_window(text, max_chars=max_chars, overlap=overlap)

    separator = separators[0]
    parts = text.split(separator)
    if len(parts) == 1:
        return _recursive_split(text, max_chars, overlap, separators[1:])

    chunks: list[str] = []
    current: list[str] = []
    for part in parts:
        part = part.strip()
        if not part:
            continue
        candidate = separator.join(current + [part])
        if len(candidate) <= max_chars:
            current.append(part)
            continue

        if current:
            chunks.append(separator.join(current).strip())
            current = []

        if len(part) > max_chars:
            chunks.extend(_recursive_split(part, max_chars, overlap, separators[1:]))
        else:
            current = [part]

    if current:
        chunks.append(separator.join(current).strip())
    return chunks


def _build_source_lines(pages: Iterable[tuple[int | None, str]]) -> list[_SourceLine]:
    lines: list[_SourceLine] = []
    for page_number, text in pages:
        normalized = _normalize_text(text)
        for raw_line in normalized.splitlines():
            lines.append(_SourceLine(text=raw_line.strip(), page_number=page_number))
    return lines


def _parse_parents(source_lines: list[_SourceLine], source_name: str = "") -> list[_Parent]:
    """문서 전체에서 조문 경계를 찾아 조 전체를 Parent로 만든다."""

    parents: list[_Parent] = []
    current_lines: list[_SourceLine] = []
    current_chapter: str | None = None
    current_section: str | None = None

    def flush() -> None:
        nonlocal current_lines
        if not current_lines:
            return
        non_empty = [line for line in current_lines if line.text]
        if not non_empty:
            current_lines = []
            return

        first = non_empty[0]
        article = _detect_article(first.text)
        content = _normalize_text("\n".join(line.text for line in current_lines))
        parents.append(
            _Parent(
                content=content,
                article=article,
                chapter=current_chapter,
                section=current_section,
                page_number=first.page_number,
                lines=list(current_lines),
                parent_id=_stable_id(source_name, article or "generic", content),
            )
        )
        current_lines = []

    for source_line in source_lines:
        line = source_line.text.strip()
        if not line:
            if current_lines:
                current_lines.append(source_line)
            continue

        if _CHAPTER_RE.match(line):
            flush()
            current_chapter = line
            current_section = None
            continue
        if _SECTION_RE.match(line):
            flush()
            current_section = line
            continue
        if _ARTICLE_START_RE.match(line):
            flush()
            current_lines = [source_line]
            continue
        if current_lines:
            current_lines.append(source_line)

    flush()
    return parents


def _article_header(parent: _Parent) -> str:
    if not parent.lines:
        return parent.article or ""
    first_line = parent.lines[0].text.strip()
    match = _ARTICLE_START_RE.match(first_line)
    if match:
        return first_line[: match.end()].strip()
    return parent.article or first_line


def _structure_level(text: str) -> int:
    value = text.lstrip()
    if _PARAGRAPH_RE.match(value):
        return 1
    if _ITEM_RE.match(value):
        return 2
    if _SUBITEM_RE.match(value):
        return 3
    return 0


def _context_lead(text: str, limit: int = _CONTEXT_MAX_CHARS) -> str:
    value = re.sub(r"\s+", " ", text).strip()
    if len(value) <= limit:
        return value
    clipped = value[:limit].rsplit(" ", 1)[0].strip() or value[:limit].strip()
    return clipped + "…"


def _raw_structural_units(parent: _Parent) -> list[_RawUnit]:
    non_empty = [line for line in parent.lines if line.text.strip()]
    if not non_empty:
        return []

    article_line = non_empty[0]
    header = _article_header(parent)
    body_lines = list(non_empty[1:])

    # "제1조(목적) 이 법은 ..."처럼 헤더와 본문이 같은 줄이면 본문 꼬리를 보존한다.
    first_tail = article_line.text[len(header) :].strip() if header else ""
    if first_tail:
        body_lines.insert(0, _SourceLine(first_tail, article_line.page_number))

    if not body_lines:
        return [_RawUnit(header or parent.content, parent.page_number, 0)]

    groups: list[list[_SourceLine]] = []
    current: list[_SourceLine] = []
    for line in body_lines:
        if _STRUCTURE_RE.match(line.text) and current:
            groups.append(current)
            current = [line]
        else:
            current.append(line)
    if current:
        groups.append(current)

    units: list[_RawUnit] = []
    for lines in groups:
        text = _normalize_text("\n".join(line.text for line in lines))
        if not text:
            continue
        units.append(
            _RawUnit(
                text=text,
                page_number=next((x.page_number for x in lines if x.text), parent.page_number),
                level=_structure_level(text),
            )
        )
    return units


def _children_from_parent(
    parent: _Parent,
    max_chars: int,
    min_chars: int,
    overlap: int,
) -> list[Chunk]:
    """항/호/목 경계를 합치지 않고 각각 독립 Child로 유지한다."""

    del min_chars  # 짧은 구조 단위도 다른 항/호와 합치지 않는 것이 이번 버전의 핵심이다.
    raw_units = _raw_structural_units(parent)
    if not raw_units:
        return []

    header = _article_header(parent)
    contexts: dict[int, str] = {}
    child_payloads: list[tuple[str, int | None]] = []

    for raw in raw_units:
        level = raw.level

        # 현재 단위보다 낮은(더 세부적인) 이전 문맥은 새 경계에서 폐기한다.
        if level > 0:
            for key in list(contexts):
                if key >= level:
                    contexts.pop(key, None)

        context_lines: list[str] = []
        if level >= 2 and contexts.get(1):
            context_lines.append(f"[상위항] {_context_lead(contexts[1])}")
        if level >= 3 and contexts.get(2):
            context_lines.append(f"[상위호] {_context_lead(contexts[2])}")

        prefix = "\n".join([x for x in [header, *context_lines] if x]).strip()
        available = max(120, max_chars - len(prefix) - (1 if prefix else 0))
        pieces = _recursive_split(raw.text, max_chars=available, overlap=overlap)
        for piece in pieces:
            child = f"{prefix}\n{piece}".strip() if prefix else piece.strip()
            # 극단적으로 긴 header/context가 있는 경우에도 hard limit를 지킨다.
            if len(child) > max_chars:
                piece_budget = max(80, max_chars - len(header) - 1)
                for sub_piece in _recursive_split(raw.text, piece_budget, overlap):
                    child_payloads.append((f"{header}\n{sub_piece}".strip(), raw.page_number))
                break
            child_payloads.append((child, raw.page_number))

        if level > 0:
            contexts[level] = raw.text

    total = len(child_payloads)
    return [
        Chunk(
            content=content,
            page_number=page_number or parent.page_number,
            article=parent.article,
            parent_content=parent.content,
            parent_id=parent.parent_id,
            child_index=index,
            child_count=total,
            chapter=parent.chapter,
            section=parent.section,
        )
        for index, (content, page_number) in enumerate(child_payloads)
    ]


def chunk_pages(
    pages: Sequence[object],
    *,
    source_name: str = "",
    max_chars: int = _DEFAULT_MAX_CHARS,
    min_chars: int = _DEFAULT_MIN_CHARS,
    overlap: int = _DEFAULT_OVERLAP,
) -> list[Chunk]:
    """API 법령 텍스트를 Parent=조, Child=항/호/목 중심으로 청킹한다."""

    if max_chars <= 0:
        raise ValueError("max_chars는 1 이상이어야 합니다.")
    if min_chars < 0:
        raise ValueError("min_chars는 0 이상이어야 합니다.")
    if overlap < 0 or overlap >= max_chars:
        raise ValueError("overlap은 0 이상 max_chars 미만이어야 합니다.")

    page_pairs: list[tuple[int | None, str]] = []
    for page in pages:
        page_number = getattr(page, "page_number", None)
        text = getattr(page, "text", "")
        if str(text or "").strip():
            page_pairs.append((page_number, str(text)))

    source_lines = _build_source_lines(page_pairs)
    parents = _parse_parents(source_lines, source_name=source_name)
    if parents:
        chunks: list[Chunk] = []
        for parent in parents:
            chunks.extend(_children_from_parent(parent, max_chars, min_chars, overlap))
        return chunks

    # 법령 조문 구조를 전혀 찾지 못한 비정형 응답만 일반 재귀 청킹으로 처리한다.
    whole_text = _normalize_text("\n".join(text for _, text in page_pairs))
    pieces = _recursive_split(whole_text, max_chars=max_chars, overlap=overlap)
    article = _detect_article(whole_text)
    parent_id = _stable_id(source_name, "generic", whole_text)
    first_page = page_pairs[0][0] if page_pairs else None
    return [
        Chunk(
            content=piece,
            page_number=first_page,
            article=_detect_article(piece) or article,
            parent_content=whole_text,
            parent_id=parent_id,
            child_index=index,
            child_count=len(pieces),
        )
        for index, piece in enumerate(pieces)
    ]


def chunk_text(
    text: str,
    page_number: int | None = None,
    max_chars: int = _DEFAULT_MAX_CHARS,
    overlap: int = _DEFAULT_OVERLAP,
    min_chars: int | None = None,
) -> list[Chunk]:
    """단일 텍스트용 기존 호환 함수."""

    if min_chars is None:
        min_chars = min(_DEFAULT_MIN_CHARS, max_chars // 2)

    class _Page:
        def __init__(self, number: int | None, value: str) -> None:
            self.page_number = number
            self.text = value

    return chunk_pages(
        [_Page(page_number, text)],
        source_name="single_text",
        max_chars=max_chars,
        min_chars=min_chars,
        overlap=overlap,
    )
