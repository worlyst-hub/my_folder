"""국가법령정보 공동활용 API 기반 RAG Pipeline 테스트."""

from __future__ import annotations

from types import SimpleNamespace

import config.settings as config_settings

from services import embedding_client as embedding_client_module
from rag import law_api as law_api_module
from rag import retriever as retriever_module
from rag.chunker import chunk_pages, chunk_text
from rag.law_api import (
    LawApiClient,
    LawApiDocument,
    TARGET_REGULATIONS,
    parse_admrul_detail,
    parse_law_detail,
)
from rag.retriever import RagRetriever

from .conftest import make_isolated_get_session


def _source(text: str, number: int | None = None):
    return SimpleNamespace(page_number=number, text=text)


def _fake_settings(tmp_path):
    return config_settings.Settings(
        chroma_persist_dir=str(tmp_path / "rag_chroma_api"),
        rag_mode="api",
        law_api_key="test-key",
    )




class _FakeResponse:
    def __init__(self, payload, status_code=200):
        self._payload = payload
        self.status_code = status_code

    def json(self):
        return self._payload


class _FakeSession:
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []

    def get(self, url, params, timeout):
        self.calls.append({"url": url, "params": dict(params), "timeout": timeout})
        return _FakeResponse(self.responses.pop(0))


def test_law_api_client_uses_correct_detail_identifiers(monkeypatch, tmp_path):
    fake_settings = _fake_settings(tmp_path)
    monkeypatch.setattr(law_api_module, "get_settings", lambda: fake_settings)

    law_session = _FakeSession([
        {"LawSearch": {"law": [{"법령명한글": "외국환거래법", "법령ID": "1234", "시행일자": "20260101"}]}},
        {"Law": {"조문": {"조문단위": {"조문번호": "1", "조문내용": "제1조(목적) 테스트"}}}},
    ])
    law_doc = LawApiClient(session=law_session).fetch_document("외국환거래법", "law")
    assert law_doc.text.startswith("제1조")
    assert law_session.calls[1]["params"]["target"] == "law"
    assert law_session.calls[1]["params"]["ID"] == "1234"

    adm_session = _FakeSession([
        {"AdmRulSearch": {"admrul": [{"행정규칙명": "외국환거래규정", "행정규칙일련번호": "2100000000001", "행정규칙ID": "999", "시행일자": "20260701"}]}},
        {"AdmRulService": {"조문내용": "제4-2조(지급등의 절차) 테스트"}},
    ])
    adm_doc = LawApiClient(session=adm_session).fetch_document("외국환거래규정", "admrul")
    assert "제4-2조" in adm_doc.text
    assert adm_session.calls[1]["params"]["target"] == "admrul"
    # 행정규칙 상세조회 ID는 행정규칙ID가 아니라 행정규칙일련번호를 사용한다.
    assert adm_session.calls[1]["params"]["ID"] == "2100000000001"

def test_target_regulations_are_fixed_to_three_documents():
    assert TARGET_REGULATIONS == (
        ("외국환거래법", "law"),
        ("외국환거래법 시행령", "law"),
        ("외국환거래규정", "admrul"),
    )


def test_parse_law_detail_builds_article_text_from_json():
    payload = {
        "Law": {
            "조문": {
                "조문단위": [
                    {
                        "조문번호": "1",
                        "조문제목": "목적",
                        "조문내용": "제1조(목적) 이 법은 외국환거래의 자유를 보장한다.",
                    },
                    {
                        "조문번호": "2",
                        "조문가지번호": "2",
                        "조문제목": "정의",
                        "조문내용": "용어의 뜻은 다음과 같다.",
                        "항": [
                            {"항내용": "① 외국환이란 대통령령으로 정하는 것을 말한다."},
                            {"항내용": "② 지급수단의 범위는 다음과 같다."},
                        ],
                    },
                ]
            }
        }
    }

    text = parse_law_detail(payload)
    assert "제1조(목적)" in text
    assert "제2조의2(정의)" in text
    assert "① 외국환이란" in text


def test_parse_admrul_detail_extracts_regulation_body():
    payload = {
        "AdmRulService": {
            "행정규칙기본정보": {"행정규칙명": "외국환거래규정"},
            "조문내용": "제1조(목적) 규정 목적입니다.\n제4-2조(지급등의 절차) 지급 절차입니다.",
        }
    }
    text = parse_admrul_detail(payload)
    assert "제1조(목적)" in text
    assert "제4-2조(지급등의 절차)" in text


def test_chunker_splits_long_text_and_detects_article():
    long_text = ("가나다라마바사아자차카타파하 " * 60) + "제5-11조 규정 내용입니다."
    chunks = chunk_text(long_text, page_number=None, max_chars=200, overlap=50)

    assert len(chunks) > 1
    assert any(c.article == "제5-11조" for c in chunks)


def test_hierarchical_chunker_preserves_parent_and_splits_children():
    sources = [
        _source(
            "제1조(목적) 이 법의 목적입니다.\n"
            "① 첫 번째 항입니다. " + ("가나다라 " * 40) + "\n"
            "② 두 번째 항입니다. " + ("마바사아 " * 40)
        )
    ]

    chunks = chunk_pages(
        sources,
        source_name="외국환거래법",
        max_chars=180,
        min_chars=60,
        overlap=20,
    )

    assert len(chunks) > 1
    assert {chunk.parent_id for chunk in chunks} == {chunks[0].parent_id}
    assert all(chunk.article == "제1조" for chunk in chunks)
    assert all(chunk.parent_content == chunks[0].parent_content for chunk in chunks)
    assert all(len(chunk.content) <= 180 for chunk in chunks)


def test_api_rag_indexes_three_documents_and_returns_api_source(monkeypatch, tmp_path):
    fake_settings = _fake_settings(tmp_path)
    monkeypatch.setattr(retriever_module, "get_settings", lambda: fake_settings)
    monkeypatch.setattr(embedding_client_module, "get_settings", lambda: fake_settings)
    monkeypatch.setattr(retriever_module, "get_session", make_isolated_get_session(tmp_path))

    fake_docs = [
        LawApiDocument(
            law_name="외국환거래법",
            target="law",
            text="제1조(목적) 외국환거래의 원활화를 목적으로 한다.",
            source_url="https://www.law.go.kr",
            identifier="001",
        ),
        LawApiDocument(
            law_name="외국환거래법 시행령",
            target="law",
            text="제1조(목적) 외국환거래법에서 위임된 사항을 정한다.",
            source_url="https://www.law.go.kr",
            identifier="002",
        ),
        LawApiDocument(
            law_name="외국환거래규정",
            target="admrul",
            text="제4-2조(지급등의 절차) 지급 사유와 금액을 확인한다.",
            source_url="https://www.law.go.kr",
            identifier="003",
        ),
    ]
    monkeypatch.setattr(retriever_module, "load_target_regulations", lambda: fake_docs)

    retriever = RagRetriever()
    count = retriever.build_index()
    matches = retriever.search("지급 사유 금액 확인", top_k=3)

    assert count >= 3
    assert matches
    assert all(m.file_name == "국가법령정보 공동활용 API" for m in matches)
    assert all(m.page_number is None for m in matches)
    assert all(m.is_sample is False for m in matches)


def test_search_returns_matched_child_content_not_parent(monkeypatch, tmp_path):
    fake_settings = _fake_settings(tmp_path)
    monkeypatch.setattr(retriever_module, "get_settings", lambda: fake_settings)
    monkeypatch.setattr(embedding_client_module, "get_settings", lambda: fake_settings)
    monkeypatch.setattr(retriever_module, "get_session", make_isolated_get_session(tmp_path))

    long_article = (
        "제5-11조(사용료)\n"
        "① 첫 번째 항입니다. " + ("가나다라 " * 180) + "\n"
        "② 두 번째 항의 고유검색어 CHILD_TARGET 입니다. " + ("마바사아 " * 180)
    )
    fake_docs = [
        LawApiDocument(
            law_name="외국환거래규정",
            target="admrul",
            text=long_article,
            source_url="https://www.law.go.kr",
            identifier="003",
        )
    ]
    monkeypatch.setattr(retriever_module, "load_target_regulations", lambda: fake_docs)

    retriever = RagRetriever()
    matches = retriever.search("CHILD_TARGET")

    assert matches
    top = matches[0]
    parent_text = next(iter(retriever._parents.values()))["content"]
    assert top.content != parent_text
    # Child에는 검색 문맥을 위해 조문 헤더가 반복되므로 본문 부분이 Parent에
    # 포함되는지 확인한다.
    child_body = top.content.split("\n", 1)[-1]
    assert child_body in parent_text
    assert "CHILD_TARGET" in top.content


def test_empty_api_result_produces_empty_search(monkeypatch, tmp_path):
    fake_settings = _fake_settings(tmp_path)
    monkeypatch.setattr(retriever_module, "get_settings", lambda: fake_settings)
    monkeypatch.setattr(embedding_client_module, "get_settings", lambda: fake_settings)
    monkeypatch.setattr(retriever_module, "get_session", make_isolated_get_session(tmp_path))
    monkeypatch.setattr(retriever_module, "load_target_regulations", lambda: [])

    retriever = RagRetriever()
    assert retriever.search("아무 질의") == []
