"""국가법령정보 공동활용 API 기반 RAG 검색 Pipeline.

외국환거래법 / 외국환거래법 시행령 / 외국환거래규정의 최신 현행 항목을
API JSON으로 읽어 Parent-Child 청킹 → Embedding → ChromaDB 색인을 수행한다.
검색과 LLM 전달에는 실제로 검색된 Child 원문을 사용한다.
"""

from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace

import chromadb

from config.settings import get_settings
from database.connection import get_session
from database.models import RagChunk, RagDocument
from rag.chunker import chunk_pages
from rag.embedder import ChunkEmbedder
from rag.law_api import load_target_regulations
from schemas.analysis import RegulationMatch
from utils.logging import get_logger

logger = get_logger(__name__)

_SOURCE_LABEL = "국가법령정보 공동활용 API"


class RagRetriever:
    def __init__(self) -> None:
        settings = get_settings()
        self._settings = settings
        self._embedder = ChunkEmbedder()
        chroma_client = chromadb.PersistentClient(path=settings.chroma_persist_dir)
        self._collection = chroma_client.get_or_create_collection(
            name=f"rag_chunks_law_api_hierarchical_v1_{self._embedder.backend_name}",
            metadata={"hnsw:space": "cosine"},
        )
        self._parent_store_path = Path(settings.chroma_persist_dir) / (
            f"rag_parents_law_api_hierarchical_v1_{self._embedder.backend_name}.json"
        )
        self._parents = self._load_parent_store()

    @property
    def embedding_backend(self) -> str:
        return self._embedder.backend_name

    def _load_parent_store(self) -> dict[str, dict]:
        if not self._parent_store_path.is_file():
            return {}
        try:
            with self._parent_store_path.open("r", encoding="utf-8") as f:
                data = json.load(f)
            return data if isinstance(data, dict) else {}
        except Exception:
            logger.exception("RAG Parent 저장소 읽기 실패: %s", self._parent_store_path)
            return {}

    def _save_parent_store(self) -> None:
        self._parent_store_path.parent.mkdir(parents=True, exist_ok=True)
        temp_path = self._parent_store_path.with_suffix(self._parent_store_path.suffix + ".tmp")
        with temp_path.open("w", encoding="utf-8") as f:
            json.dump(self._parents, f, ensure_ascii=False, indent=2)
        temp_path.replace(self._parent_store_path)

    def _register_parent(
        self,
        *,
        parent_id: str | None,
        content: str,
        law_name: str,
        article: str | None,
        source_url: str,
    ) -> str:
        resolved_id = parent_id or f"{law_name}:{article or 'generic'}:{len(self._parents)}"
        self._parents[resolved_id] = {
            "content": content,
            "law_name": law_name,
            "article": article or "",
            "source": _SOURCE_LABEL,
            "source_url": source_url,
        }
        return resolved_id

    def build_index(self, force: bool = False) -> int:
        if self._collection.count() > 0:
            if not force and self._parents:
                logger.info("RAG API 인덱스가 이미 존재합니다 (force=True로 재생성 가능)")
                return self._collection.count()
            existing_ids = self._collection.get()["ids"]
            if existing_ids:
                self._collection.delete(ids=existing_ids)

        self._parents = {}
        with get_session() as session:
            session.execute(RagChunk.__table__.delete())
            session.execute(RagDocument.__table__.delete())

        chunk_rows = self._build_source_chunks()
        if not chunk_rows:
            logger.warning("국가법령정보 API에서 색인할 RAG 문서를 얻지 못했습니다.")
            return 0

        texts = [row["content"] for row in chunk_rows]
        embeddings = self._embedder.embed(texts)
        self._collection.add(
            ids=[str(row["chunk_id"]) for row in chunk_rows],
            embeddings=embeddings,
            documents=texts,
            metadatas=[
                {
                    "law_name": row["law_name"],
                    "article": row["article"] or "",
                    "source": row["source"],
                    "source_url": row["source_url"],
                    "api_target": row["api_target"],
                    "api_identifier": row["api_identifier"],
                    "parent_id": row.get("parent_id") or "",
                    "child_index": row.get("child_index", 0),
                    "child_count": row.get("child_count", 1),
                }
                for row in chunk_rows
            ],
        )
        self._save_parent_store()
        logger.info(
            "RAG API 청크 %d건 / Parent %d건 인덱싱 완료 (embedding backend=%s)",
            len(chunk_rows),
            len(self._parents),
            self._embedder.backend_name,
        )
        return len(chunk_rows)

    def _build_source_chunks(self) -> list[dict]:
        """3개 대상 법령을 API JSON으로 받아 SQL + Chroma용 Child로 변환한다."""

        documents = load_target_regulations()
        return self._store_api_chunks(documents)

    def _store_api_chunks(self, documents) -> list[dict]:
        rows: list[dict] = []
        with get_session() as session:
            for api_doc in documents:
                doc = RagDocument(
                    file_name=api_doc.law_name,
                    title=api_doc.law_name,
                    source_path=api_doc.source_url,
                    is_sample=False,
                )
                session.add(doc)
                session.flush()

                # chunk_pages는 이름과 달리 page_number/text 속성이 있는 일반 소스도
                # 처리한다. API 문서는 페이지가 없으므로 page_number=None으로 넘긴다.
                source = SimpleNamespace(page_number=None, text=api_doc.text)
                chunks = chunk_pages([source], source_name=api_doc.law_name)

                for i, chunk in enumerate(chunks):
                    row = RagChunk(
                        document_id=doc.id,
                        chunk_index=i,
                        page_number=None,
                        article=chunk.article,
                        content=chunk.content,
                    )
                    session.add(row)
                    session.flush()

                    parent_id = self._register_parent(
                        parent_id=chunk.parent_id,
                        content=chunk.parent_content or chunk.content,
                        law_name=api_doc.law_name,
                        article=row.article,
                        source_url=api_doc.source_url,
                    )
                    rows.append(
                        {
                            "chunk_id": row.id,
                            "content": row.content,
                            "law_name": api_doc.law_name,
                            "article": row.article,
                            "source": _SOURCE_LABEL,
                            "source_url": api_doc.source_url,
                            "api_target": api_doc.target,
                            "api_identifier": api_doc.identifier,
                            "parent_id": parent_id,
                            "child_index": chunk.child_index,
                            "child_count": chunk.child_count,
                        }
                    )
        return rows

    def search(
        self,
        query_text: str,
        top_k: int = 5,
        regulation_tags: list[str] | None = None,
    ) -> list[RegulationMatch]:
        """Child 임베딩으로 검색하고 같은 Parent에서는 가장 가까운 Child만 반환한다.

        ``regulation_tags`` 인자는 기존 호출부 호환을 위해 유지한다. API 법령 원문에는
        프로젝트 내부 사유코드 태그가 없으므로 현재는 임베딩 검색에만 사용하지 않는다.
        """

        if self._collection.count() == 0:
            self.build_index()
        if self._collection.count() == 0:
            return []

        query_embedding = self._embedder.embed([query_text])[0]
        result = self._collection.query(
            query_embeddings=[query_embedding], n_results=self._collection.count()
        )

        matches: list[RegulationMatch] = []
        seen_parents: set[str] = set()
        for distance, metadata, document in zip(
            result["distances"][0], result["metadatas"][0], result["documents"][0]
        ):
            parent_key = metadata.get("parent_id") or (
                f"{metadata.get('law_name', '')}:{metadata.get('article', '')}"
            )
            if parent_key in seen_parents:
                continue
            seen_parents.add(parent_key)

            score = max(0.0, min(1.0, 1.0 - distance))
            matches.append(
                RegulationMatch(
                    law_name=metadata.get("law_name") or "",
                    article=metadata.get("article") or None,
                    # 중요: Parent 전체가 아니라 실제 검색된 Child를 LLM/화면에 반환.
                    content=document,
                    file_name=metadata.get("source") or _SOURCE_LABEL,
                    page_number=None,
                    is_sample=False,
                    score=round(score, 4),
                    source_url=metadata.get("source_url") or None,
                )
            )
            if len(matches) >= top_k:
                break

        return matches
