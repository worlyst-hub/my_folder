"""사유코드 스키마 (섹션 12~14)."""

from __future__ import annotations

from pydantic import BaseModel, Field


class ReasonCode(BaseModel):
    code: str
    name: str
    category: str
    description: str
    keywords: list[str] = Field(default_factory=list)
    required_documents: list[str] = Field(default_factory=list)
    regulation_tags: list[str] = Field(default_factory=list)
    is_active: bool = True


class ReasonCodeCandidate(BaseModel):
    """Vector Search로 찾은 사유코드 후보 1건.

    ``score`` 는 임베딩 코사인 유사도(참고용 표시)이며, 임의의 숫자
    가중치를 조합한 점수식이 아니다. 최종 채택 여부는 은행원이 결정한다.
    """

    reason_code: ReasonCode
    score: float = Field(description="Embedding 코사인 유사도 (0~1, 참고용)")
    matched_keywords: list[str] = Field(default_factory=list)
