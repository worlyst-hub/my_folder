"""SWIFT BIC 조회 스키마 (섹션 19~23)."""

from __future__ import annotations

from pydantic import BaseModel


class SwiftLookupResult(BaseModel):
    swift_code: str
    bank_name: str
    country_code: str
    is_sanctioned: bool
    sanction_reason: str | None = None
    estimated_days: str | None = None
    handling_note: str | None = None


class SwiftLookupNotFound(BaseModel):
    """DB에 존재하지 않는 SWIFT Code 조회 결과 (섹션 33 오류 처리)."""

    swift_code: str
    found: bool = False
    message: str = "등록되지 않은 SWIFT Code이거나 DB에 해당 데이터가 존재하지 않습니다."
