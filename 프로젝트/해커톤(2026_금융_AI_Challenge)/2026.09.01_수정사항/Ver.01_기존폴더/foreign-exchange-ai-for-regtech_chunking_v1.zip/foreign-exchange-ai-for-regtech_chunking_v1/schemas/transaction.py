"""거래 신청 정보 스키마 (섹션 4, 6). OCR 결과가 매핑되는 대상."""

from __future__ import annotations

from decimal import Decimal

from pydantic import BaseModel, Field

from database.models import RecipientType


class RecipientInfo(BaseModel):
    recipient_type: RecipientType | None = None
    recipient_name: str | None = None
    recipient_country: str | None = Field(default=None, description="ISO 2자리 국가코드")
    beneficiary_bank_name: str | None = None
    swift_bic: str | None = None


class TransactionRequest(BaseModel):
    raw_transaction_purpose: str | None = Field(
        default=None, description="OCR로 추출한 송금 목적/적요 원문. 은행원이 확인/수정."
    )
    remittance_currency: str | None = None
    remittance_amount: Decimal | None = None
    recipient_info: RecipientInfo = Field(default_factory=RecipientInfo)
