"""은행 내부/외부 시스템 조회 데이터 스키마 (섹션 5).

고객이 신청서에 작성하는 값이 아니라 Mock System Lookup Service 가
채워주는 값이다.
"""

from __future__ import annotations

from decimal import Decimal

from pydantic import BaseModel, Field


class SystemLookupData(BaseModel):
    annual_accumulated_usd: Decimal = Field(
        default=Decimal("0"),
        description="금융결제원 연동을 가정한 당해연도 전 금융기관 누적 증빙미제출 송금액",
    )
    designated_bank_status: str = Field(
        default="NONE",
        description=(
            "거래외국환은행 지정 상태 (은행 Core DB) - 'SELF'(당행 지정) / "
            "'OTHER'(타행 지정) / 'NONE'(미지정)"
        ),
    )
    designated_purpose: str | None = Field(
        default=None, description="기존 지정 거래 목적 사유코드 (없으면 None)"
    )
    is_delinquent_borrower: bool = Field(
        default=False,
        description="신용정보원 연동을 가정한 신용불량/채무 체납 여부 (자본거래 제외)",
    )

    # 아래 세 필드는 당행 등록 고객 마스터(RegisteredCustomerMaster, Mock
    # 100건)를 신청서의 식별번호로 조회한 결과다 - 등록된 고객이면 실제
    # 마스터 값을, 아니면(당행 미등록/신규 고객) None/False로 채운다.
    is_registered_customer: bool = Field(
        default=False, description="당행 등록 고객 마스터에서 식별번호가 조회되었는지 여부"
    )
    credit_rating: int | None = Field(
        default=None, description="신용등급 1(최우량)~10(최저) - 등록 고객만 존재"
    )
    annual_remittance_limit_usd: Decimal | None = Field(
        default=None, description="연간 송금 한도(USD) - 등록 고객만 존재"
    )
