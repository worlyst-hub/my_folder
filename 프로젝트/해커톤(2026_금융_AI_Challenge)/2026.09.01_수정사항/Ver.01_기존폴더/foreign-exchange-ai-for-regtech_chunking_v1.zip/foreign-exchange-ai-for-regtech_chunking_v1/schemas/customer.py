"""고객 기본정보 스키마 (섹션 4.1)."""

from __future__ import annotations

from datetime import date
from decimal import Decimal

from pydantic import BaseModel, ConfigDict, Field

from database.models import CustomerType, ResidenceStatus


class CustomerProfile(BaseModel):
    """고객 자체의 기본정보. OCR 및 은행원 수정을 거쳐 확정된다."""

    model_config = ConfigDict(use_enum_values=False)

    customer_type: CustomerType = Field(default=CustomerType.INDIVIDUAL)
    residence_status: ResidenceStatus = Field(default=ResidenceStatus.RESIDENT)
    name_ko: str | None = None
    name_eng: str | None = None
    identification_no: str | None = None
    account_number: str | None = None


class RegisteredCustomer(BaseModel):
    """당행에 이미 등록되어 있는 고객 마스터 정보.

    신청서 OCR로 매번 새로 생기는 ``CustomerProfile``과는 완전히 별개다 -
    이건 은행이 사전에 보유한 고정된 기존 고객 데이터(Mock)로, ②단계에서
    거래정보를 확정할 때 신청서의 식별번호와 대조해 신용도/송금한도를
    참고하는 데 쓰인다(``services/system_lookup``). 신청서를 낸 사람이
    항상 이 목록에 있는 건 아니다 - 당행 미등록/신규 고객일 수도 있고,
    그 경우 신용도 조회 자체가 안 되는 게 현실적이다.
    """

    model_config = ConfigDict(use_enum_values=False)

    identification_no: str
    name_ko: str
    name_eng: str | None = None
    customer_type: CustomerType = Field(default=CustomerType.INDIVIDUAL)
    residence_status: ResidenceStatus = Field(default=ResidenceStatus.RESIDENT)
    credit_rating: int = Field(description="신용등급 1(최우량)~10(최저)")
    annual_remittance_limit_usd: Decimal = Field(description="연간 송금 한도(USD)")
    annual_accumulated_usd: Decimal = Field(
        default=Decimal("0"), description="당해연도 누적 송금액(USD) - 한도 대비 사용량"
    )
    designated_bank_status: str = Field(
        default="NONE", description="거래외국환은행 지정 상태 - 'SELF'/'OTHER'/'NONE'"
    )
    designated_purpose: str | None = Field(default=None, description="기존 지정 거래목적 사유코드")
    is_delinquent_borrower: bool = Field(default=False, description="신용불량/채무 체납 여부")
    registered_since: date = Field(description="당행 고객 등록일")
