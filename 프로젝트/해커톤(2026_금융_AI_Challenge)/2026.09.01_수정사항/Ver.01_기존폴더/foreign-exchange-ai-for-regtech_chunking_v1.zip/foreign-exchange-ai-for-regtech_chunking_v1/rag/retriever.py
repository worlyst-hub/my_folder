"""RAG 검색 Pipeline 오케스트레이션 (섹션 15~17).

국가법령정보센터 PDF(``RAG_MODE=pdf``) 또는 샘플 규정 데이터
(``RAG_MODE=mock``)를 읽어 Chunking → Embedding → Vector DB 색인을 수행하고,
질의에 대해 관련 법령/조문을 검색한다.

RAG 결과는 은행원의 업무 참고 정보이며 법률적 최종 판단으로 표현하지 않는다.
"""

from __future__ import annotations

import json
from pathlib import Path

import chromadb
from sqlalchemy import select

from config.settings import get_settings
from database.connection import get_session
from database.models import RagChunk, RagDocument
from schemas.analysis import RegulationMatch
from rag.chunker import chunk_pages
from rag.document_loader import load_all_regulation_pdfs
from rag.embedder import ChunkEmbedder
from rag.sample_regulations import SAMPLE_FILE_NAME, SAMPLE_REGULATIONS
from utils.logging import get_logger

logger = get_logger(__name__)


class RagRetriever:
    def __init__(self) -> None:
        settings = get_settings()
        self._settings = settings
        self._embedder = ChunkEmbedder()
        chroma_client = chromadb.PersistentClient(path=settings.chroma_persist_dir)
        self._collection = chroma_client.get_or_create_collection(
            # 기존 고정-window 인덱스와 섞이지 않도록 실험 버전을 별도 collection으로 둔다.
            name=f"rag_chunks_hierarchical_v1_{self._embedder.backend_name}",
            metadata={"hnsw:space": "cosine"},
        )

        # rag_v2_ordered와 같은 원칙으로 긴 Parent 조문을 모든 Child metadata에
        # 반복 저장하지 않는다. Child에는 parent_id만 두고 Parent는 JSON에 1회 저장한다.
        self._parent_store_path = Path(settings.chroma_persist_dir) / (
            f"rag_parents_hierarchical_v1_{self._embedder.backend_name}.json"
        )
        self._parents = self._load_parent_store()

    @property
    def embedding_backend(self) -> str:
        """실제 사용 중인 임베딩 백엔드("ollama"/"hash"). services/reason_code/mapper.py의
        동일 프로퍼티 참고 - Ollama 연결 실패 시 조용히 해시 임베딩으로 폴백하는 것을
        화면에 노출하기 위함이다."""

        return self._embedder.backend_name

    def _load_parent_store(self) -> dict[str, dict]:
        if not self._parent_store_path.is_file():
            return {}
        try:
            with self._parent_store_path.open("r", encoding="utf-8") as f:
                data = json.load(f)
            return data if isinstance(data, dict) else {}
        except Exception:
            logger.exception("RAG Parent 저장소 읽기 실패: %s", self._parent_store_path)
            return {}

    def _save_parent_store(self) -> None:
        self._parent_store_path.parent.mkdir(parents=True, exist_ok=True)
        temp_path = self._parent_store_path.with_suffix(self._parent_store_path.suffix + ".tmp")
        with temp_path.open("w", encoding="utf-8") as f:
            json.dump(self._parents, f, ensure_ascii=False, indent=2)
        temp_path.replace(self._parent_store_path)

    def _register_parent(
        self,
        *,
        parent_id: str | None,
        content: str,
        law_name: str,
        article: str | None,
        file_name: str,
        page_number: int | None,
    ) -> str:
        resolved_id = parent_id or f"{file_name}:{article or 'generic'}:{len(self._parents)}"
        self._parents[resolved_id] = {
            "content": content,
            "law_name": law_name,
            "article": article or "",
            "file_name": file_name,
            "page_number": page_number or 0,
        }
        return resolved_id

    # ------------------------------------------------------------------
    # 색인
    # ------------------------------------------------------------------

    def build_index(self, force: bool = False) -> int:
        if self._collection.count() > 0:
            if not force and self._parents:
                logger.info("RAG 인덱스가 이미 존재합니다 (force=True로 재생성 가능)")
                return self._collection.count()
            if not force and not self._parents:
                logger.warning("Child 인덱스는 있으나 Parent 저장소가 없어 자동 재생성합니다.")
            existing_ids = self._collection.get()["ids"]
            if existing_ids:
                self._collection.delete(ids=existing_ids)

        # 재색인 시 Parent도 새 원문 기준으로 다시 구성한다.
        self._parents = {}

        # SQL의 rag_documents/rag_chunks는 "가장 최근에 색인한 한 벌"만 원문 출처로
        # 보존한다. 임베딩 백엔드(Mock 해시 ↔ Ollama)를 변경해 컬렉션 이름이
        # 바뀌면 이전 컬렉션의 벡터는 그대로 남지만 SQL 원문은 새로 색인한
        # 데이터로 교체된다 - 프로토타입 범위에서는 이 제약을 감수한다.
        with get_session() as session:
            session.execute(RagChunk.__table__.delete())
            session.execute(RagDocument.__table__.delete())

        chunk_rows = self._build_source_chunks()
        if not chunk_rows:
            logger.warning("색인할 RAG 문서가 없습니다.")
            return 0

        texts = [row["content"] for row in chunk_rows]
        embeddings = self._embedder.embed(texts)

        self._collection.add(
            ids=[str(row["chunk_id"]) for row in chunk_rows],
            embeddings=embeddings,
            documents=texts,
            metadatas=[
                {
                    "law_name": row["law_name"],
                    "article": row["article"] or "",
                    "file_name": row["file_name"],
                    "page_number": row["page_number"] or 0,
                    "is_sample": row["is_sample"],
                    "regulation_tags": "|".join(row.get("regulation_tags") or []),
                    # Child 벡터가 검색되면 조문 전체 Parent를 복원하기 위한 연결 정보.
                    "parent_id": row.get("parent_id") or "",
                    "child_index": row.get("child_index", 0),
                    "child_count": row.get("child_count", 1),
                }
                for row in chunk_rows
            ],
        )
        self._save_parent_store()
        logger.info(
            "RAG 청크 %d건 / Parent %d건 인덱싱 완료 (embedding backend=%s)",
            len(chunk_rows),
            len(self._parents),
            self._embedder.backend_name,
        )
        return len(chunk_rows)

    def _build_source_chunks(self) -> list[dict]:
        """PDF(있으면) 또는 샘플 규정 데이터를 SQL(RagDocument/RagChunk)에 저장하고,
        Chroma 색인에 필요한 정보를 함께 반환한다."""

        if self._settings.rag_mode == "pdf":
            pages = load_all_regulation_pdfs(self._settings.regulation_pdf_dir)
            if pages:
                return self._store_pdf_chunks(pages)
            logger.warning(
                "RAG_MODE=pdf 이지만 data/regulations/ 에 PDF가 없어 샘플 규정으로 대체합니다."
            )

        return self._store_sample_chunks()

    def _store_pdf_chunks(self, pages) -> list[dict]:
        """PDF를 파일 단위로 묶어 조(Parent) → Child 계층 청킹한다.

        기존에는 각 PDF 페이지를 독립적으로 600자 슬라이딩 윈도우로 잘랐기
        때문에 하나의 조문이 페이지를 넘기면 문맥이 끊겼다. 이제 같은 파일의
        페이지들을 순서대로 ``chunk_pages``에 넘겨 조문 전체 Parent를 먼저 만들고,
        항·호·목/재귀 분할로 만든 Child만 임베딩 대상으로 저장한다.
        """

        rows: list[dict] = []
        pages_by_file: dict[str, list] = {}
        for page in pages:
            pages_by_file.setdefault(page.file_name, []).append(page)

        with get_session() as session:
            for file_name, file_pages in pages_by_file.items():
                file_pages = sorted(file_pages, key=lambda page: page.page_number)

                doc = RagDocument(
                    file_name=file_name,
                    title=file_name,
                    is_sample=False,
                )
                session.add(doc)
                session.flush()

                chunks = chunk_pages(
                    file_pages,
                    source_name=file_name,
                )

                for i, chunk in enumerate(chunks):
                    row = RagChunk(
                        document_id=doc.id,
                        chunk_index=i,
                        page_number=chunk.page_number,
                        article=chunk.article,
                        # SQL에는 실제 검색 단위인 Child를 보존한다.
                        content=chunk.content,
                    )
                    session.add(row)
                    session.flush()

                    parent_id = self._register_parent(
                        parent_id=chunk.parent_id,
                        content=chunk.parent_content or chunk.content,
                        law_name=doc.title or doc.file_name,
                        article=row.article,
                        file_name=doc.file_name,
                        page_number=row.page_number,
                    )
                    rows.append(
                        {
                            "chunk_id": row.id,
                            "content": row.content,
                            "law_name": doc.title or doc.file_name,
                            "article": row.article,
                            "file_name": doc.file_name,
                            "page_number": row.page_number,
                            "is_sample": False,
                            "regulation_tags": [],
                            "parent_id": parent_id,
                            "child_index": chunk.child_index,
                            "child_count": chunk.child_count,
                        }
                    )
        return rows

    def _store_sample_chunks(self) -> list[dict]:
        rows: list[dict] = []
        with get_session() as session:
            doc = RagDocument(file_name=SAMPLE_FILE_NAME, title="외국환거래규정 (샘플)", is_sample=True)
            session.add(doc)
            session.flush()

            for i, sample in enumerate(SAMPLE_REGULATIONS):
                row = RagChunk(
                    document_id=doc.id,
                    chunk_index=i,
                    page_number=None,
                    article=sample.article,
                    content=sample.content,
                )
                session.add(row)
                session.flush()
                parent_id = self._register_parent(
                    parent_id=f"sample:{sample.law_name}:{sample.article}",
                    content=row.content,
                    law_name=sample.law_name,
                    article=row.article,
                    file_name=doc.file_name,
                    page_number=None,
                )
                rows.append(
                    {
                        "chunk_id": row.id,
                        "content": row.content,
                        "law_name": sample.law_name,
                        "article": row.article,
                        "file_name": doc.file_name,
                        "page_number": None,
                        "is_sample": True,
                        "regulation_tags": sample.regulation_tags,
                        "parent_id": parent_id,
                        "child_index": 0,
                        "child_count": 1,
                    }
                )
        return rows

    # ------------------------------------------------------------------
    # 검색
    # ------------------------------------------------------------------

    def search(
        self,
        query_text: str,
        top_k: int = 5,
        regulation_tags: list[str] | None = None,
    ) -> list[RegulationMatch]:
        """관련 법령/조문을 검색한다.

        ``regulation_tags`` 를 전달하면(예: 확정된 사유코드의 regulation_tags)
        해당 태그와 겹치는 문서만으로 범위를 좁힌 뒤 그 안에서 임베딩
        유사도로 정렬한다 - 임의의 가중치를 섞는 것이 아니라 명확한 필터
        조건이다. 겹치는 문서가 하나도 없으면 필터 없이 전체 결과를 반환한다.
        """

        if self._collection.count() == 0:
            self.build_index()
        if self._collection.count() == 0:
            return []

        query_embedding = self._embedder.embed([query_text])[0]
        # 태그 필터를 적용할 수 있도록 전체 후보를 유사도 순으로 가져온다
        # (색인 규모가 프로토타입 수준으로 작아 비용이 크지 않다).
        result = self._collection.query(
            query_embeddings=[query_embedding], n_results=self._collection.count()
        )

        all_matches: list[RegulationMatch] = []
        match_tags: list[set[str]] = []
        seen_parents: set[str] = set()
        for distance, metadata, document in zip(
            result["distances"][0], result["metadatas"][0], result["documents"][0]
        ):
            # 같은 조문 Parent의 여러 Child가 상위권에 동시에 잡혀도 같은 조문을
            # 중복 표시하지 않는다. Chroma 결과가 유사도 순이므로 첫 Child가 해당
            # Parent의 대표 점수가 된다.
            parent_key = (
                metadata.get("parent_id")
                or f"{metadata.get('file_name', '')}:{metadata.get('article', '')}"
            )
            if parent_key in seen_parents:
                continue
            seen_parents.add(parent_key)

            score = max(0.0, min(1.0, 1.0 - distance))
            all_matches.append(
                RegulationMatch(
                    law_name=metadata.get("law_name") or "",
                    article=metadata.get("article") or None,
                    # 유사도 계산은 검색된 Child 기준으로 하되, 화면/LLM에는
                    # 연결된 조문 전체 Parent를 반환한다.
                    content=(
                        self._parents.get(metadata.get("parent_id") or "", {}).get("content")
                        or document
                    ),
                    file_name=metadata.get("file_name") or "",
                    page_number=(metadata.get("page_number") or None),
                    is_sample=bool(metadata.get("is_sample")),
                    score=round(score, 4),
                )
            )
            match_tags.append(set((metadata.get("regulation_tags") or "").split("|")))

        if regulation_tags:
            tag_set = set(regulation_tags)
            filtered = [
                (m, len(tag_set & tags)) for m, tags in zip(all_matches, match_tags) if tag_set & tags
            ]
            if filtered:
                # 겹치는 태그 개수를 1순위로, 임베딩 유사도를 2순위(동점자 처리)로 정렬한다.
                # 임의의 숫자 가중치를 섞는 점수식이 아니라 명확한 정렬 기준이다.
                filtered.sort(key=lambda pair: (pair[1], pair[0].score), reverse=True)
                return [m for m, _ in filtered[:top_k]]

        return all_matches[:top_k]
