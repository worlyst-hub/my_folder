"""당행 등록 고객 마스터 Mock 데이터(100건) 생성 스크립트.

한 번 실행하여 ``data/registered_customers.csv`` 를 생성하는 용도이며, 앱
실행 시에는 호출되지 않는다(seed는 ``database/seed.py`` 가 이 CSV를 읽어서
수행 - ``data/generate_reason_codes.py`` 와 동일한 패턴).

여기서 만드는 고객은 신청서 OCR로 매번 새로 생기는 ``customer_profile``과
완전히 별개다 - 은행이 사전에 보유한 고정된 기존 고객 목록(신용도/송금한도
판단용)을 흉내낸 것이다. ``random.seed()``로 고정해 다시 실행해도 항상
같은 100건이 나오게 한다(재현 가능성).

99건은 임의 생성이고, 나머지 1건은 실제 데모/테스트에 쓴 식별번호를
고정으로 박아둔다(``_FIXED_DEMO_CUSTOMERS``) - 랜덤 100명 중 하나가 우연히
그 식별번호와 일치할 확률은 사실상 0이라, 등록 고객 조회 경로를 직접
시연하려면 이렇게 고정해두는 게 유일한 방법이다.

연간 송금한도는 전원 $100,000으로 통일한다. 기존지정목적은 "대분류(1자리)
+ 중분류(1자리) + 소분류(1자리)"로 구성된 3자리 코드 체계(``_MAJOR_
CATEGORIES``/``_MIDDLE_CATEGORIES``, 4개 대분류 x 5개 중분류 x 5개
소분류 = 정확히 100가지)를 임의로 만든다.

거래외국환은행 지정 상태(``designated_bank_status``)는 실제 "거래외국환은행
지정제도"를 반영해 3단계로 나눈다 - 당행 지정(SELF, 70%) / 타행 지정(OTHER,
20%) / 미지정(NONE, 10%). 기존지정목적 코드는 **SELF인 경우에만** 배정하고,
OTHER·NONE에는 비워둔다 - 이 마스터는 "당행이 보유한" 고객 정보를 흉내낸
것이라, 고객이 타행을 지정거래은행으로 등록했다면 그 지정목적은 타행에
등록된 정보이지 당행이 알 수 있는 정보가 아니다(OTHER인데 지정목적이
채워져 있으면 당행이 타행 내부 정보를 알고 있는 것처럼 보여 앞뒤가 안
맞는다).
"""

from __future__ import annotations

import csv
import random
from datetime import date, timedelta
from pathlib import Path

OUT_PATH = Path(__file__).resolve().parent / "registered_customers.csv"

_SEED = 20260101

# 실제 데모/테스트에서 쓴 식별번호를 등록 고객 마스터에 고정으로 넣어둔다
# - ②단계에서 이 식별번호로 확정하면 "등록 고객" 조회 경로를 바로 볼 수
# 있다. 나머지 99건만 임의 생성이다.
_FIXED_DEMO_CUSTOMERS = [
    {
        "identification_no": "980317-1234567",
        "name_ko": "최기영",
        "name_eng": "KIYOUNG CHOI",
        "customer_type": "INDIVIDUAL",
        "residence_status": "RESIDENT",
        "credit_rating": 4,
        "annual_remittance_limit_usd": 100000,
        "annual_accumulated_usd": 50000,
        "designated_bank_status": "SELF",  # 당행 지정
        "is_bank_designated": "true",
        "designated_purpose": "211",  # 자본거래 > 해외직접투자 > 1호 (실제 테스트 시나리오인 "해외 법인 설립"과 매칭)
        "is_delinquent_borrower": "false",
        "registered_since": "2021-05-10",
    },
]

_SURNAMES = [
    ("김", "KIM"), ("이", "LEE"), ("박", "PARK"), ("최", "CHOI"), ("정", "JUNG"),
    ("강", "KANG"), ("조", "CHO"), ("윤", "YOON"), ("장", "JANG"), ("임", "LIM"),
    ("한", "HAN"), ("오", "OH"), ("서", "SEO"), ("신", "SHIN"), ("권", "KWON"),
]
_GIVEN_NAMES = [
    ("민준", "MINJUN"), ("서연", "SEOYEON"), ("도윤", "DOYOON"), ("하은", "HAEUN"),
    ("시우", "SIWOO"), ("지호", "JIHO"), ("수아", "SUA"), ("은우", "EUNWOO"),
    ("예준", "YEJUN"), ("다인", "DAIN"), ("지훈", "JIHOON"), ("서준", "SEOJUN"),
    ("유진", "YUJIN"), ("현우", "HYUNWOO"), ("소율", "SOYUL"), ("우진", "WOOJIN"),
    ("가은", "GAEUN"), ("동현", "DONGHYUN"), ("나윤", "NAYOON"), ("준서", "JUNSEO"),
]

_CORP_STEMS = [
    "대한", "한빛", "글로벌", "동아", "서울", "한강", "미래", "태평양", "신성", "우리",
    "동양", "삼일", "국제", "센트럴", "코리아", "그린", "블루오션", "이스트", "하나", "빛나",
]
_CORP_KINDS = ["무역", "상사", "물산", "전자", "식품", "바이오", "인터내셔널", "solutions", "테크", "실업"]

# 기존지정목적 3자리 코드 체계 - 실제 외국환거래 목적코드가 아니라 이
# 프로젝트에서 임의로 만든 것이다. 1번째 자리=대분류, 2번째 자리=중분류
# (대분류 안에서 1~5), 3번째 자리=소분류 일련번호(1~5) - 총 4*5*5=100가지
# 조합이 나와서 등록 고객 100명에게 정확히 하나씩, 겹치지 않게 배정할 수
# 있다.
_MAJOR_CATEGORIES = {
    "1": "경상거래",
    "2": "자본거래",
    "3": "서비스거래",
    "4": "이전거래",
}
_MIDDLE_CATEGORIES = {
    "11": "무역대금", "12": "운송료", "13": "보험료", "14": "여행경비", "15": "통신료",
    "21": "해외직접투자", "22": "해외부동산취득", "23": "증권투자", "24": "대출금", "25": "파생상품거래",
    "31": "용역대가", "32": "지적재산권사용료", "33": "컨설팅수수료", "34": "광고선전비", "35": "임차료",
    "41": "유학경비", "42": "생활비송금", "43": "증여성송금", "44": "기부금", "45": "상속재산",
}


def _all_designated_purpose_codes() -> list[str]:
    """대분류·중분류·소분류를 조합한 3자리 코드 100개를 전부 만든다."""

    return [
        f"{major}{middle}{minor}"
        for major in _MAJOR_CATEGORIES
        for middle in "12345"
        for minor in "12345"
    ]


def _random_individual_id(rng: random.Random) -> str:
    year = rng.randint(1955, 2005)
    month = rng.randint(1, 12)
    day = rng.randint(1, 28)
    century_digit = "1" if year < 2000 else "3"  # 성별+세기 자리(임의) - 여성은 각각 2/4로 절반 배정
    if rng.random() < 0.5:
        century_digit = str(int(century_digit) + 1)
    back = "".join(str(rng.randint(0, 9)) for _ in range(6))
    return f"{year % 100:02d}{month:02d}{day:02d}-{century_digit}{back}"


def _random_corporate_id(rng: random.Random) -> str:
    return f"{rng.randint(100, 999)}-{rng.randint(10, 99)}-{rng.randint(10000, 99999)}"


def _random_registered_since(rng: random.Random) -> date:
    days_ago = rng.randint(30, 15 * 365)
    return date.today() - timedelta(days=days_ago)


_ANNUAL_REMITTANCE_LIMIT_USD = 100_000


def _random_credit_rating(rng: random.Random) -> int:
    """신용등급(1=최우량~10=최저)만 만든다 - 연간 송금한도는 전원 동일하게
    고정이라(``_ANNUAL_REMITTANCE_LIMIT_USD``) 더 이상 한도 계산에 쓰이지
    않지만, 고객 속성 자체로는 여전히 의미가 있어 남겨둔다."""

    return rng.choices(range(1, 11), weights=[4, 6, 10, 14, 16, 16, 14, 10, 6, 4])[0]


def _random_bank_status(rng: random.Random) -> str:
    """거래외국환은행 지정 상태를 당행 70% / 타행 20% / 미지정 10%로 배정한다."""

    return rng.choices(["SELF", "OTHER", "NONE"], weights=[70, 20, 10])[0]


def build_rows(n_individual: int = 70, n_corporate: int = 30) -> list[dict]:
    rng = random.Random(_SEED)
    rows: list[dict] = list(_FIXED_DEMO_CUSTOMERS)
    used_ids: set[str] = {c["identification_no"] for c in _FIXED_DEMO_CUSTOMERS}
    used_names: set[str] = {c["name_ko"] for c in _FIXED_DEMO_CUSTOMERS}
    n_individual -= len(_FIXED_DEMO_CUSTOMERS)

    def _unique_id(factory) -> str:
        while True:
            candidate = factory(rng)
            if candidate not in used_ids:
                used_ids.add(candidate)
                return candidate

    def _unique_individual_name() -> tuple[str, str]:
        # 성×이름 조합 풀(15*20=300가지)에서 뽑다 보면 30~70명 규모에서도
        # 우연히 같은 이름이 겹칠 수 있어(생일 문제) 이름까지 중복 없이 뽑는다.
        while True:
            sur_ko, sur_en = rng.choice(_SURNAMES)
            given_ko, given_en = rng.choice(_GIVEN_NAMES)
            name_ko = f"{sur_ko}{given_ko}"
            if name_ko not in used_names:
                used_names.add(name_ko)
                return name_ko, f"{given_en} {sur_en}"

    def _unique_corporate_name() -> str:
        while True:
            name_ko = f"(주){rng.choice(_CORP_STEMS)}{rng.choice(_CORP_KINDS)}"
            if name_ko not in used_names:
                used_names.add(name_ko)
                return name_ko

    # 기존지정목적 100가지 코드 중 고정 데모 고객이 이미 쓴 걸 빼고 나머지를
    # 섞어서, 지정 상태가 SELF인 고객에게만 하나씩 순서대로 나눠준다(OTHER/
    # NONE인 고객은 당행이 알 수 있는 지정목적이 없으니 코드도 비워둔다) -
    # 코드가 99개 있고 실제 배정 대상(SELF, 약 70%)은 그보다 훨씬 적으므로
    # 모자랄 일은 없다.
    used_purpose_codes = {c["designated_purpose"] for c in _FIXED_DEMO_CUSTOMERS}
    remaining_purpose_codes = [c for c in _all_designated_purpose_codes() if c not in used_purpose_codes]
    rng.shuffle(remaining_purpose_codes)
    purpose_code_iter = iter(remaining_purpose_codes)

    def _purpose_code_for(bank_status: str) -> str:
        return next(purpose_code_iter) if bank_status == "SELF" else ""

    for _ in range(n_individual):
        name_ko, name_eng = _unique_individual_name()
        is_delinquent = rng.random() < 0.08
        accumulated_ratio = rng.uniform(0, 1.1) if not is_delinquent else rng.uniform(0.9, 1.3)
        bank_status = _random_bank_status(rng)
        rows.append(
            {
                "identification_no": _unique_id(_random_individual_id),
                "name_ko": name_ko,
                "name_eng": name_eng,
                "customer_type": "INDIVIDUAL",
                "residence_status": rng.choices(
                    ["RESIDENT", "NON_RESIDENT", "FOREIGN_RESIDENT"], weights=[80, 12, 8]
                )[0],
                "credit_rating": _random_credit_rating(rng),
                "annual_remittance_limit_usd": _ANNUAL_REMITTANCE_LIMIT_USD,
                "annual_accumulated_usd": round(_ANNUAL_REMITTANCE_LIMIT_USD * min(accumulated_ratio, 1.5)),
                "designated_bank_status": bank_status,
                "is_bank_designated": "true" if bank_status != "NONE" else "false",
                "designated_purpose": _purpose_code_for(bank_status),
                "is_delinquent_borrower": "true" if is_delinquent else "false",
                "registered_since": _random_registered_since(rng).isoformat(),
            }
        )

    for _ in range(n_corporate):
        name_ko = _unique_corporate_name()
        is_delinquent = rng.random() < 0.05
        accumulated_ratio = rng.uniform(0, 1.1) if not is_delinquent else rng.uniform(0.9, 1.3)
        bank_status = _random_bank_status(rng)
        rows.append(
            {
                "identification_no": _unique_id(_random_corporate_id),
                "name_ko": name_ko,
                "name_eng": "",
                "customer_type": "CORPORATE",
                "residence_status": "RESIDENT",
                "credit_rating": _random_credit_rating(rng),
                "annual_remittance_limit_usd": _ANNUAL_REMITTANCE_LIMIT_USD,
                "annual_accumulated_usd": round(_ANNUAL_REMITTANCE_LIMIT_USD * min(accumulated_ratio, 1.5)),
                "designated_bank_status": bank_status,
                "is_bank_designated": "true" if bank_status != "NONE" else "false",
                "designated_purpose": _purpose_code_for(bank_status),
                "is_delinquent_borrower": "true" if is_delinquent else "false",
                "registered_since": _random_registered_since(rng).isoformat(),
            }
        )

    rng.shuffle(rows)
    return rows


def main() -> None:
    rows = build_rows()
    fieldnames = [
        "identification_no", "name_ko", "name_eng", "customer_type", "residence_status",
        "credit_rating", "annual_remittance_limit_usd", "annual_accumulated_usd",
        "designated_bank_status", "is_bank_designated", "designated_purpose",
        "is_delinquent_borrower", "registered_since",
    ]
    with OUT_PATH.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print(f"wrote {len(rows)} registered customers to {OUT_PATH}")


if __name__ == "__main__":
    main()
