"""사유코드 Mock 데이터(약 100건) 생성 스크립트.

한 번 실행하여 ``data/reason_codes.csv`` 를 생성하는 용도이며, 앱 실행 시에는
호출되지 않는다 (seed는 database/seed.py 가 이 CSV를 읽어서 수행).

리스트 필드(keywords / required_documents / regulation_tags)는 CSV 셀 안에서
파이프(``|``)로 구분하여 저장한다.
"""

from __future__ import annotations

import csv
import re
from pathlib import Path

OUT_PATH = Path(__file__).resolve().parent / "reason_codes.csv"

# (subcategory_tag, category, required_documents, extra_keywords, names)
GROUPS: list[tuple[str, str, list[str], list[str], list[str]]] = [
    (
        "TRADE",
        "경상거래",
        ["계약서 또는 인보이스", "선하증권 등 운송서류", "수출입신고필증"],
        ["무역", "수입", "수출", "물품대금"],
        [
            "물품수입대금",
            "물품수출대금 회수",
            "중계무역대금",
            "위탁가공무역대금",
            "재수출입대금",
            "운임(해상)",
            "운임(항공)",
            "보험료(무역보험)",
            "통관/관세대행수수료",
            "무역클레임 배상금",
        ],
    ),
    (
        "SERVICE",
        "경상거래",
        ["용역계약서", "세금계산서 또는 인보이스"],
        ["용역", "서비스대가"],
        [
            "용역대가(컨설팅)",
            "용역대가(IT개발)",
            "광고선전비",
            "시장조사비",
            "교육훈련비(해외연수)",
            "전시회 참가비",
            "국제회의 참가비",
            "통번역료",
            "법률자문수수료",
            "회계/감사자문수수료",
        ],
    ),
    (
        "STUDY_ABROAD",
        "경상거래",
        ["재학증명서 또는 입학허가서", "등록금 고지서"],
        ["유학", "학비", "등록금", "체재비"],
        [
            "해외유학비(등록금)",
            "해외유학 생활비",
            "해외연수비",
            "해외출장 체재비",
            "어학연수비",
            "교환학생 체재비",
            "인턴십 체재비",
            "해외 의료연수비",
        ],
    ),
    (
        "TRAVEL",
        "경상거래",
        ["여행/출장 증빙서류"],
        ["여행", "출장", "카드대금"],
        [
            "해외여행경비",
            "해외카드대금 정산",
            "신용장개설수수료",
            "해외출장 항공/숙박비",
            "해외 의료비(치료비)",
        ],
    ),
    (
        "IP_ROYALTY",
        "경상거래",
        ["라이선스 또는 사용권 계약서"],
        ["로열티", "사용료", "지식재산권"],
        [
            "특허권 사용료(로열티)",
            "상표권 사용료",
            "저작권료",
            "프랜차이즈 가맹비",
            "소프트웨어 라이선스료",
        ],
    ),
    (
        "FINANCE_COST",
        "경상거래",
        ["금융계약서 또는 약정서"],
        ["금융비용", "수수료", "이자"],
        [
            "해외차입 이자지급",
            "보증수수료",
            "팩토링수수료",
            "신용장 확인수수료",
            "환가료",
        ],
    ),
    (
        "INVESTMENT_INCOME",
        "경상거래",
        ["배당/이자 지급 통지서"],
        ["배당금", "투자수익", "이자수취"],
        [
            "해외투자 배당금 수취",
            "해외예금 이자 수취",
            "해외채권 이자 수취",
            "해외펀드 배당금",
        ],
    ),
    (
        "REAL_ESTATE",
        "자본거래",
        ["부동산 매매계약서", "자금출처확인서", "등기부등본"],
        ["부동산", "주택", "아파트", "매매", "구매", "계약금"],
        [
            "해외부동산 취득(주택)",
            "해외부동산 취득(상업용)",
            "해외부동산 처분대금 회수",
            "해외부동산 임대보증금",
            "해외부동산 리모델링비용",
            "해외부동산 중개수수료",
        ],
    ),
    (
        "FDI",
        "자본거래",
        ["해외직접투자 신고수리서", "투자계획서", "법인등기부등본"],
        ["해외직접투자", "법인설립", "지분인수", "증자"],
        [
            "해외직접투자(법인설립)",
            "해외직접투자(지분인수)",
            "해외직접투자(증자)",
            "해외지사 운영자금",
            "해외지점 설치비",
            "해외현지법인 대여금",
            "해외직접투자 청산대금 회수",
            "해외 M&A 인수대금",
            "해외합작투자(JV) 출자금",
            "해외직접투자 사후관리비용",
        ],
    ),
    (
        "SECURITIES_INVESTMENT",
        "자본거래",
        ["투자설명서", "매매내역서"],
        ["증권투자", "펀드", "채권"],
        [
            "해외상장증권 투자",
            "해외비상장증권 투자",
            "해외채권 투자",
            "해외펀드 투자",
            "해외파생상품 증거금",
            "해외증권 매각대금 회수",
            "해외 ETF 투자",
            "해외 IPO 청약대금",
        ],
    ),
    (
        "LOAN",
        "자본거래",
        ["금전소비대차계약서", "대출약정서"],
        ["차입", "대여", "상환", "대출"],
        [
            "해외차입금 원금상환",
            "해외차입금 도입",
            "거주자의 비거주자에 대한 대여",
            "비거주자의 거주자에 대한 대여 상환",
            "계열사간 자금대여",
            "해외 담보대출 상환",
            "해외 신디케이트론 참여",
            "해외 채무보증 이행",
        ],
    ),
    (
        "IMMIGRATION_GIFT_INHERITANCE",
        "자본거래",
        ["가족관계증명서", "증여 또는 상속 관련 증빙서류"],
        ["이주비", "증여", "상속", "위자료"],
        [
            "해외이주비 송금",
            "재외동포 국내재산 반출",
            "증여성 송금(가족)",
            "상속재산 반출",
            "위자료 송금",
            "양육비/자녀 유학비 송금",
            "유산정리 관련 비용",
            "이민 정착지원금",
        ],
    ),
    (
        "PERSONAL",
        "기타",
        ["송금 목적 증빙서류(해당 시)"],
        ["개인송금", "생활비", "의료비", "기부금"],
        [
            "개인간 소액송금",
            "경조사비 송금",
            "생활비 지원(가족)",
            "의료비 지원(가족)",
            "기부금(해외 단체)",
            "종교단체 헌금/기부",
            "회비/멤버십비 납부",
            "벌금/과태료 납부",
            "소송비용/합의금",
            "보험료(개인 해외보험)",
        ],
    ),
    (
        "WAGE_OTHER",
        "기타",
        ["근로계약서 또는 용역계약서(해당 시)"],
        ["급여", "임금", "프리랜서"],
        [
            "해외근로자 급여 송금",
            "해외 프리랜서 용역대가",
            "기타 미분류 송금",
        ],
    ),
]

_CATEGORY_TAG = {
    "경상거래": "CURRENT_TRANSACTION",
    "자본거래": "CAPITAL_TRANSACTION",
    "기타": "OTHER",
}

_PAREN_RE = re.compile(r"[()/]")


def _name_keywords(name: str) -> list[str]:
    tokens = [t for t in _PAREN_RE.sub(" ", name).split() if t]
    return tokens


def build_rows() -> list[dict[str, str]]:
    rows = []
    seq = 1
    for subcat_tag, category, docs, extra_keywords, names in GROUPS:
        for name in names:
            code = f"FX-{seq:04d}"
            keywords = list(dict.fromkeys(_name_keywords(name) + extra_keywords))
            regulation_tags = [subcat_tag, _CATEGORY_TAG[category]]
            rows.append(
                {
                    "code": code,
                    "name": name,
                    "category": category,
                    "description": f"{name} 관련 외환거래 ({category})",
                    "keywords": "|".join(keywords),
                    "required_documents": "|".join(docs),
                    "regulation_tags": "|".join(regulation_tags),
                    "is_active": "true",
                }
            )
            seq += 1
    return rows


def main() -> None:
    rows = build_rows()
    fieldnames = [
        "code",
        "name",
        "category",
        "description",
        "keywords",
        "required_documents",
        "regulation_tags",
        "is_active",
    ]
    with OUT_PATH.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print(f"wrote {len(rows)} reason codes to {OUT_PATH}")


if __name__ == "__main__":
    main()
