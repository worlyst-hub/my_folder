"""공용 Embedding 클라이언트.

사유코드 검색(``services/reason_code/mapper.py``)과 RAG 임베딩
(``rag/embedder.py``)이 동일한 임베딩 백엔드를 공유하도록 분리한
모듈이다. Ollama API를 우선 사용하되(``LLM_MODE=live``), Ollama가 없거나
호출에 실패하면 경량 해시 기반 임베딩으로 자동 폴백하여 Mock 모드에서도
Vector Search 파이프라인 자체는 동작하도록 한다.

주의: 두 백엔드는 벡터 차원/의미 체계가 다르므로, 같은 이름의 Vector DB
컬렉션을 공유하지 않도록 백엔드별로 컬렉션 이름을 구분한다
(``backend_name`` 참고).
"""

from __future__ import annotations

import hashlib
import math
import re
from typing import Sequence

from config.settings import get_settings
from services.ollama_client import build_ollama_client
from utils.logging import get_logger

logger = get_logger(__name__)

_HASH_DIM = 256
_TOKEN_RE = re.compile(r"[0-9A-Za-z가-힣]+")


def _tokenize(text: str) -> list[str]:
    return _TOKEN_RE.findall(text.lower())


def _hash_embed(text: str) -> list[float]:
    """의존성 없는 경량 임베딩 (feature hashing).

    실제 의미 임베딩만큼 정교하지 않지만, 키워드가 겹치는 문서를 비슷한
    방향의 벡터로 보내주어 오프라인 데모에서도 Vector Search 흐름을 그대로
    시연할 수 있게 한다.
    """

    vec = [0.0] * _HASH_DIM
    for tok in _tokenize(text):
        digest = int(hashlib.md5(tok.encode("utf-8")).hexdigest(), 16)
        idx = digest % _HASH_DIM
        sign = 1.0 if (digest // _HASH_DIM) % 2 == 0 else -1.0
        vec[idx] += sign
    norm = math.sqrt(sum(v * v for v in vec)) or 1.0
    return [v / norm for v in vec]


class EmbeddingClient:
    def __init__(self) -> None:
        settings = get_settings()
        self._settings = settings
        self._client = None
        self.backend_name = "hash"

        if settings.llm_mode == "live":
            client = build_ollama_client(
                settings,
                host=settings.ollama_embed_base_url,
                api_key=settings.ollama_embed_api_key,
            )
            try:
                # 초기화 시점에 한 번 연결을 확인하여, 컬렉션 이름(backend_name)이
                # 인덱싱 도중 바뀌어 벡터 차원이 섞이는 상황을 방지한다.
                client.embeddings(model=settings.ollama_embed_model, prompt="ping")
                self._client = client
                self.backend_name = "ollama"
            except Exception:
                logger.warning(
                    "Ollama 임베딩 연결 확인에 실패하여 경량 해시 임베딩으로 대체합니다.",
                    exc_info=True,
                )

    def embed(self, texts: Sequence[str]) -> list[list[float]]:
        if self._client is not None:
            try:
                return [
                    self._client.embeddings(model=self._settings.ollama_embed_model, prompt=t)[
                        "embedding"
                    ]
                    for t in texts
                ]
            except Exception:
                logger.warning(
                    "Ollama 임베딩 호출에 실패하여 경량 해시 임베딩으로 대체합니다.",
                    exc_info=True,
                )
                self._client = None
                self.backend_name = "hash"

        return [_hash_embed(t) for t in texts]
