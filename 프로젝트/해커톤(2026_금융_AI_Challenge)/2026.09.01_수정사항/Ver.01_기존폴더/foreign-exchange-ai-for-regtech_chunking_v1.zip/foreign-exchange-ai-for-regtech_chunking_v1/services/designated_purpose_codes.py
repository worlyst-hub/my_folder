"""기존지정목적 3자리 코드(대분류+중분류+소분류) 정의.

실제 외국환거래 목적코드가 아니라 이 프로젝트 시연용으로 임의로 만든
체계다(대분류 4개 x 중분류 5개 x 소분류 5개 = 정확히 100가지 조합).

``data/generate_registered_customers.py``가 등록 고객 마스터 100명에게
이 코드를 하나씩 겹치지 않게 배정할 때 쓴 것과 같은 정의를 여기 다시
담아둔다 - 그 생성 스크립트는 앱 실행 시 임포트되지 않는 완전히 독립된
1회성 스크립트라(``data/`` 아래 다른 generate_*.py들과 동일한 패턴), 여기서
그 스크립트를 임포트하지 않고 값만 그대로 옮겨왔다. 두 값 체계가 갈라지면
안 되므로, 코드 구성을 바꿀 일이 생기면 두 파일을 함께 수정해야 한다.

``frontend/purpose_codes.py``(⑩ 지정목적코드 화면)가 코드표 전체를 보여줄 때
쓴다.
"""

from __future__ import annotations

from dataclasses import dataclass

MAJOR_CATEGORIES: dict[str, str] = {
    "1": "경상거래",
    "2": "자본거래",
    "3": "서비스거래",
    "4": "이전거래",
}

MIDDLE_CATEGORIES: dict[str, str] = {
    "11": "무역대금", "12": "운송료", "13": "보험료", "14": "여행경비", "15": "통신료",
    "21": "해외직접투자", "22": "해외부동산취득", "23": "증권투자", "24": "대출금", "25": "파생상품거래",
    "31": "용역대가", "32": "지적재산권사용료", "33": "컨설팅수수료", "34": "광고선전비", "35": "임차료",
    "41": "유학경비", "42": "생활비송금", "43": "증여성송금", "44": "기부금", "45": "상속재산",
}


@dataclass(frozen=True)
class PurposeCodeEntry:
    code: str  # 3자리 코드 (예: "211")
    major_name: str  # 대분류명 (예: "자본거래")
    middle_name: str  # 중분류명 (예: "해외직접투자")
    minor_seq: str  # 소분류 일련번호 - 별도 명칭 없이 1~5 중 하나


def all_purpose_code_entries() -> list[PurposeCodeEntry]:
    """대분류·중분류·소분류를 조합한 3자리 코드 100개를 전부 만든다."""

    entries = []
    for major, major_name in MAJOR_CATEGORIES.items():
        for middle_seq in "12345":
            middle_key = major + middle_seq
            for minor in "12345":
                entries.append(
                    PurposeCodeEntry(
                        code=middle_key + minor,
                        major_name=major_name,
                        middle_name=MIDDLE_CATEGORIES[middle_key],
                        minor_seq=minor,
                    )
                )
    return entries
