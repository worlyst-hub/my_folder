"""Ollama Client 생성 헬퍼.

로컬 Ollama(``http://localhost:11434``, 인증 불필요)와 Ollama Cloud
(``https://ollama.com``, API Key 필요) 양쪽을 동일한 코드로 지원하기 위해
클라이언트 생성 로직을 한 곳에 모은다. LLM 분석/Vision OCR은 기본
Ollama 접속 정보(``OLLAMA_BASE_URL``/``OLLAMA_API_KEY``)를, 임베딩은 별도
접속 정보(``OLLAMA_EMBED_BASE_URL``/``OLLAMA_EMBED_API_KEY``)를 쓸 수 있다
- 예: LLM은 Ollama Cloud의 대형 모델, 임베딩은 로컬 Ollama의 경량 모델처럼
서로 다른 엔드포인트를 조합하는 구성을 지원하기 위함이다.
"""

from __future__ import annotations

import ollama

from config.settings import Settings


def build_ollama_client(
    settings: Settings,
    *,
    host: str | None = None,
    api_key: str | None = None,
    timeout: int | None = None,
) -> ollama.Client:
    """Ollama 클라이언트를 만든다.

    ``host``/``api_key`` 를 명시하지 않으면 기본 Ollama 접속 정보
    (``settings.ollama_base_url`` / ``settings.ollama_api_key``)를 사용한다.
    """

    resolved_host = host if host is not None else settings.ollama_base_url
    resolved_key = api_key if api_key is not None else settings.ollama_api_key

    headers: dict[str, str] = {}
    if resolved_key:
        headers["authorization"] = f"Bearer {resolved_key}"

    return ollama.Client(
        host=resolved_host,
        timeout=timeout if timeout is not None else settings.ollama_timeout,
        headers=headers or None,
    )
