"""지급등의 절차 판정 - 외국환거래규정 제4-2조/제4-3조 + 제10-9조/제10-11조 (섹션 41.x).

④ 법령·필요서류 화면에서 "지정거래은행 상태 + 증빙/무증빙 선택 + 송금액 +
연간 누계액"을 기준으로 이 송금을 당행에서 어떻게 처리할 수 있는지 판정한다.

근거 조문 (data/regulations/외국환거래규정_...pdf 원문 확인, 국가법령정보센터 기준):
    - 제4-2조(지급등의 절차) ①: 지급등을 하려는 자는 원칙적으로 지급등의
      증빙서류를 제출해야 한다. ⑤: 거래외국환은행을 지정한 경우에는 그
      은행을 통해서만 지급등을 해야 한다.
    - 제4-3조(거주자의 지급등 절차 예외) ①1호: 신고 불요 거래로서 "연간
      누계금액이 미화 10만불 이내"인 지급은 증빙서류 없이 가능하다(단,
      외국환업무취급기관 전체 합산 기준). ①2호: 연간 누계금액을 초과하여
      지급하려는 경우 가목(건당 미화 5천불 이내) 또는 나목(신고 불요 거래로서
      서류로 내용/금액을 은행이 확인 가능)에 해당하면 예외적으로 가능. ①3호:
      수령의 경우 건당 미화 5천불 이내(또는 신고 불요)는 증빙 없이 가능.
    - 제10-9조(사후관리절차 등) ①: 거래외국환은행을 지정한 경우에는 그
      지정된 은행이 사후관리를 한다.
    - 제10-11조(거래외국환은행 지정 등) ①: 해외직접투자·해외부동산취득·
      증권발행·자금차입 등 열거된 사후관리 대상 거래는 거래외국환은행을
      반드시 지정해야 한다. ⑤: 지정된 은행을 변경하려면 현재 지정 은행을
      경유해 새 은행의 확인을 받아야 한다("변경 절차").

이 프로젝트의 사유코드 마스터(data/reason_codes.csv)는 제10-11조가 열거하는
"사후관리 필요" 항목을 개별 사유코드 단위로 태깅하지 않으므로, `category ==
"자본거래"`로 근사한다(제10-11조가 열거하는 해외직접투자/해외부동산취득/
증권발행/자금차입 등이 대부분 자본거래에 속함 - 정확한 목록은 사유코드별로
다를 수 있으므로 은행원의 최종 확인이 필요하다는 점을 화면에 함께 안내한다).

이 모듈은 임의의 숫자 가중치를 조합한 점수식이 아니라, 조문에 나온 금액
기준(미화 5천불/10만불)을 그대로 비교하는 명확한 규칙이다(섹션 12 원칙과
동일). 최종 처리 가능 여부는 은행원이 확인한다(섹션 3 원칙) - 이 모듈은
판단을 대신하지 않고 참고 정보와 근거 조문을 제시할 뿐이다.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal

ANNUAL_CUMULATIVE_LIMIT_USD = Decimal("100000")
"""제4-3조제1항제1호 - 무증빙 지급의 연간 누계 한도(미화 10만불)."""

PER_TRANSACTION_LIMIT_USD = Decimal("5000")
"""제4-3조제1항제2호가목·제3호 - 건당 무증빙 한도(미화 5천불).

지정거래은행이 당행이 아닌 경우, 당행은 그 고객의 다른 은행 거래까지
합산한 연간 누계를 확인할 방법이 없어(제4-3조제1항제1호 본문의 "외국환업무
취급기관등을 통해 지급한 금액을 합산한 금액" 요건을 당행 혼자서는 확인할 수
없음) 연간 누계 한도 대신 이 건당 한도만 적용한다.
"""


@dataclass(frozen=True)
class PaymentProcedureResult:
    """판정 결과. 화면에는 이 결과를 참고 정보로만 보여주고, 최종 처리
    가능 여부는 은행원이 결정한다."""

    can_proceed_as_selected: bool
    """지금 선택한 증빙/무증빙 방식으로 당행에서 처리 가능한지."""

    requires_documents: bool
    """이 거래를 처리하려면(또는 계속 처리하려면) 증빙서류가 필요한지."""

    counts_toward_cumulative: bool
    """이 금액이 연간 누계액에 반영되는지(무증빙만 반영, 증빙은 미반영)."""

    projected_cumulative_usd: Decimal | None
    """이 거래를 반영하면 연간 누계액이 얼마가 되는지(참고용, USD)."""

    message: str
    """은행원에게 보여줄 판정 설명."""

    citation: str
    """근거 조문."""


def evaluate_payment_procedure(
    *,
    designated_bank_status: str,
    is_capital_transaction: bool,
    is_documented: bool,
    amount_usd: Decimal | None,
    accumulated_usd: Decimal,
) -> PaymentProcedureResult:
    """지급 절차를 판정한다.

    Args:
        designated_bank_status: "SELF"(당행) / "OTHER"(타행) / "NONE"(미지정).
        is_capital_transaction: 사유코드가 자본거래(제10-11조 사후관리 대상
            추정)인지 - ``ReasonCode.category == "자본거래"``.
        is_documented: 은행원이 이 거래에 대해 증빙서류를 제출/확인받기로
            했는지(참) 아니면 무증빙으로 처리하려는지(거짓).
        amount_usd: 이번 송금액(USD). 알 수 없으면 ``None``.
        accumulated_usd: 이번 송금 반영 전 연간 누계액(USD).
    """

    bank_label = {"SELF": "당행", "OTHER": "타행", "NONE": "미지정"}.get(
        designated_bank_status, designated_bank_status
    )

    # 1. 사후관리가 필요한 거래인데 당행이 지정거래은행이 아니면, 증빙 여부와
    #    무관하게 당행에서 사후관리 자체를 할 수 없다(제10-9조제1항).
    if is_capital_transaction and designated_bank_status != "SELF":
        if designated_bank_status == "OTHER":
            action = "지정거래외국환은행 변경 절차(제10-11조제5항 - 현재 지정 은행을 경유해 당행의 확인을 받아야 함)"
        else:
            action = "당행으로 지정거래외국환은행 신규 지정(제10-11조제1항)"
        return PaymentProcedureResult(
            can_proceed_as_selected=False,
            requires_documents=is_documented,
            counts_toward_cumulative=False,
            projected_cumulative_usd=None,
            message=(
                f"사후관리가 필요한 거래(자본거래)로 추정되는데 지정거래은행이 {bank_label}입니다. "
                f"당행은 사후관리를 할 수 없으므로 이 거래를 처리하려면 {action}가 먼저 필요합니다."
            ),
            citation="외국환거래규정 제10-9조제1항, 제10-11조제1항·제5항",
        )

    # 2. 증빙서류를 제출/확인받는 경우 - 원칙(제4-2조제1항) 그대로 처리 가능하고
    #    연간 누계액에는 반영되지 않는다.
    if is_documented:
        return PaymentProcedureResult(
            can_proceed_as_selected=True,
            requires_documents=True,
            counts_toward_cumulative=False,
            projected_cumulative_usd=accumulated_usd,
            message="증빙서류로 처리 가능한 거래입니다. 연간 누계액에는 반영되지 않습니다.",
            citation="외국환거래규정 제4-2조제1항",
        )

    # 3. 무증빙 처리를 원하는 경우.
    if amount_usd is None:
        return PaymentProcedureResult(
            can_proceed_as_selected=False,
            requires_documents=False,
            counts_toward_cumulative=False,
            projected_cumulative_usd=None,
            message="송금액이 확인되지 않아 무증빙 한도를 판정할 수 없습니다. ②단계에서 금액을 먼저 확인하세요.",
            citation="외국환거래규정 제4-3조제1항",
        )

    if designated_bank_status != "SELF" and amount_usd > PER_TRANSACTION_LIMIT_USD:
        return PaymentProcedureResult(
            can_proceed_as_selected=False,
            requires_documents=True,
            counts_toward_cumulative=False,
            projected_cumulative_usd=None,
            message=(
                f"지정거래은행이 {bank_label}이라 무증빙 송금은 건당 미화 {PER_TRANSACTION_LIMIT_USD:,.0f}불 "
                f"이하만 가능합니다(당행은 다른 은행 거래까지 합산한 연간 누계를 확인할 수 없기 때문). "
                "증빙서류를 제출하거나, 더 큰 금액을 무증빙으로 보내려면 당행으로 지정거래외국환은행을 "
                "변경/신규 지정해야 합니다."
            ),
            citation="외국환거래규정 제4-3조제1항제2호가목·제3호",
        )

    projected = accumulated_usd + amount_usd
    if projected > ANNUAL_CUMULATIVE_LIMIT_USD:
        return PaymentProcedureResult(
            can_proceed_as_selected=False,
            requires_documents=True,
            counts_toward_cumulative=False,
            projected_cumulative_usd=projected,
            message=(
                f"이 송금을 반영하면 연간 누계액이 {projected:,.0f}달러로 미화 "
                f"{ANNUAL_CUMULATIVE_LIMIT_USD:,.0f}불을 초과합니다. 무증빙으로 처리할 수 없으며 "
                "증빙서류가 필요합니다."
            ),
            citation="외국환거래규정 제4-3조제1항제1호·제2호",
        )

    return PaymentProcedureResult(
        can_proceed_as_selected=True,
        requires_documents=False,
        counts_toward_cumulative=True,
        projected_cumulative_usd=projected,
        message=f"무증빙으로 처리 가능합니다(반영 후 연간 누계액 {projected:,.0f}달러).",
        citation="외국환거래규정 제4-3조제1항제1호",
    )
