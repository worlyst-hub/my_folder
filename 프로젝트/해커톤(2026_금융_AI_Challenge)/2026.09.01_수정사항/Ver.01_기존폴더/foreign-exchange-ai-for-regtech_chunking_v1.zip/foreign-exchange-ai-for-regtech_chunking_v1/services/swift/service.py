"""SWIFT BIC 조회 서비스 (섹션 19~23).

단순 SQL 조회만 수행한다. ML/Rule Engine을 사용하지 않으며, 조회 결과만으로
실제 송금 가능 여부를 자동 확정하지 않는다.
"""

from __future__ import annotations

from sqlalchemy import case, select

from database.connection import get_session
from database.models import SwiftSanctionMaster
from schemas.swift import SwiftLookupNotFound, SwiftLookupResult
from utils.logging import get_logger

logger = get_logger(__name__)


class SwiftService:
    def lookup(self, swift_code: str) -> SwiftLookupResult | SwiftLookupNotFound:
        """SWIFT BIC로 은행/제재/예상 소요시간 정보를 조회한다.

        8자리 BIC가 입력된 경우 LIKE Prefix 검색으로 11자리(Branch Code
        포함) 레코드까지 조회할 수 있다(섹션 22). 실제 SWIFT 마스터 데이터에는
        한 은행 아래 지점(Branch Code)이 여러 건 등재된 경우가 많으므로,
        8자리 BIC(Branch Code 미포함)는 관례상 본점/대표 코드를 뜻하는
        Branch Code "XXX"를 우선 매칭하고, 없으면 등재된 지점 중 하나로
        폴백한다.
        """

        code = (swift_code or "").strip().upper()
        if not code:
            return SwiftLookupNotFound(swift_code=code)

        with get_session() as session:
            # 0=정확히 일치, 1=본점(XXX) Branch Code, 2=그 외 지점(폴백)
            priority = case(
                (SwiftSanctionMaster.swift_code == code, 0),
                (SwiftSanctionMaster.swift_code == f"{code}XXX", 1),
                else_=2,
            )
            stmt = (
                select(SwiftSanctionMaster)
                .where(SwiftSanctionMaster.swift_code.like(f"{code}%"))
                .order_by(priority, SwiftSanctionMaster.swift_code)
            )
            row = session.execute(stmt).scalars().first()

            if row is None:
                logger.warning("SWIFT 코드 조회 실패 (DB에 없음): %s", code)
                return SwiftLookupNotFound(swift_code=code)

            return SwiftLookupResult(
                swift_code=row.swift_code,
                bank_name=row.bank_name,
                country_code=row.country_code,
                is_sanctioned=row.is_sanctioned,
                sanction_reason=row.sanction_reason,
                estimated_days=row.estimated_days,
                handling_note=row.handling_note,
            )
