"""사유코드 Embedding 기반 Vector Search (섹션 12~14).

임의의 숫자 가중치를 조합한 점수식을 사용하지 않는다. Embedding 코사인
유사도만으로 Top-K 후보를 뽑아 은행원에게 보여주고, 최종 채택은 은행원이
판단한다.
"""

from __future__ import annotations

import chromadb
from sqlalchemy import select

from config.settings import get_settings
from database.connection import get_session
from database.models import ReasonCode as ReasonCodeORM
from schemas.analysis import RequiredDocumentItem, RequiredDocumentsResult
from schemas.reason_code import ReasonCode, ReasonCodeCandidate
from services.embedding_client import EmbeddingClient
from utils.logging import get_logger

logger = get_logger(__name__)


def _index_text(rc: ReasonCodeORM) -> str:
    return f"{rc.name} {rc.description} {' '.join(rc.keywords)}"


def _to_schema(rc: ReasonCodeORM) -> ReasonCode:
    return ReasonCode(
        code=rc.code,
        name=rc.name,
        category=rc.category,
        description=rc.description,
        keywords=rc.keywords,
        required_documents=rc.required_documents,
        regulation_tags=rc.regulation_tags,
        is_active=rc.is_active,
    )


class ReasonCodeMapper:
    """사유코드 Vector Search 인덱스 빌드/검색을 담당."""

    def __init__(self) -> None:
        settings = get_settings()
        self._embedder = EmbeddingClient()
        chroma_client = chromadb.PersistentClient(path=settings.chroma_persist_dir)
        self._collection = chroma_client.get_or_create_collection(
            name=f"reason_codes_{self._embedder.backend_name}",
            metadata={"hnsw:space": "cosine"},
        )

    @property
    def embedding_backend(self) -> str:
        """실제 사용 중인 임베딩 백엔드("ollama"/"hash").

        ``LLM_MODE=live`` 여도 Ollama 연결에 실패하면 ``EmbeddingClient``가
        조용히 경량 해시 임베딩으로 폴백한다(섹션 14 원칙). 화면에서 이
        값을 실제로 노출해, 사이드바의 "Live" 배지만 보고 검색 품질까지
        Live라고 오해하지 않도록 한다.
        """

        return self._embedder.backend_name

    def build_index(self, force: bool = False) -> int:
        """DB의 활성 사유코드를 임베딩하여 Vector DB에 색인한다."""

        if self._collection.count() > 0:
            if not force:
                logger.info("사유코드 인덱스가 이미 존재합니다 (force=True로 재생성 가능)")
                return self._collection.count()
            existing_ids = self._collection.get()["ids"]
            if existing_ids:
                self._collection.delete(ids=existing_ids)

        with get_session() as session:
            reason_codes = (
                session.execute(select(ReasonCodeORM).where(ReasonCodeORM.is_active.is_(True)))
                .scalars()
                .all()
            )
            if not reason_codes:
                logger.warning("색인할 사유코드가 없습니다. 먼저 database.seed를 실행하세요.")
                return 0

            texts = [_index_text(rc) for rc in reason_codes]
            ids = [rc.code for rc in reason_codes]
            metadatas = [{"code": rc.code} for rc in reason_codes]
            embeddings = self._embedder.embed(texts)

        self._collection.add(ids=ids, embeddings=embeddings, documents=texts, metadatas=metadatas)
        logger.info(
            "사유코드 %d건 인덱싱 완료 (embedding backend=%s)", len(ids), self._embedder.backend_name
        )
        return len(ids)

    def search(self, query_text: str, top_k: int = 5) -> list[ReasonCodeCandidate]:
        """자연어 거래 문맥 텍스트로 사유코드 후보 Top-K를 검색한다."""

        if self._collection.count() == 0:
            self.build_index()
        if self._collection.count() == 0:
            return []

        query_embedding = self._embedder.embed([query_text])[0]
        n_results = min(top_k, self._collection.count())
        result = self._collection.query(query_embeddings=[query_embedding], n_results=n_results)

        codes = result["ids"][0]
        distances = result["distances"][0]

        candidates: list[ReasonCodeCandidate] = []
        with get_session() as session:
            for code, distance in zip(codes, distances):
                rc = session.execute(
                    select(ReasonCodeORM).where(ReasonCodeORM.code == code)
                ).scalar_one_or_none()
                if rc is None:
                    continue
                # cosine space 이므로 distance = 1 - cosine_similarity
                score = max(0.0, min(1.0, 1.0 - distance))
                matched_keywords = [kw for kw in rc.keywords if kw in query_text]
                candidates.append(
                    ReasonCodeCandidate(
                        reason_code=_to_schema(rc),
                        score=round(score, 4),
                        matched_keywords=matched_keywords,
                    )
                )
        return candidates


def build_required_documents_result(reason_code: ReasonCode) -> RequiredDocumentsResult:
    """선택된 사유코드의 필요서류 목록을 화면 체크리스트용 스키마로 변환한다
    (섹션 18). 실제 서류 확인/체크는 은행원이 직접 수행한다.
    """

    return RequiredDocumentsResult(
        items=[RequiredDocumentItem(name=doc, checked=False) for doc in reason_code.required_documents],
        is_sample=True,
        source_note=f"사유코드 {reason_code.code} ({reason_code.name}) 기준 테스트용 필요서류 목록",
    )
