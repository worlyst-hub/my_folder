"""Mock OCR 구현.

API Key/Vision 모델 없이도 전체 프로젝트 흐름을 시연할 수 있도록, 업로드된
파일 이름에 포함된 키워드에 따라 몇 가지 대표 시나리오 중 하나를 반환한다.
일치하는 키워드가 없으면 섹션 36의 기본 Mock 신청서(해외부동산 취득)를
반환한다.

데모 시 파일명에 다음 키워드를 포함시키면 다른 시나리오를 볼 수 있다:
``study``(유학비), ``trade``(물품대금), ``sanction``(제재 은행 케이스).
"""

from __future__ import annotations

from pathlib import Path

from schemas.customer import CustomerProfile
from schemas.transaction import RecipientInfo, TransactionRequest
from services.ocr.base import OCRExtractionResult, OCRService
from utils.logging import get_logger

logger = get_logger(__name__)


def _scenario_real_estate() -> OCRExtractionResult:
    return OCRExtractionResult(
        customer_profile=CustomerProfile(
            customer_type="INDIVIDUAL",
            residence_status="RESIDENT",
            name_ko="홍길동",
            name_eng="HONG GIL DONG",
            identification_no="850101-1******",
            account_number="123-4567-8901-23",
        ),
        transaction_request=TransactionRequest(
            raw_transaction_purpose="해외 주택 구매 목적으로 계약금 송금하려고 함",
            remittance_currency="USD",
            remittance_amount="150000.00",
            recipient_info=RecipientInfo(
                recipient_type="CORPORATE",
                recipient_name="US REALTY LLC",
                recipient_country="US",
                beneficiary_bank_name="CHASE BANK N.A.",
                swift_bic="BKTRUS33XXX",
            ),
        ),
        field_confidence={
            "name_ko": 0.97,
            "remittance_amount": 0.95,
            "swift_bic": 0.90,
            "identification_no": 0.62,
        },
        warnings=["식별번호(주민등록번호) 필드는 인식률이 낮아 원본 대조가 필요합니다."],
    )


def _scenario_study_abroad() -> OCRExtractionResult:
    return OCRExtractionResult(
        customer_profile=CustomerProfile(
            customer_type="INDIVIDUAL",
            residence_status="RESIDENT",
            name_ko="김유학",
            name_eng="KIM YU HAK",
            identification_no="020305-4******",
            account_number="110-222-333444",
        ),
        transaction_request=TransactionRequest(
            raw_transaction_purpose="미국 대학교 2026년 가을학기 등록금 납부",
            remittance_currency="USD",
            remittance_amount="42000.00",
            recipient_info=RecipientInfo(
                recipient_type="CORPORATE",
                recipient_name="UNIVERSITY OF EXAMPLE",
                recipient_country="US",
                beneficiary_bank_name="BANK OF AMERICA N.A.",
                swift_bic="BOFAUS3NXXX",
            ),
        ),
        field_confidence={"name_ko": 0.96, "remittance_amount": 0.93},
        warnings=[],
    )


def _scenario_trade() -> OCRExtractionResult:
    return OCRExtractionResult(
        customer_profile=CustomerProfile(
            customer_type="CORPORATE",
            residence_status="RESIDENT",
            name_ko="주식회사 예시무역",
            name_eng="EXAMPLE TRADING CO., LTD.",
            identification_no="123-81-12345",
            account_number="356-9988-7766",
        ),
        transaction_request=TransactionRequest(
            raw_transaction_purpose="전자부품 수입대금 결제 (INVOICE NO. EX-2026-0912)",
            remittance_currency="USD",
            remittance_amount="87500.00",
            recipient_info=RecipientInfo(
                recipient_type="CORPORATE",
                recipient_name="SHENZHEN ELECTRONICS CO., LTD.",
                recipient_country="CN",
                beneficiary_bank_name="BANK OF CHINA",
                swift_bic="BKCHCNBJXXX",
            ),
        ),
        field_confidence={"remittance_amount": 0.94, "swift_bic": 0.88},
        warnings=[],
    )


def _scenario_sanction() -> OCRExtractionResult:
    return OCRExtractionResult(
        customer_profile=CustomerProfile(
            customer_type="CORPORATE",
            residence_status="RESIDENT",
            name_ko="주식회사 테스트상사",
            name_eng="TEST TRADING CO., LTD.",
            identification_no="222-81-54321",
            account_number="789-1122-3344",
        ),
        transaction_request=TransactionRequest(
            raw_transaction_purpose="러시아 원자재 수입대금 결제",
            remittance_currency="USD",
            remittance_amount="63000.00",
            recipient_info=RecipientInfo(
                recipient_type="CORPORATE",
                recipient_name="SBERBANK TRADE PARTNER LLC",
                recipient_country="RU",
                beneficiary_bank_name="SBERBANK OF RUSSIA",
                swift_bic="SABRRU22XXX",
            ),
        ),
        field_confidence={"remittance_amount": 0.91, "swift_bic": 0.89},
        warnings=["제재 데이터 등재 가능성이 있는 수취은행입니다. 조회 결과를 반드시 확인하세요."],
    )


_KEYWORD_SCENARIOS = {
    "study": _scenario_study_abroad,
    "유학": _scenario_study_abroad,
    "trade": _scenario_trade,
    "무역": _scenario_trade,
    "sanction": _scenario_sanction,
    "제재": _scenario_sanction,
}


class MockOCRService(OCRService):
    """실제 OCR 없이 미리 정의된 시나리오를 반환하는 Mock 구현."""

    def extract(self, file_path: str | Path) -> OCRExtractionResult:
        name = Path(file_path).stem.lower()
        for keyword, factory in _KEYWORD_SCENARIOS.items():
            if keyword in name:
                logger.info("Mock OCR: '%s' 시나리오 매칭 (파일명=%s)", keyword, name)
                result = factory()
                break
        else:
            logger.info("Mock OCR: 기본(해외부동산) 시나리오 사용 (파일명=%s)", name)
            result = _scenario_real_estate()

        result.source_file_name = Path(file_path).name
        return result
