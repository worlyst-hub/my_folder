"""OCR Service 팩토리.

``config.settings.Settings.ocr_mode`` 값에 따라 Mock/Vision 구현을 선택한다.
UI/다른 서비스는 이 팩토리를 통해서만 OCRService를 얻는다.

.. note::
    이전에는 PaddleOCR(``OCR_MODE=paddle``) 모드도 있었으나, 실제 서식으로
    Vision(``qwen2.5vl``)과 비교한 결과 속도/정확도 모두 크게 뒤처져 제거했다
    (섹션 41.18 참고). 오프라인 환경이 꼭 필요하면 과거 커밋에서
    ``services/ocr/paddle_ocr.py`` 를 참고할 수 있다.
"""

from __future__ import annotations

from config.settings import get_settings
from services.ocr.base import OCRService


def get_ocr_service() -> OCRService:
    settings = get_settings()

    if settings.ocr_mode == "vision":
        from services.ocr.vision_ocr import VisionOCRService

        return VisionOCRService()

    from services.ocr.mock_ocr import MockOCRService

    return MockOCRService()
