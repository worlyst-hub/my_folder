"""Ollama Vision 모델 기반 실제 OCR 구현.

별도의 상용 OCR API 대신, LLM과 동일하게 Ollama의 이미지 인식 모델
(``OLLAMA_VISION_MODEL``)을 사용하여 외화송금신청서 이미지/PDF를 구조화된
JSON으로 추출한다.

권장 모델: ``qwen2.5vl``. 실제 한글 손글씨 서식(빈칸에 직접 작성한 예시)으로
``llava``와 비교 검증한 결과, ``llava``는 이미지를 제대로 읽지 못하고 위
프롬프트의 필드 설명 문구를 그대로 베껴 쓰는 문제가 있었다(예:
``name_ko`` 값이 실제 이름이 아니라 "고객 한글명" 그대로). ``qwen2.5vl``은
같은 이미지에서 이름/주민번호/계좌번호/SWIFT까지 거의 전부 정확히
추출했고, PaddleOCR(``OCR_MODE=paddle``, 같은 이미지 기준 수 분 소요)보다
훨씬 빠르다(10~30초 내외). 자세한 비교 결과는 프롬프트 파일 섹션 41.17
참고.

제약:
    - 이미지 파일(JPG/PNG) 또는 PDF를 지원한다. PDF는 ``pypdfium2``로 첫
      페이지만 이미지로 변환한 뒤 Vision 모델에 넘긴다(poppler 등 시스템
      패키지 불필요 - PDFium 바이너리를 함께 배포함). 여러 페이지가 있으면
      1페이지 외 내용은 인식에 반영되지 않으므로 경고를 덧붙인다(외화송금
      신청서는 1페이지에 필요한 정보가 모두 있고 2페이지는 무관한 내용이라
      - 섹션 9 참고 - 실사용에는 문제가 없다).
    - Vision 모델의 인식 결과는 참고용이며, 은행원이 원본과 반드시 대조
      해야 한다(섹션 3의 OCR 처리 원칙과 동일).
"""

from __future__ import annotations

import json
import re
import tempfile
import uuid
from pathlib import Path

from config.settings import get_settings
from schemas.customer import CustomerProfile
from schemas.transaction import RecipientInfo, TransactionRequest
from services.ocr.base import OCRExtractionResult, OCRError, OCRService
from services.ollama_client import build_ollama_client
from utils.logging import get_logger

logger = get_logger(__name__)

_SUPPORTED_SUFFIXES = {".jpg", ".jpeg", ".png", ".pdf"}

# PDF 첫 페이지를 렌더링할 배율. PDFium 기본 좌표계는 72DPI 기준이라 2.0배면
# 약 144DPI - 손글씨 인식에 충분하면서 과도하게 큰 이미지는 아니다.
_PDF_RENDER_SCALE = 2.0


def _rasterize_first_page(pdf_path: Path) -> tuple[Path, int]:
    """PDF 첫 페이지를 임시 PNG 파일로 렌더링하고 (경로, 전체 페이지 수)를 반환한다."""
    import pypdfium2 as pdfium

    pdf = pdfium.PdfDocument(str(pdf_path))
    try:
        page_count = len(pdf)
        page = pdf[0]
        bitmap = page.render(scale=_PDF_RENDER_SCALE)
        image = bitmap.to_pil()
    finally:
        pdf.close()

    tmp_path = Path(tempfile.gettempdir()) / f"fixar_vision_ocr_{uuid.uuid4().hex}.png"
    image.save(tmp_path)
    return tmp_path, page_count


_PROMPT = """\
당신은 은행 창구에서 사용하는 외화송금신청서 OCR 보조 도구입니다.
첨부된 외화송금신청서 이미지를 읽고 아래 JSON 스키마와 정확히 동일한 키를
가진 JSON만 출력하세요. 값을 읽을 수 없으면 null을 사용하세요. 설명 문장을
절대 추가하지 마세요.

{
  "customer_type": "INDIVIDUAL 또는 CORPORATE",
  "residence_status": "RESIDENT, NON_RESIDENT, FOREIGN_RESIDENT 중 하나",
  "name_ko": "고객 한글명",
  "name_eng": "고객 영문명",
  "identification_no": "주민등록번호 또는 사업자번호",
  "account_number": "출금 계좌번호",
  "raw_transaction_purpose": "송금 목적/적요 원문",
  "remittance_currency": "통화 코드 (예: USD)",
  "remittance_amount": "송금 금액 (숫자만)",
  "recipient_type": "INDIVIDUAL 또는 CORPORATE",
  "recipient_name": "수취인명",
  "recipient_country": "수취국가 ISO 2자리 코드",
  "beneficiary_bank_name": "수취은행명",
  "swift_bic": "SWIFT BIC 코드"
}
"""

_JSON_BLOCK_RE = re.compile(r"\{.*\}", re.DOTALL)


def _extract_json(text: str) -> dict:
    match = _JSON_BLOCK_RE.search(text)
    if not match:
        raise OCRError("Vision 모델 응답에서 JSON을 찾지 못했습니다.")
    try:
        return json.loads(match.group(0))
    except json.JSONDecodeError as exc:
        raise OCRError(f"Vision 모델 JSON 파싱 실패: {exc}") from exc


class VisionOCRService(OCRService):
    """Ollama Vision 모델을 이용한 실제 OCR 구현."""

    def __init__(self) -> None:
        settings = get_settings()
        self._client = build_ollama_client(
            settings,
            host=settings.ollama_vision_base_url,
            api_key=settings.ollama_vision_api_key,
        )
        self._model = settings.ollama_vision_model

    def extract(self, file_path: str | Path) -> OCRExtractionResult:
        path = Path(file_path)
        if path.suffix.lower() not in _SUPPORTED_SUFFIXES:
            raise OCRError(
                f"Vision OCR은 이미지 파일(JPG/PNG) 또는 PDF만 지원합니다: {path.suffix}. "
                "다른 형식이면 Mock 모드를 사용하거나 지원되는 형식으로 변환해 업로드하세요."
            )

        image_path = path
        temp_image_path: Path | None = None
        page_count = 1
        if path.suffix.lower() == ".pdf":
            try:
                temp_image_path, page_count = _rasterize_first_page(path)
            except Exception as exc:  # noqa: BLE001
                logger.exception("PDF 래스터화 실패")
                raise OCRError(f"PDF를 이미지로 변환하지 못했습니다: {exc}") from exc
            image_path = temp_image_path

        try:
            try:
                response = self._client.chat(
                    model=self._model,
                    messages=[
                        {
                            "role": "user",
                            "content": _PROMPT,
                            "images": [str(image_path)],
                        }
                    ],
                )
            except Exception as exc:  # noqa: BLE001 - Ollama 클라이언트 예외를 통일된 오류로 변환
                logger.exception("Vision OCR 호출 실패")
                raise OCRError(f"Ollama Vision 모델 호출에 실패했습니다: {exc}") from exc
        finally:
            if temp_image_path is not None:
                temp_image_path.unlink(missing_ok=True)

        content = response["message"]["content"]
        data = _extract_json(content)

        customer = CustomerProfile(
            customer_type=data.get("customer_type") or "INDIVIDUAL",
            residence_status=data.get("residence_status") or "RESIDENT",
            name_ko=data.get("name_ko"),
            name_eng=data.get("name_eng"),
            identification_no=data.get("identification_no"),
            account_number=data.get("account_number"),
        )
        transaction = TransactionRequest(
            raw_transaction_purpose=data.get("raw_transaction_purpose"),
            remittance_currency=data.get("remittance_currency"),
            remittance_amount=data.get("remittance_amount") or None,
            recipient_info=RecipientInfo(
                recipient_type=data.get("recipient_type"),
                recipient_name=data.get("recipient_name"),
                recipient_country=data.get("recipient_country"),
                beneficiary_bank_name=data.get("beneficiary_bank_name"),
                swift_bic=data.get("swift_bic"),
            ),
        )

        warnings = ["Vision 모델 인식 결과입니다. 반드시 원본 신청서와 대조 후 확정하세요."]
        if page_count > 1:
            warnings.append(
                f"PDF {page_count}페이지 중 1페이지만 인식에 사용했습니다. "
                "2페이지 이후 내용은 반영되지 않았으니 필요하면 원본을 직접 확인하세요."
            )

        return OCRExtractionResult(
            customer_profile=customer,
            transaction_request=transaction,
            field_confidence={},
            warnings=warnings,
            source_file_name=path.name,
        )
