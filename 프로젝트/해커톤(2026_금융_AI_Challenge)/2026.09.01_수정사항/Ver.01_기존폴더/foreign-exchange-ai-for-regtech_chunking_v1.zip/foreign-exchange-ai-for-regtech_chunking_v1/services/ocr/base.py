"""OCR Service 추상 인터페이스.

외화송금신청서(이미지/PDF)를 읽어 ``customer_profile`` / ``transaction_request``
데이터 구조로 변환하는 책임만 가진다. 증빙서류는 이 서비스의 대상이 아니다
(섹션 2.2).

실제 OCR/Vision API 연동(``vision_ocr.py``)과 Mock 구현(``mock_ocr.py``)이
동일한 인터페이스를 따르도록 하여 설정만으로 교체 가능하게 한다.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

from pydantic import BaseModel, Field

from schemas.customer import CustomerProfile
from schemas.transaction import TransactionRequest


class OCRExtractionResult(BaseModel):
    """OCR 1회 실행 결과.

    ``field_confidence`` 는 OCR 라이브러리/API가 제공하는 경우에 한해
    화면에 참고 정보로 표시할 수 있으나(섹션 3), 자동 승인/거절의 판단
    기준으로 사용하지 않는다.
    """

    customer_profile: CustomerProfile
    transaction_request: TransactionRequest
    field_confidence: dict[str, float] = Field(
        default_factory=dict, description="필드별 OCR 신뢰도 (참고용, 선택적)"
    )
    warnings: list[str] = Field(
        default_factory=list, description="OCR 과정에서 발견된 누락/모호 항목 안내"
    )
    source_file_name: str | None = None


class OCRError(Exception):
    """OCR 처리 실패 시 발생. UI는 섹션 33의 오류 메시지를 표시한다."""


class OCRService(ABC):
    """OCR Service 인터페이스. 모든 구현체는 이 클래스를 상속한다."""

    @abstractmethod
    def extract(self, file_path: str | Path) -> OCRExtractionResult:
        """외화송금신청서 파일에서 구조화된 거래정보를 추출한다.

        Args:
            file_path: 업로드된 신청서 파일 경로 (PDF/JPG/PNG).

        Returns:
            OCRExtractionResult: customer_profile / transaction_request 초안.

        Raises:
            OCRError: 인식 자체가 불가능한 경우 (해상도 문제 등).
        """
        raise NotImplementedError
