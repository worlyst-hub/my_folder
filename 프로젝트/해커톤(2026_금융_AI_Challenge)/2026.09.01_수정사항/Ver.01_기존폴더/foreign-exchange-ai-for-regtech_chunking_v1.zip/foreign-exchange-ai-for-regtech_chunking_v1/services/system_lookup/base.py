"""System Lookup Service 추상 인터페이스 (섹션 5, 24).

금융결제원 / 은행 Core DB / 신용정보원 연동을 가정한 조회를 추상화한다.
프로토타입에서는 Mock 구현만 제공한다.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from schemas.system_lookup import SystemLookupData


class SystemLookupService(ABC):
    @abstractmethod
    def get_customer_data(
        self, identification_no: str | None, account_number: str | None
    ) -> SystemLookupData:
        """고객 식별정보를 기준으로 시스템 조회 데이터를 반환한다."""
        raise NotImplementedError
