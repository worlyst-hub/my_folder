"""Mock System Lookup Service.

실제 금융결제원 / 은행 Core DB / 신용정보원 연동 없이 두 단계로 조회한다.

1. **당행 등록 고객 마스터** (``database.models.RegisteredCustomerMaster``,
   ``data/registered_customers.csv``로 시딩된 Mock 100건)을 신청서의
   식별번호로 먼저 조회한다. 찾으면 그 고객의 실제(Mock) 신용등급/송금
   한도/지정은행 여부/체납 여부를 그대로 쓴다.
2. 등록 고객 마스터에 없으면(당행 미등록/신규 고객) - 신용도/한도 자체를
   조회할 수 없는 게 현실적이므로 그 값들은 비워두고, 지정은행/체납 여부
   같은 나머지 항목만 식별정보를 해시한 결정론적 Mock 값으로 채운다
   (이전 버전과 동일한 동작 - 데모에서 다양한 케이스를 보여주기 위함).
"""

from __future__ import annotations

import hashlib
from decimal import Decimal

from database.connection import get_session
from database.models import RegisteredCustomerMaster
from schemas.system_lookup import SystemLookupData
from services.system_lookup.base import SystemLookupService
from utils.logging import get_logger

logger = get_logger(__name__)

_ACCUMULATED_BUCKETS = [Decimal("0"), Decimal("8000"), Decimal("22000"), Decimal("35000"), Decimal("55000")]
_DESIGNATED_PURPOSE_POOL = ["411", "412", "421", None]
_BANK_STATUS_POOL = ["SELF", "OTHER", "NONE"]


def _seed(identification_no: str | None, account_number: str | None) -> int:
    key = f"{identification_no or ''}|{account_number or ''}" or "unknown"
    digest = hashlib.md5(key.encode("utf-8")).hexdigest()
    return int(digest, 16)


class MockSystemLookupService(SystemLookupService):
    def get_customer_data(
        self, identification_no: str | None, account_number: str | None
    ) -> SystemLookupData:
        registered = self._lookup_registered_customer(identification_no)
        if registered is not None:
            logger.info(
                "System Lookup(등록 고객): id=%s -> rating=%s, limit=%s, designated=%s, delinquent=%s",
                identification_no,
                registered.credit_rating,
                registered.annual_remittance_limit_usd,
                registered.designated_bank_status,
                registered.is_delinquent_borrower,
            )
            return registered

        seed = _seed(identification_no, account_number)

        annual_accumulated_usd = _ACCUMULATED_BUCKETS[seed % len(_ACCUMULATED_BUCKETS)]
        bank_status = _BANK_STATUS_POOL[(seed // 10) % len(_BANK_STATUS_POOL)]
        # 지정목적은 당행이 지정거래은행일 때(SELF)만 안다 - 타행 지정(OTHER)의
        # 지정목적은 타행에 등록된 정보라 당행 시스템이 알 수 없다.
        designated_purpose = (
            _DESIGNATED_PURPOSE_POOL[(seed // 100) % len(_DESIGNATED_PURPOSE_POOL)]
            if bank_status == "SELF"
            else None
        )
        is_delinquent_borrower = (seed // 1000) % 7 == 0

        logger.info(
            "System Lookup(미등록 고객, 해시 Mock): id=%s -> designated=%s, accumulated=%s, delinquent=%s",
            identification_no,
            bank_status,
            annual_accumulated_usd,
            is_delinquent_borrower,
        )

        return SystemLookupData(
            annual_accumulated_usd=annual_accumulated_usd,
            designated_bank_status=bank_status,
            designated_purpose=designated_purpose,
            is_delinquent_borrower=is_delinquent_borrower,
            is_registered_customer=False,
        )

    def _lookup_registered_customer(self, identification_no: str | None) -> SystemLookupData | None:
        if not identification_no:
            return None
        with get_session() as session:
            row = (
                session.query(RegisteredCustomerMaster)
                .filter(RegisteredCustomerMaster.identification_no == identification_no.strip())
                .first()
            )
            if row is None:
                return None
            return SystemLookupData(
                annual_accumulated_usd=row.annual_accumulated_usd,
                designated_bank_status=row.designated_bank_status,
                designated_purpose=row.designated_purpose,
                is_delinquent_borrower=row.is_delinquent_borrower,
                is_registered_customer=True,
                credit_rating=row.credit_rating,
                annual_remittance_limit_usd=row.annual_remittance_limit_usd,
            )
