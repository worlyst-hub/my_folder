"""System Lookup Service 팩토리. 현재는 Mock 구현만 제공한다."""

from __future__ import annotations

from services.system_lookup.base import SystemLookupService


def get_system_lookup_service() -> SystemLookupService:
    from services.system_lookup.mock_service import MockSystemLookupService

    return MockSystemLookupService()
