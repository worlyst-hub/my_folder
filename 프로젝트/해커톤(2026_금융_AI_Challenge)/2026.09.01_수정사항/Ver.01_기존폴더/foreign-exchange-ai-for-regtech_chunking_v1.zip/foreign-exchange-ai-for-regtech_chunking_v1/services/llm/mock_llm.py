"""Mock LLM 구현.

Ollama 없이도 화면 전체 흐름(섹션 33 "Mock LLM 모드")을 테스트할 수 있도록,
송금 목적 텍스트의 키워드를 규칙 기반으로 매칭하여 그럴듯한 구조화 결과를
반환한다. 실제 의미 이해가 아닌 데모/테스트용 근사치임을 유의한다.
"""

from __future__ import annotations

from schemas.analysis import TransactionAnalysis, TransactionAnalysisInput
from services.llm.base import LLMService
from utils.logging import get_logger

logger = get_logger(__name__)

# (매칭 키워드, category, action, nature, normalized_purpose)
_RULES: list[tuple[list[str], str, str, str, str]] = [
    (["부동산", "주택", "아파트", "매매", "처분"], "해외부동산", "취득", "자본거래", "해외부동산 취득"),
    (["유학", "학비", "등록금", "연수", "어학"], "해외유학/연수", "납부", "경상거래", "해외유학비 납부"),
    (["수입", "수출", "물품", "인보이스", "무역", "원자재"], "무역대금", "결제", "경상거래", "물품대금 결제"),
    (["투자", "증권", "펀드", "주식", "지분", "IPO"], "해외증권투자", "투자", "자본거래", "해외증권 투자"),
    (["차입", "대출", "대여", "상환"], "자금대차", "상환", "자본거래", "해외차입금 상환"),
    (["이주비", "증여", "상속", "위자료"], "이주비/증여", "송금", "자본거래", "이주비/증여성 송금"),
    (["로열티", "사용료", "특허", "저작권"], "지식재산권 대가", "지급", "경상거래", "로열티/사용료 지급"),
    (["급여", "임금", "용역대가"], "급여/용역대가", "지급", "경상거래", "급여/용역대가 지급"),
]

_ALL_KEYWORDS = sorted({kw for rule in _RULES for kw in rule[0]})

_DEFAULT = ("기타", "송금", "경상거래", "기타 목적 송금")


class MockLLMService(LLMService):
    def analyze_transaction(self, data: TransactionAnalysisInput) -> TransactionAnalysis:
        text = data.raw_transaction_purpose or ""

        matched_facts = [kw for kw in _ALL_KEYWORDS if kw in text]

        for keywords, category, action, nature, normalized in _RULES:
            if any(kw in text for kw in keywords):
                logger.info("Mock LLM: 규칙 매칭 category=%s", category)
                return TransactionAnalysis(
                    transaction_category=category,
                    transaction_action=action,
                    transaction_nature=nature,
                    normalized_purpose=normalized,
                    country=data.recipient_country,
                    important_facts=matched_facts or [text[:20]],
                )

        logger.info("Mock LLM: 매칭되는 규칙이 없어 기본값 사용")
        category, action, nature, normalized = _DEFAULT
        return TransactionAnalysis(
            transaction_category=category,
            transaction_action=action,
            transaction_nature=nature,
            normalized_purpose=normalized,
            country=data.recipient_country,
            important_facts=matched_facts or ([text[:20]] if text else []),
        )
