"""Ollama 기반 실제 LLM 거래 문맥 분석 구현 (섹션 10~11)."""

from __future__ import annotations

import json

from config.settings import get_settings
from schemas.analysis import TransactionAnalysis, TransactionAnalysisInput
from services.llm.base import LLMService, LLMServiceError
from services.ollama_client import build_ollama_client
from utils.logging import get_logger

logger = get_logger(__name__)

_SYSTEM_PROMPT = """\
당신은 은행의 외환거래 업무를 지원하는 보조 도구입니다.
고객이 작성한 송금 목적 문장을 분석하여 거래 문맥을 구조화하는 것이 역할이며,
법률적 최종 판단이나 거래 승인 여부는 절대 결정하지 않습니다.
반드시 아래 JSON 스키마와 동일한 키만 가진 JSON 객체 하나만 출력하세요.
설명 문장이나 코드블록 표시 없이 순수 JSON만 출력합니다.
모든 값(transaction_category, transaction_action, transaction_nature,
normalized_purpose, important_facts 포함)은 반드시 한국어로 작성하세요.
country만 예외로 ISO 2자리 국가 코드를 사용합니다.

{
  "transaction_category": "거래 유형 (예: 해외부동산, 무역대금, 해외유학/연수 등)",
  "transaction_action": "거래 행위 (예: 취득, 결제, 상환, 투자 등)",
  "transaction_nature": "거래 성격 (자본거래 또는 경상거래)",
  "normalized_purpose": "정규화된 거래 목적 (짧은 명사구)",
  "country": "관련 국가 (ISO 2자리 코드, 모르면 null)",
  "important_facts": ["핵심 키워드", "..."]
}
"""


def _build_user_prompt(data: TransactionAnalysisInput) -> str:
    return (
        "다음 거래 정보를 분석하세요.\n\n"
        f"송금 목적 원문: {data.raw_transaction_purpose}\n"
        f"송금 통화: {data.remittance_currency}\n"
        f"송금 금액: {data.remittance_amount}\n"
        f"수취인: {data.recipient_name} ({data.recipient_type})\n"
        f"수취 국가: {data.recipient_country}\n"
        f"수취은행: {data.beneficiary_bank_name}\n"
        f"고객 유형: {data.customer_type}\n"
        f"거주자 구분: {data.residence_status}\n"
    )


class OllamaLLMService(LLMService):
    def __init__(self) -> None:
        settings = get_settings()
        self._client = build_ollama_client(settings)
        self._model = settings.ollama_model

    def analyze_transaction(self, data: TransactionAnalysisInput) -> TransactionAnalysis:
        try:
            response = self._client.chat(
                model=self._model,
                messages=[
                    {"role": "system", "content": _SYSTEM_PROMPT},
                    {"role": "user", "content": _build_user_prompt(data)},
                ],
                format="json",
                options={"temperature": 0},
            )
        except Exception as exc:  # noqa: BLE001
            logger.exception("Ollama 호출 실패")
            raise LLMServiceError(
                "AI 분석 서비스를 사용할 수 없습니다. Ollama 실행 상태와 모델 설정을 확인해주세요."
            ) from exc

        content = response["message"]["content"]
        try:
            parsed = json.loads(content)
            return TransactionAnalysis(**parsed)
        except (json.JSONDecodeError, TypeError, ValueError) as exc:
            logger.error("Ollama 응답 파싱 실패: %s / content=%s", exc, content)
            raise LLMServiceError(f"AI 분석 결과를 해석하지 못했습니다: {exc}") from exc
