"""LLM Service 팩토리. ``settings.llm_mode`` 에 따라 Mock/Ollama 구현을 선택한다."""

from __future__ import annotations

from config.settings import get_settings
from services.llm.base import LLMService


def get_llm_service() -> LLMService:
    settings = get_settings()
    if settings.llm_mode == "live":
        from services.llm.ollama_service import OllamaLLMService

        return OllamaLLMService()

    from services.llm.mock_llm import MockLLMService

    return MockLLMService()
