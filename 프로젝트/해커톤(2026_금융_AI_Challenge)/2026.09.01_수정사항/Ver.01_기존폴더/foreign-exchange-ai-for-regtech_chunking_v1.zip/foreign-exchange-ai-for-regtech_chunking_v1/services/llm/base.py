"""LLM Service 추상 인터페이스.

거래 문맥(자연어 송금 목적 등)을 구조화하는 책임만 가진다. 법률적 최종
판단은 하지 않으며, 결과는 사유코드 검색/화면 표시에 활용되는 참고 정보다
(섹션 10~11).
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from schemas.analysis import TransactionAnalysis, TransactionAnalysisInput


class LLMServiceError(Exception):
    """LLM 호출/파싱 실패 시 발생. UI는 섹션 33의 오류 메시지를 표시한다."""


class LLMService(ABC):
    @abstractmethod
    def analyze_transaction(self, data: TransactionAnalysisInput) -> TransactionAnalysis:
        """자연어 거래 목적을 구조화된 거래 문맥으로 변환한다."""
        raise NotImplementedError
