"""공용 입력값 검증/정규화 유틸리티.

은행원이 OCR 결과를 수정하거나 SWIFT BIC를 직접 입력할 때 재사용하는
가벼운 파싱/형식 검증 함수만 모아둔다. 거래 승인 여부를 판단하는 로직은
포함하지 않는다.
"""

from __future__ import annotations

import re
from decimal import Decimal, InvalidOperation

_SWIFT_BIC_RE = re.compile(r"^[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?$")


def parse_amount(raw: str | None) -> Decimal | None:
    """"1,234.56" 같은 사용자 입력 문자열을 Decimal로 변환한다.

    콤마(천단위 구분)를 허용하며, 비어있거나 숫자로 해석할 수 없으면
    ``None`` 을 반환한다 (예외를 던지지 않아 폼 입력 처리에 사용하기 쉽다).
    """

    if not raw:
        return None
    cleaned = raw.replace(",", "").strip()
    if not cleaned:
        return None
    try:
        return Decimal(cleaned)
    except InvalidOperation:
        return None


def normalize_swift_bic(raw: str | None) -> str | None:
    """공백 제거 + 대문자 변환. 빈 문자열은 ``None`` 으로 정규화한다."""

    if not raw:
        return None
    value = raw.strip().upper()
    return value or None


def is_valid_swift_bic_format(code: str | None) -> bool:
    """SWIFT BIC의 형식(8자리 또는 11자리, 은행4+국가2+위치2[+지점3])만 검사한다.

    DB 등재 여부나 제재 여부와는 무관하며, 형식이 올바르지 않다고 해서
    거래를 자동으로 거부하지 않는다 - 은행원의 참고용 안내에만 사용한다.
    """

    if not code:
        return False
    return bool(_SWIFT_BIC_RE.match(code.strip().upper()))
