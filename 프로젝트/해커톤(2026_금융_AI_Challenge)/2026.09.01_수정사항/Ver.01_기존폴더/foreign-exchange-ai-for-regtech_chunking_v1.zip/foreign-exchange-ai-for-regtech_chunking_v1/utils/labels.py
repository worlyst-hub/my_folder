"""화면 표시용 한글 라벨 매핑.

DB/스키마에는 영문 Enum 값(``INDIVIDUAL``, ``RESIDENT`` 등)을 그대로 쓰되,
은행원이 보는 화면에는 한글로 표시하기 위한 매핑만 모아둔다. 저장되는 값
자체를 바꾸는 것이 아니라 "표시"만 한글로 바꾸는 용도다.
"""

from __future__ import annotations

CUSTOMER_TYPE_LABELS = {"INDIVIDUAL": "개인", "CORPORATE": "법인"}
RESIDENCE_STATUS_LABELS = {
    "RESIDENT": "거주자",
    "NON_RESIDENT": "비거주자",
    "FOREIGN_RESIDENT": "외국인거주자",
}
RECIPIENT_TYPE_LABELS = {"INDIVIDUAL": "개인", "CORPORATE": "법인"}
# 거래외국환은행 지정 상태 - 외국환거래규정상 "거래외국환은행 지정제도"를
# 반영한 3단계다. SELF(당행 지정)만 당행에서 바로 처리 가능하고, OTHER(타행
# 지정)는 지정거래외국환은행 변경 절차가 필요할 수 있으며, NONE(미지정)은
# 이 거래를 계기로 당행을 신규 지정할 수 있다.
DESIGNATED_BANK_STATUS_LABELS = {"SELF": "당행", "OTHER": "타행", "NONE": "없음"}


def label(mapping: dict[str, str], value: object) -> str:
    """Enum 인스턴스든 순수 문자열이든 상관없이 한글 라벨을 반환한다.

    매핑에 없는 값이거나 ``None`` 이면 화면이 비어 보이지 않도록 원래 값
    (또는 "-")을 그대로 반환한다.
    """

    if value is None:
        return "-"
    key = value.value if hasattr(value, "value") else value
    return mapping.get(key, str(key))
