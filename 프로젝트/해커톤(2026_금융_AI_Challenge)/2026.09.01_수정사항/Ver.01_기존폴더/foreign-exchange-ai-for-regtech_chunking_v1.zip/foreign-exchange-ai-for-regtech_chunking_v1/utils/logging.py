"""애플리케이션 공통 로깅 설정.

모든 모듈은 ``logging.getLogger(__name__)`` 대신 이 모듈의
``get_logger(__name__)`` 를 사용하여 포맷/레벨이 일관되게 유지되도록 한다.
"""

from __future__ import annotations

import logging
import sys

from config.settings import get_settings

_CONFIGURED = False


def _configure_root() -> None:
    global _CONFIGURED
    if _CONFIGURED:
        return

    settings = get_settings()
    level = getattr(logging, settings.log_level.upper(), logging.INFO)

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(
        logging.Formatter(
            fmt="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
    )

    root = logging.getLogger()
    root.setLevel(level)
    # 중복 핸들러 등록 방지 (Streamlit 재실행 시 여러 번 호출될 수 있음)
    if not any(isinstance(h, logging.StreamHandler) for h in root.handlers):
        root.addHandler(handler)

    _CONFIGURED = True


def get_logger(name: str) -> logging.Logger:
    """모듈별 로거를 반환한다.

    사용 예::

        from utils.logging import get_logger
        logger = get_logger(__name__)
        logger.info("...")
    """

    _configure_root()
    return logging.getLogger(name)
