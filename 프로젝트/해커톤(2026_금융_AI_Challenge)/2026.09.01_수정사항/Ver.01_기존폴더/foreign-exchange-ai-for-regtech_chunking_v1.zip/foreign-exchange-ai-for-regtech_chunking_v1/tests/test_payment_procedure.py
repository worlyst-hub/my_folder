"""지급 절차 판정(services/payment_procedure.py) 테스트 (섹션 41.x).

외국환거래규정 제4-2조/제4-3조 + 제10-9조/제10-11조 기준 규칙을 검증한다.
"""

from __future__ import annotations

from decimal import Decimal

from services.payment_procedure import evaluate_payment_procedure


def test_capital_transaction_blocked_when_other_bank_designated():
    result = evaluate_payment_procedure(
        designated_bank_status="OTHER",
        is_capital_transaction=True,
        is_documented=True,
        amount_usd=Decimal("1000"),
        accumulated_usd=Decimal("0"),
    )
    assert result.can_proceed_as_selected is False
    assert "변경" in result.message


def test_capital_transaction_blocked_when_no_bank_designated():
    result = evaluate_payment_procedure(
        designated_bank_status="NONE",
        is_capital_transaction=True,
        is_documented=False,
        amount_usd=Decimal("1000"),
        accumulated_usd=Decimal("0"),
    )
    assert result.can_proceed_as_selected is False
    assert "신규" in result.message


def test_capital_transaction_allowed_when_self_designated():
    result = evaluate_payment_procedure(
        designated_bank_status="SELF",
        is_capital_transaction=True,
        is_documented=True,
        amount_usd=Decimal("50000"),
        accumulated_usd=Decimal("0"),
    )
    assert result.can_proceed_as_selected is True


def test_documented_never_counts_toward_cumulative_regardless_of_amount():
    result = evaluate_payment_procedure(
        designated_bank_status="SELF",
        is_capital_transaction=False,
        is_documented=True,
        amount_usd=Decimal("999999"),
        accumulated_usd=Decimal("50000"),
    )
    assert result.can_proceed_as_selected is True
    assert result.counts_toward_cumulative is False
    assert result.requires_documents is True


def test_self_undocumented_within_cumulative_limit_ok():
    result = evaluate_payment_procedure(
        designated_bank_status="SELF",
        is_capital_transaction=False,
        is_documented=False,
        amount_usd=Decimal("30000"),
        accumulated_usd=Decimal("50000"),
    )
    assert result.can_proceed_as_selected is True
    assert result.counts_toward_cumulative is True
    assert result.projected_cumulative_usd == Decimal("80000")


def test_self_undocumented_exceeding_cumulative_limit_needs_documents():
    """사용자가 직접 든 예시: 누계 7만불 + 3.5만불 송금 = 10.5만불 > 10만불."""
    result = evaluate_payment_procedure(
        designated_bank_status="SELF",
        is_capital_transaction=False,
        is_documented=False,
        amount_usd=Decimal("35000"),
        accumulated_usd=Decimal("70000"),
    )
    assert result.can_proceed_as_selected is False
    assert result.requires_documents is True
    assert result.projected_cumulative_usd == Decimal("105000")


def test_self_undocumented_exactly_at_limit_ok():
    result = evaluate_payment_procedure(
        designated_bank_status="SELF",
        is_capital_transaction=False,
        is_documented=False,
        amount_usd=Decimal("30000"),
        accumulated_usd=Decimal("70000"),
    )
    assert result.can_proceed_as_selected is True
    assert result.projected_cumulative_usd == Decimal("100000")


def test_other_bank_undocumented_within_5000_ok_and_counts():
    result = evaluate_payment_procedure(
        designated_bank_status="OTHER",
        is_capital_transaction=False,
        is_documented=False,
        amount_usd=Decimal("5000"),
        accumulated_usd=Decimal("1000"),
    )
    assert result.can_proceed_as_selected is True
    assert result.counts_toward_cumulative is True
    assert result.projected_cumulative_usd == Decimal("6000")


def test_other_bank_undocumented_over_5000_blocked():
    result = evaluate_payment_procedure(
        designated_bank_status="OTHER",
        is_capital_transaction=False,
        is_documented=False,
        amount_usd=Decimal("5001"),
        accumulated_usd=Decimal("0"),
    )
    assert result.can_proceed_as_selected is False
    assert result.requires_documents is True
    assert "5,000" in result.message


def test_none_bank_undocumented_over_5000_blocked_even_if_cumulative_low():
    """미지정 고객은 누계가 낮아도(0불) 건당 5천불 초과면 무증빙 불가."""
    result = evaluate_payment_procedure(
        designated_bank_status="NONE",
        is_capital_transaction=False,
        is_documented=False,
        amount_usd=Decimal("10000"),
        accumulated_usd=Decimal("0"),
    )
    assert result.can_proceed_as_selected is False


def test_other_bank_undocumented_still_blocked_by_cumulative_cap_when_under_5000():
    """건당 5천불 이내라도, 반영 후 누계가 10만불을 넘으면 여전히 서류가 필요하다
    ("모든 경우에서 누계액이 10만달러를 넘으면 서류 필요" 공통 규칙)."""
    result = evaluate_payment_procedure(
        designated_bank_status="OTHER",
        is_capital_transaction=False,
        is_documented=False,
        amount_usd=Decimal("4000"),
        accumulated_usd=Decimal("98000"),
    )
    assert result.can_proceed_as_selected is False
    assert result.requires_documents is True


def test_amount_unknown_cannot_be_evaluated():
    result = evaluate_payment_procedure(
        designated_bank_status="SELF",
        is_capital_transaction=False,
        is_documented=False,
        amount_usd=None,
        accumulated_usd=Decimal("0"),
    )
    assert result.can_proceed_as_selected is False
    assert result.projected_cumulative_usd is None
