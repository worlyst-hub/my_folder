"""utils/validation.py 단위 테스트."""

from __future__ import annotations

from decimal import Decimal

from utils.validation import is_valid_swift_bic_format, normalize_swift_bic, parse_amount


def test_parse_amount_handles_commas():
    assert parse_amount("150,000.50") == Decimal("150000.50")


def test_parse_amount_blank_returns_none():
    assert parse_amount("") is None
    assert parse_amount(None) is None


def test_parse_amount_invalid_returns_none():
    assert parse_amount("abc") is None


def test_normalize_swift_bic_uppercases_and_trims():
    assert normalize_swift_bic(" bktrus33xxx ") == "BKTRUS33XXX"
    assert normalize_swift_bic("") is None
    assert normalize_swift_bic(None) is None


def test_is_valid_swift_bic_format_8_and_11_digit():
    assert is_valid_swift_bic_format("BKTRUS33") is True
    assert is_valid_swift_bic_format("BKTRUS33XXX") is True


def test_is_valid_swift_bic_format_rejects_bad_input():
    assert is_valid_swift_bic_format("SHORT") is False
    assert is_valid_swift_bic_format(None) is False
