"""Vision OCR의 PDF 지원 테스트.

``VisionOCRService.extract()`` 전체 흐름은 실제 Ollama Vision 모델 호출이
필요해(무겁고 네트워크 의존적) 결정론적 단위 테스트에 적합하지 않다 -
``tests/test_integration_flow.py``의 설명과 같은 이유로 여기서도 실제 모델
호출 없이 확인 가능한 부분(지원 확장자, PDF 래스터화)만 테스트한다. 실제
Vision 모델 호출은 수동으로 확인했다(프롬프트 파일 섹션 41.23 참고).
"""

from __future__ import annotations

from pathlib import Path

from services.ocr.vision_ocr import _SUPPORTED_SUFFIXES, _rasterize_first_page

_BLANK_FORM = Path("data/forms/하나은행_외화송금신청서_3-09-0131.pdf")


def test_vision_ocr_supports_pdf_suffix():
    assert ".pdf" in _SUPPORTED_SUFFIXES
    assert ".jpg" in _SUPPORTED_SUFFIXES
    assert ".png" in _SUPPORTED_SUFFIXES


def test_rasterize_first_page_returns_image_and_page_count():
    tmp_path, page_count = _rasterize_first_page(_BLANK_FORM)
    try:
        assert tmp_path.exists()
        assert tmp_path.suffix == ".png"
        # data/forms/README.md에 문서화된 실제 서식 페이지 수(2페이지) 기준.
        assert page_count == 2

        from PIL import Image

        with Image.open(tmp_path) as image:
            width, height = image.size
        assert width > 0 and height > 0
    finally:
        tmp_path.unlink(missing_ok=True)
