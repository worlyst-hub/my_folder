"""LLM 거래 문맥 분석 테스트 (섹션 37 - LLM).

Ollama 없이도 검증 가능하도록 Mock LLM 구현을 직접 사용한다.
"""

from __future__ import annotations

from schemas.analysis import TransactionAnalysisInput
from services.llm.mock_llm import MockLLMService


def _input(purpose: str, country: str | None = "US") -> TransactionAnalysisInput:
    return TransactionAnalysisInput(raw_transaction_purpose=purpose, recipient_country=country)


def test_transaction_purpose_is_structured():
    """거래 목적 구조화: 자유 텍스트가 스키마의 모든 필드를 채운 결과로 변환된다."""

    analysis = MockLLMService().analyze_transaction(
        _input("해외 주택 구매 목적으로 계약금 송금하려고 함")
    )
    assert analysis.transaction_category
    assert analysis.transaction_action
    assert analysis.transaction_nature
    assert analysis.normalized_purpose
    assert analysis.country == "US"


def test_real_estate_purpose():
    analysis = MockLLMService().analyze_transaction(_input("해외 아파트 매매 계약금 송금"))
    assert analysis.transaction_category == "해외부동산"
    assert analysis.transaction_nature == "자본거래"


def test_study_abroad_purpose():
    analysis = MockLLMService().analyze_transaction(_input("미국 대학교 등록금 납부"))
    assert analysis.transaction_category == "해외유학/연수"
    assert analysis.transaction_nature == "경상거래"


def test_trade_purpose():
    analysis = MockLLMService().analyze_transaction(_input("전자부품 수입 물품대금 결제", country="CN"))
    assert analysis.transaction_category == "무역대금"
    assert analysis.country == "CN"


def test_other_purpose_falls_back_to_default_category():
    """기타 목적: 어떤 규칙에도 해당하지 않으면 기본 카테고리로 분류된다."""

    analysis = MockLLMService().analyze_transaction(_input("친구에게 생일 축하金 보냄", country=None))
    assert analysis.transaction_category == "기타"
    assert analysis.transaction_action == "송금"
