"""OCR 서비스 테스트 (섹션 37 - OCR).

Mock OCR은 실제 이미지 내용과 무관하게 파일명 키워드로 시나리오를 고르므로,
"정상 인식 / 체크박스(유형) 인식 / SWIFT 인식 / 은행원 수정" 흐름을 결정론적으로
검증할 수 있다.
"""

from __future__ import annotations

from services.ocr.base import OCRExtractionResult, OCRService
from services.ocr.mock_ocr import MockOCRService
from schemas.customer import CustomerProfile
from schemas.transaction import RecipientInfo, TransactionRequest


def test_mock_ocr_is_ocr_service():
    assert isinstance(MockOCRService(), OCRService)


def test_mock_ocr_normal_extraction_real_estate_scenario():
    """신청서 정상 OCR: 기본(해외부동산) 시나리오가 필수 필드를 모두 채운다."""

    result = MockOCRService().extract("신청서_홍길동.png")

    assert result.customer_profile.name_ko == "홍길동"
    assert result.transaction_request.remittance_currency == "USD"
    assert result.transaction_request.remittance_amount is not None
    assert result.transaction_request.recipient_info.recipient_name == "US REALTY LLC"


def test_mock_ocr_swift_bic_recognition():
    """SWIFT BIC 인식: 11자리 BIC가 그대로 추출된다."""

    result = MockOCRService().extract("application.png")
    assert result.transaction_request.recipient_info.swift_bic == "BKTRUS33XXX"
    assert len(result.transaction_request.recipient_info.swift_bic) == 11


def test_mock_ocr_checkbox_style_fields_are_enums():
    """체크박스 인식: 고객유형/거주자구분/수취인유형처럼 신청서의 체크박스 선택 항목이
    올바른 Enum 값으로 구조화된다."""

    result = MockOCRService().extract("application.png")
    assert result.customer_profile.customer_type.value in {"INDIVIDUAL", "CORPORATE"}
    assert result.customer_profile.residence_status.value in {
        "RESIDENT",
        "NON_RESIDENT",
        "FOREIGN_RESIDENT",
    }
    assert result.transaction_request.recipient_info.recipient_type.value in {
        "INDIVIDUAL",
        "CORPORATE",
    }


def test_mock_ocr_scenario_selection_by_filename():
    study = MockOCRService().extract("고객_study_신청서.jpg")
    trade = MockOCRService().extract("무역_trade_invoice.jpg")
    sanction = MockOCRService().extract("sanction_case.jpg")

    assert "대학교" in (study.transaction_request.raw_transaction_purpose or "") or "등록금" in (
        study.transaction_request.raw_transaction_purpose or ""
    )
    assert trade.transaction_request.recipient_info.recipient_country == "CN"
    assert sanction.transaction_request.recipient_info.swift_bic == "SABRRU22XXX"


def test_ocr_extraction_result_tolerates_missing_fields():
    """OCR 누락 필드: 일부 필드가 인식되지 않아도(None) 데이터 구조가 깨지지 않는다."""

    result = OCRExtractionResult(
        customer_profile=CustomerProfile(name_ko=None, identification_no=None),
        transaction_request=TransactionRequest(
            raw_transaction_purpose=None,
            remittance_amount=None,
            recipient_info=RecipientInfo(swift_bic=None),
        ),
        field_confidence={"identification_no": 0.4},
        warnings=["식별번호 필드를 인식하지 못했습니다."],
    )

    assert result.customer_profile.name_ko is None
    assert result.transaction_request.remittance_amount is None
    assert result.warnings


def test_banker_can_correct_ocr_result():
    """은행원 수정: OCR 초안을 은행원이 값을 바꿔 새 스키마 인스턴스로 확정할 수 있다
    (오인식 필드 교정 시나리오)."""

    draft = MockOCRService().extract("application.png")

    corrected_customer = draft.customer_profile.model_copy(update={"name_ko": "정정된이름"})
    corrected_transaction = draft.transaction_request.model_copy(
        update={"remittance_amount": "200000.00"}
    )

    assert corrected_customer.name_ko == "정정된이름"
    assert corrected_transaction.remittance_amount == "200000.00"
    # 원본 OCR 초안은 변경되지 않는다 (불변 데이터로 취급)
    assert draft.customer_profile.name_ko == "홍길동"
