"""SWIFT 조회 테스트 (섹션 37 - SWIFT)."""

from __future__ import annotations

from schemas.swift import SwiftLookupNotFound, SwiftLookupResult
from services.swift.service import SwiftService


def test_normal_bank_lookup():
    result = SwiftService().lookup("BKTRUS33XXX")
    assert isinstance(result, SwiftLookupResult)
    assert result.is_sanctioned is False
    assert result.bank_name == "CHASE BANK N.A."


def test_sanctioned_bank_lookup():
    result = SwiftService().lookup("SABRRU22XXX")
    assert isinstance(result, SwiftLookupResult)
    assert result.is_sanctioned is True
    assert result.sanction_reason


def test_8_digit_bic_resolves_to_11_digit_record():
    """8자리 BIC 입력 시 LIKE Prefix 검색으로 11자리 Branch Code까지 조회된다."""

    result = SwiftService().lookup("BKTRUS33")
    assert isinstance(result, SwiftLookupResult)
    assert result.swift_code == "BKTRUS33XXX"


def test_11_digit_bic_exact_match():
    result = SwiftService().lookup("CITIUS33XXX")
    assert isinstance(result, SwiftLookupResult)
    assert result.swift_code == "CITIUS33XXX"


def test_unknown_swift_code_not_found():
    result = SwiftService().lookup("ZZZZZZZZZZZ")
    assert isinstance(result, SwiftLookupNotFound)
    assert result.found is False


def test_blank_swift_code_not_found():
    result = SwiftService().lookup("")
    assert isinstance(result, SwiftLookupNotFound)


def test_lookup_is_case_insensitive():
    result = SwiftService().lookup("bktrus33xxx")
    assert isinstance(result, SwiftLookupResult)
    assert result.swift_code == "BKTRUS33XXX"
