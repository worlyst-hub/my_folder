"""RAG Pipeline 테스트 (섹션 37 - RAG).

빌드/재색인이 필요한 테스트는 실제 개발 DB(data/fx_remittance.db)를 건드리지
않도록 격리된 SQLite DB(``conftest.make_isolated_get_session``)를 사용한다.
"""

from __future__ import annotations

import config.settings as config_settings

from services import embedding_client as embedding_client_module
from rag import retriever as retriever_module
from rag.chunker import chunk_pages, chunk_text
from rag.document_loader import PdfPage, find_regulation_pdfs, load_pdf_pages
from rag.retriever import RagRetriever

from .conftest import make_isolated_get_session


def test_chunker_splits_long_text_and_detects_article():
    long_text = ("가나다라마바사아자차카타파하 " * 60) + "제5-11조 규정 내용입니다."
    chunks = chunk_text(long_text, page_number=3, max_chars=200, overlap=50)

    assert len(chunks) > 1
    assert any(c.article == "제5-11조" for c in chunks)
    assert all(c.page_number == 3 for c in chunks)


def test_chunker_short_text_returns_single_chunk():
    chunks = chunk_text("짧은 텍스트입니다.", page_number=1)
    assert len(chunks) == 1
    assert chunks[0].page_number == 1


def test_hierarchical_chunker_preserves_parent_and_splits_children():
    pages = [
        PdfPage(
            file_name="법령.pdf",
            page_number=1,
            text=(
                "제1조(목적) 이 법의 목적입니다.\n"
                "① 첫 번째 항입니다. " + ("가나다라 " * 40) + "\n"
                "② 두 번째 항입니다. " + ("마바사아 " * 40)
            ),
        )
    ]

    chunks = chunk_pages(
        pages,
        source_name="법령.pdf",
        max_chars=180,
        min_chars=60,
        overlap=20,
    )

    assert len(chunks) > 1
    assert {chunk.parent_id for chunk in chunks} == {chunks[0].parent_id}
    assert all(chunk.article == "제1조" for chunk in chunks)
    assert all(chunk.parent_content == chunks[0].parent_content for chunk in chunks)
    assert all(len(chunk.content) <= 180 for chunk in chunks)
    assert "① 첫 번째 항" in chunks[0].parent_content
    assert "② 두 번째 항" in chunks[0].parent_content


def test_hierarchical_chunker_keeps_article_across_pages():
    pages = [
        PdfPage(
            file_name="법령.pdf",
            page_number=1,
            text="제5-11조(사용료)\n① 첫 페이지에서 시작하는 내용입니다.",
        ),
        PdfPage(
            file_name="법령.pdf",
            page_number=2,
            text="첫 조문의 계속 내용입니다.\n② 두 번째 항입니다.\n제5-12조(다음 조문)\n① 다음 조문입니다.",
        ),
    ]

    chunks = chunk_pages(pages, source_name="법령.pdf", max_chars=120, min_chars=30, overlap=10)
    first_article = [chunk for chunk in chunks if chunk.article == "제5-11조"]
    second_article = [chunk for chunk in chunks if chunk.article == "제5-12조"]

    assert first_article
    assert second_article
    assert "첫 조문의 계속 내용입니다." in first_article[0].parent_content
    assert "제5-12조" not in first_article[0].parent_content


def test_document_loader_handles_invalid_pdf_gracefully(tmp_path):
    """텍스트 추출 실패(손상된 PDF)도 예외 없이 빈 결과를 반환한다."""

    bad_pdf = tmp_path / "broken.pdf"
    bad_pdf.write_bytes(b"not a real pdf")
    assert load_pdf_pages(bad_pdf) == []


def test_document_loader_finds_pdf_files(tmp_path):
    (tmp_path / "a.pdf").write_bytes(b"%PDF-1.4 fake")
    (tmp_path / "readme.md").write_text("not a pdf", encoding="utf-8")

    found = find_regulation_pdfs(tmp_path)
    assert [p.name for p in found] == ["a.pdf"]


def test_regulation_and_article_search_with_sample_flag(monkeypatch, tmp_path):
    """관련 법령 검색 + 관련 조문 검색: 샘플 모드에서 법령명/조문/출처가 채워진다.

    .env의 RAG_MODE(mock/pdf)와 무관하게 항상 mock(샘플 규정)을 쓰도록
    명시적으로 고정한다 - 실제 PDF가 등록된 환경에서도 이 테스트는 결정론적
    이어야 한다.
    """

    fake_settings = config_settings.Settings(
        chroma_persist_dir=str(tmp_path / "rag_chroma_sample"),
        rag_mode="mock",
    )
    monkeypatch.setattr(retriever_module, "get_settings", lambda: fake_settings)
    monkeypatch.setattr(embedding_client_module, "get_settings", lambda: fake_settings)
    monkeypatch.setattr(retriever_module, "get_session", make_isolated_get_session(tmp_path))

    retriever = RagRetriever()
    matches = retriever.search("해외부동산 취득 신고", top_k=3, regulation_tags=["REAL_ESTATE"])

    assert matches
    top = matches[0]
    assert top.law_name
    assert top.article
    assert top.is_sample is True
    assert top.file_name


def test_regulation_search_no_match_with_empty_index(monkeypatch, tmp_path):
    """검색 결과 없음: 색인할 문서가 없으면 빈 리스트를 반환한다."""

    fake_settings = config_settings.Settings(
        chroma_persist_dir=str(tmp_path / "rag_chroma_empty"),
        rag_mode="mock",
    )
    monkeypatch.setattr(retriever_module, "get_settings", lambda: fake_settings)
    monkeypatch.setattr(embedding_client_module, "get_settings", lambda: fake_settings)
    monkeypatch.setattr(retriever_module, "get_session", make_isolated_get_session(tmp_path))
    monkeypatch.setattr(retriever_module.RagRetriever, "_store_sample_chunks", lambda self: [])

    retriever = RagRetriever()
    assert retriever.search("아무 의미 없는 질의") == []


def test_pdf_mode_preserves_page_and_file_citation(monkeypatch, tmp_path):
    """PDF 출처/페이지 표시: PDF 모드로 색인하면 페이지 번호와 파일명이 검색 결과에 보존된다."""

    fake_settings = config_settings.Settings(
        chroma_persist_dir=str(tmp_path / "rag_chroma_pdf"),
        rag_mode="pdf",
        regulation_pdf_dir=str(tmp_path / "regs"),
    )
    monkeypatch.setattr(retriever_module, "get_settings", lambda: fake_settings)
    monkeypatch.setattr(embedding_client_module, "get_settings", lambda: fake_settings)
    monkeypatch.setattr(retriever_module, "get_session", make_isolated_get_session(tmp_path))

    fake_pages = [
        PdfPage(
            file_name="외국환거래규정.pdf",
            page_number=35,
            text="제5-11조 지식재산권 사용료 지급 관련 내용입니다. " * 3,
        )
    ]
    monkeypatch.setattr(retriever_module, "load_all_regulation_pdfs", lambda _dir: fake_pages)

    retriever = RagRetriever()
    matches = retriever.search("지식재산권 사용료 지급")

    assert matches
    top = matches[0]
    assert top.file_name == "외국환거래규정.pdf"
    assert top.page_number == 35
    assert top.is_sample is False
    assert top.article == "제5-11조"
