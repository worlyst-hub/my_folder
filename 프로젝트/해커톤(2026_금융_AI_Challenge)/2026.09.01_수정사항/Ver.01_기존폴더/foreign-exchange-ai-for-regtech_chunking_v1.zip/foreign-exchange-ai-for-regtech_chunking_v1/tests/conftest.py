"""pytest 공용 fixture.

프로토타입은 SQLite 파일 DB를 그대로 사용하며, 테스트 세션 시작 시 테이블
생성과 Mock 데이터(사유코드/SWIFT) 시딩을 보장한다.
"""

from __future__ import annotations

import contextlib

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from database.connection import Base
from database.seed import run as seed_run


@pytest.fixture(scope="session", autouse=True)
def _seeded_database():
    seed_run(reset=False)
    yield


def make_isolated_get_session(tmp_path):
    """테스트 전용 격리 SQLite DB에 바인딩된 ``get_session`` 대체 함수를 만든다.

    RagRetriever.build_index() 처럼 SQL 테이블을 삭제/재적재하는 로직을
    테스트할 때, 실제 개발용 DB(data/fx_remittance.db)를 건드리지 않도록
    ``monkeypatch.setattr(<module>, "get_session", make_isolated_get_session(tmp_path))``
    형태로 사용한다.
    """

    db_path = tmp_path / "isolated_test.db"
    engine = create_engine(f"sqlite:///{db_path}", connect_args={"check_same_thread": False})

    from database import models  # noqa: F401  - 모델을 등록해야 create_all이 테이블을 만든다

    Base.metadata.create_all(bind=engine)
    isolated_session_factory = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

    @contextlib.contextmanager
    def _get_session():
        session = isolated_session_factory()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    return _get_session
