"""사유코드 Vector Search 테스트 (섹션 37 - 사유코드).

임의의 숫자 가중치 점수식을 쓰지 않는다는 원칙(섹션 12)에 따라, 여기서는
Embedding 유사도 기반 Top-K 검색이 그럴듯한 후보를 반환하는지만 검증한다.
"""

from __future__ import annotations

from services.reason_code import mapper as mapper_module
from services.reason_code.mapper import ReasonCodeMapper, build_required_documents_result
from services import embedding_client as embedding_client_module


def test_clear_purpose_returns_matching_top_candidate():
    """명확한 거래 목적: 해외부동산 취득 문맥이 부동산 관련 사유코드를 1순위로 반환한다."""

    mapper = ReasonCodeMapper()
    candidates = mapper.search("해외 주택 구매 목적으로 계약금 송금하려고 함", top_k=5)

    assert candidates
    assert "부동산" in candidates[0].reason_code.name or "REAL_ESTATE" in candidates[0].reason_code.regulation_tags


def test_similar_purpose_matches_study_abroad_category():
    """유사 거래 목적: 표현이 달라도(등록금/학비) 유학 관련 사유코드가 후보에 포함된다."""

    mapper = ReasonCodeMapper()
    candidates = mapper.search("미국 대학교 등록금 납부 목적의 송금", top_k=5)

    codes_and_names = [(c.reason_code.code, c.reason_code.name) for c in candidates]
    assert any("유학" in name or "학비" in name for _, name in codes_and_names)


def test_multiple_candidates_are_distinct():
    """복수 후보: Top-K 검색은 서로 다른 사유코드를 여러 건 반환한다."""

    mapper = ReasonCodeMapper()
    candidates = mapper.search("수입 물품대금 결제", top_k=5)

    assert len(candidates) >= 2
    codes = [c.reason_code.code for c in candidates]
    assert len(set(codes)) == len(codes)  # 중복 없음
    for c in candidates:
        assert 0.0 <= c.score <= 1.0


def test_no_match_when_reason_code_table_is_empty(monkeypatch, tmp_path):
    """매칭 결과 없음: 사유코드가 하나도 없으면 검색 결과도 빈 리스트다."""

    class _FakeResult:
        def scalars(self):
            return self

        def all(self):
            return []

    class _FakeSession:
        def execute(self, *_args, **_kwargs):
            return _FakeResult()

    class _FakeSessionCtx:
        def __enter__(self):
            return _FakeSession()

        def __exit__(self, *_exc):
            return False

    import config.settings as config_settings

    fake_settings = config_settings.Settings(chroma_persist_dir=str(tmp_path / "chroma_empty_test"))

    monkeypatch.setattr(mapper_module, "get_session", lambda: _FakeSessionCtx())
    monkeypatch.setattr(mapper_module, "get_settings", lambda: fake_settings)
    monkeypatch.setattr(embedding_client_module, "get_settings", lambda: fake_settings)

    mapper = ReasonCodeMapper()
    count = mapper.build_index(force=True)

    assert count == 0
    assert mapper.search("아무 의미 없는 질의") == []


def test_required_documents_result_from_reason_code():
    mapper = ReasonCodeMapper()
    candidates = mapper.search("해외 주택 구매 목적으로 계약금 송금하려고 함", top_k=1)
    result = build_required_documents_result(candidates[0].reason_code)

    assert result.items
    assert all(item.checked is False for item in result.items)
