#!/usr/bin/env bash
#
# FIXAR(ForeIgn eXchange AI for RegTech) - 원클릭 셋업 스크립트 (macOS/Linux 전용).
#
# setup.ps1(Windows)과 동일한 절차를 macOS/Linux에서 수행합니다:
#   1. 가상환경(fixar/) 생성 (없으면)
#   2. requirements.txt 설치 (Python 패키지: Streamlit 등)
#   3. .env 생성 (없으면 .env.example 복사)
#   4. 로컬 Ollama 설치 확인 - 없으면 설치 여부를 물어보고, 동의 시 공식
#      설치 스크립트 실행 (Ollama는 Python 패키지가 아니라 시스템
#      프로그램이라 requirements.txt로는 설치할 수 없습니다)
#   5. 임베딩 모델(.env의 OLLAMA_EMBED_MODEL, 기본 bge-m3) pull
#      - .env에서 LLM_MODE=live면 OLLAMA_MODEL도, OCR_MODE=vision이면
#        OLLAMA_VISION_MODEL도 같이 pull합니다(기본값 mock/mock이면
#        건너뜁니다 - 무거운 모델을 불필요하게 받지 않기 위함).
#   6. DB 초기화 + Mock 데이터(사유코드 100건/SWIFT 마스터) 시딩
#
# 사용법:
#   ./setup.sh
#   ./setup.sh --skip-ollama   # Ollama 설치/모델 pull 단계를 건너뜁니다 (Python 쪽만 셋업)
#   ./setup.sh --yes           # 확인 프롬프트 없이 진행합니다 (Ollama 설치 여부도 자동 "예")
#
# 파이썬 버전: 이 저장소는 특정 Python 버전을 고정하지 않습니다 - 아래
# `python3` 명령이 PATH에서 찾는 버전을 그대로 사용해 fixar/ 가상환경을
# 만듭니다. macOS/Linux에 Python 3.10 이상이 설치되어 있는지 미리
# 확인해주세요 (`python3 --version`).

set -euo pipefail

SKIP_OLLAMA=false
YES=false
for arg in "$@"; do
    case "$arg" in
        --skip-ollama) SKIP_OLLAMA=true ;;
        --yes|-y) YES=true ;;
        *)
            echo "알 수 없는 옵션: $arg (사용 가능: --skip-ollama, --yes)" >&2
            exit 1
            ;;
    esac
done

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_ROOT"

CYAN='\033[0;36m'
YELLOW='\033[1;33m'
GREEN='\033[0;32m'
NC='\033[0m'

step() {
    echo ""
    echo -e "${CYAN}==> $1${NC}"
}

confirm() {
    if [ "$YES" = true ]; then
        return 0
    fi
    read -r -p "$1 (y/N) " answer
    [[ "$answer" =~ ^[Yy]$ ]]
}

# ---------------------------------------------------------------------------
# 1. 가상환경 (fixar/)
# ---------------------------------------------------------------------------
step "가상환경 확인 (fixar/)"
VENV_PYTHON="$PROJECT_ROOT/fixar/bin/python"
if [ ! -f "$VENV_PYTHON" ]; then
    echo "fixar/ 가상환경이 없어 새로 만듭니다 (python3 $(python3 --version 2>&1 | awk '{print $2}'))..."
    python3 -m venv fixar
else
    echo "이미 존재합니다: $VENV_PYTHON ($("$VENV_PYTHON" --version 2>&1))"
fi

# ---------------------------------------------------------------------------
# 2. Python 의존성 설치
# ---------------------------------------------------------------------------
step "Python 패키지 설치 (requirements.txt), 시간이 걸릴 수 있습니다"
"$VENV_PYTHON" -m pip install --upgrade pip -q
"$VENV_PYTHON" -m pip install -r requirements.txt

# ---------------------------------------------------------------------------
# 3. .env
# ---------------------------------------------------------------------------
step ".env 확인"
ENV_PATH="$PROJECT_ROOT/.env"
ENV_EXAMPLE_PATH="$PROJECT_ROOT/.env.example"
if [ ! -f "$ENV_PATH" ]; then
    cp "$ENV_EXAMPLE_PATH" "$ENV_PATH"
    echo ".env.example을 복사해 .env를 만들었습니다. 필요하면 값을 직접 채워주세요."
else
    echo "이미 존재합니다: $ENV_PATH (건드리지 않음)"
fi

# ---------------------------------------------------------------------------
# 4. 로컬 Ollama 설치 확인 (임베딩용 - 사유코드/RAG 검색)
# ---------------------------------------------------------------------------
if [ "$SKIP_OLLAMA" = false ]; then
    step "로컬 Ollama 확인 (임베딩 - 사유코드/RAG 검색에 사용)"
    if command -v ollama >/dev/null 2>&1; then
        echo "이미 설치되어 있습니다: $(command -v ollama)"
    else
        echo "Ollama가 설치되어 있지 않습니다."
        echo "(Ollama는 Python 패키지가 아니라 백그라운드 서비스가 딸린 시스템 프로그램이라,"
        echo " requirements.txt/pip로는 설치할 수 없어 별도로 공식 설치 스크립트를 실행합니다.)"
        if confirm "지금 Ollama를 설치할까요? (공식 설치 스크립트 실행, 시스템 변경 발생)"; then
            echo "Ollama 공식 설치 스크립트를 실행합니다..."
            curl -fsSL https://ollama.com/install.sh | sh
        else
            echo -e "${YELLOW}Ollama 설치를 건너뜁니다. 임베딩은 자동으로 경량 해시 기반 폴백을 사용합니다 (검색 품질만 낮아짐, 앱은 정상 동작).${NC}"
        fi
    fi

    # -----------------------------------------------------------------------
    # 5. 임베딩 모델 pull (.env의 OLLAMA_EMBED_MODEL, 기본 bge-m3)
    # -----------------------------------------------------------------------
    if command -v ollama >/dev/null 2>&1; then
        EMBED_MODEL="bge-m3"
        if [ -f "$ENV_PATH" ]; then
            line="$(grep '^OLLAMA_EMBED_MODEL=' "$ENV_PATH" || true)"
            if [ -n "$line" ]; then
                EMBED_MODEL="${line#OLLAMA_EMBED_MODEL=}"
            fi
        fi
        if [ -n "$EMBED_MODEL" ]; then
            step "임베딩 모델 pull: $EMBED_MODEL (이미 받았으면 바로 넘어감)"
            # macOS/Linux는 백그라운드 서비스로 `ollama serve`가 떠 있어야
            # pull이 됩니다. 로컬에 아직 안 떠 있으면 잠깐 띄웁니다.
            if ! curl -fsS http://localhost:11434/api/version >/dev/null 2>&1; then
                echo "로컬 Ollama 서버가 응답하지 않아 백그라운드로 띄웁니다 (ollama serve)..."
                nohup ollama serve >/tmp/ollama_serve.log 2>&1 &
                sleep 2
            fi
            ollama pull "$EMBED_MODEL"
        fi

        # -------------------------------------------------------------------
        # 5-1. LLM_MODE=live / OCR_MODE=vision이면 해당 모델도 pull
        #      (기본값 mock/mock이면 무거운 모델을 받지 않고 건너뜀)
        # -------------------------------------------------------------------
        env_value() {
            local key="$1" default="$2"
            local line
            line="$(grep "^${key}=" "$ENV_PATH" 2>/dev/null || true)"
            if [ -n "$line" ]; then echo "${line#${key}=}"; else echo "$default"; fi
        }
        if [ -f "$ENV_PATH" ] && [ "$(env_value LLM_MODE mock)" = "live" ]; then
            LLM_MODEL="$(env_value OLLAMA_MODEL gpt-oss:120b-cloud)"
            step "LLM_MODE=live 감지 - LLM 모델 pull: $LLM_MODEL"
            # -cloud 모델은 매니페스트만 받아 수 초 내로 끝나지만(가중치는
            # Ollama 서버에서 실행), Ollama Cloud 계정/API Key가 없으면
            # 인증 오류가 날 수 있다. 그래도 셋업 전체가 중단되지 않도록
            # 실패는 경고만 남기고 계속 진행한다(set -e 우회).
            if ! ollama pull "$LLM_MODEL"; then
                echo -e "${YELLOW}LLM 모델 pull 실패: $LLM_MODEL (Ollama Cloud 계정/OLLAMA_API_KEY를 확인하세요. .env를 llama3.1 + 로컬로 바꾸면 무료로 쓸 수 있습니다 - .env.example 주석 참고)${NC}"
            fi
        fi
        if [ -f "$ENV_PATH" ] && [ "$(env_value OCR_MODE mock)" = "vision" ]; then
            VISION_MODEL="$(env_value OLLAMA_VISION_MODEL qwen2.5vl)"
            step "OCR_MODE=vision 감지 - Vision 모델 pull: $VISION_MODEL"
            if ! ollama pull "$VISION_MODEL"; then
                echo -e "${YELLOW}Vision 모델 pull 실패: $VISION_MODEL (네트워크/디스크 용량을 확인하세요)${NC}"
            fi
        fi
    fi
else
    echo -e "\n${YELLOW}(--skip-ollama 지정됨 - Ollama 설치/모델 pull 단계 건너뜀)${NC}"
fi

# ---------------------------------------------------------------------------
# 6. DB 초기화 + Mock 데이터 시딩
# ---------------------------------------------------------------------------
step "DB 초기화 + Mock 데이터 시딩 (사유코드 100건 + SWIFT 마스터)"
"$VENV_PYTHON" -m database.seed

# ---------------------------------------------------------------------------
step "셋업 완료"
echo -e "${GREEN}다음 명령으로 앱을 실행하세요:${NC}"
echo "  fixar/bin/streamlit run app.py"
echo ""
