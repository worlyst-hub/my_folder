"""화면 8 - 고객 데이터.

당행에 이미 등록되어 있는 고객 마스터(``RegisteredCustomerMaster``, Mock
100건 - ``data/generate_registered_customers.py``로 생성, ``database.seed``가
적재)를 조회 전용으로 보여준다. ⑦ 처리 로그와 마찬가지로 마법사(①~⑥)
순번이 아니라 언제든 들어가는 별도 화면이다.

주의: 이건 신청서 OCR로 매번 새로 생기는 ``customer_profile``(거래 처리
이력)이 아니다 - 은행이 사전에 보유한 고정 고객 목록이며,
``services/system_lookup``이 ②단계 거래정보 확정 시 이 목록에서 신청서의
식별번호를 조회해 신용등급/송금한도를 판단하는 데 쓴다.

식별번호처럼 민감한 정보는 화면에 일부만 보여주고 나머지는 마스킹한다.
"""

from __future__ import annotations

import pandas as pd
import streamlit as st

from database.connection import get_session
from database.models import RegisteredCustomerMaster as CustomerMasterORM
from frontend import theme
from utils.labels import (
    CUSTOMER_TYPE_LABELS,
    DESIGNATED_BANK_STATUS_LABELS,
    RESIDENCE_STATUS_LABELS,
    label,
)

_COLUMNS = [
    "식별번호", "성명", "고객유형", "거주자구분", "신용등급",
    "연간한도(USD)", "연간누계액(USD)", "한도사용률", "지정거래은행",
    "기존지정목적", "체납여부", "등록일",
]


def _mask_tail(value: str, keep: int) -> str:
    """앞 ``keep``자리만 남기고 나머지를 ``*``로 가린다(주민/사업자번호용)."""

    if len(value) <= keep:
        return value
    return value[:keep] + "*" * (len(value) - keep)


def _load_registered_customers() -> list[dict]:
    """등록 고객 마스터를 신용등급순으로 읽어 화면 표시용 dict 목록으로 변환한다."""

    with get_session() as session:
        rows = (
            session.query(CustomerMasterORM)
            .order_by(CustomerMasterORM.credit_rating.asc(), CustomerMasterORM.name_ko.asc())
            .all()
        )
        records = []
        for row in rows:
            usage_pct = (
                float(row.annual_accumulated_usd / row.annual_remittance_limit_usd) * 100
                if row.annual_remittance_limit_usd else 0
            )
            records.append(
                {
                    "id": row.id,
                    "식별번호": _mask_tail(row.identification_no, 8),
                    "성명": row.name_ko + (f" ({row.name_eng})" if row.name_eng else ""),
                    "고객유형": label(CUSTOMER_TYPE_LABELS, row.customer_type),
                    "거주자구분": label(RESIDENCE_STATUS_LABELS, row.residence_status),
                    "신용등급": str(row.credit_rating),
                    "연간한도(USD)": f"{row.annual_remittance_limit_usd:,.0f}",
                    "연간누계액(USD)": f"{row.annual_accumulated_usd:,.0f}",
                    "한도사용률": f"{usage_pct:.0f}%" + (" ⚠️" if usage_pct >= 100 else ""),
                    "지정거래은행": label(DESIGNATED_BANK_STATUS_LABELS, row.designated_bank_status),
                    "기존지정목적": row.designated_purpose or "-",
                    "체납여부": "⚠️ 해당" if row.is_delinquent_borrower else "해당없음",
                    "등록일": row.registered_since.isoformat() if row.registered_since else "-",
                }
            )
        return records


def render() -> None:
    theme.widen_main_container()
    with st.container(border=True, key="fx_card_customers"):
        theme.section_title("👤", "고객 데이터", "당행 등록 고객 마스터(신용등급 · 송금한도 참고용, Mock)를 조회합니다.")

        st.caption(
            "실제 은행 Core DB 연동이 아닌 프로토타입 시연용 Mock 데이터(100건)입니다. "
            "②단계에서 거래정보를 확정할 때 신청서의 식별번호가 여기 있으면 신용등급/송금한도를 "
            "참고 정보로 보여주고, 없으면 당행 미등록/신규 고객으로 취급합니다."
        )

        records = _load_registered_customers()

        if not records:
            st.info(
                "등록된 고객 마스터 데이터가 없습니다. "
                "`python -m database.seed` 를 실행하면 채워집니다."
            )
            return

        df = pd.DataFrame.from_records(records)[_COLUMNS]

        # 주민번호(개인)와 사업자번호(법인)는 자릿수/형식이 아예 달라서,
        # "식별번호" 컬럼 헤더를 눌러 정렬하면 두 형식이 섞여 보기 어렵다 -
        # 정렬 전에 고객유형으로 먼저 좁혀볼 수 있게 필터를 둔다.
        type_filter = st.radio(
            "고객유형 필터", ["전체", "개인", "법인"], index=0, horizontal=True
        )
        base_df = df if type_filter == "전체" else df[df["고객유형"] == type_filter]

        # SWIFT 조회 화면과 같은 레이아웃(입력창이 남는 공간을 채우고,
        # "조회" 버튼은 같은 크기로 우측 끝에 고정) - key는 화면마다 검색
        # 박스가 하나뿐이라 다른 화면(처리 로그)과 공유해도 안전하다.
        with st.container(key="fx_search_row"):
            with st.form("fx_customer_search_form", border=False):
                col_q, col_btn = st.columns([5, 1])
                with col_q:
                    query = st.text_input(
                        "검색",
                        placeholder="식별번호·성명·고객유형·거주자구분·신용등급으로 검색",
                        label_visibility="collapsed",
                    )
                with col_btn:
                    st.form_submit_button("조회", type="primary", key="fx_search_btn")

        type_label = "" if type_filter == "전체" else f" · {type_filter}만"
        if query:
            mask = pd.Series(False, index=base_df.index)
            for col in _COLUMNS:
                mask |= base_df[col].astype(str).str.contains(query, case=False, na=False, regex=False)
            filtered = base_df[mask]
            st.caption(f"총 {len(base_df)}건{type_label} 중 {len(filtered)}건 검색됨")
        else:
            filtered = base_df
            st.caption(f"총 {len(filtered)}건{type_label}")

        if filtered.empty:
            st.info(
                f"\"{query}\"와(과) 일치하는 고객 데이터가 없습니다." if query
                else "조건에 맞는 고객 데이터가 없습니다."
            )
        else:
            st.dataframe(
                filtered, use_container_width=True, hide_index=True
            )

        st.caption("※ 식별번호는 일부만 표시됩니다(마스킹).")
