"""공통 디자인 테마.

은행 내부 업무 시스템 느낌의 카드형 레이아웃(하나은행 CI 그린 사이드바 +
화이트 카드)을 Streamlit 기본 컴포넌트 위에 CSS로 입힌다. 실제 셀렉터는
Streamlit의 내부 ``data-testid`` 를 대상으로 하므로, Streamlit 버전이 크게
바뀌면 일부 셀렉터를 다시 확인해야 할 수 있다 (설치된 버전: streamlit>=1.38,
확인:1.62).

색상은 하나은행의 공식 브랜드 가이드 문서를 직접 확인한 것이 아니라 일반적으로
알려진 하나은행 CI 그린 톤으로 근사한 것이다. 정확한 공식 헥스코드가 있으면
``--brand`` 계열 변수만 바꾸면 된다.
"""

from __future__ import annotations

import streamlit as st

_CSS = """
<style>
:root{
  /* 하나은행 CI 그린 근사 팔레트 */
  --brand:#008485; --brand-dark:#00453D; --brand-darker:#013129; --brand-mid:#0F6E5F;
  --brand-light:#E5F4F1; --brand-light-border:#BFE0D8; --brand-light-text:#04594F;
  --ink:#172033; --muted:#68748a;
  --line:#dce3ed; --bg:#f3f6fa; --green:#16865c; --amber:#b16b00; --red:#dc2626;
}

/* 하나은행 서체(Hana2)는 .streamlit/config.toml의 [[theme.fontFaces]] +
   [theme].font 로 Streamlit 앱 전체 기본 폰트로 등록되어 있다. 여기서는
   우리가 직접 만든 커스텀 HTML(사이드바, 카드 헤더 등)에도 동일하게
   적용되도록 폰트 패밀리명을 맞춰서 한 번 더 명시한다. */
/* 이모지(🤖, 🔎 등)는 하나체(Hana2)에 글리프가 없어 깨진 대체 글리프로
   보인다. body 하나에만 걸면 안 되는 게, Streamlit이 h1~h6 등 요소에
   font-family: hana2, "Source Sans", sans-serif 를 직접(상속이 아니라)
   지정해버려서 - 직접 지정된 값은 상속보다 항상 우선하므로 !important를
   건 body 규칙조차 못 이긴다. 그래서 전체 요소(*)에 이모지 폴백 폰트를
   포함해 직접 강제한다. 다만 Streamlit 아이콘(사이드바 화살표, 알림
   아이콘 등)과 우리가 만든 .fx-notice-icon은 "Material Symbols Rounded"
   리거처 폰트로 글자 텍스트를 아이콘 모양으로 그리는 방식이라, 여기 걸리면
   아이콘이 깨지므로 별도로 그 폰트를 다시 지정해 제외한다. */
* {
  font-family: "hana2", "Noto Sans KR", "Segoe UI Emoji", "Apple Color Emoji",
    "Noto Color Emoji", Arial, sans-serif !important;
}
[data-testid="stIconMaterial"], [data-testid="stAlertDynamicIcon"], .fx-notice-icon {
  font-family: "Material Symbols Rounded" !important;
}

/* 전체 배경 (테스트id는 태그가 버전마다 달라질 수 있어 태그명을 지정하지 않는다) */
[data-testid="stAppViewContainer"], [data-testid="stMain"] { background: var(--bg); }
[data-testid="stMainBlockContainer"] { padding-top: 1.8rem; padding-bottom: 3rem; max-width: 1200px; }
[data-testid="stHeader"] { background: transparent; }

/* 사이드바 */
section[data-testid="stSidebar"] { background: var(--brand-dark); }
section[data-testid="stSidebar"] > div { padding-top: 1.2rem; }
section[data-testid="stSidebar"] * { color: #CFE7E1; }
section[data-testid="stSidebar"] hr { border-color: #0B5347; }

/* 사이드바 네비게이션 버튼 - 화면 여유가 있어 글자를 넉넉하게 키운다 */
section[data-testid="stSidebar"] [data-testid="stButton"] button {
  background: transparent !important; border: 0 !important; box-shadow: none !important;
  text-align: left; justify-content: flex-start; color: #AFD6CD !important;
  font-weight: 600; border-radius: 8px !important; padding: 13px 14px !important; width: 100%;
}
section[data-testid="stSidebar"] [data-testid="stButton"] button:hover:not(:disabled) {
  background: var(--brand-darker) !important; color: white !important;
}
section[data-testid="stSidebar"] [data-testid="stButton"] button:disabled {
  opacity: 0.4 !important; cursor: default; color: #AFD6CD !important;
}
section[data-testid="stSidebar"] [data-testid="stButton"] button p { font-size: 16px; margin: 0; }

/* 카드: st.container(border=True, key="fx_card_...")로 만든 컨테이너만 대상으로 한다.
   Streamlit 버전에 따라 바뀌는 내부 testid/emotion 클래스에 의존하지 않고,
   우리가 직접 지정한 key(-> "st-key-<key>" 클래스)만 신뢰한다. */
[class*="st-key-fx_card"] {
  background: white !important; border: 1px solid var(--line) !important;
  border-radius: 12px !important; box-shadow: 0 2px 8px rgba(0,69,61,0.06);
}

/* 메인 영역 버튼. st.form_submit_button(type="primary")은 일반
   st.button(type="primary")과 testid가 달라서(stBaseButton-primaryFormSubmit)
   두 testid를 모두 선택해야 폼 안의 제출 버튼도 같은 색으로 나온다. */
[data-testid="stMain"] button[data-testid="stBaseButton-primary"],
[data-testid="stMain"] button[data-testid="stBaseButton-primaryFormSubmit"] {
  background: var(--brand); border-color: var(--brand); border-radius: 7px; font-weight: 700; color: white;
}
[data-testid="stMain"] button[data-testid="stBaseButton-primary"]:hover,
[data-testid="stMain"] button[data-testid="stBaseButton-primaryFormSubmit"]:hover {
  background: var(--brand-mid); border-color: var(--brand-mid);
}
[data-testid="stMain"] button[data-testid="stBaseButton-secondary"] {
  border-radius: 7px; border-color: var(--line); color: var(--ink); font-weight: 700; background: white;
}
[data-testid="stMain"] button[data-testid="stBaseButton-secondary"]:hover:not(:disabled) {
  border-color: var(--brand); color: var(--brand);
}

/* OCR 결과 화면의 이전/다음 버튼 - 다른 화면의 primary 버튼(예: "AI 거래
   문맥 분석 시작")과 동일한 브랜드 그린으로 통일. "이전" 버튼 컨테이너는
   margin-top:auto로 좌측 열(원본 미리보기) 안에서 맨 아래로 밀어붙여,
   우측 열 맨 아래에 있는 "다음"(form_submit_button)과 높이를 맞춘다 -
   Streamlit의 컬럼은 같은 행에서 높이가 늘어나므로(stretch) 가능하다. */
.st-key-fx_ocr_next button[data-testid="stBaseButton-primaryFormSubmit"],
.st-key-fx_ocr_prev button[data-testid="stBaseButton-secondary"] {
  background: var(--brand) !important; border-color: var(--brand) !important; color: white !important;
}
.st-key-fx_ocr_next button[data-testid="stBaseButton-primaryFormSubmit"]:hover,
.st-key-fx_ocr_prev button[data-testid="stBaseButton-secondary"]:hover:not(:disabled) {
  background: var(--brand-mid) !important; border-color: var(--brand-mid) !important; color: white !important;
}
.st-key-fx_ocr_prev { margin-top: auto; }
/* "다음"은 폼 안에서 자연스럽게 왼쪽에 붙으므로, 컨테이너를 폭 전체로
   펼친 뒤 그 안에서 오른쪽 끝으로 밀어 카드 우측 끝에 맞춘다(법령 화면의
   fx_reg_next와 동일한 방식 - 버튼 자체 크기는 그대로 유지). */
.st-key-fx_ocr_next {
  width: 100% !important; display: flex !important; justify-content: flex-end !important;
}
.st-key-fx_ocr_next > div { width: auto !important; }

/* 법령·필요서류 화면의 "다음" - 둘 다 type="primary"라 색은 이미 기본
   규칙(var(--brand))으로 통일되어 있고, 버튼 자체 크기는 그대로 두고
   wrapper만 오른쪽 끝에 붙여서 카드 우측 끝에 맞춘다("이전"은 기본
   정렬이 이미 왼쪽 끝이라 손댈 필요 없음). */
.st-key-fx_reg_next {
  width: 100% !important; display: flex !important; justify-content: flex-end !important;
}
.st-key-fx_reg_next [data-testid="stButton"] { width: auto !important; }

/* SWIFT 조회 화면의 이전/다음도 동일한 방식(버튼 크기 유지 + 우측 정렬). */
.st-key-fx_swift_next {
  width: 100% !important; display: flex !important; justify-content: flex-end !important;
}
.st-key-fx_swift_next [data-testid="stButton"] { width: auto !important; }

/* SWIFT BIC 입력창 옆 "조회" 버튼도 크기는 이전/다음과 동일하게 두고,
   자신이 속한 좁은 열의 오른쪽 끝(= 카드 우측 끝)으로 밀어붙인다.
   form_submit_button이라 stButton이 아니라 바로 아래 div가 wrapper다
   (fx_ocr_next와 동일한 구조). */
.st-key-fx_swift_lookup {
  width: 100% !important; display: flex !important; justify-content: flex-end !important;
}
.st-key-fx_swift_lookup > div { width: auto !important; }

/* 검색창 옆 "조회" 버튼 공용 레이아웃(처리 로그 ⑦ / 고객 데이터 ⑧) -
   입력창은 남는 공간을 채우고(flex-grow) 버튼은 크기 그대로 우측 끝에
   붙는다(SWIFT 조회 화면의 fx_swift_bic_row/fx_swift_lookup과 동일한
   방식). 화면마다 검색창이 하나뿐이라 이 키를 여러 화면이 공유해도
   안전하다(같은 스크립트 실행에서 한 화면만 렌더링되므로 충돌 없음). */
.st-key-fx_search_row [data-testid="stHorizontalBlock"] { gap: 0.5rem !important; }
.st-key-fx_search_row [data-testid="stHorizontalBlock"] > [data-testid="stColumn"]:first-child {
  flex: 1 1 auto !important; width: auto !important; min-width: 0 !important;
}
.st-key-fx_search_row [data-testid="stHorizontalBlock"] > [data-testid="stColumn"]:last-child {
  flex: 0 0 auto !important; width: auto !important;
}
.st-key-fx_search_btn {
  width: 100% !important; display: flex !important; justify-content: flex-end !important;
}
.st-key-fx_search_btn > div { width: auto !important; }

/* SWIFT BIC 입력창은 남는 공간을 전부 채우도록(flex-grow) 늘리고, "조회"
   버튼 열은 버튼 크기만큼만 차지하도록(flex-shrink-to-content) 줄여서
   둘 사이에 빈 틈이 안 남게 한다 - 위 fx_swift_lookup의 우측 정렬 규칙과
   같이 써서 버튼은 카드 우측 끝, 입력창은 그 바로 앞까지 이어지게 한다. */
.st-key-fx_swift_bic_row [data-testid="stHorizontalBlock"] {
  gap: 0.5rem !important;
}
.st-key-fx_swift_bic_row [data-testid="stHorizontalBlock"] > [data-testid="stColumn"]:first-child {
  flex: 1 1 auto !important; width: auto !important; min-width: 0 !important;
}
.st-key-fx_swift_bic_row [data-testid="stHorizontalBlock"] > [data-testid="stColumn"]:last-child {
  flex: 0 0 auto !important; width: auto !important;
}

/* 비활성 버튼: Streamlit이 disabled 상태에서는 primary도 secondary 스타일로
   내려버려서, primary/secondary 규칙과 무관하게 항상 회색으로 보이도록
   별도 규칙을 :disabled 전용으로 둔다 (특이도를 위해 위 규칙들과 동일하게
   button[data-testid=...] 형태를 함께 명시). */
[data-testid="stMain"] button:disabled,
[data-testid="stMain"] button[data-testid="stBaseButton-primary"]:disabled,
[data-testid="stMain"] button[data-testid="stBaseButton-secondary"]:disabled {
  background: #eef1f5 !important; border-color: #dde3ea !important;
  color: #a3adbd !important; cursor: not-allowed; font-weight: 600;
}

/* 입력 요소 (포커스 시 기본 하늘색 테두리 대신 브랜드 그린).
   Streamlit 기본 배경(#F0F2F6 회색)은 입력 가능한 필드도 비활성처럼
   보이게 해서, 수정 가능하다는 걸 분명히 하려고 흰 배경으로 덮어쓴다.
   실제로 disabled=True인 필드(예: 거래 문맥 분석 화면의 원문 참고용
   텍스트)는 아래 :disabled 규칙에서 다시 회색으로 되돌려 구분한다. */
[data-testid="stTextInput"] input, [data-testid="stTextArea"] textarea,
[data-testid="stNumberInput"] input {
  border-radius: 7px !important; border: 1px solid #ced7e4 !important;
  background: white !important; color: var(--ink) !important;
}
[data-testid="stTextInput"]:focus-within input, [data-testid="stTextArea"]:focus-within textarea,
[data-testid="stNumberInput"]:focus-within input {
  border-color: var(--brand) !important; box-shadow: 0 0 0 1px var(--brand) !important;
}
[data-testid="stTextInput"] input:disabled, [data-testid="stTextArea"] textarea:disabled,
[data-testid="stNumberInput"] input:disabled {
  background: #eef1f5 !important; color: #8b93a3 !important;
  -webkit-text-fill-color: #8b93a3 !important; opacity: 1 !important;
}
[data-testid="stSelectbox"] > div > div { border-radius: 7px !important; border: 1px solid #ced7e4 !important; background: white !important; }
[data-testid="stSelectbox"]:focus-within > div > div {
  border-color: var(--brand) !important; box-shadow: 0 0 0 1px var(--brand) !important;
}
[data-testid="stSelectbox"] div[aria-disabled="true"] { background: #eef1f5 !important; }

/* 체크박스/라디오(필요서류 체크, 사유코드 선택 등) 기본 하늘색 대신 브랜드 그린 */
input[type="checkbox"], input[type="radio"] { accent-color: var(--brand) !important; }

/* 헤딩 옆 "#" 앵커 링크 아이콘도 기본 하늘색이라 맞춘다 */
a[href^="#"] { color: var(--brand) !important; }

/* st.info() 안내 박스 - Streamlit 기본은 하늘색이라 브랜드 그린으로 덮어쓴다.
   success(초록)/warning(주황)/error(빨강)는 의미가 있는 색이라 그대로 둔다.
   실제로 눈에 보이는 배경은 안쪽(stAlertContentInfo)이 아니라 바깥쪽
   stAlertContainer가 그린다 - 안쪽만 덮으면 바깥쪽 하늘색이 테두리처럼
   비쳐 보이므로 둘 다 지정한다. :has()로 info 컨텐츠를 담은 컨테이너만
   골라서, success/warning/error 컨테이너는 건드리지 않는다. */
[data-testid="stAlertContainer"]:has([data-testid="stAlertContentInfo"]) {
  background: var(--brand-light) !important;
}
[data-testid="stAlertContentInfo"] {
  background: var(--brand-light) !important; color: var(--brand-light-text) !important;
  font-size: 12px !important;
}
[data-testid="stAlertContentInfo"] * { color: var(--brand-light-text) !important; font-size: 12px !important; }

/* 메트릭 */
[data-testid="stMetric"] { background: #f7f9fc; border-radius: 8px; padding: 10px 14px; }
[data-testid="stMetricLabel"] p { color: var(--muted) !important; font-size: 11px !important; }
[data-testid="stMetricValue"] { color: var(--ink); font-size: 16px; }

/* 진행률 바 */
[data-testid="stProgress"] div[role="progressbar"] > div { background: var(--green) !important; }

/* 섹션 헤더 (section_title 헬퍼) */
.fx-section-title{display:flex;gap:12px;align-items:flex-start;border-bottom:1px solid #edf0f5;padding-bottom:14px;margin-bottom:16px;}
.fx-section-title .fx-badge{width:31px;height:31px;border-radius:7px;background:var(--brand-light);color:var(--brand);display:grid;place-items:center;font-size:13px;font-weight:800;flex-shrink:0;}
.fx-section-title h2{margin:0;padding:0;font-size:17px;color:var(--ink);}
.fx-section-title p{margin:5px 0 0;color:var(--muted);font-size:12px;}

/* 사이드바 브랜드 / 정보 카드 - 화면 여유가 있어 글자를 넉넉하게 키운다 */
.fx-brand{display:flex;gap:12px;align-items:center;padding:0 4px 22px;}
.fx-brand-mark{display:grid;place-items:center;width:42px;height:42px;background:var(--brand);border-radius:10px;font-weight:800;color:white;flex-shrink:0;font-size:9px;letter-spacing:.2px;}
.fx-brand b{color:white;display:block;font-size:17px;}
.fx-brand small{color:#9CCAC0;font-size:13px;}

.fx-version-card{background:var(--brand-darker);border:1px solid #0B5347;border-radius:10px;padding:14px;display:flex;flex-direction:column;gap:10px;margin:14px 4px 0;}
.fx-version-card .fx-vc-row{display:flex;flex-direction:column;gap:2px;font-size:11px;color:#9CCAC0;letter-spacing:.3px;}
.fx-version-card .fx-vc-row b{color:white;font-weight:700;font-size:13px;line-height:1.4;word-break:break-word;}
.fx-version-card i{font-style:normal;color:#FFCF7A;font-size:11px;margin-top:6px;display:block;line-height:1.5;}

.fx-user{display:flex;gap:10px;align-items:center;border-top:1px solid #0B5347;margin:18px 4px 0;padding:16px 0 0;}
.fx-user span{width:34px;height:34px;background:var(--brand-mid);border-radius:50%;display:grid;place-items:center;flex-shrink:0;}
.fx-user b{color:white;font-size:14px;display:block;}
.fx-user small{color:#9CCAC0;font-size:13px;}

/* 페이지 상단 헤더 */
.fx-page-eyebrow{color:var(--brand);font-size:12px;font-weight:800;margin:0 0 4px;}
.fx-page-title{font-size:25px;margin:0;color:var(--ink);}

/* AI 참고정보 안내 배너 */
.fx-notice{display:flex;gap:14px;align-items:center;background:var(--brand-light);border:1px solid var(--brand-light-border);color:var(--brand-light-text);padding:12px 16px;border-radius:8px;font-size:16px;margin:18px 0;}
.fx-notice b{color:var(--brand-dark);}
/* st.info() 박스와 똑같은 원형 테두리 정보 아이콘(Material Symbols Rounded
   폰트의 "info" 리거처)을 그대로 재사용해 아이콘 스타일을 통일한다 -
   Streamlit이 이미 이 폰트를 전역으로 로드해두므로 폰트만 지정하면 된다. */
.fx-notice-icon{font-family:"Material Symbols Rounded";font-size:20px;line-height:1;flex-shrink:0;}
</style>
"""

_STEP_HEADERS: dict[int, tuple[str, str]] = {
    1: ("신청서 업로드", "외화송금신청서 처리"),
    2: ("OCR 결과 확인", "OCR 인식 결과 확인 · 수정"),
    3: ("거래 문맥 분석", "거래 문맥 분석 · 사유코드 확인"),
    4: ("법령 · 필요서류", "관련 법령 및 필요서류 확인"),
    5: ("SWIFT 조회", "수취은행 SWIFT · 제재 조회"),
    6: ("최종 처리 요약", "외환거래 처리 요약"),
    7: ("처리 로그", "처리 완료 거래 이력"),
    8: ("고객 데이터", "등록된 고객 정보 조회"),
    9: ("사유코드", "사유코드 마스터 조회"),
    10: ("지정목적코드", "지정목적코드 마스터 조회"),
}

# ①~⑥ 마법사 순번이 아니라, 사이드바에서 구분선 아래에 번호 없이 언제든
# 들어가는 조회 전용 화면들 (⑦ 처리 로그, ⑧ 고객 데이터, ⑨ 사유코드,
# ⑩ 지정목적코드).
_UTILITY_STEPS = {7, 8, 9, 10}


def inject_theme() -> None:
    st.markdown(_CSS, unsafe_allow_html=True)


def widen_main_container(max_width: str = "1600px") -> None:
    """이 함수를 호출한 화면에서만 메인 콘텐츠 폭 상한을 넓힌다(기본 1200px).

    Streamlit은 사이드바에서 다른 단계로 이동할 때마다 스크립트를 처음부터
    다시 실행하고 그 화면의 렌더 함수만 호출하므로, 여기서 넣는 `<style>`
    태그는 이 함수를 호출한 화면이 떠 있는 동안만 DOM에 존재한다 - 다른
    화면(마법사 ①~⑥)의 폭은 그대로 1200px로 남는다. 표(컬럼 수가 많은
    ⑦ 처리 로그 / ⑧ 고객 데이터)처럼 좁으면 내용이 심하게 잘리는 화면에서
    쓴다. 창을 좁히면 이 상한과 무관하게 뷰포트 폭에 맞춰 그대로 줄어든다
    (고정폭이 아니라 상한일 뿐이라, 표 셀은 여전히 말줄임표로 처리됨).
    """

    st.markdown(
        f'<style>[data-testid="stMainBlockContainer"] {{ max-width: {max_width} !important; }}</style>',
        unsafe_allow_html=True,
    )


def section_title(icon: str, title: str, subtitle: str | None = None) -> None:
    """카드 내부 섹션 제목을 번호/아이콘 배지가 있는 헤더로 렌더링한다."""

    subtitle_html = f"<p>{subtitle}</p>" if subtitle else ""
    st.markdown(
        f'<div class="fx-section-title"><div class="fx-badge">{icon}</div>'
        f"<div><h2>{title}</h2>{subtitle_html}</div></div>",
        unsafe_allow_html=True,
    )


def render_page_header(step: int) -> None:
    eyebrow, title = _STEP_HEADERS.get(step, ("", ""))
    st.markdown(
        f'<p class="fx-page-eyebrow">{eyebrow}</p><h1 class="fx-page-title">{title}</h1>',
        unsafe_allow_html=True,
    )


def render_notice() -> None:
    st.markdown(
        '<div class="fx-notice"><span class="fx-notice-icon">info</span><div>'
        "<b>이 화면의 AI 분석/검색 결과는 은행원의 업무 참고 정보입니다.</b><br>"
        "법률적 최종 판단과 송금 승인 여부는 은행원이 직접 결정합니다."
        "</div></div>",
        unsafe_allow_html=True,
    )


def render_sidebar(
    steps: list[tuple[int, str]], current_step: int, max_step_reached: int, mode_badges: list[tuple[str, str]]
) -> None:
    with st.sidebar:
        st.markdown(
            '<div class="fx-brand"><div class="fx-brand-mark">FIXAR</div>'
            "<div><b>FIXAR</b><small>외화송금신청서 처리 지원</small></div></div>",
            unsafe_allow_html=True,
        )

        # 현재 단계 행만 강조 (st.container(key=...)가 만들어주는 st-key-* 클래스를 이용).
        # 주의: 사이드바는 Streamlit 레이아웃상 항상 메인 영역보다 DOM에서
        # 먼저 나오기 때문에, 이 <style> 태그가 Python에서 inject_theme()
        # 보다 "나중에" 호출되어도 실제 문서 순서는 더 앞이 될 수 있다.
        # 그래서 소스 순서에 기대지 않고, 기본 규칙
        # (section[data-testid="stSidebar"] [data-testid="stButton"] button:disabled)
        # 보다 선택자 특이도를 한 단계 더 높여서(같은 체인 + 클래스) 항상
        # 이기도록 한다.
        st.markdown(
            f"<style>"
            f'section[data-testid="stSidebar"] .st-key-fx_nav_{current_step} [data-testid="stButton"] button, '
            f'section[data-testid="stSidebar"] .st-key-fx_nav_{current_step} [data-testid="stButton"] button:disabled '
            f"{{ background:#0F6E5F !important; color:white !important; opacity:1 !important; }}"
            f'section[data-testid="stSidebar"] .st-key-fx_nav_{current_step} [data-testid="stButton"] button p '
            f"{{ color:white !important; font-weight:700 !important; }}"
            f"</style>",
            unsafe_allow_html=True,
        )

        # 모든 단계를 자유롭게 오갈 수 있다. 아직 도달하지 못한 단계로 가면
        # 그 화면이 이전 단계 데이터가 없는 채로(빈 서식) 렌더링한다 - 예전엔
        # 안전장치가 앞 단계로 강제로 되돌려버려 "눌렀는데 딴 데로 튕기는"
        # 경험이라 막아뒀었지만, 실제로는 은행원이 정보를 미리 알고 있어
        # 특정 단계를 먼저 확인/입력하고 싶은 경우가 많아 각 화면 쪽의
        # 안전장치를 제거하고 이동 자체는 항상 허용하는 쪽으로 바꿨다.
        # 현재 위치("▶")만 눌러봐야 의미가 없으므로 비활성으로 둔다.
        #
        # "✅ 완료" 표시는 current_step(지금 보고 있는 화면 번호)이 아니라
        # max_step_reached(각 화면의 실제 제출/확정 액션을 거쳐 도달한 가장
        # 마지막 단계) 기준으로 판단한다 - 사이드바로 번호만 옮겨 다닌
        # 단계까지 완료로 잘못 표시되는 걸 막기 위함이다.
        for num, label in steps:
            if num == min(_UTILITY_STEPS):
                # 처리 로그/고객 데이터는 ①~⑥ 마법사 흐름과 별개인 조회
                # 화면이라 시각적으로도 구분되도록 구분선을 넣는다(맨 처음
                # 유틸리티 화면 앞에만 한 번).
                st.divider()
            with st.container(key=f"fx_nav_{num}"):
                if num < max_step_reached and num != current_step:
                    btn_label = f"✅  {label}"
                elif num == current_step:
                    btn_label = f"▶  {label}"
                elif num in _UTILITY_STEPS:
                    # 마법사처럼 "다음"으로 순서대로 도달하는 단계가 아니라
                    # 언제든 들어가 조회하는 화면이라 번호를 안 붙인다.
                    btn_label = label
                else:
                    btn_label = f"{num}. {label}"
                if st.button(
                    btn_label, key=f"fx_navbtn_{num}", use_container_width=True, disabled=(num == current_step)
                ):
                    st.session_state.step = num
                    st.rerun()

        rows = "".join(f'<div class="fx-vc-row"><span>{k}</span><b>{v}</b></div>' for k, v in mode_badges)
        st.markdown(
            f'<div class="fx-version-card">{rows}'
            "<i>⚠ Mock/데모 데이터가 포함되어 있습니다 — 실무 적용 전 검증 필요</i></div>",
            unsafe_allow_html=True,
        )

        st.markdown(
            '<div class="fx-user"><span>👤</span><div><b>은행원</b>'
            "<small>외환거래 담당</small></div></div>",
            unsafe_allow_html=True,
        )
