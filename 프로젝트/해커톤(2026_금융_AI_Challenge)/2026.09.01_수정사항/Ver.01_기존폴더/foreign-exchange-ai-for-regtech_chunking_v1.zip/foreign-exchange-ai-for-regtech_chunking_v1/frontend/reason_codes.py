"""화면 9 - 사유코드.

③ 거래 문맥 분석에서 후보로 추천되는 사유코드 마스터(``ReasonCode``, DB
``reason_codes`` 테이블 - ``data/reason_codes.csv``를 ``database.seed``가
적재) 전체를 조회 전용으로 보여준다. ⑦ 처리 로그 / ⑧ 고객 데이터와 마찬가지로
마법사(①~⑥) 순번이 아니라 언제든 들어가는 별도 화면이다.
"""

from __future__ import annotations

import pandas as pd
import streamlit as st

from database.connection import get_session
from database.models import ReasonCode as ReasonCodeORM
from frontend import theme

_COLUMNS = ["사유코드", "명칭", "대분류", "설명", "키워드", "필요서류"]


def _load_reason_codes() -> list[dict]:
    """사유코드 마스터를 코드순으로 읽어 화면 표시용 dict 목록으로 변환한다."""

    with get_session() as session:
        rows = session.query(ReasonCodeORM).order_by(ReasonCodeORM.code.asc()).all()
        return [
            {
                "사유코드": row.code,
                "명칭": row.name,
                "대분류": row.category,
                "설명": row.description,
                "키워드": ", ".join(row.keywords or []),
                "필요서류": ", ".join(row.required_documents or []),
            }
            for row in rows
        ]


def render() -> None:
    theme.widen_main_container()
    with st.container(border=True, key="fx_card_reason_codes"):
        theme.section_title("📖", "사유코드", "거래 문맥 분석에서 후보로 쓰이는 사유코드 마스터를 조회합니다.")

        records = _load_reason_codes()

        if not records:
            st.info(
                "등록된 사유코드 마스터 데이터가 없습니다. "
                "`python -m database.seed` 를 실행하면 채워집니다."
            )
            return

        df = pd.DataFrame.from_records(records)[_COLUMNS]

        # SWIFT 조회 화면과 같은 레이아웃(입력창이 남는 공간을 채우고,
        # "조회" 버튼은 같은 크기로 우측 끝에 고정) - key는 화면마다 검색
        # 박스가 하나뿐이라 다른 화면(처리 로그/고객 데이터/지정목적코드)과
        # 공유해도 안전하다.
        with st.container(key="fx_search_row"):
            with st.form("fx_reason_code_search_form", border=False):
                col_q, col_btn = st.columns([5, 1])
                with col_q:
                    query = st.text_input(
                        "검색",
                        placeholder="사유코드·명칭·대분류·설명·키워드·필요서류로 검색",
                        label_visibility="collapsed",
                    )
                with col_btn:
                    st.form_submit_button("조회", type="primary", key="fx_search_btn")

        if query:
            mask = pd.Series(False, index=df.index)
            for col in _COLUMNS:
                mask |= df[col].astype(str).str.contains(query, case=False, na=False, regex=False)
            filtered = df[mask]
            st.caption(f"총 {len(df)}건 중 {len(filtered)}건 검색됨")
        else:
            filtered = df
            st.caption(f"총 {len(filtered)}건")

        if query and filtered.empty:
            st.info(f"\"{query}\"와(과) 일치하는 사유코드가 없습니다.")
        else:
            st.dataframe(filtered, use_container_width=True, hide_index=True)
