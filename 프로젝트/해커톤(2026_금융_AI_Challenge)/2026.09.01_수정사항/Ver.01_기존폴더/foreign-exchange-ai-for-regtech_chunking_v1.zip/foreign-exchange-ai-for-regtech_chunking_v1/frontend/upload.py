"""화면 1 - 신청서 업로드 (섹션 26)."""

from __future__ import annotations

from pathlib import Path

import streamlit as st

from config.settings import get_settings
from services.ocr import get_ocr_service
from services.ocr.base import OCRError
from frontend import theme
from utils.logging import get_logger

logger = get_logger(__name__)

_ALLOWED_TYPES = ["pdf", "jpg", "jpeg", "png"]


def _save_uploaded_file(uploaded_file) -> Path:
    settings = get_settings()
    upload_dir = Path(settings.data_dir) / "uploads"
    upload_dir.mkdir(parents=True, exist_ok=True)
    dest = upload_dir / uploaded_file.name
    dest.write_bytes(uploaded_file.getvalue())
    return dest


def render() -> None:
    card = st.container(border=True, key="fx_card_upload")
    with card:
        theme.section_title("①", "신청서 업로드", "외화송금신청서 이미지/PDF를 업로드하면 OCR로 거래정보를 추출합니다.")

        settings = get_settings()
        mode_label = {
            "mock": "Mock OCR",
            "vision": f"Vision OCR - {settings.ollama_vision_model} (Ollama)",
        }.get(settings.ocr_mode, settings.ocr_mode)
        st.info(
            f"현재 OCR 모드: **{mode_label}**  \n"
            "외화송금신청서만 업로드하세요. 증빙서류는 이 화면에서 처리하지 않습니다.",
            icon=":material/info:",
        )

        uploaded_file = st.file_uploader(
            "외화송금신청서를 업로드하세요 (PDF / JPG / PNG)",
            type=_ALLOWED_TYPES,
        )

        if uploaded_file is not None:
            if uploaded_file.type and "image" in uploaded_file.type:
                st.image(uploaded_file, caption=uploaded_file.name, width=320)
            else:
                st.write(f"📄 {uploaded_file.name}")

        disabled = uploaded_file is None
        clicked = st.button("OCR 분석 시작", type="primary", disabled=disabled)

    if clicked:
        with st.spinner("신청서를 분석하는 중입니다..."):
            try:
                saved_path = _save_uploaded_file(uploaded_file)
                ocr_service = get_ocr_service()
                result = ocr_service.extract(saved_path)
            except OCRError as exc:
                st.error(f"OCR 분석에 실패했습니다.\n\n{exc}\n\n신청서 이미지의 해상도 또는 촬영 상태를 확인해주세요.")
                logger.warning("OCR 실패: %s", exc)
                return
            except Exception:
                logger.exception("OCR 처리 중 예기치 못한 오류")
                st.error("OCR 분석 중 예기치 못한 오류가 발생했습니다. 다시 업로드해주세요.")
                return

        st.session_state.uploaded_file_path = str(saved_path)
        st.session_state.ocr_result = result
        st.session_state.customer_profile = result.customer_profile.model_copy()
        st.session_state.transaction_request = result.transaction_request.model_copy()
        st.session_state.step = 2
        st.session_state.max_step_reached = max(st.session_state.max_step_reached, 2)
        st.rerun()
