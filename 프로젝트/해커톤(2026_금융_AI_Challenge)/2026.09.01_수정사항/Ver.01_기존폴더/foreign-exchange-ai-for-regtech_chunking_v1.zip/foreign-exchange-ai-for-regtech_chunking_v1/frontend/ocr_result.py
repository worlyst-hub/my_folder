"""화면 2 - OCR 결과 확인 및 수정 (섹션 27, ③ 거래정보 확정 포함).

원본 신청서와 OCR 결과를 좌우로 비교하고, 은행원이 직접 수정할 수 있는
입력 UI를 제공한다. 최종 정확성 확인 책임은 은행원에게 있다(섹션 3).
"""

from __future__ import annotations

from pathlib import Path

import streamlit as st

from database.connection import get_session
from database.models import CustomerProfile as CustomerORM
from database.models import SystemLookupData as SystemLookupORM
from database.models import TransactionRequest as TransactionORM
from database.models import TransactionStatus
from schemas.customer import CustomerProfile
from schemas.transaction import RecipientInfo, TransactionRequest
from services.system_lookup import get_system_lookup_service
from frontend import theme
from utils.labels import CUSTOMER_TYPE_LABELS, RECIPIENT_TYPE_LABELS, RESIDENCE_STATUS_LABELS
from utils.logging import get_logger
from utils.validation import normalize_swift_bic, parse_amount

logger = get_logger(__name__)

_PLACEHOLDER = "-"

# 맨 앞의 빈 문자열이 은행원이 아무것도 안 고른 기본 상태를 뜻한다 - OCR이
# 추정한 값이 있어도 자동으로 선택해두지 않고, 은행원이 원본 신청서를 보고
# 직접 골라야만 값이 채워지도록 한다(고객유형/거주자구분은 이후 필요서류
# 판단에 직접 영향을 주는 항목이라 AI 추정을 그대로 믿지 않게 하기 위함).
_CUSTOMER_TYPES = ["", "INDIVIDUAL", "CORPORATE"]
_RESIDENCE_STATUSES = ["", "RESIDENT", "NON_RESIDENT", "FOREIGN_RESIDENT"]
_RECIPIENT_TYPES = ["", "INDIVIDUAL", "CORPORATE"]


def _confidence_badge(field_confidence: dict[str, float], field: str) -> str:
    if field not in field_confidence:
        return ""
    value = field_confidence[field]
    icon = "🟢" if value >= 0.85 else ("🟡" if value >= 0.6 else "🔴")
    return f" {icon} `{value:.0%}` (참고용)"


def _render_pdf_preview(path: Path) -> None:
    """PDF 첫 페이지를 이미지로 렌더링해 미리보기로 보여준다.

    Vision OCR(``services/ocr/vision_ocr.py``)과 동일하게 ``pypdfium2``로
    렌더링한다 - poppler 등 시스템 패키지 불필요(PDFium 바이너리 동봉).
    여러 페이지가 있어도 1페이지만 보여준다(Vision OCR 인식 범위와 동일).
    """
    import pypdfium2 as pdfium

    try:
        pdf = pdfium.PdfDocument(str(path))
        try:
            page_count = len(pdf)
            image = pdf[0].render(scale=2.0).to_pil()
        finally:
            pdf.close()
    except Exception as exc:  # pragma: no cover - 손상된 PDF 등 예외 상황
        logger.exception("PDF 미리보기 렌더링 실패: %s", path)
        st.info(f"📄 {path.name} (PDF 미리보기 생성 실패: {exc})")
        return

    st.image(image, use_container_width=True)
    if page_count > 1:
        st.caption(
            f"⚠️ 총 {page_count}페이지 중 1페이지만 미리보기로 표시합니다 "
            "(Vision OCR 인식도 1페이지만 사용합니다)."
        )


def _render_original_preview(file_path: str | None) -> None:
    st.markdown("**원본 신청서**")
    if not file_path:
        st.info("원본 파일이 없습니다.")
        return
    path = Path(file_path)
    if path.suffix.lower() in {".jpg", ".jpeg", ".png"}:
        st.image(str(path), use_container_width=True)
    elif path.suffix.lower() == ".pdf":
        _render_pdf_preview(path)
    else:
        st.info(f"📄 {path.name}")


_CORRECTION_FIELD_LABELS = {
    "customer_type": "고객유형",
    "residence_status": "거주자구분",
    "name_ko": "고객명(한글)",
    "name_eng": "고객명(영문)",
    "identification_no": "식별번호",
    "account_number": "출금 계좌번호",
    "raw_transaction_purpose": "송금 목적/적요",
    "remittance_currency": "송금 통화",
    "remittance_amount": "송금 금액",
    "recipient_type": "수취인 유형",
    "recipient_name": "수취인명",
    "recipient_country": "수취 국가",
    "beneficiary_bank_name": "수취은행명",
    "swift_bic": "SWIFT BIC",
}


def _display_value(value: object) -> str:
    if value is None:
        return ""
    return str(value.value if hasattr(value, "value") else value)


def _diff_ocr_corrections(
    ocr_customer: CustomerProfile,
    ocr_transaction: TransactionRequest,
    confirmed_customer: CustomerProfile,
    confirmed_transaction: TransactionRequest,
) -> dict[str, dict[str, str]]:
    """OCR이 처음 인식한 값과 은행원이 최종 확정한 값을 필드별로 비교한다.

    은행원이 실제로 고친 필드만(값이 그대로면 제외) ``{한글라벨:
    {"ocr": 원래값, "confirmed": 확정값}}`` 형태로 돌려준다 - OCR 정확도를
    나중에 처리 로그(⑦)에서 참고할 수 있도록 하기 위함이다.
    """

    pairs: list[tuple[str, object, object]] = [
        ("customer_type", ocr_customer.customer_type, confirmed_customer.customer_type),
        ("residence_status", ocr_customer.residence_status, confirmed_customer.residence_status),
        ("name_ko", ocr_customer.name_ko, confirmed_customer.name_ko),
        ("name_eng", ocr_customer.name_eng, confirmed_customer.name_eng),
        ("identification_no", ocr_customer.identification_no, confirmed_customer.identification_no),
        ("account_number", ocr_customer.account_number, confirmed_customer.account_number),
        ("raw_transaction_purpose", ocr_transaction.raw_transaction_purpose, confirmed_transaction.raw_transaction_purpose),
        ("remittance_currency", ocr_transaction.remittance_currency, confirmed_transaction.remittance_currency),
        ("remittance_amount", ocr_transaction.remittance_amount, confirmed_transaction.remittance_amount),
        ("recipient_type", ocr_transaction.recipient_info.recipient_type, confirmed_transaction.recipient_info.recipient_type),
        ("recipient_name", ocr_transaction.recipient_info.recipient_name, confirmed_transaction.recipient_info.recipient_name),
        ("recipient_country", ocr_transaction.recipient_info.recipient_country, confirmed_transaction.recipient_info.recipient_country),
        ("beneficiary_bank_name", ocr_transaction.recipient_info.beneficiary_bank_name, confirmed_transaction.recipient_info.beneficiary_bank_name),
        ("swift_bic", ocr_transaction.recipient_info.swift_bic, confirmed_transaction.recipient_info.swift_bic),
    ]

    corrections: dict[str, dict[str, str]] = {}
    for field, ocr_value, confirmed_value in pairs:
        before, after = _display_value(ocr_value), _display_value(confirmed_value)
        if before != after:
            corrections[_CORRECTION_FIELD_LABELS[field]] = {"ocr": before, "confirmed": after}
    return corrections


def _persist_confirmed_transaction(
    customer: CustomerProfile,
    transaction: TransactionRequest,
    ocr_corrections: dict[str, dict[str, str]] | None,
) -> tuple[int, int]:
    """확정된 고객/거래정보를 DB에 저장하고 (customer_id, transaction_id)를 반환한다."""

    with get_session() as session:
        customer_row = CustomerORM(
            customer_type=customer.customer_type,
            residence_status=customer.residence_status,
            name_ko=customer.name_ko,
            name_eng=customer.name_eng,
            identification_no=customer.identification_no,
            account_number=customer.account_number,
        )
        session.add(customer_row)
        session.flush()

        transaction_row = TransactionORM(
            customer_id=customer_row.id,
            raw_transaction_purpose=transaction.raw_transaction_purpose,
            remittance_currency=transaction.remittance_currency,
            remittance_amount=transaction.remittance_amount,
            recipient_type=transaction.recipient_info.recipient_type,
            recipient_name=transaction.recipient_info.recipient_name,
            recipient_country=transaction.recipient_info.recipient_country,
            beneficiary_bank_name=transaction.recipient_info.beneficiary_bank_name,
            swift_bic=transaction.recipient_info.swift_bic,
            status=TransactionStatus.CONFIRMED,
            ocr_corrections=ocr_corrections or None,
        )
        session.add(transaction_row)
        session.flush()

        lookup_service = get_system_lookup_service()
        lookup_data = lookup_service.get_customer_data(
            customer.identification_no, customer.account_number
        )
        session.add(
            SystemLookupORM(
                customer_id=customer_row.id,
                annual_accumulated_usd=lookup_data.annual_accumulated_usd,
                designated_bank_status=lookup_data.designated_bank_status,
                is_bank_designated=lookup_data.designated_bank_status != "NONE",
                designated_purpose=lookup_data.designated_purpose,
                is_delinquent_borrower=lookup_data.is_delinquent_borrower,
            )
        )

        st.session_state.system_lookup = lookup_data
        return customer_row.id, transaction_row.id


def render() -> None:
    ocr_result = st.session_state.ocr_result

    card = st.container(border=True, key="fx_card_ocr")
    with card:
        theme.section_title("②", "OCR 결과 확인", "원본 신청서와 OCR 인식 결과를 대조하고 필요한 항목을 직접 수정하세요.")

        if ocr_result is None:
            st.info("아직 업로드/인식된 신청서가 없습니다. 아래 서식은 비어있는 상태이니 직접 입력해도 되고, ①단계에서 먼저 업로드해도 됩니다.")
        elif ocr_result.warnings:
            for w in ocr_result.warnings:
                st.warning(w, icon="⚠️")

        # 업로드/OCR을 거치지 않고 이 단계로 바로 온 경우, 두 스키마 모두
        # 필수값이 없어 인자 없이 만들면 전부 빈 값인 기본 객체가 된다.
        customer: CustomerProfile = st.session_state.customer_profile or CustomerProfile()
        transaction: TransactionRequest = st.session_state.transaction_request or TransactionRequest()
        fc = ocr_result.field_confidence if ocr_result is not None else {}

        left, right = st.columns([1, 1.3])

        with left:
            _render_original_preview(st.session_state.uploaded_file_path)
            go_back = st.button("이전", key="fx_ocr_prev")

        with right:
            st.markdown("**인식된 거래정보 (수정 가능)**")

            with st.form("ocr_edit_form"):
                st.markdown("###### 고객 정보")
                c1, c2 = st.columns(2)
                customer_type = c1.selectbox(
                    "고객유형", _CUSTOMER_TYPES,
                    format_func=lambda v: CUSTOMER_TYPE_LABELS.get(v, v) if v else _PLACEHOLDER,
                )
                residence_status = c2.selectbox(
                    "거주자구분", _RESIDENCE_STATUSES,
                    format_func=lambda v: RESIDENCE_STATUS_LABELS.get(v, v) if v else _PLACEHOLDER,
                )
                name_ko = st.text_input("고객명(한글)" + _confidence_badge(fc, "name_ko"), value=customer.name_ko or "")
                name_eng = st.text_input("고객명(영문)" + _confidence_badge(fc, "name_eng"), value=customer.name_eng or "")
                identification_no = st.text_input(
                    "식별번호(주민/사업자번호)" + _confidence_badge(fc, "identification_no"),
                    value=customer.identification_no or "",
                )
                account_number = st.text_input("출금 계좌번호", value=customer.account_number or "")

                st.markdown("###### 거래 정보")
                raw_purpose = st.text_area(
                    "송금 목적 / 적요", value=transaction.raw_transaction_purpose or "", height=80
                )
                c3, c4 = st.columns(2)
                currency = c3.text_input("송금 통화", value=transaction.remittance_currency or "USD")
                amount_str = c4.text_input(
                    "송금 금액" + _confidence_badge(fc, "remittance_amount"),
                    value=str(transaction.remittance_amount) if transaction.remittance_amount is not None else "",
                )

                st.markdown("###### 수취인 / 수취은행 정보")
                recipient = transaction.recipient_info
                c5, c6 = st.columns(2)
                recipient_type = c5.selectbox(
                    "수취인 유형", _RECIPIENT_TYPES,
                    format_func=lambda v: RECIPIENT_TYPE_LABELS.get(v, v) if v else _PLACEHOLDER,
                )
                recipient_country = c6.text_input("수취 국가(ISO 2자리)", value=recipient.recipient_country or "")
                recipient_name = st.text_input("수취인명", value=recipient.recipient_name or "")
                beneficiary_bank_name = st.text_input("수취은행명", value=recipient.beneficiary_bank_name or "")
                swift_bic = st.text_input(
                    "SWIFT BIC" + _confidence_badge(fc, "swift_bic"), value=recipient.swift_bic or ""
                )

                submitted = st.form_submit_button("다음", type="primary", key="fx_ocr_next")

        if submitted and (not customer_type or not residence_status or not recipient_type):
            st.error("고객유형, 거주자구분, 수취인 유형은 반드시 선택해야 합니다.")

        elif submitted:
            updated_customer = CustomerProfile(
                customer_type=customer_type,
                residence_status=residence_status,
                name_ko=name_ko or None,
                name_eng=name_eng or None,
                identification_no=identification_no or None,
                account_number=account_number or None,
            )
            updated_transaction = TransactionRequest(
                raw_transaction_purpose=raw_purpose or None,
                remittance_currency=currency or None,
                remittance_amount=parse_amount(amount_str),
                recipient_info=RecipientInfo(
                    recipient_type=recipient_type or None,
                    recipient_name=recipient_name or None,
                    recipient_country=recipient_country or None,
                    beneficiary_bank_name=beneficiary_bank_name or None,
                    swift_bic=normalize_swift_bic(swift_bic),
                ),
            )

            # OCR을 거치지 않고(빈 서식에 직접 입력) 확정한 경우엔 비교할
            # "원래 OCR 인식값"이 없으므로 수정 내역을 남기지 않는다.
            corrections = (
                _diff_ocr_corrections(
                    ocr_result.customer_profile, ocr_result.transaction_request,
                    updated_customer, updated_transaction,
                )
                if ocr_result is not None
                else None
            )

            try:
                customer_id, transaction_id = _persist_confirmed_transaction(
                    updated_customer, updated_transaction, corrections
                )
            except Exception:
                logger.exception("거래정보 확정(DB 저장) 중 예기치 못한 오류")
                st.error(
                    "거래정보를 저장하는 중 오류가 발생했습니다. 죄송하지만 방금 입력한 "
                    "내용을 다시 입력한 뒤 재시도해주세요."
                )
                return

            st.session_state.customer_profile = updated_customer
            st.session_state.transaction_request = updated_transaction
            st.session_state.db_customer_id = customer_id
            st.session_state.db_transaction_id = transaction_id

            # 거래정보가 (재)확정되었으므로, 이전 확정 내용을 기준으로 만들어진
            # 이후 단계 결과는 더 이상 유효하지 않다 - 사이드바로 되돌아와 OCR
            # 데이터를 고쳐서 다시 제출한 경우, 옛 분석/사유코드/법령/SWIFT
            # 결과가 화면에 남아있지 않도록 전부 초기화한다.
            st.session_state.analysis = None
            st.session_state.reason_code_candidates = []
            st.session_state.confirmed_reason_code = None
            st.session_state.regulation_matches = []
            st.session_state.required_documents = None
            st.session_state.swift_result = None
            st.session_state.swift_queried_code = None

            st.session_state.step = 3
            # 위에서 이후 단계 결과를 초기화했으므로, "완료" 표시도 함께
            # 3단계까지로 되돌린다(max로 올리기만 하면 재확정 전의 더 앞선
            # 진행 상태가 잘못 남아있게 된다).
            st.session_state.max_step_reached = 3
            st.rerun()

        if go_back:
            st.session_state.step = 1
            st.rerun()
