"""화면 3 - 거래 문맥 분석 / 사유코드 (섹션 28, 11~14)."""

from __future__ import annotations

import streamlit as st

from config.settings import get_settings
from database.connection import get_session
from database.models import TransactionRequest as TransactionORM
from schemas.customer import CustomerProfile
from schemas.transaction import TransactionRequest
from schemas.analysis import TransactionAnalysisInput
from services.llm import get_llm_service
from services.llm.base import LLMServiceError
from services.reason_code.mapper import ReasonCodeMapper
from frontend import theme
from utils.logging import get_logger

logger = get_logger(__name__)


@st.cache_resource
def _get_reason_code_mapper() -> ReasonCodeMapper:
    """ReasonCodeMapper(Chroma client + Ollama 임베딩 클라이언트 보유)를 프로세스당
    한 번만 만들어 재사용한다. 이게 없으면 "AI 거래 문맥 분석 시작"을 누를 때마다
    디스크의 Vector 인덱스를 다시 읽고 Ollama 연결까지 재확인해 불필요하게 느려진다."""

    return ReasonCodeMapper()


def _run_analysis() -> None:
    transaction = st.session_state.transaction_request or TransactionRequest()
    customer = st.session_state.customer_profile or CustomerProfile()
    recipient = transaction.recipient_info

    llm_input = TransactionAnalysisInput(
        raw_transaction_purpose=transaction.raw_transaction_purpose or "",
        remittance_currency=transaction.remittance_currency,
        remittance_amount=str(transaction.remittance_amount) if transaction.remittance_amount else None,
        recipient_name=recipient.recipient_name,
        recipient_country=recipient.recipient_country,
        recipient_type=(recipient.recipient_type.value if recipient.recipient_type else None),
        beneficiary_bank_name=recipient.beneficiary_bank_name,
        customer_type=(customer.customer_type.value if customer.customer_type else None),
        residence_status=(customer.residence_status.value if customer.residence_status else None),
    )

    llm_service = get_llm_service()
    try:
        analysis = llm_service.analyze_transaction(llm_input)
    except LLMServiceError as exc:
        st.error(f"⚠️ {exc}")
        return

    st.session_state.analysis = analysis

    query_text = " ".join(
        filter(
            None,
            [analysis.normalized_purpose, transaction.raw_transaction_purpose, *analysis.important_facts],
        )
    )
    try:
        mapper = _get_reason_code_mapper()
        st.session_state.reason_code_candidates = mapper.search(query_text, top_k=5)
        st.session_state.reason_code_embedding_backend = mapper.embedding_backend
    except Exception:
        logger.exception("사유코드 Vector Search 중 예기치 못한 오류")
        st.error("사유코드 검색 중 오류가 발생했습니다. 잠시 후 다시 시도해주세요.")
        return


def render() -> None:
    transaction = st.session_state.transaction_request or TransactionRequest()

    with st.container(border=True, key="fx_card_analysis"):
        theme.section_title("③", "거래 문맥 분석 / 사유코드", "AI가 송금 목적을 구조화하고, 사유코드 후보를 은행원이 확인합니다.")

        if st.session_state.transaction_request is None:
            st.info("아직 확정된 거래정보가 없습니다. ②단계에서 거래정보를 입력/확정하면 여기서 더 정확하게 분석됩니다 - 지금 바로 분석을 실행할 수도 있습니다.")

        recipient = transaction.recipient_info
        amount_display = (
            f"{transaction.remittance_currency or ''} {transaction.remittance_amount or ''}".strip()
            if transaction.remittance_currency or transaction.remittance_amount
            else "-"
        )
        c1, c2, c3 = st.columns(3)
        c1.metric("송금금액", amount_display)
        c2.metric("수취국가", recipient.recipient_country or "-")
        c3.metric("수취은행", recipient.beneficiary_bank_name or "-")
        st.text_area("송금 목적", value=transaction.raw_transaction_purpose or "", height=70, disabled=True)

        # 시스템 조회 정보(신용등급/한도 등)는 ④ 법령·필요서류 화면에서만
        # 보여준다 - 같은 내용을 두 화면에 중복 표시하지 않는다.

        st.divider()

        settings = get_settings()
        llm_label = f"Ollama({settings.ollama_model})" if settings.llm_mode == "live" else "Mock 규칙 기반"

        if st.button("분석 시작", type="primary"):
            with st.spinner(f"{llm_label}으로 거래 목적을 분석하는 중입니다..."):
                _run_analysis()

        analysis = st.session_state.analysis
        if analysis is None:
            st.info("AI 분석을 실행하면 거래 유형과 사유코드 후보를 확인할 수 있습니다.")
            return

        st.markdown(f"##### 🤖 {llm_label} 분석 결과")
        a1, a2, a3, a4 = st.columns(4)
        a1.metric("거래 유형", analysis.transaction_category)
        a2.metric("거래 행위", analysis.transaction_action)
        a3.metric("거래 성격", analysis.transaction_nature)
        a4.metric("정규화 거래 목적", analysis.normalized_purpose)
        if analysis.important_facts:
            st.caption("핵심 키워드: " + ", ".join(analysis.important_facts))
        st.caption("※ 이 분석 결과는 참고 정보이며 법률적 최종 판단이 아닙니다.")

        st.markdown("##### 📋 추천 사유코드 (은행원 확인 필요)")
        if st.session_state.get("reason_code_embedding_backend") == "hash":
            st.caption(
                "⚠️ Ollama 임베딩 연결에 실패해 경량 해시 임베딩으로 검색했습니다 - "
                "사이드바의 RAG 배지가 'bge-m3 + ChromaDB'로 표시되어도 이 검색 결과의 "
                "정확도는 낮을 수 있습니다."
            )
        candidates = st.session_state.reason_code_candidates
        if not candidates:
            st.warning("일치하는 사유코드 후보를 찾지 못했습니다. 사유코드 DB를 확인하세요.")
            return

        options = [f"{c.reason_code.code} · {c.reason_code.name} (유사도 {c.score:.0%})" for c in candidates]
        selected_idx = st.radio(
            "사유코드 후보 중 하나를 선택하세요", options=range(len(options)), format_func=lambda i: options[i]
        )
        selected = candidates[selected_idx]
        with st.container(border=True, key="fx_card_analysis_selected"):
            st.write(f"**{selected.reason_code.code} · {selected.reason_code.name}**  ({selected.reason_code.category})")
            st.caption(selected.reason_code.description)
            if selected.matched_keywords:
                st.caption("일치 키워드: " + " / ".join(selected.matched_keywords))

        confirm_clicked = st.button("사유코드 확인", type="primary")

    if confirm_clicked:
        st.session_state.confirmed_reason_code = selected.reason_code
        if st.session_state.db_transaction_id:
            with get_session() as session:
                row = session.get(TransactionORM, st.session_state.db_transaction_id)
                if row is not None:
                    row.confirmed_reason_code = selected.reason_code.code
        st.session_state.step = 4
        st.session_state.max_step_reached = max(st.session_state.max_step_reached, 4)
        st.rerun()
