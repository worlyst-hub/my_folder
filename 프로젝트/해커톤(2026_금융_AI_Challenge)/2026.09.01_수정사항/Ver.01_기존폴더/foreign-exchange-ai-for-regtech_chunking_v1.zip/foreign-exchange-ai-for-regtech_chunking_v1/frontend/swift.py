"""화면 5 - SWIFT 조회 (섹션 30, 19~23)."""

from __future__ import annotations

import streamlit as st

from schemas.swift import SwiftLookupNotFound, SwiftLookupResult
from schemas.transaction import TransactionRequest
from services.swift.service import SwiftService
from frontend import theme
from utils.logging import get_logger
from utils.validation import is_valid_swift_bic_format, normalize_swift_bic

logger = get_logger(__name__)


def _render_result(result: SwiftLookupResult | SwiftLookupNotFound) -> None:
    if isinstance(result, SwiftLookupNotFound):
        st.error(
            f"⚠️ SWIFT 정보를 조회할 수 없습니다.\n\n"
            f"등록되지 않은 SWIFT Code({result.swift_code})이거나 DB에 해당 데이터가 존재하지 않습니다.\n\n"
            "은행원 확인이 필요합니다."
        )
        return

    if result.is_sanctioned:
        st.error("⚠️ 확인 필요 - 제재 데이터 등재 은행")
    else:
        st.success("✅ 정상")

    with st.container(border=True, key="fx_card_swift_result"):
        c1, c2 = st.columns(2)
        c1.metric("수취은행", result.bank_name)
        c2.metric("국가", result.country_code)
        c3, c4 = st.columns(2)
        c3.metric("SWIFT BIC", result.swift_code)
        c4.metric("예상 소요시간", result.estimated_days or "-")

        st.write(f"**제재 데이터**: {'등재' if result.is_sanctioned else '정상'}")
        if result.is_sanctioned:
            st.write(f"**제재 사유**: {result.sanction_reason or '-'}")
            st.warning("※ 최신 내부 제재 기준 및 은행 내부 절차 확인이 필요합니다.")
        if result.handling_note:
            st.caption(f"안내사항: {result.handling_note}")

    st.caption("※ 이 조회 결과만으로 실제 송금 가능 여부를 자동 확정하지 않습니다.")


def render() -> None:
    transaction = st.session_state.transaction_request or TransactionRequest()

    with st.container(border=True, key="fx_card_swift"):
        theme.section_title("⑤", "SWIFT 조회", "수취은행 SWIFT BIC로 은행 정보·제재 데이터·예상 소요시간을 조회합니다.")

        if st.session_state.transaction_request is None:
            st.info("아직 확정된 거래정보가 없습니다. SWIFT BIC를 직접 입력해 바로 조회할 수 있습니다.")

        default_code = transaction.recipient_info.swift_bic or ""

        # st.form으로 감싸면 입력창에서 Enter를 눌렀을 때 폼 안의 유일한
        # submit 버튼("조회")이 눌린 것으로 처리된다 - 폼 밖에 있는
        # "이전"/"다음" 버튼과는 무관하게 동작한다.
        with st.form("fx_swift_lookup_form"):
            st.caption("수취은행 SWIFT BIC")
            with st.container(key="fx_swift_bic_row"):
                col_input, col_btn = st.columns([4, 1])
                with col_input:
                    code = st.text_input(
                        "수취은행 SWIFT BIC", value=default_code or "", label_visibility="collapsed"
                    )
                with col_btn:
                    # 버튼 크기(이전/다음과 동일)는 그대로 두고, 입력창 열이
                    # 남는 공간을 다 채우도록(flex-grow) CSS로 늘려서, 버튼
                    # 바로 앞까지 입력창이 이어지고 버튼은 카드 우측 끝에
                    # 딱 붙게 만든다(theme.py의 fx_swift_bic_row 규칙 참고).
                    lookup_clicked = st.form_submit_button("조회", type="primary", key="fx_swift_lookup")
            if code and not is_valid_swift_bic_format(code):
                st.caption("⚠️ 일반적인 SWIFT BIC 형식(8자리 또는 11자리)과 다릅니다. 입력값을 확인해주세요.")

        normalized_code = normalize_swift_bic(code)

        if lookup_clicked:
            try:
                service = SwiftService()
                st.session_state.swift_result = service.lookup(normalized_code or "")
                st.session_state.swift_queried_code = normalized_code
            except Exception:
                logger.exception("SWIFT 조회 중 예기치 못한 오류")
                st.error("SWIFT 조회 중 오류가 발생했습니다. 잠시 후 다시 시도해주세요.")

        if st.session_state.swift_result is not None:
            _render_result(st.session_state.swift_result)

        st.divider()
        stale = normalized_code != st.session_state.get("swift_queried_code")
        if st.session_state.swift_result is not None and stale:
            st.caption("⚠️ 조회 이후 SWIFT BIC 입력값이 변경되었습니다. 다시 조회해주세요.")

        foot_left, foot_right = st.columns(2)
        with foot_left:
            back_clicked = st.button("이전", type="primary", key="fx_swift_prev")
        with foot_right:
            next_clicked = st.button("다음", type="primary", key="fx_swift_next")

    if next_clicked:
        st.session_state.step = 6
        st.session_state.max_step_reached = max(st.session_state.max_step_reached, 6)
        st.rerun()

    if back_clicked:
        st.session_state.step = 4
        st.rerun()
