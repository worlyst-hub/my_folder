"""화면 6 - 최종 처리 요약 (섹션 31).

AI 분석/검색 결과는 참고 정보로만 표시하며, 최종 처리 완료는 은행원의
확인을 거쳐 이루어진다.
"""

from __future__ import annotations

import streamlit as st

from database.connection import get_session
from database.models import TransactionRequest as TransactionORM
from database.models import TransactionStatus
from schemas.customer import CustomerProfile
from schemas.swift import SwiftLookupResult
from schemas.transaction import TransactionRequest
from frontend import theme
from utils.labels import CUSTOMER_TYPE_LABELS, RESIDENCE_STATUS_LABELS, label
from utils.logging import get_logger

logger = get_logger(__name__)


def render() -> None:
    customer = st.session_state.customer_profile or CustomerProfile()
    transaction = st.session_state.transaction_request or TransactionRequest()
    analysis = st.session_state.analysis
    reason_code = st.session_state.confirmed_reason_code
    swift_result = st.session_state.swift_result
    required = st.session_state.required_documents

    recipient = transaction.recipient_info

    with st.container(border=True, key="fx_card_summary"):
        theme.section_title("⑥", "외환거래 처리 요약", "전체 거래 정보를 확인한 뒤 최종 처리를 완료하세요.")

        if st.session_state.customer_profile is None or st.session_state.transaction_request is None:
            st.info("아직 확정된 거래정보가 없어 일부 항목이 비어있습니다. 필요하면 ②단계에서 먼저 입력/확정하세요.")

        col1, col2 = st.columns(2)
        with col1:
            with st.container(border=True, key="fx_card_sum_customer"):
                st.markdown("**[고객]**")
                st.write(customer.name_ko or customer.name_eng or "-")
                st.caption(
                    f"{label(CUSTOMER_TYPE_LABELS, customer.customer_type)} / "
                    f"{label(RESIDENCE_STATUS_LABELS, customer.residence_status)}"
                )

            with st.container(border=True, key="fx_card_sum_remit"):
                st.markdown("**[송금]**")
                st.write(f"{transaction.remittance_currency or ''} {transaction.remittance_amount or ''}")

            with st.container(border=True, key="fx_card_sum_recipient"):
                st.markdown("**[수취인]**")
                st.write(recipient.recipient_name or "-")
                st.caption(recipient.recipient_country or "-")

            with st.container(border=True, key="fx_card_sum_bank"):
                st.markdown("**[수취은행]**")
                st.write(recipient.beneficiary_bank_name or "-")
                st.caption(recipient.swift_bic or "-")

        with col2:
            with st.container(border=True, key="fx_card_sum_analysis"):
                st.markdown("**[거래 분석]**  (참고 정보)")
                if analysis:
                    st.write(analysis.normalized_purpose)
                    st.caption(analysis.transaction_nature)
                else:
                    st.caption("분석 결과 없음")

            with st.container(border=True, key="fx_card_sum_reason"):
                st.markdown("**[사유코드]**")
                if reason_code:
                    st.write(f"{reason_code.code} · {reason_code.name}")
                else:
                    st.caption("확인된 사유코드 없음")

            with st.container(border=True, key="fx_card_sum_swift"):
                st.markdown("**[SWIFT]**")
                if isinstance(swift_result, SwiftLookupResult):
                    st.write("제재 데이터 " + ("⚠️ 등재" if swift_result.is_sanctioned else "정상"))
                    st.caption(f"예상 소요시간 {swift_result.estimated_days or '-'}")
                else:
                    st.caption("SWIFT 조회 결과 없음")

            with st.container(border=True, key="fx_card_sum_docs"):
                st.markdown("**[필요서류]**")
                if required and required.items:
                    for item in required.items:
                        mark = "☑" if item.checked else "☐"
                        st.write(f"{mark} {item.name}")
                else:
                    st.caption("필요서류 정보 없음")

        st.divider()
        st.caption(
            "이 요약은 AI 분석/검색 결과를 포함한 업무 참고 정보입니다. "
            "실제 송금 처리 여부에 대한 최종 판단과 승인은 은행원이 직접 수행합니다."
        )

        sanction_flag = isinstance(swift_result, SwiftLookupResult) and swift_result.is_sanctioned
        docs_incomplete = bool(required and required.items and not all(item.checked for item in required.items))
        needs_ack = sanction_flag or docs_incomplete

        ack = True
        if needs_ack:
            unresolved = []
            if sanction_flag:
                unresolved.append("SWIFT 조회 결과 **제재 데이터 등재 은행**입니다.")
            if docs_incomplete:
                unresolved.append("**필요서류 체크리스트**가 모두 확인되지 않았습니다.")
            st.warning("⚠️ 확인이 필요한 항목이 있습니다.\n\n" + "\n\n".join(f"- {w}" for w in unresolved))
            ack = st.checkbox("위 사항을 확인했으며, 은행원으로서 처리 완료 여부를 최종 판단합니다.")

        # ②단계에서 거래정보를 확정한 적이 없으면 db_transaction_id가 없어
        # DB에 저장할 실제 거래 레코드 자체가 없다 - 이 상태로 "처리 완료"를
        # 눌러봐야 아무것도 저장되지 않으므로(예전엔 이 경우에도 무조건
        # "완료되었습니다" 메시지가 떠서 실제로는 아무 일도 안 일어났는데
        # 완료된 것처럼 보이는 문제가 있었다), 아예 막고 이유를 안내한다.
        no_confirmed_transaction = not st.session_state.db_transaction_id
        if no_confirmed_transaction:
            st.caption("⚠️ 확정된 거래정보가 없어 처리를 완료할 수 없습니다. ②단계에서 거래정보를 먼저 확정하세요.")

        c_complete, c_reset = st.columns(2)
        with c_complete:
            complete_clicked = st.button(
                "✅ 처리 완료",
                type="primary",
                use_container_width=True,
                disabled=no_confirmed_transaction or (needs_ack and not ack),
            )
        with c_reset:
            reset_clicked = st.button("🔄 새 거래 시작", use_container_width=True)

    if complete_clicked:
        saved = False
        if st.session_state.db_transaction_id:
            with get_session() as session:
                row = session.get(TransactionORM, st.session_state.db_transaction_id)
                if row is not None:
                    row.status = TransactionStatus.COMPLETED
                    saved = True
        if saved:
            st.session_state.max_step_reached = max(st.session_state.max_step_reached, 7)
            st.success("거래 처리가 완료 처리되었습니다. 처리 로그에서 확인할 수 있습니다.")
        else:
            st.error("거래정보를 찾지 못해 완료 처리하지 못했습니다. ②단계에서 거래정보를 다시 확정해주세요.")

    if reset_clicked:
        for key in list(st.session_state.keys()):
            del st.session_state[key]
        st.rerun()
