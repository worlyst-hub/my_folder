"""화면 7 - 처리 로그.

⑥ 최종 처리 요약에서 "처리 완료"를 눌러 ``TransactionStatus.COMPLETED``로
바뀐 거래만 모아 보여주는 조회 전용 화면이다. 마법사(①~⑥)와 달리 이전/다음
개념이 없고, DB에 실제로 저장된 완료 이력을 그대로 보여준다 - 세션이
끊기거나 "새 거래 시작"으로 화면 상태를 초기화해도 여기 기록은 남는다.
"""

from __future__ import annotations

import pandas as pd
import streamlit as st

from database.connection import get_session
from database.models import TransactionRequest as TransactionORM
from database.models import TransactionStatus
from frontend import theme
from utils.labels import CUSTOMER_TYPE_LABELS, RESIDENCE_STATUS_LABELS, label

_COLUMNS = [
    "처리일시", "고객명", "고객유형", "거주자구분", "통화", "금액",
    "수취인", "수취은행", "SWIFT BIC", "사유코드", "OCR 수정",
]

# 검색창 하나로 표에 보이는 모든 컬럼을 훑는다 - 처리일시(예: "2026-08-26"
# 로 특정 날짜 찾기)도 검색되는 게 자연스럽다.
_SEARCHABLE_COLUMNS = _COLUMNS


def _load_completed_transactions() -> list[dict]:
    """완료 처리된 거래를 최신순으로 읽어 화면 표시용 dict 목록으로 변환한다.

    세션이 닫히면 ORM 객체(특히 ``row.customer`` 같은 관계)는 더 이상
    접근할 수 없으므로(``expire_on_commit`` 기본값), 세션 블록 안에서 필요한
    값을 전부 순수 파이썬 값으로 꺼내둔다.
    """

    with get_session() as session:
        rows = (
            session.query(TransactionORM)
            .filter(TransactionORM.status == TransactionStatus.COMPLETED)
            .order_by(TransactionORM.updated_at.desc())
            .all()
        )
        records = []
        for row in rows:
            customer = row.customer
            corrections = row.ocr_corrections or {}
            records.append(
                {
                    "id": row.id,
                    "처리일시": row.updated_at.strftime("%Y-%m-%d %H:%M") if row.updated_at else "-",
                    "고객명": (customer.name_ko or customer.name_eng or "-") if customer else "-",
                    "고객유형": label(CUSTOMER_TYPE_LABELS, customer.customer_type) if customer else "-",
                    "거주자구분": label(RESIDENCE_STATUS_LABELS, customer.residence_status) if customer else "-",
                    "통화": row.remittance_currency or "-",
                    "금액": f"{row.remittance_amount:,.0f}" if row.remittance_amount is not None else "-",
                    "수취인": row.recipient_name or "-",
                    "수취은행": row.beneficiary_bank_name or "-",
                    "SWIFT BIC": row.swift_bic or "-",
                    "사유코드": row.confirmed_reason_code or "-",
                    "OCR 수정": f"{len(corrections)}개" if corrections else "-",
                    "_corrections": corrections,
                }
            )
        return records


def render() -> None:
    theme.widen_main_container()
    with st.container(border=True, key="fx_card_log"):
        theme.section_title("📋", "처리 로그", "처리 완료된 외환송금 거래 이력을 확인합니다.")

        records = _load_completed_transactions()

        if not records:
            st.info(
                "아직 처리 완료된 거래가 없습니다. ⑥ 최종 처리 요약 화면에서 "
                "\"처리 완료\"를 누르면 여기에 기록됩니다."
            )
            return

        df = pd.DataFrame.from_records(records)[_COLUMNS]

        # SWIFT 조회 화면과 같은 레이아웃(입력창이 남는 공간을 채우고,
        # "조회" 버튼은 같은 크기로 우측 끝에 고정) - key는 화면마다 검색
        # 박스가 하나뿐이라 다른 화면(고객 데이터)과 공유해도 안전하다.
        with st.container(key="fx_search_row"):
            with st.form("fx_log_search_form", border=False):
                col_q, col_btn = st.columns([5, 1])
                with col_q:
                    query = st.text_input(
                        "검색",
                        placeholder="처리일시·고객명·고객유형·거주자구분·통화·금액·수취인·수취은행·SWIFT BIC·사유코드·OCR 수정으로 검색",
                        label_visibility="collapsed",
                    )
                with col_btn:
                    st.form_submit_button("조회", type="primary", key="fx_search_btn")
        if query:
            mask = pd.Series(False, index=df.index)
            for col in _SEARCHABLE_COLUMNS:
                mask |= df[col].astype(str).str.contains(query, case=False, na=False, regex=False)
            filtered = df[mask]
            st.caption(f"총 {len(records)}건 중 {len(filtered)}건 검색됨")
        else:
            filtered = df
            st.caption(f"총 {len(records)}건")

        if query and filtered.empty:
            st.info(f"\"{query}\"와(과) 일치하는 처리 로그가 없습니다.")
        else:
            st.dataframe(filtered, use_container_width=True, hide_index=True)

        st.caption(
            "※ 이 로그는 업무 참고용 이력이며, SWIFT 제재 조회 결과 등 세션에서만 "
            "확인했던 일부 정보는 DB에 저장되지 않아 여기에 포함되지 않습니다."
        )

        st.markdown("##### 🔍 OCR 수정 내역 상세")
        st.caption("은행원이 ② 화면에서 OCR 인식값을 고쳐 확정한 거래만 골라 필드별로 보여줍니다.")

        corrected = [r for r in records if r["_corrections"]]
        if not corrected:
            st.caption("OCR 인식값을 수정해서 확정한 거래가 없습니다.")
        else:
            option_labels = [f"{r['처리일시']} · {r['고객명']} ({r['OCR 수정']})" for r in corrected]
            picked = st.selectbox("거래 선택", range(len(corrected)), format_func=lambda i: option_labels[i])
            detail_rows = [
                {"필드": field, "OCR 인식값": diff["ocr"] or "(빈값)", "은행원 확정값": diff["confirmed"] or "(빈값)"}
                for field, diff in corrected[picked]["_corrections"].items()
            ]
            st.dataframe(pd.DataFrame(detail_rows), use_container_width=True, hide_index=True)
