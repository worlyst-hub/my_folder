"""화면 10 - 지정목적코드.

⑧ 고객 데이터의 "기존지정목적" 컬럼에 쓰이는 3자리 코드 체계(대분류+중분류
+소분류, ``services/designated_purpose_codes.py``) 전체 100가지 조합을
조회 전용으로 보여준다. 실제 외국환거래 목적코드가 아니라 이 프로젝트
시연용으로 임의로 만든 체계다. ⑦ 처리 로그 / ⑧ 고객 데이터 / ⑨ 사유코드와
마찬가지로 마법사(①~⑥) 순번이 아니라 언제든 들어가는 별도 화면이다.
"""

from __future__ import annotations

import pandas as pd
import streamlit as st

from frontend import theme
from services.designated_purpose_codes import all_purpose_code_entries

_COLUMNS = ["코드", "대분류", "중분류", "소분류"]


def _load_purpose_codes() -> list[dict]:
    return [
        {
            "코드": entry.code,
            "대분류": entry.major_name,
            "중분류": entry.middle_name,
            "소분류": entry.minor_seq,
        }
        for entry in all_purpose_code_entries()
    ]


def render() -> None:
    theme.widen_main_container()
    with st.container(border=True, key="fx_card_purpose_codes"):
        theme.section_title("🏷️", "지정목적코드", "고객 데이터의 \"기존지정목적\" 코드 체계 전체를 조회합니다.")

        records = _load_purpose_codes()
        df = pd.DataFrame.from_records(records)[_COLUMNS]

        # SWIFT 조회 화면과 같은 레이아웃(입력창이 남는 공간을 채우고,
        # "조회" 버튼은 같은 크기로 우측 끝에 고정) - key는 화면마다 검색
        # 박스가 하나뿐이라 다른 화면(처리 로그/고객 데이터/사유코드)과
        # 공유해도 안전하다.
        with st.container(key="fx_search_row"):
            with st.form("fx_purpose_code_search_form", border=False):
                col_q, col_btn = st.columns([5, 1])
                with col_q:
                    query = st.text_input(
                        "검색",
                        placeholder="코드·대분류·중분류·소분류로 검색",
                        label_visibility="collapsed",
                    )
                with col_btn:
                    st.form_submit_button("조회", type="primary", key="fx_search_btn")

        if query:
            mask = pd.Series(False, index=df.index)
            for col in _COLUMNS:
                mask |= df[col].astype(str).str.contains(query, case=False, na=False, regex=False)
            filtered = df[mask]
            st.caption(f"총 {len(df)}건 중 {len(filtered)}건 검색됨")
        else:
            filtered = df
            st.caption(f"총 {len(filtered)}건")

        if query and filtered.empty:
            st.info(f"\"{query}\"와(과) 일치하는 지정목적코드가 없습니다.")
        else:
            st.dataframe(filtered, use_container_width=True, hide_index=True)
