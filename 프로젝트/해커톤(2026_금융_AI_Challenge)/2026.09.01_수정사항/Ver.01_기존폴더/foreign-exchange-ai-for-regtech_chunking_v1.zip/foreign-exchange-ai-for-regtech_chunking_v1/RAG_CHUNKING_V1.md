# RAG Chunking V1 — Parent-Child + Recursive Chunking

이 버전은 **검색 소스/API와 임베딩 방식은 바꾸지 않고 청킹 구조만 먼저 비교하기 위한 실험 버전**입니다.

## 이번에 바꾼 범위

- 기존: PDF 페이지별 `600자 고정 window + 100자 overlap`
- 변경:
  1. 한 법령 PDF의 페이지를 순서대로 연결
  2. `제○조`, `제○-○조`, `제○조의○`를 **Parent(조문 전체)** 로 파싱
  3. Parent 안에서 `항 → 호 → 목` 경계를 우선하여 **Child** 생성
  4. 구조 단위 하나가 너무 길 때만 `문단 → 줄 → 문장 → 공백` 순서로 **재귀 청킹**
  5. 위 경계로도 나눌 수 없는 긴 텍스트만 마지막에 overlap window 사용
  6. **Child만 기존 EmbeddingClient로 임베딩하여 ChromaDB에 저장**
  7. Child metadata에는 `parent_id`를 저장하고, Parent 원문은 별도 JSON에 한 번만 저장
  8. 검색 시 가장 가까운 Child를 찾은 뒤 연결된 Parent 조문 전체를 화면/LLM에 반환
  9. 같은 Parent의 여러 Child가 동시에 검색되면 Parent 기준으로 중복 제거

## 변경 파일

- `rag/chunker.py`
  - 계층적 법령 파싱
  - Parent/Child 생성
  - 재귀 청킹
  - 페이지가 넘어가는 조문 Parent 유지
- `rag/retriever.py`
  - PDF를 페이지별이 아닌 파일 단위로 chunker에 전달
  - Child 임베딩 + Parent JSON 저장
  - Child 검색 후 Parent 복원
  - 기존 인덱스와 분리된 Chroma collection 사용
- `tests/test_rag.py`
  - Parent/Child 생성 및 페이지 연결 조문 테스트 추가

## 의도적으로 바꾸지 않은 부분

이번 V1에서는 다음을 그대로 유지했습니다.

- `rag/document_loader.py`: 국가법령정보센터 PDF 로더
- `rag/embedder.py`: 기존 `EmbeddingClient`
- `services/embedding_client.py`: Ollama/hash 임베딩 방식
- 검색 query 임베딩 및 cosine 유사도 방식
- `regulation_tags` 필터
- `RegulationMatch` 스키마와 Streamlit 화면 인터페이스
- 국가법령정보 공동활용 API 연동
  - **아직 구현하지 않음**
  - 다음 단계에서 PDF 입력을 API 응답 기반 정규화 레코드로 교체하는 방향 권장

## Parent 저장 방식

기존 `rag_v2_ordered.py`의 아이디어와 동일하게 긴 Parent를 모든 Child metadata에 복제하지 않습니다.

- ChromaDB: Child text + embedding + `parent_id`
- JSON: Parent 조문 원문 1회 저장

생성 파일 예:

```text
data/chroma/rag_parents_hierarchical_v1_hash.json
data/chroma/rag_parents_hierarchical_v1_ollama.json
```

Chroma collection도 기존 고정-window 버전과 분리됩니다.

```text
rag_chunks_hierarchical_v1_hash
rag_chunks_hierarchical_v1_ollama
```

따라서 기존 인덱스를 지우지 않고 V1을 시험할 수 있습니다.

## 실제 포함 PDF로 확인한 결과

| 문서 | 기존 고정 window | V1 Parent | V1 Child |
|---|---:|---:|---:|
| 외국환거래규정 | 457 | 217 | 307 |
| 외국환거래법 | 95 | 59 | 72 |

예를 들어 매우 긴 `외국환거래규정 제1-2조`는 **Parent 1개를 유지하면서 Child 10개**로 나뉘었습니다.

V1 기본 Child 최대 길이는 `1200자`이며, 실제 PDF 검증에서 생성 Child가 이 상한을 넘지 않는 것을 확인했습니다.

## 실행

프로젝트 가상환경에서 필요한 패키지가 설치된 상태로 실행합니다.

```bash
python -c "from rag.retriever import RagRetriever; print(RagRetriever().build_index(force=True))"
```

앱에서 평소처럼 검색해도 collection이 비어 있으면 자동으로 인덱싱됩니다.

## 검증 상태

확인 완료:

- `rag/chunker.py`, `rag/retriever.py`, `tests/test_rag.py` Python syntax compile 통과
- 인공 법령 텍스트 Parent/Child 분리 통과
- 페이지를 넘어가는 동일 조문 Parent 유지 통과
- 프로젝트에 포함된 실제 외국환거래법/외국환거래규정 PDF 청킹 통과
- 모든 Child가 설정 최대 길이 이하인지 확인 통과

현재 작업 환경에는 `chromadb`, `ollama`가 설치되어 있지 않아 전체 `pytest tests/test_rag.py`는 import 단계에서 실행할 수 없었습니다. 프로젝트 가상환경에서는 `requirements.txt` 설치 후 전체 테스트를 실행하면 됩니다.

## 다음 비교 단계 제안

V1을 먼저 질문 세트로 평가한 뒤 다음 버전을 하나씩 추가하는 것이 좋습니다.

1. **V1 (현재)**: Parent-Child + Recursive Chunking
2. **V2**: 국가법령정보 공동활용 API 입력으로 교체
3. **V3**: 검색 개선(BM25/Vector Hybrid 또는 reranker)
4. 각 버전에 동일 질문 세트를 넣어 `정답 조문 hit`, `상위 K`, `중복`, `응답 근거 범위` 비교

이렇게 해야 청킹 변경 효과와 검색 변경 효과가 섞이지 않습니다.
