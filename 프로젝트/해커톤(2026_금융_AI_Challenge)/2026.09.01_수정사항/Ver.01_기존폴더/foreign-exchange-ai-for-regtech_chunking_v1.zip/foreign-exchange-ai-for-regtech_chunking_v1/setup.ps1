﻿<#
.SYNOPSIS
    FIXAR(ForeIgn eXchange AI for RegTech) - 원클릭 셋업 스크립트.

.DESCRIPTION
    다음을 순서대로 처리한다:
      1. 가상환경(fixar/) 생성 (없으면)
      2. requirements.txt 설치 (Python 패키지: Streamlit 등)
      3. .env 생성 (없으면 .env.example 복사)
      4. 로컬 Ollama 설치 확인 - 없으면 설치 여부를 물어보고, 동의 시 공식
         설치 스크립트 실행 (Ollama는 Python 패키지가 아니라 시스템
         프로그램이라 requirements.txt로는 설치할 수 없다)
      5. 임베딩 모델(.env의 OLLAMA_EMBED_MODEL, 기본 bge-m3) pull
         - .env에서 LLM_MODE=live면 OLLAMA_MODEL도, OCR_MODE=vision이면
           OLLAMA_VISION_MODEL도 같이 pull한다(기본값 mock/mock이면
           건너뜀 - 무거운 모델을 불필요하게 받지 않기 위함).
      6. DB 초기화 + Mock 데이터(사유코드 100건/SWIFT 마스터) 시딩

.PARAMETER SkipOllama
    Ollama 설치/모델 pull 단계를 건너뛴다 (Python 쪽만 셋업).

.PARAMETER Yes
    확인 프롬프트 없이 진행한다 (Ollama 설치 여부도 자동으로 "예"로 처리).

.EXAMPLE
    .\setup.ps1
    .\setup.ps1 -SkipOllama
    .\setup.ps1 -Yes
#>

param(
    [switch]$SkipOllama,
    [switch]$Yes
)

$ErrorActionPreference = "Stop"
# 한글이 콘솔에서 깨지지 않도록 UTF-8 출력 인코딩을 강제한다
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8

$ProjectRoot = $PSScriptRoot
Set-Location $ProjectRoot

function Write-Step($msg) {
    Write-Host ""
    Write-Host "==> $msg" -ForegroundColor Cyan
}

function Confirm-Action($prompt) {
    if ($Yes) { return $true }
    $answer = Read-Host "$prompt (y/N)"
    return $answer -match '^[Yy]'
}

# ---------------------------------------------------------------------------
# 1. 가상환경 (fixar/)
# ---------------------------------------------------------------------------
Write-Step "가상환경 확인 (fixar/)"
$venvPython = Join-Path $ProjectRoot "fixar\Scripts\python.exe"
if (-not (Test-Path $venvPython)) {
    Write-Host "fixar/ 가상환경이 없어 새로 만듭니다..."
    python -m venv fixar
} else {
    Write-Host "이미 존재합니다: $venvPython"
}

# ---------------------------------------------------------------------------
# 2. Python 의존성 설치
# ---------------------------------------------------------------------------
Write-Step "Python 패키지 설치 (requirements.txt), 시간이 걸릴 수 있습니다"
& $venvPython -m pip install --upgrade pip -q
& $venvPython -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw "pip install 실패 (exit $LASTEXITCODE)" }

# ---------------------------------------------------------------------------
# 3. .env
# ---------------------------------------------------------------------------
Write-Step ".env 확인"
$envPath = Join-Path $ProjectRoot ".env"
$envExamplePath = Join-Path $ProjectRoot ".env.example"
if (-not (Test-Path $envPath)) {
    Copy-Item $envExamplePath $envPath
    Write-Host ".env.example을 복사해 .env를 만들었습니다. 필요하면 값을 직접 채워주세요."
} else {
    Write-Host "이미 존재합니다: $envPath (건드리지 않음)"
}

# ---------------------------------------------------------------------------
# 4. 로컬 Ollama 설치 확인 (임베딩용 - 사유코드/RAG 검색)
# ---------------------------------------------------------------------------
if (-not $SkipOllama) {
    Write-Step "로컬 Ollama 확인 (임베딩 - 사유코드/RAG 검색에 사용)"
    $ollamaCmd = Get-Command ollama -ErrorAction SilentlyContinue

    if ($ollamaCmd) {
        Write-Host "이미 설치되어 있습니다: $($ollamaCmd.Source)"
    } else {
        Write-Host "Ollama가 설치되어 있지 않습니다."
        Write-Host "(Ollama는 Python 패키지가 아니라 백그라운드 서비스가 딸린 시스템 프로그램이라,"
        Write-Host " requirements.txt/pip로는 설치할 수 없어 별도로 공식 설치 스크립트를 실행합니다.)"
        if (Confirm-Action "지금 Ollama를 설치할까요? (공식 설치 스크립트 실행, 시스템 변경 발생)") {
            Write-Host "Ollama 공식 설치 스크립트를 실행합니다..."
            Invoke-Expression (Invoke-RestMethod -Uri "https://ollama.com/install.ps1")
            $ollamaCmd = Get-Command ollama -ErrorAction SilentlyContinue
        } else {
            Write-Host "Ollama 설치를 건너뜁니다. 임베딩은 자동으로 경량 해시 기반 폴백을 사용합니다 (검색 품질만 낮아짐, 앱은 정상 동작)." -ForegroundColor Yellow
        }
    }

    # ---------------------------------------------------------------------------
    # 5. 임베딩 모델 pull (.env의 OLLAMA_EMBED_MODEL, 기본 bge-m3)
    # ---------------------------------------------------------------------------
    if (Get-Command ollama -ErrorAction SilentlyContinue) {
        $embedModel = "bge-m3"
        if (Test-Path $envPath) {
            $line = Select-String -Path $envPath -Pattern '^OLLAMA_EMBED_MODEL=' -ErrorAction SilentlyContinue
            if ($line) { $embedModel = ($line.Line -split '=', 2)[1].Trim() }
        }
        if ($embedModel) {
            Write-Step "임베딩 모델 pull: $embedModel (이미 받았으면 바로 넘어감)"
            ollama pull $embedModel
        }

        # -----------------------------------------------------------------
        # 5-1. LLM_MODE=live / OCR_MODE=vision이면 해당 모델도 pull
        #      (기본값 mock/mock이면 무거운 모델을 받지 않고 건너뜀)
        # -----------------------------------------------------------------
        function Get-EnvValue($key, $default) {
            if (Test-Path $envPath) {
                $line = Select-String -Path $envPath -Pattern "^$key=" -ErrorAction SilentlyContinue
                if ($line) { return ($line.Line -split '=', 2)[1].Trim() }
            }
            return $default
        }
        if ((Get-EnvValue "LLM_MODE" "mock") -eq "live") {
            $llmModel = Get-EnvValue "OLLAMA_MODEL" "gpt-oss:120b-cloud"
            Write-Step "LLM_MODE=live 감지 - LLM 모델 pull: $llmModel"
            # -cloud 모델은 매니페스트만 받아 수 초 내로 끝나지만(가중치는
            # Ollama 서버에서 실행), Ollama Cloud 계정/API Key가 없으면
            # 인증 오류가 날 수 있다. 그래도 셋업 전체가 중단되지 않도록
            # 실패는 경고만 남기고 계속 진행한다.
            ollama pull $llmModel
            if ($LASTEXITCODE -ne 0) {
                Write-Host "LLM 모델 pull 실패: $llmModel (Ollama Cloud 계정/OLLAMA_API_KEY를 확인하세요. .env를 llama3.1 + 로컬로 바꾸면 무료로 쓸 수 있습니다 - .env.example 주석 참고)" -ForegroundColor Yellow
            }
        }
        if ((Get-EnvValue "OCR_MODE" "mock") -eq "vision") {
            $visionModel = Get-EnvValue "OLLAMA_VISION_MODEL" "qwen2.5vl"
            Write-Step "OCR_MODE=vision 감지 - Vision 모델 pull: $visionModel"
            ollama pull $visionModel
            if ($LASTEXITCODE -ne 0) {
                Write-Host "Vision 모델 pull 실패: $visionModel (네트워크/디스크 용량을 확인하세요)" -ForegroundColor Yellow
            }
        }
    }
} else {
    Write-Host "`n(-SkipOllama 지정됨 - Ollama 설치/모델 pull 단계 건너뜀)" -ForegroundColor Yellow
}

# ---------------------------------------------------------------------------
# 6. DB 초기화 + Mock 데이터 시딩
# ---------------------------------------------------------------------------
Write-Step "DB 초기화 + Mock 데이터 시딩 (사유코드 100건 + SWIFT 마스터)"
& $venvPython -m database.seed

# ---------------------------------------------------------------------------
Write-Step "셋업 완료"
Write-Host "다음 명령으로 앱을 실행하세요:" -ForegroundColor Green
Write-Host "  .\fixar\Scripts\streamlit.exe run app.py`n"
