"""Mock 데이터 시딩 스크립트.

``data/reason_codes.csv`` 와 ``data/swift_sanction_master.csv`` 를 읽어
DB에 적재한다. 이미 데이터가 있는 테이블은 건드리지 않아 반복 실행해도
안전하다 (재적재하려면 ``--reset`` 옵션 사용).

실행:
    python -m database.seed
    python -m database.seed --reset
"""

from __future__ import annotations

import argparse
import csv
from datetime import date
from pathlib import Path

from sqlalchemy import delete, insert, select

from config.settings import get_settings
from database.connection import get_session, init_db
from database.models import ReasonCode, RegisteredCustomerMaster, SwiftSanctionMaster
from utils.logging import get_logger

logger = get_logger(__name__)


def _split_list(value: str) -> list[str]:
    return [v.strip() for v in value.split("|") if v.strip()]


def _to_bool(value: str) -> bool:
    return value.strip().lower() in {"true", "1", "yes", "y"}


def seed_reason_codes(reset: bool = False) -> int:
    settings = get_settings()
    csv_path = Path(settings.data_dir) / "reason_codes.csv"
    if not csv_path.exists():
        logger.warning("사유코드 CSV가 없습니다: %s", csv_path)
        return 0

    with get_session() as session:
        if reset:
            session.execute(delete(ReasonCode))
        else:
            existing = session.execute(select(ReasonCode.id).limit(1)).first()
            if existing:
                logger.info("reason_codes 테이블에 이미 데이터가 있어 건너뜁니다.")
                return 0

        count = 0
        with csv_path.open(encoding="utf-8") as f:
            for row in csv.DictReader(f):
                session.add(
                    ReasonCode(
                        code=row["code"],
                        name=row["name"],
                        category=row["category"],
                        description=row["description"],
                        keywords=_split_list(row["keywords"]),
                        required_documents=_split_list(row["required_documents"]),
                        regulation_tags=_split_list(row["regulation_tags"]),
                        is_active=_to_bool(row["is_active"]),
                    )
                )
                count += 1
        logger.info("사유코드 %d건 적재 완료", count)
        return count


def seed_swift_master(reset: bool = False, chunk_size: int = 5000) -> int:
    """SWIFT 마스터 CSV(수기 큐레이션 29건)를 적재한다.

    한때는 공개 저장소(``swift-bic-codes-allinone``, 2019년 스냅샷 기준
    약 10만여 건)를 함께 적재했지만 제재 스크리닝이 안 된 데이터라 제거했다
    (README "3. DB 초기화 / 재적재" 참고). 지금은 건수가 적지만, 나중에
    실제 데이터를 다시 붙일 가능성을 감안해 ORM ``session.add()`` 1건씩이
    아니라 ``chunk_size`` 단위로 묶어 ``session.execute(insert(...), rows)``
    벌크 삽입하는 방식은 그대로 유지한다.
    """

    settings = get_settings()
    csv_path = Path(settings.data_dir) / "swift_sanction_master.csv"
    if not csv_path.exists():
        logger.warning("SWIFT 마스터 CSV가 없습니다: %s", csv_path)
        return 0

    with get_session() as session:
        if reset:
            session.execute(delete(SwiftSanctionMaster))
        else:
            existing = session.execute(select(SwiftSanctionMaster.id).limit(1)).first()
            if existing:
                logger.info("swift_sanction_master 테이블에 이미 데이터가 있어 건너뜁니다.")
                return 0

        count = 0
        buffer: list[dict] = []
        with csv_path.open(encoding="utf-8") as f:
            for row in csv.DictReader(f):
                buffer.append(
                    {
                        "swift_code": row["swift_code"].strip(),
                        "bank_name": row["bank_name"].strip(),
                        "country_code": row["country_code"].strip(),
                        "is_sanctioned": _to_bool(row["is_sanctioned"]),
                        "sanction_reason": row["sanction_reason"].strip() or None,
                        "estimated_days": row["estimated_days"].strip() or None,
                        "handling_note": row["handling_note"].strip() or None,
                    }
                )
                if len(buffer) >= chunk_size:
                    session.execute(insert(SwiftSanctionMaster), buffer)
                    count += len(buffer)
                    buffer.clear()
            if buffer:
                session.execute(insert(SwiftSanctionMaster), buffer)
                count += len(buffer)

        logger.info("SWIFT 마스터 %d건 적재 완료", count)
        return count


def seed_registered_customers(reset: bool = False) -> int:
    """당행 등록 고객 마스터 CSV(``data/generate_registered_customers.py``로 생성)를 적재한다."""

    settings = get_settings()
    csv_path = Path(settings.data_dir) / "registered_customers.csv"
    if not csv_path.exists():
        logger.warning("등록 고객 마스터 CSV가 없습니다: %s", csv_path)
        return 0

    with get_session() as session:
        if reset:
            session.execute(delete(RegisteredCustomerMaster))
        else:
            existing = session.execute(select(RegisteredCustomerMaster.id).limit(1)).first()
            if existing:
                logger.info("registered_customer_master 테이블에 이미 데이터가 있어 건너뜁니다.")
                return 0

        count = 0
        with csv_path.open(encoding="utf-8") as f:
            for row in csv.DictReader(f):
                session.add(
                    RegisteredCustomerMaster(
                        identification_no=row["identification_no"].strip(),
                        name_ko=row["name_ko"].strip(),
                        name_eng=row["name_eng"].strip() or None,
                        customer_type=row["customer_type"].strip(),
                        residence_status=row["residence_status"].strip(),
                        credit_rating=int(row["credit_rating"]),
                        annual_remittance_limit_usd=row["annual_remittance_limit_usd"],
                        annual_accumulated_usd=row["annual_accumulated_usd"],
                        designated_bank_status=row["designated_bank_status"].strip(),
                        is_bank_designated=_to_bool(row["is_bank_designated"]),
                        designated_purpose=row["designated_purpose"].strip() or None,
                        is_delinquent_borrower=_to_bool(row["is_delinquent_borrower"]),
                        registered_since=date.fromisoformat(row["registered_since"].strip()),
                    )
                )
                count += 1
        logger.info("등록 고객 마스터 %d건 적재 완료", count)
        return count


def run(reset: bool = False) -> None:
    init_db()
    n_reason = seed_reason_codes(reset=reset)
    n_swift = seed_swift_master(reset=reset)
    n_customers = seed_registered_customers(reset=reset)
    logger.info(
        "Seed 완료: reason_codes=%d, swift_sanction_master=%d, registered_customer_master=%d",
        n_reason, n_swift, n_customers,
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Mock 데이터 시딩")
    parser.add_argument(
        "--reset", action="store_true", help="기존 데이터를 삭제하고 다시 적재"
    )
    args = parser.parse_args()
    run(reset=args.reset)


if __name__ == "__main__":
    main()
