"""SQLAlchemy 엔진 / 세션 관리.

프로토타입은 SQLite를 기본으로 사용하지만, ``DATABASE_URL`` 환경변수만
바꾸면 PostgreSQL 등으로 쉽게 전환할 수 있도록 연결 문자열을 config에서만
다룬다 (모델/서비스 코드는 특정 DB 방언에 의존하지 않는다).
"""

from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from sqlalchemy import create_engine, inspect, text
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from config.settings import get_settings


class Base(DeclarativeBase):
    """모든 ORM 모델의 공통 Base."""


def _make_engine():
    settings = get_settings()

    # SQLite 파일 사용 시 상위 디렉토리(data/)가 없으면 생성한다.
    if settings.database_url.startswith("sqlite:///"):
        db_path = settings.database_url.replace("sqlite:///", "", 1)
        Path(db_path).resolve().parent.mkdir(parents=True, exist_ok=True)
        connect_args = {"check_same_thread": False}
    else:
        connect_args = {}

    return create_engine(settings.database_url, connect_args=connect_args, future=True)


engine = _make_engine()
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)


def init_db() -> None:
    """등록된 모든 모델을 기반으로 테이블을 생성한다 (없는 테이블만 생성)."""

    # 모델을 import 해야 Base.metadata 에 테이블이 등록된다.
    from database import models  # noqa: F401

    Base.metadata.create_all(bind=engine)
    _ensure_new_columns()


def _ensure_new_columns() -> None:
    """이미 만들어진 기존 DB 파일에 새로 추가된 컬럼이 없으면 보강한다.

    이 프로젝트는 Alembic 같은 마이그레이션 도구 없이 ``create_all``만
    쓰는데, ``create_all``은 없는 "테이블"만 만들 뿐 이미 있는 테이블에
    "컬럼"을 추가해주지는 않는다. 그래서 모델에 컬럼을 새로 추가하면,
    이미 만들어져 있던 기존 DB 파일(예: 처리 로그에 남아있는 과거 완료
    거래)에서는 그 컬럼이 없어 저장 시 "no such column" 오류가 난다.
    여기서 없는 컬럼만 ``ALTER TABLE ... ADD COLUMN``으로 최소한으로
    보강해, 기존 데이터를 지우지 않고 새 컬럼을 쓸 수 있게 한다.
    """

    inspector = inspect(engine)
    table_names = inspector.get_table_names()

    if "transaction_request" in table_names:
        existing_columns = {c["name"] for c in inspector.get_columns("transaction_request")}
        if "ocr_corrections" not in existing_columns:
            with engine.begin() as conn:
                conn.execute(text("ALTER TABLE transaction_request ADD COLUMN ocr_corrections JSON"))

    # designated_bank_status("SELF"=당행 지정/"OTHER"=타행 지정/"NONE"=미지정) -
    # 기존 불리언 is_bank_designated를 대체하는 3단계 컬럼. 기존 행은 당행/타행을
    # 구분할 수 없어 True -> "SELF", False -> "NONE"으로 보수적으로 채운다
    # (registered_customer_master는 이후 Mock 데이터를 새로 재시딩하므로
    # 대부분 실제 3단계 값으로 덮어써진다).
    for table in ("registered_customer_master", "system_lookup_data"):
        if table not in table_names:
            continue
        existing_columns = {c["name"] for c in inspector.get_columns(table)}
        if "designated_bank_status" not in existing_columns:
            with engine.begin() as conn:
                conn.execute(text(f"ALTER TABLE {table} ADD COLUMN designated_bank_status VARCHAR(10)"))
                conn.execute(
                    text(
                        f"UPDATE {table} SET designated_bank_status = "
                        "CASE WHEN is_bank_designated THEN 'SELF' ELSE 'NONE' END"
                    )
                )


@contextmanager
def get_session() -> Iterator[Session]:
    """with 문으로 사용하는 세션 컨텍스트 매니저.

    사용 예::

        with get_session() as session:
            session.add(obj)
    """

    session = SessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
