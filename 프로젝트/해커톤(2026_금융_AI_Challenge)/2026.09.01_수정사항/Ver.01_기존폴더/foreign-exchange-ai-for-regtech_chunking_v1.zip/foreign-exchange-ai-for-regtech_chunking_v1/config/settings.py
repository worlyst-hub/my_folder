"""애플리케이션 전역 설정.

모든 환경변수는 이 모듈을 통해서만 읽는다. 다른 모듈에서 ``os.environ``을
직접 참조하지 않고 ``from config.settings import get_settings`` 를 사용한다.
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic_settings import BaseSettings, SettingsConfigDict

# 프로젝트 루트 (이 파일 기준 상위 디렉토리)
BASE_DIR = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    """.env / 환경변수에서 로드되는 설정값.

    실제 값이 없을 경우에도 프로토타입이 Mock 모드로 동작할 수 있도록
    모든 필드에 안전한 기본값을 둔다.
    """

    model_config = SettingsConfigDict(
        env_file=str(BASE_DIR / ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # ---- 실행 모드 ----
    llm_mode: Literal["mock", "live"] = "mock"
    ocr_mode: Literal["mock", "vision"] = "mock"
    rag_mode: Literal["mock", "pdf"] = "mock"

    # ---- Ollama (LLM 분석 전용) ----
    # 로컬 Ollama(http://localhost:11434, 인증 불필요) 또는
    # Ollama Cloud(https://ollama.com, OLLAMA_API_KEY 필요) 둘 다 지원한다.
    # 기본값은 Ollama Cloud의 gpt-oss:120b-cloud다 - 실측 비교 결과
    # llama3.1(8B, 로컬)보다 종합 지능/코딩/한국어 이해 전부 확실히 앞서서
    # (섹션 41.21 참고) LLM_MODE=live일 때의 기본 모델로 채택했다. 다만
    # Ollama Cloud 계정/API Key가 필요하다 - 키가 없으면 아래 OLLAMA_MODEL을
    # `llama3.1`로, OLLAMA_BASE_URL을 `http://localhost:11434`로 바꾸고
    # `ollama pull llama3.1`로 로컬에서 무료로 쓸 수 있다.
    ollama_base_url: str = "https://ollama.com"
    ollama_model: str = "gpt-oss:120b-cloud"
    # Vision OCR 콜드 스타트(모델이 메모리에서 내려간 뒤 첫 호출)가 이미지
    # 인코딩만으로 약 50초, 전체는 70~90초까지 걸릴 수 있어(섹션 41.20) 60초
    # 미만이면 타임아웃이 실제로 발생한다. 120초로 여유를 둔다.
    ollama_timeout: int = 120
    # Ollama Cloud 등 인증이 필요한 엔드포인트용 API Key. 설정되면 LLM 분석
    # 호출에 "Authorization: Bearer <key>" 헤더로 자동 첨부된다. 로컬
    # Ollama는 비워두면 된다.
    ollama_api_key: str | None = None

    # ---- Ollama Vision (OCR_MODE=vision 전용) ----
    # LLM과 별도의 엔드포인트를 쓸 수 있다(비워두면 위 ollama_base_url/
    # ollama_api_key를 그대로 씀). Ollama Cloud는 qwen2.5vl 같은 Vision
    # 모델을 제공하지 않으므로, 위 LLM 기본값이 Cloud로 바뀐 것과 별개로
    # Vision은 항상 로컬 Ollama를 쓰는 것으로 분리했다(.env.example 참고).
    ollama_vision_model: str = "qwen2.5vl"
    ollama_vision_base_url: str | None = None
    ollama_vision_api_key: str | None = None

    # ---- Ollama Embedding (사유코드/RAG 검색) ----
    # LLM과 별도의 엔드포인트를 쓸 수 있다 - 예: LLM은 Ollama Cloud의 대형
    # 모델, 임베딩은 로컬 Ollama의 경량 모델(예: bge-m3) 조합. 비워두면
    # 위의 ollama_base_url/ollama_api_key를 그대로 사용한다. Vision과
    # 마찬가지로 Ollama Cloud는 임베딩 모델을 제공하지 않으므로 로컬로
    # 분리한다.
    ollama_embed_model: str = "nomic-embed-text"
    ollama_embed_base_url: str | None = None
    ollama_embed_api_key: str | None = None

    # ---- Database ----
    database_url: str = f"sqlite:///{(BASE_DIR / 'data' / 'fx_remittance.db').as_posix()}"

    # ---- Vector Store / RAG ----
    chroma_persist_dir: str = str(BASE_DIR / "data" / "chroma")
    regulation_pdf_dir: str = str(BASE_DIR / "data" / "regulations")

    # ---- Logging ----
    log_level: str = "INFO"

    # ---- 기타 경로 ----
    data_dir: str = str(BASE_DIR / "data")


@lru_cache
def get_settings() -> Settings:
    """설정 싱글턴을 반환한다.

    ``lru_cache`` 로 프로세스 내에서 한 번만 로드하여 반복적인 환경변수
    파싱 비용을 피한다.
    """

    return Settings()
