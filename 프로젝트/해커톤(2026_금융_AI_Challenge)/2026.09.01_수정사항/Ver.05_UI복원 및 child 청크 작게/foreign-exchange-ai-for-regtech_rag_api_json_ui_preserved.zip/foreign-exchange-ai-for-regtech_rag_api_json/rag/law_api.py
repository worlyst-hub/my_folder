"""국가법령정보 공동활용 Open API(JSON) 로더.

RAG 색인 대상은 아래 3개로 고정한다.
- 외국환거래법 (target=law)
- 외국환거래법 시행령 (target=law)
- 외국환거래규정 (target=admrul)

API 인증값은 .env의 LAW_API_KEY를 사용하며, 로그/예외 메시지에 인증값을
노출하지 않는다.
"""

from __future__ import annotations

import html
import re
from dataclasses import dataclass
from typing import Any, Iterable
from urllib.parse import parse_qs, urlparse

import requests

from config.settings import get_settings
from utils.logging import get_logger

logger = get_logger(__name__)

TARGET_REGULATIONS: tuple[tuple[str, str], ...] = (
    ("외국환거래법", "law"),
    ("외국환거래법 시행령", "law"),
    ("외국환거래규정", "admrul"),
)

_TAG_RE = re.compile(r"<[^>]+>")
_BR_RE = re.compile(r"<\s*br\s*/?\s*>", re.IGNORECASE)
_SPACE_RE = re.compile(r"[ \t]+")


# API JSON의 조문내용이 한 문자열에 항·호·목을 이어 붙여 반환되는 경우가 있어
# 청커가 구조 경계를 잃지 않도록 법령 번호 표현 앞에 줄바꿈을 복원한다.
_CIRCLED_RE = re.compile(r"(?<!\n)\s*(?=[①-⑳])")
_NUMBERED_ITEM_RE = re.compile(r"(?<!\n)\s+(?=\d+(?:-\d+)?\s*[.)]\s*)")
_KOREAN_ITEM_RE = re.compile(r"(?<!\n)\s+(?=[가-하]\s*[.)]\s*)")
_PARAGRAPH_WORD_RE = re.compile(r"(?<!\n)\s+(?=제\s*\d+\s*항(?:\s|$))")
# 행정규칙 전체 조문이 한 필드로 오는 비정형 응답 방어. 제목 괄호가 있는
# 조문 표기는 본문 중 단순 인용보다 실제 조문 시작일 가능성이 높다.
_ARTICLE_INLINE_RE = re.compile(
    r"(?<!^)\s+(?=제\s*\d+(?:-\d+)?\s*조(?:의\s*\d+)?\s*\([^)]*\))"
)


def _structure_legal_text(value: Any) -> str:
    """긴 API 문자열에서 조/항/호/목 시작을 줄 단위로 복원한다."""

    text = _clean_text(value)
    if not text:
        return ""
    text = _ARTICLE_INLINE_RE.sub("\n", text)
    text = _CIRCLED_RE.sub("\n", text)
    text = _PARAGRAPH_WORD_RE.sub("\n", text)
    text = _NUMBERED_ITEM_RE.sub("\n", text)
    text = _KOREAN_ITEM_RE.sub("\n", text)
    lines = [re.sub(r"[ \t]+", " ", line).strip() for line in text.splitlines()]
    return "\n".join(line for line in lines if line).strip()


class LawApiError(RuntimeError):
    """국가법령정보 API 조회/파싱 오류."""


@dataclass(frozen=True)
class LawApiDocument:
    law_name: str
    target: str
    text: str
    source_url: str
    identifier: str


def _clean_text(value: Any) -> str:
    text = html.unescape(str(value or ""))
    text = _BR_RE.sub("\n", text)
    text = _TAG_RE.sub("", text)
    text = text.replace("\r\n", "\n").replace("\r", "\n").replace("\xa0", " ")
    lines = [_SPACE_RE.sub(" ", line).strip() for line in text.splitlines()]
    return "\n".join(line for line in lines if line).strip()


def _as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def _walk_dicts(node: Any) -> Iterable[dict[str, Any]]:
    if isinstance(node, dict):
        yield node
        for value in node.values():
            yield from _walk_dicts(value)
    elif isinstance(node, list):
        for value in node:
            yield from _walk_dicts(value)


def _find_records(payload: Any, name_keys: tuple[str, ...]) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    seen: set[int] = set()
    for item in _walk_dicts(payload):
        if any(key in item for key in name_keys):
            marker = id(item)
            if marker not in seen:
                seen.add(marker)
                records.append(item)
    return records


def _first_scalar(record: dict[str, Any], *keys: str) -> str:
    for key in keys:
        value = record.get(key)
        if value is None or isinstance(value, (dict, list)):
            continue
        text = _clean_text(value)
        if text:
            return text
    return ""


def _normalize_name(value: str) -> str:
    return re.sub(r"\s+", "", _clean_text(value))


def _extract_query_identifier(link: str, key: str) -> str:
    if not link:
        return ""
    try:
        return parse_qs(urlparse(link).query).get(key, [""])[0]
    except Exception:
        return ""


def _collect_content_values(node: Any, wanted_keys: set[str]) -> list[str]:
    values: list[str] = []
    if isinstance(node, dict):
        for key, value in node.items():
            if key in wanted_keys:
                if isinstance(value, list):
                    for child in value:
                        if not isinstance(child, (dict, list)):
                            text = _clean_text(child)
                            if text:
                                values.append(text)
                elif not isinstance(value, dict):
                    text = _clean_text(value)
                    if text:
                        values.append(text)
            if isinstance(value, (dict, list)):
                values.extend(_collect_content_values(value, wanted_keys))
    elif isinstance(node, list):
        for value in node:
            values.extend(_collect_content_values(value, wanted_keys))
    return values


def _dedupe_preserve_order(values: Iterable[str]) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for value in values:
        text = _clean_text(value)
        if not text or text in seen:
            continue
        seen.add(text)
        result.append(text)
    return result


def _render_law_article(unit: dict[str, Any]) -> str:
    number = _first_scalar(unit, "조문번호")
    branch = _first_scalar(unit, "조문가지번호")
    title = _first_scalar(unit, "조문제목")

    if number:
        header = f"제{number}조"
        if branch and branch not in {"0", "00"}:
            header += f"의{int(branch)}" if branch.isdigit() else f"의{branch}"
        if title:
            header += f"({title})"
    else:
        header = title

    base = _structure_legal_text(_first_scalar(unit, "조문내용"))
    lines: list[str] = []
    if base:
        lines.append(base)
    elif header:
        lines.append(header)

    extras = _collect_content_values(unit.get("항"), {"항내용", "호내용", "목내용"})
    base_flat = base.replace("\n", " ") if base else ""
    for extra in _dedupe_preserve_order(extras):
        structured_extra = _structure_legal_text(extra)
        if not structured_extra:
            continue
        if structured_extra.replace("\n", " ") in base_flat:
            continue
        lines.append(structured_extra)

    rendered = "\n".join(_dedupe_preserve_order(lines)).strip()
    if header and rendered and not re.match(r"^제\s*\d+", rendered):
        rendered = f"{header}\n{rendered}"
    return rendered


def parse_law_detail(payload: Any) -> str:
    """target=law 상세 JSON에서 조문 원문을 조문 순서대로 합친다."""

    article_units: list[dict[str, Any]] = []
    for item in _walk_dicts(payload):
        value = item.get("조문단위")
        if value is not None:
            article_units.extend(v for v in _as_list(value) if isinstance(v, dict))

    # 응답 구조가 달라져 조문단위 wrapper를 찾지 못한 경우에도 조문번호를
    # 가진 객체를 최후 수단으로 사용한다.
    if not article_units:
        article_units = [item for item in _walk_dicts(payload) if "조문번호" in item]

    rendered = _dedupe_preserve_order(_render_law_article(unit) for unit in article_units)
    if rendered:
        return "\n\n".join(rendered)

    # 드문 비정형 응답 방어: 조문내용 필드만이라도 회수한다.
    fallback = _dedupe_preserve_order(
        _structure_legal_text(value)
        for value in _collect_content_values(payload, {"조문내용"})
    )
    return "\n\n".join(fallback)


def parse_admrul_detail(payload: Any) -> str:
    """target=admrul 상세 JSON에서 행정규칙 조문내용을 추출한다."""

    values = _dedupe_preserve_order(
        _structure_legal_text(value)
        for value in _collect_content_values(payload, {"조문내용"})
    )
    if not values:
        raise LawApiError("행정규칙 JSON 응답에서 조문내용을 찾지 못했습니다.")
    return "\n\n".join(values)


class LawApiClient:
    def __init__(self, session: requests.Session | None = None) -> None:
        settings = get_settings()
        self._api_key = (settings.law_api_key or "").strip()
        self._base_url = settings.law_api_base_url.rstrip("/")
        self._timeout = settings.law_api_timeout
        self._session = session or requests.Session()

    def _get_json(self, endpoint: str, params: dict[str, str | int]) -> Any:
        if not self._api_key:
            raise LawApiError(
                ".env의 LAW_API_KEY가 비어 있습니다. 국가법령정보 공동활용 API 인증값을 입력해주세요."
            )

        request_params = {"OC": self._api_key, "type": "JSON", **params}
        try:
            response = self._session.get(
                f"{self._base_url}/{endpoint}",
                params=request_params,
                timeout=self._timeout,
            )
        except requests.RequestException:
            raise LawApiError("국가법령정보 공동활용 API에 연결하지 못했습니다.") from None

        if response.status_code != 200:
            raise LawApiError(
                f"국가법령정보 공동활용 API가 HTTP {response.status_code}를 반환했습니다."
            )
        try:
            return response.json()
        except ValueError:
            raise LawApiError("국가법령정보 공동활용 API 응답이 JSON 형식이 아닙니다.") from None

    def _search_exact(self, law_name: str, target: str) -> dict[str, Any]:
        payload = self._get_json(
            "lawSearch.do",
            {"target": target, "query": law_name, "search": 1, "display": 20},
        )
        name_keys = ("법령명한글", "법령명") if target == "law" else ("행정규칙명",)
        records = _find_records(payload, name_keys)

        wanted = _normalize_name(law_name)
        exact: list[dict[str, Any]] = []
        for record in records:
            candidate = _first_scalar(record, *name_keys)
            if _normalize_name(candidate) == wanted:
                exact.append(record)

        if not exact:
            raise LawApiError(f"API 검색 결과에서 '{law_name}'의 정확한 현행 항목을 찾지 못했습니다.")

        # 검색 결과가 여러 건이면 시행일자/공포일자/발령일자가 큰 항목을 우선한다.
        def sort_key(record: dict[str, Any]) -> tuple[str, str]:
            return (
                _first_scalar(record, "시행일자"),
                _first_scalar(record, "공포일자", "발령일자"),
            )

        exact.sort(key=sort_key, reverse=True)
        return exact[0]

    def _detail_params(self, record: dict[str, Any], target: str) -> tuple[dict[str, str], str]:
        if target == "law":
            law_id = _first_scalar(record, "법령ID")
            mst = _first_scalar(record, "법령일련번호", "법령MST", "MST")
            link = _first_scalar(record, "법령상세링크", "상세링크")
            law_id = law_id or _extract_query_identifier(link, "ID")
            mst = mst or _extract_query_identifier(link, "MST")
            if law_id:
                return {"target": "law", "ID": law_id}, law_id
            if mst:
                return {"target": "law", "MST": mst}, mst
            raise LawApiError("법령 검색 결과에서 상세 조회용 ID/MST를 찾지 못했습니다.")

        # 행정규칙 상세 API의 ID는 '행정규칙일련번호', LID는 '행정규칙ID'다.
        serial = _first_scalar(record, "행정규칙일련번호")
        lid = _first_scalar(record, "행정규칙ID")
        link = _first_scalar(record, "행정규칙상세링크", "상세링크")
        serial = serial or _extract_query_identifier(link, "ID")
        lid = lid or _extract_query_identifier(link, "LID")
        if serial:
            return {"target": "admrul", "ID": serial}, serial
        if lid:
            return {"target": "admrul", "LID": lid}, lid
        raise LawApiError("행정규칙 검색 결과에서 상세 조회용 ID/LID를 찾지 못했습니다.")

    def fetch_document(self, law_name: str, target: str) -> LawApiDocument:
        record = self._search_exact(law_name, target)
        detail_params, identifier = self._detail_params(record, target)
        payload = self._get_json("lawService.do", detail_params)
        text = parse_law_detail(payload) if target == "law" else parse_admrul_detail(payload)
        if not text.strip():
            raise LawApiError(f"'{law_name}' JSON 응답에서 색인할 조문 텍스트를 찾지 못했습니다.")

        logger.info("국가법령정보 API 로드 완료: %s (target=%s)", law_name, target)
        return LawApiDocument(
            law_name=law_name,
            target=target,
            text=text,
            source_url="https://www.law.go.kr",
            identifier=identifier,
        )

    def fetch_target_regulations(self) -> list[LawApiDocument]:
        return [self.fetch_document(name, target) for name, target in TARGET_REGULATIONS]


def load_target_regulations() -> list[LawApiDocument]:
    """RAG에서 사용하는 3개 외국환 법령/규정을 API JSON으로 로드한다."""

    return LawApiClient().fetch_target_regulations()
