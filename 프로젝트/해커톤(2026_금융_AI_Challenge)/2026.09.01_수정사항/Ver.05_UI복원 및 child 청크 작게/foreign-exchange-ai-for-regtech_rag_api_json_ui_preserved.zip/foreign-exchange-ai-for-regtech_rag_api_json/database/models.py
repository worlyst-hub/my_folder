"""SQLAlchemy ORM 모델.

기준 데이터 모델(섹션 4 JSON 구조)에 대응하는 테이블과, 사유코드 /
SWIFT / RAG 문서 관리를 위한 테이블을 정의한다.

customer_profile, transaction_request, system_lookup_data 는 실제 업무
흐름상 1건의 거래 처리마다 생성되는 레코드로 취급한다 (은행원이 신청서를
처리할 때마다 새 고객/거래 레코드가 생기는 프로토타입 전제).
"""

from __future__ import annotations

import enum
from datetime import date, datetime, timezone
from decimal import Decimal

from sqlalchemy import (
    JSON,
    Boolean,
    Date,
    DateTime,
    Enum as SAEnum,
    ForeignKey,
    Numeric,
    String,
    Text,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from database.connection import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class CustomerType(str, enum.Enum):
    INDIVIDUAL = "INDIVIDUAL"
    CORPORATE = "CORPORATE"


class ResidenceStatus(str, enum.Enum):
    RESIDENT = "RESIDENT"
    NON_RESIDENT = "NON_RESIDENT"
    FOREIGN_RESIDENT = "FOREIGN_RESIDENT"


class RecipientType(str, enum.Enum):
    INDIVIDUAL = "INDIVIDUAL"
    CORPORATE = "CORPORATE"


class TransactionStatus(str, enum.Enum):
    """Streamlit Wizard 진행 상태 추적용."""

    DRAFT = "DRAFT"                # OCR 직후, 은행원 확인 전
    CONFIRMED = "CONFIRMED"        # 은행원이 OCR 결과 확인/수정 완료
    ANALYZED = "ANALYZED"          # LLM 분석 + 사유코드 확인 완료
    DOCS_CHECKED = "DOCS_CHECKED"  # 필요서류 체크 완료
    COMPLETED = "COMPLETED"        # 최종 처리 완료


# ---------------------------------------------------------------------------
# customer_profile
# ---------------------------------------------------------------------------


class CustomerProfile(Base):
    __tablename__ = "customer_profile"

    id: Mapped[int] = mapped_column(primary_key=True)
    customer_type: Mapped[CustomerType] = mapped_column(SAEnum(CustomerType))
    residence_status: Mapped[ResidenceStatus] = mapped_column(SAEnum(ResidenceStatus))
    name_ko: Mapped[str | None] = mapped_column(String(100), nullable=True)
    name_eng: Mapped[str | None] = mapped_column(String(100), nullable=True)
    identification_no: Mapped[str | None] = mapped_column(String(50), nullable=True)
    account_number: Mapped[str | None] = mapped_column(String(50), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    system_lookup: Mapped["SystemLookupData | None"] = relationship(
        back_populates="customer", uselist=False, cascade="all, delete-orphan"
    )
    transactions: Mapped[list["TransactionRequest"]] = relationship(
        back_populates="customer", cascade="all, delete-orphan"
    )


# ---------------------------------------------------------------------------
# registered_customer_master
# ---------------------------------------------------------------------------


class RegisteredCustomerMaster(Base):
    """당행에 이미 등록되어 있는 고객 마스터 (Mock, ``data/registered_customers.csv`` 시딩).

    위 ``CustomerProfile``(신청서를 낼 때마다 새로 생기는 레코드)과 달리
    이 테이블은 은행이 사전에 보유한 고정 데이터다. ②단계에서 거래정보를
    확정할 때 ``identification_no``로 이 테이블을 조회해 신용도/송금한도를
    참고 정보로 보여준다(``services/system_lookup``). 신청서의 고객이
    항상 여기 있는 건 아니다 - 없으면 당행 미등록/신규 고객으로 취급한다.
    """

    __tablename__ = "registered_customer_master"

    id: Mapped[int] = mapped_column(primary_key=True)
    identification_no: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    name_ko: Mapped[str] = mapped_column(String(100))
    name_eng: Mapped[str | None] = mapped_column(String(100), nullable=True)
    customer_type: Mapped[CustomerType] = mapped_column(SAEnum(CustomerType))
    residence_status: Mapped[ResidenceStatus] = mapped_column(SAEnum(ResidenceStatus))

    credit_rating: Mapped[int] = mapped_column()
    annual_remittance_limit_usd: Mapped[Decimal] = mapped_column(Numeric(18, 2))
    annual_accumulated_usd: Mapped[Decimal] = mapped_column(Numeric(18, 2), default=0)
    # 거래외국환은행 지정 상태 - "SELF"(당행 지정) / "OTHER"(타행 지정) /
    # "NONE"(미지정) 3단계 (utils/labels.py의 DESIGNATED_BANK_STATUS_LABELS).
    # is_bank_designated(레거시 불리언 컬럼)는 이전 스키마와의 호환을 위해
    # 남겨두고 저장 시점에 designated_bank_status로부터 자동 계산한다 -
    # 화면/서비스 로직에서는 더 이상 직접 읽지 않는다.
    designated_bank_status: Mapped[str] = mapped_column(String(10), default="NONE")
    is_bank_designated: Mapped[bool] = mapped_column(Boolean, default=False)
    designated_purpose: Mapped[str | None] = mapped_column(String(20), nullable=True)
    is_delinquent_borrower: Mapped[bool] = mapped_column(Boolean, default=False)
    registered_since: Mapped[date] = mapped_column(Date)


# ---------------------------------------------------------------------------
# system_lookup_data
# ---------------------------------------------------------------------------


class SystemLookupData(Base):
    """은행 내부/외부 시스템(금융결제원, Core DB, 신용정보원 등) 조회 결과.

    프로토타입에서는 ``services/system_lookup`` 의 Mock Service 가 채운다.
    """

    __tablename__ = "system_lookup_data"

    id: Mapped[int] = mapped_column(primary_key=True)
    customer_id: Mapped[int] = mapped_column(
        ForeignKey("customer_profile.id", ondelete="CASCADE"), unique=True
    )

    annual_accumulated_usd: Mapped[Decimal] = mapped_column(Numeric(18, 2), default=0)
    # RegisteredCustomerMaster.designated_bank_status와 동일한 3단계값
    # ("SELF"/"OTHER"/"NONE"). is_bank_designated는 레거시 호환용으로 남겨두고
    # 저장 시점에 자동 계산한다.
    designated_bank_status: Mapped[str] = mapped_column(String(10), default="NONE")
    is_bank_designated: Mapped[bool] = mapped_column(Boolean, default=False)
    designated_purpose: Mapped[str | None] = mapped_column(String(20), nullable=True)
    is_delinquent_borrower: Mapped[bool] = mapped_column(Boolean, default=False)
    looked_up_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    customer: Mapped["CustomerProfile"] = relationship(back_populates="system_lookup")


# ---------------------------------------------------------------------------
# transaction_request
# ---------------------------------------------------------------------------


class TransactionRequest(Base):
    __tablename__ = "transaction_request"

    id: Mapped[int] = mapped_column(primary_key=True)
    customer_id: Mapped[int] = mapped_column(
        ForeignKey("customer_profile.id", ondelete="CASCADE")
    )

    raw_transaction_purpose: Mapped[str | None] = mapped_column(Text, nullable=True)
    remittance_currency: Mapped[str | None] = mapped_column(String(10), nullable=True)
    remittance_amount: Mapped[Decimal | None] = mapped_column(Numeric(18, 2), nullable=True)

    recipient_type: Mapped[RecipientType | None] = mapped_column(
        SAEnum(RecipientType), nullable=True
    )
    recipient_name: Mapped[str | None] = mapped_column(String(200), nullable=True)
    recipient_country: Mapped[str | None] = mapped_column(String(2), nullable=True)
    beneficiary_bank_name: Mapped[str | None] = mapped_column(String(200), nullable=True)
    swift_bic: Mapped[str | None] = mapped_column(String(11), nullable=True)

    status: Mapped[TransactionStatus] = mapped_column(
        SAEnum(TransactionStatus), default=TransactionStatus.DRAFT
    )

    # 은행원이 확인한 사유코드 (확정 시 채워짐)
    confirmed_reason_code: Mapped[str | None] = mapped_column(String(20), nullable=True)

    # 필요서류 체크 상태: {"부동산 매매계약서": true, "자금 증빙서류": false, ...}
    required_documents_checked: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    # 은행원이 ②단계에서 OCR 원본 인식값을 고쳐 확정한 필드만 기록한다:
    # {"고객명(한글)": {"ocr": "최기영", "confirmed": "최기영2"}, ...}. OCR을
    # 거치지 않고 처음부터 직접 입력한 경우(빈 서식)나 고친 필드가 없으면
    # null. 처리 로그(⑦)에서 OCR 정확도 참고용으로 보여준다.
    ocr_corrections: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow
    )

    customer: Mapped["CustomerProfile"] = relationship(back_populates="transactions")


# ---------------------------------------------------------------------------
# reason_codes
# ---------------------------------------------------------------------------


class ReasonCode(Base):
    __tablename__ = "reason_codes"

    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(20), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(200))
    category: Mapped[str] = mapped_column(String(100))
    description: Mapped[str] = mapped_column(Text)
    keywords: Mapped[list[str]] = mapped_column(JSON, default=list)
    required_documents: Mapped[list[str]] = mapped_column(JSON, default=list)
    regulation_tags: Mapped[list[str]] = mapped_column(JSON, default=list)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


# ---------------------------------------------------------------------------
# swift_sanction_master
# ---------------------------------------------------------------------------


class SwiftSanctionMaster(Base):
    __tablename__ = "swift_sanction_master"

    id: Mapped[int] = mapped_column(primary_key=True)
    swift_code: Mapped[str] = mapped_column(String(11), unique=True, index=True)
    bank_name: Mapped[str] = mapped_column(String(100))
    country_code: Mapped[str] = mapped_column(String(2))
    is_sanctioned: Mapped[bool] = mapped_column(Boolean, default=False)
    sanction_reason: Mapped[str | None] = mapped_column(String(200), nullable=True)
    estimated_days: Mapped[str | None] = mapped_column(String(10), nullable=True)
    handling_note: Mapped[str | None] = mapped_column(Text, nullable=True)


# ---------------------------------------------------------------------------
# rag_documents / rag_chunks
# ---------------------------------------------------------------------------


class RagDocument(Base):
    """국가법령정보 공동활용 API에서 색인한 법령/행정규칙 1건."""

    __tablename__ = "rag_documents"

    id: Mapped[int] = mapped_column(primary_key=True)
    file_name: Mapped[str] = mapped_column(String(300))
    title: Mapped[str | None] = mapped_column(String(300), nullable=True)
    source_path: Mapped[str | None] = mapped_column(String(500), nullable=True)
    is_sample: Mapped[bool] = mapped_column(Boolean, default=False)
    indexed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    chunks: Mapped[list["RagChunk"]] = relationship(
        back_populates="document", cascade="all, delete-orphan"
    )


class RagChunk(Base):
    """RAG 검색 단위 청크. 실제 임베딩 벡터는 Chroma에 별도 저장하고,

    이 테이블은 원문/출처(조문)를 보존하는 SQL 진실원본(source of
    truth) 역할을 한다. API 원문은 페이지 개념이 없어 page_number는 null이다. Chroma 벡터의 id는 이 레코드의 ``id`` 문자열을
    그대로 사용한다.
    """

    __tablename__ = "rag_chunks"

    id: Mapped[int] = mapped_column(primary_key=True)
    document_id: Mapped[int] = mapped_column(
        ForeignKey("rag_documents.id", ondelete="CASCADE")
    )
    chunk_index: Mapped[int] = mapped_column(default=0)
    page_number: Mapped[int | None] = mapped_column(nullable=True)
    article: Mapped[str | None] = mapped_column(String(100), nullable=True)
    content: Mapped[str] = mapped_column(Text)

    document: Mapped["RagDocument"] = relationship(back_populates="chunks")
