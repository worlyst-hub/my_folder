> **2026-09-01 API 전용 RAG 변경 안내**
> 현재 실행 코드는 PDF/Mock RAG가 아니라 국가법령정보 공동활용 API(JSON) 전용입니다.
> 대상은 외국환거래법, 외국환거래법 시행령, 외국환거래규정 3개이며, 아래 문서의 과거 PDF/Mock RAG 기록은 개발 이력 참고용입니다.

# FIXAR(ForeIgn eXchange AI for RegTech) - 외환거래 업무 지원 AI 시스템 - Python 프로젝트 구현 프롬프트

## 0. 프로젝트 목적

Python과 Streamlit을 이용해 은행 창구 직원의 외환거래 업무를 지원하는 프로토타입을 구현합니다.

핵심 목표는 고객이 수기로 작성하고 체크한 외화송금신청서를 OCR로 읽어 구조화된 거래 데이터로 변환한 뒤, 은행원이 내용을 확인·수정하고, 확정된 거래정보를 기반으로 다음 업무를 지원하는 것입니다.

1. 외화송금신청서 OCR
2. 은행원 OCR 결과 확인 및 수정
3. LLM(Ollama)을 이용한 거래 목적/적요 문맥 분석
4. 사유코드 DB 기반 거래 목적 표준화
5. 국가법령정보센터 PDF를 활용한 RAG 기반 외환거래 규정 검색
6. RAG 기반 필요서류 안내
7. 수취은행 SWIFT BIC 기반 은행/제재/예상 소요시간 SQL 조회
8. 은행원의 필요서류 직접 확인 및 최종 거래 처리

이 시스템은 은행원의 업무를 지원하는 시스템이며, AI가 법률적 최종 판단이나 실제 송금 승인 여부를 자동 결정하지 않습니다.

---

# 1. 전체 업무 흐름

전체 시스템은 다음 순서로 동작합니다.

```text
고객
 ↓
수기로 외화송금신청서 작성 및 체크
 ↓
은행원이 신청서 이미지/PDF 업로드
 ↓
OCR / Vision
 ↓
신청서 정보 구조화
 ↓
은행원이 OCR 결과를 원본과 대조
 ↓
필요한 항목 직접 수정
 ↓
거래정보 확정
 ↓
┌──────────────────────────────┐
│                              │
▼                              ▼
LLM(Ollama) 거래 문맥 분석       SWIFT BIC SQL 조회
│                              │
▼                              ▼
사유코드 DB 검색                은행/제재/소요시간 정보
│
▼
RAG
│
├─ 관련 외환거래 법령/규정
└─ 필요한 증빙서류
       ↓
은행원이 실제 증빙서류 직접 확인
       ↓
필요서류 체크
       ↓
최종 처리 요약
       ↓
은행원 최종 확인 및 처리 완료
```

---

# 2. 중요한 범위 및 제외사항

## 2.1 OCR 사용 범위

OCR은 **외화송금신청서에서만 사용합니다.**

고객이 수기로 작성하거나 체크한 신청서를 OCR/Vision으로 읽어 구조화된 데이터로 변환합니다.

OCR 대상 예:

- 고객 기본정보
- 송금 통화
- 송금 금액
- 수취인 정보
- 수취은행 정보
- SWIFT BIC
- 송금 목적
- DETAILS OF PAYMENT
- 체크박스
- 기타 신청서에 작성된 거래정보

## 2.2 증빙서류 OCR 금지

증빙서류는 OCR로 읽지 않습니다.

증빙서류는 다음과 같은 비정형 문서가 많다는 전제하에 은행원이 직접 확인합니다.

예:

- 계약서
- 인보이스
- 자금 증빙서류
- 기타 거래 증빙자료

RAG가 필요한 서류를 안내하면 은행원이 실제 제출 서류를 확인하고 화면에서 직접 체크합니다.

구현하지 않는 기능:

- 증빙서류 OCR
- 증빙서류 자동 분류
- 증빙서류 자동 진위 판정
- 증빙서류 OCR 기반 자동 대조

---

# 3. OCR 결과에 대한 처리 원칙

OCR 결과에 대해 별도의 자동 정확도 판정 시스템을 구현하지 않습니다.

즉, 다음과 같은 기능을 핵심 기능으로 구현하지 않습니다.

- OCR confidence threshold 기반 자동 통과/실패
- 자동 OCR 정확도 판정
- 복잡한 OCR validation engine
- OCR 결과를 근거로 자동 거래 승인

대신 다음 방식으로 처리합니다.

```text
OCR
 ↓
OCR 결과 화면 표시
 ↓
원본 신청서와 OCR 결과를 함께 표시
 ↓
은행원이 직접 대조
 ↓
오류/누락이 있으면 직접 수정
 ↓
[확인 완료]
 ↓
확정 거래정보 생성
```

OCR 라이브러리/API가 confidence 값을 제공하는 경우 해당 값을 화면에 참고정보로 표시하는 것은 가능하지만, 프로젝트의 핵심 판단 기준으로 사용하지 않습니다.

최종 정확성 확인 책임은 은행원에게 있습니다.

---

# 4. 최종 데이터 구조

전체 프로젝트의 기준 데이터 모델은 다음 JSON 구조를 사용합니다.

```json
{
  "customer_profile": {
    "customer_type": "INDIVIDUAL",
    "residence_status": "RESIDENT",
    "name_ko": "홍길동",
    "name_eng": "HONG GIL DONG",
    "identification_no": "850101-1******",
    "account_number": "123-4567-8901-23"
  },

  "system_lookup_data": {
    "annual_accumulated_usd": 35000.00,
    "is_bank_designated": true,
    "designated_purpose": "411",
    "is_delinquent_borrower": false
  },

  "transaction_request": {
    "raw_transaction_purpose": "해외 주택 구매 목적으로 계약금 송금하려고 함",
    "remittance_currency": "USD",
    "remittance_amount": 150000.00,

    "recipient_info": {
      "recipient_type": "CORPORATE",
      "recipient_name": "US REALTY LLC",
      "recipient_country": "US",
      "beneficiary_bank_name": "CHASE BANK N.A.",
      "swift_bic": "BKTRUS33XXX"
    }
  }
}
```

## 4.1 customer_profile

고객 자체의 기본정보를 관리합니다.

```json
{
  "customer_type": "INDIVIDUAL",
  "residence_status": "RESIDENT",
  "name_ko": "홍길동",
  "name_eng": "HONG GIL DONG",
  "identification_no": "850101-1******",
  "account_number": "123-4567-8901-23"
}
```

### customer_type

- `INDIVIDUAL`: 개인
- `CORPORATE`: 법인/사업자

### residence_status

- `RESIDENT`: 거주자
- `NON_RESIDENT`: 비거주자
- `FOREIGN_RESIDENT`: 외국인거주자

---

# 5. system_lookup_data

고객이 신청서에 작성하는 정보가 아니라 은행 내부 또는 외부 시스템에서 조회된 데이터를 별도로 관리합니다.

```json
{
  "annual_accumulated_usd": 35000.00,
  "is_bank_designated": true,
  "designated_purpose": "411",
  "is_delinquent_borrower": false
}
```

각 데이터의 의미:

- `annual_accumulated_usd`
  - 금융결제원 연동을 가정한 당해연도 전 금융기관 누적 증빙미제출 송금액
- `is_bank_designated`
  - 은행 Core DB에서 해당 고객의 거래외국환은행 지정 등록 여부
- `designated_purpose`
  - 은행 Core DB의 기존 지정 거래 목적
  - 예: `411`
  - 없을 경우 `null`
- `is_delinquent_borrower`
  - 신용정보원 연동을 가정한 신용불량 또는 채무 체납 여부
  - 자본거래 제외

프로토타입에서는 실제 금융결제원/은행 Core DB/신용정보원에 연결하지 않고 Mock DB 또는 Mock Service로 구현합니다.

---

# 6. transaction_request

이번에 신청한 외환거래 정보를 관리합니다.

```json
{
  "raw_transaction_purpose": "해외 주택 구매 목적으로 계약금 송금하려고 함",
  "remittance_currency": "USD",
  "remittance_amount": 150000.00,

  "recipient_info": {
    "recipient_type": "CORPORATE",
    "recipient_name": "US REALTY LLC",
    "recipient_country": "US",
    "beneficiary_bank_name": "CHASE BANK N.A.",
    "swift_bic": "BKTRUS33XXX"
  }
}
```

`raw_transaction_purpose`는 신청서의 송금 목적/적요를 OCR로 추출한 값을 기본으로 합니다.

OCR로 읽기 어렵거나 누락된 경우 은행원이 확인 및 직접 수정합니다.

---

# 7. OCR → 데이터 구조 연결

OCR 결과를 위 데이터 구조에 매핑합니다.

예:

```text
외화송금신청서
      ↓
OCR
      ↓
┌────────────────────────────┐
│ customer_profile           │
│ transaction_request        │
└────────────────────────────┘
      ↓
은행원 확인/수정
      ↓
확정 거래정보
```

`system_lookup_data`는 OCR로 읽지 않습니다.

거래정보가 확정된 후 Mock Service 또는 DB 조회를 통해 채웁니다.

---

# 8. OCR 서비스 구현

OCR은 Service Layer로 분리합니다.

```text
services/
└── ocr/
    ├── base.py
    ├── mock_ocr.py
    ├── paddle_ocr.py        # 실제 구현: PaddleOCR (기본값)
    ├── text_field_mapper.py # PaddleOCR 텍스트 줄 → 신청서 필드 규칙 기반 매퍼
    └── vision_ocr.py        # 실제 구현: Ollama Vision(멀티모달 LLM)
```

예시 인터페이스:

```python
class OCRService:
    def extract(self, file_path):
        ...
```

실제 OCR API 또는 Vision 모델을 나중에 교체할 수 있도록 추상화합니다.

API Key가 없는 환경에서도 전체 프로젝트를 실행할 수 있도록 Mock OCR 구현을 반드시 제공합니다.

> **[구현 변경, 41.18/41.23에서 재변경]** OCR_MODE 두 가지 지원: `mock`(기본) /
> `vision`(Ollama Vision 모델이 이미지/PDF에서 구조화 JSON 직접 추출,
> JPG/PNG/PDF - PDF는 첫 페이지만 인식에 사용, 41.23 참고).
> **`vision`(모델 `qwen2.5vl`)이 유일한 실사용 모드입니다.** 한때 규칙
> 기반 `paddle`(PaddleOCR) 모드도 있었으나, 실제 손글씨 서식으로 직접
> 비교한 결과 `paddle`은 라벨 주변 텍스트를 패턴/키워드로 찾는 방식이라
> 라벨이 밀집된 실제 서식에서 부정확하고 속도도 훨씬 느려서(같은 이미지
> 기준 약 5분 vs `vision` 콜드 스타트 약 70~90초, 캐시 재사용 시 약 17초 -
> 섹션 41.20 참고) 41.18에서 코드/의존성을 완전히 제거했습니다(단, 좋은
> vision 모델을 쓰는 게 전제입니다 - 모델 자체가 약하면(`llava`) 오히려
> 못 씀, 섹션 41.17 참고). 어느 경우든 은행원이
> 원본과 대조해 수정하는 것을 전제로 합니다(섹션 3 원칙과 동일). 자세한
> 배경은 섹션 41.12/41.15/41.17/41.18 참고(과거 PaddleOCR 실험 기록이며,
> 현재 코드베이스에는 해당 구현이 없습니다).

---

# 9. OCR 화면

은행원이 신청서를 업로드하면 원본과 OCR 결과를 함께 보여줍니다.

```text
┌────────────────────┬──────────────────────────┐
│ 원본 신청서          │ OCR 결과                 │
│                    │                          │
│ [신청서 이미지]     │ 고객명: 홍길동            │
│                    │ 금액: USD 150,000        │
│                    │ 수취인: US REALTY LLC    │
│                    │ 은행: CHASE BANK N.A.    │
│                    │ SWIFT: BKTRUS33XXX       │
│                    │ 목적: 해외 주택 구매...    │
└────────────────────┴──────────────────────────┘

[OCR 결과 확인 및 수정]

[확인 완료 → 거래 분석]
```

은행원이 OCR 결과를 직접 수정할 수 있는 입력 UI를 제공합니다.

---

# 10. LLM - Ollama 사용

LLM은 외부 OpenAI API를 사용하지 않습니다.

**Ollama를 사용합니다.**

LLM 호출은 별도의 Service Layer로 분리합니다.

```text
services/
└── llm/
    ├── base.py
    └── ollama_service.py
```

예:

```python
class LLMService:
    def analyze_transaction(self, transaction):
        ...
```

Ollama의 로컬 모델명을 `.env` 또는 설정 파일에서 지정할 수 있도록 합니다.

예:

```text
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=<사용할 로컬 모델>
```

실제 모델명은 하드코딩하지 않습니다.

> **[구현 변경] Ollama Cloud 지원**: 로컬 Ollama(`http://localhost:11434`,
> 인증 불필요) 뿐 아니라 Ollama Cloud(`https://ollama.com`, 대형 모델을
> 클라우드에서 서빙)도 동일한 `OllamaLLMService`로 지원합니다.
> `OLLAMA_API_KEY`를 설정하면 모든 Ollama 호출에
> `Authorization: Bearer <key>` 헤더가 자동으로 붙습니다
> (`services/ollama_client.py`).
>
> **[구현 변경] LLM/임베딩 엔드포인트 분리**: 사유코드/RAG 임베딩
> (섹션 14, 16)은 LLM과 다른 Ollama 엔드포인트를 쓸 수 있습니다
> (`OLLAMA_EMBED_BASE_URL` / `OLLAMA_EMBED_API_KEY` / `OLLAMA_EMBED_MODEL`,
> 비워두면 LLM과 동일한 엔드포인트 사용). 대형 모델은 Ollama Cloud로,
> 임베딩은 로컬 Ollama의 경량 모델로 돌리는 조합을 위한 것입니다. 임베딩
> 모델 기본값은 다국어(한국어 포함) 검색 품질이 좋은 `bge-m3`를 권장합니다
> (영어 위주 모델인 `nomic-embed-text`보다 한국어 문서 검색에 유리).
> Ollama(로컬/Cloud 모두)가 연결되지 않으면 자동으로 경량 해시 기반
> 임베딩으로 폴백하여 앱 자체는 계속 동작합니다 - 자세한 배경은 섹션 41 참고.

---

# 11. LLM 거래 문맥 분석

은행원이 OCR 결과를 확인하고 거래정보를 확정하면 Ollama LLM을 호출합니다.

주요 입력:

- `raw_transaction_purpose`
- `remittance_currency`
- `remittance_amount`
- 수취인 정보
- 수취국가
- 수취은행
- 고객 유형
- 거주자 구분
- 기타 거래정보

예:

```text
송금 목적:
해외 주택 구매 목적으로 계약금 송금하려고 함
```

Ollama LLM은 자연어 거래 목적을 구조화합니다.

예:

```json
{
  "transaction_category": "해외부동산",
  "transaction_action": "취득",
  "transaction_nature": "자본거래",
  "normalized_purpose": "해외부동산 취득",
  "country": "US",
  "important_facts": [
    "해외",
    "주택",
    "구매",
    "계약금"
  ]
}
```

LLM은 법률적 최종 판단을 하지 않습니다.

LLM의 역할은 자연어를 구조화하고 검색에 활용할 수 있는 문맥으로 정리하는 것입니다.

---

# 12. 사유코드

거래 목적을 표준화하기 위해 사유코드를 사용합니다.

프로젝트에는 별도의 사유코드 DB를 구축합니다.

약 100개 수준의 테스트용 사유코드를 구성합니다.

예:

```text
FX-0001 해외유학비
FX-0002 해외체재비
FX-0003 해외부동산 취득
FX-0004 해외부동산 처분
FX-0005 물품대금
...
```

실제 사유코드 명칭과 법적 분류는 프로젝트에서 사용하는 기준 데이터에 맞게 관리합니다.

임의의 숫자 가중치를 이용한 점수식은 사용하지 않습니다.

예를 들어 다음 방식은 구현하지 않습니다.

```python
0.4 * semantic_similarity \
+ 0.2 * transaction_match \
+ 0.15 * customer_match \
+ 0.15 * regulation_match \
+ 0.10 * additional_match
```

---

# 13. 사유코드 DB 구조

```text
reason_codes

id
code
name
category
description
keywords
required_documents
regulation_tags
is_active
```

예:

```json
{
  "code": "FX-0003",
  "name": "해외부동산 취득",
  "category": "자본거래",
  "description": "해외 부동산 취득 관련 거래",
  "keywords": [
    "부동산",
    "주택",
    "아파트",
    "매매",
    "구매",
    "계약금"
  ],
  "regulation_tags": [
    "REAL_ESTATE",
    "CAPITAL_TRANSACTION"
  ]
}
```

---

# 14. 사유코드 검색

LLM이 구조화한 거래 문맥을 이용하여 사유코드 후보를 검색합니다.

가능하면 Embedding 기반 Vector Search를 사용합니다.

```text
LLM 거래 문맥
      ↓
Embedding
      ↓
사유코드 Vector Search
      ↓
Top-K 후보
      ↓
후보 목록 표시
      ↓
은행원 확인
```

중요:

사유코드를 AI가 무조건 최종 확정하도록 만들지 않습니다.

사유코드 후보와 판단 근거를 은행원에게 보여주고, 은행원이 최종 확인할 수 있도록 합니다.

---

# 15. RAG 데이터 원문

RAG에 사용하는 원문 데이터는 **국가법령정보센터에서 제공하는 PDF 파일**을 사용합니다.

프로젝트에서 사용할 실제 PDF 파일은 사용자가 `data/regulations/` 디렉토리에 넣는 것을 전제로 합니다.

```text
data/
└── regulations/
    ├── *.pdf
    ├── *.pdf
    └── ...
```

프로젝트는 PDF를 자동으로 읽어 RAG 인덱스를 생성할 수 있어야 합니다.

---

# 16. RAG 처리 과정

다음 Pipeline을 구현합니다.

```text
국가법령정보센터 PDF
        ↓
PDF Text Extraction
        ↓
문서 Chunking
        ↓
Embedding
        ↓
Vector DB
        ↓
Query 생성
        ↓
관련 법령/조문 검색
        ↓
Ollama LLM을 이용한 결과 정리
        ↓
은행원 화면 출력
```

PDF에서 법령명, 조문 정보, 페이지 등 출처 정보를 최대한 보존합니다.

검색 결과에는 출처를 표시합니다.

예:

```text
[관련 법령]

외국환거래규정

제○조 ...

출처:
파일명: 외국환거래규정.pdf
페이지: 35
```

실제 PDF의 내용과 페이지 정보를 우선하여 표시합니다.

---

# 17. RAG 검색 범위

RAG는 다음 정보를 제공하는 데 사용합니다.

### 관련 외환거래 법령/규정

예:

- 해당 거래와 관련된 법령
- 관련 조문
- 신고/보고 관련 내용
- 거래 요건
- 제한사항

### 필요서류

해당 거래와 관련하여 필요한 증빙서류 정보를 검색합니다.

단, RAG 결과는 은행원의 업무 참고를 위한 정보이며 법률적 최종 판단으로 표현하지 않습니다.

---

# 18. 필요서류 처리

RAG가 필요서류를 안내합니다.

예:

```text
📄 필요서류

☐ 부동산 매매계약서
☐ 자금 증빙서류
☐ 기타 필요서류
```

은행원은 실제 고객이 제출한 서류를 직접 확인합니다.

```text
☑ 부동산 매매계약서
☑ 자금 증빙서류
☐ 기타 필요서류
```

**증빙서류 자체를 OCR로 읽지 않습니다.**

필요서류 체크 상태는 최종 거래 요약에 반영합니다.

---

# 19. SWIFT BIC 조회

SWIFT BIC는 외화송금신청서 OCR 과정에서 추출합니다.

데이터 구조:

```json
{
  "recipient_info": {
    "beneficiary_bank_name": "CHASE BANK N.A.",
    "swift_bic": "BKTRUS33XXX"
  }
}
```

이 값을 이용하여 SWIFT DB를 SQL Query로 조회합니다.

---

# 20. SWIFT DB

`swift_sanction_master` 테이블을 구축합니다.

| 컬럼 | 타입 | 설명 |
|---|---|---|
| `swift_code` | VARCHAR(11) | SWIFT Code |
| `bank_name` | VARCHAR(100) | 은행 영문명 |
| `country_code` | VARCHAR(2) | ISO 국가 코드 |
| `is_sanctioned` | BOOLEAN | 제재 데이터 등재 여부 |
| `sanction_reason` | VARCHAR(200) | 제재 사유 |
| `estimated_days` | VARCHAR(10) | 예상 소요 시간 |
| `handling_note` | TEXT | 창구 안내사항 |

예:

```text
BKTRUS33XXX
CHASE BANK N.A.
US
false
NULL
T+1
현지 시차로 당일 입금이 어려울 수 있음
```

---

# 21. SWIFT 데이터 출처

프로토타입에서는 오픈 SWIFT Code 데이터셋과 오픈 제재 데이터 등을 이용하여 로컬 DB를 구성할 수 있도록 합니다.

실제 운영 환경에서는 은행 내부 Core Banking 및 최신 제재 마스터 데이터로 교체할 수 있도록 데이터 접근 계층을 분리합니다.

오픈 데이터만으로 실제 송금 가능 여부를 최종 판단하지 않습니다.

> **[구현 변경]** `maranemil/swift-bic-codes-allinone`의 `AllCountries_v1`
> (2019년 스냅샷, 232개국)을 가져와 큐레이션 29건에 109,008건을 추가했습니다.
> 추가된 건은 은행 식별 정보만 있고 `is_sanctioned`는 전부 `false`다(실제
> 제재 스크리닝 아님). 원본 국가 컬럼은 스크래핑 오류로 버리고 BIC 코드
> 자체에서 국가를 재계산했습니다. 자세한 내용은 섹션 41.9 참고.

---

# 22. SWIFT 조회 방식

복잡한 ML이나 Rule Engine을 사용하지 않습니다.

단순 SQL Query로 조회합니다.

```sql
SELECT
    swift_code,
    bank_name,
    country_code,
    is_sanctioned,
    sanction_reason,
    estimated_days,
    handling_note
FROM swift_sanction_master
WHERE swift_code LIKE 'BKTRUS33%';
```

8자리 BIC가 입력된 경우 11자리 Branch Code까지 조회할 수 있도록 합니다.

> **[구현 변경]** 한 은행 아래 Branch Code가 여러 건 등재된 경우, 8자리
> BIC(Branch Code 미포함) 조회는 알파벳순 임의 지점이 아니라 관례상
> 본점을 뜻하는 `XXX` 지점을 우선 매칭하도록 정렬 우선순위를 추가했습니다
> (정확히 일치 → `{code}XXX` → 그 외 지점 순). 섹션 41.9 참고.

---

# 23. SWIFT UI

### 정상

```text
✅ 정상

수취은행
CHASE BANK N.A.

국가
United States

SWIFT BIC
BKTRUS33XXX

제재 데이터
정상

예상 소요시간
T+1

안내사항
현지 시차로 인해 당일 입금이 어려울 수 있습니다.
```

### 제재 데이터 등재

```text
⚠️ 확인 필요

수취은행
Sberbank

SWIFT BIC
SABRRU22XXX

제재 데이터
등재

제재 사유
OFAC Sanctions

※ 최신 내부 제재 기준 및 은행 내부 절차 확인 필요
```

"송금 불가"를 오픈 데이터 조회만으로 자동 확정하지 않습니다.

---

# 24. System Lookup Mock Service

실제 시스템 연동을 가정한 데이터는 별도의 Service Layer에서 관리합니다.

```text
services/
└── system_lookup/
    ├── base.py
    └── mock_service.py
```

예:

```python
class SystemLookupService:
    def get_customer_data(self, customer_id):
        ...
```

프로토타입에서는 다음 데이터를 Mock으로 제공합니다.

- 당해연도 전 금융기관 누적 증빙미제출 송금액
- 거래외국환은행 지정 여부
- 기존 지정 거래 목적
- 신용불량/채무 체납 여부

---

# 25. Frontend 구조

Streamlit을 사용하여 은행원 업무용 화면을 구현합니다.

Wizard 방식으로 구성합니다.

```text
① 신청서 업로드
   ↓
② OCR 결과 확인
   ↓
③ 거래정보 확정
   ↓
④ 거래 문맥 분석 / 사유코드
   ↓
⑤ 법령 / 필요서류
   ↓
⑥ SWIFT 조회
   ↓
⑦ 최종 처리 요약
```

현재 단계가 화면 상단에서 표시되도록 합니다.

> **[구현 변경]** ②(OCR 결과 확인)와 ③(거래정보 확정)은 한 화면
> (`frontend/ocr_result.py`)에서 "수정 → 확인 완료" 흐름으로 합쳐서 총 6개
> Wizard 화면으로 구현했습니다(섹션 34 `frontend/` 참고). 진행 단계 표시는 화면
> 상단이 아니라 **왼쪽 사이드바 네비게이션**으로 구현했습니다 - 네이비 배경,
> 완료(✅)/현재(▶)/예정 단계 구분, 완료된 단계는 클릭해서 되돌아갈 수
> 있습니다. 사용자가 예전에 진행한 다른 프로젝트(네이비 사이드바 + 화이트
> 카드 레이아웃)의 디자인 톤을 참고해 재구성했습니다. 자세한 배경은 섹션 41
> 참고.

---

# 26. 화면 1 - 신청서 업로드

```text
외환거래 신청 처리

① 신청서 업로드

┌─────────────────────────────┐
│                             │
│ 외화송금신청서를 업로드하세요 │
│                             │
│     PDF / JPG / PNG         │
│                             │
└─────────────────────────────┘

[OCR 분석 시작]
```

---

# 27. 화면 2 - OCR 결과 확인

원본 신청서와 OCR 결과를 좌우로 표시합니다.

```text
┌──────────────────┬─────────────────────────┐
│ 원본 신청서       │ 인식된 거래정보         │
│                  │                         │
│ [신청서 이미지]  │ 고객명  홍길동          │
│                  │ 금액    USD 150,000     │
│                  │ 수취인  US REALTY LLC  │
│                  │ SWIFT   BKTRUS33XXX     │
│                  │ 목적    해외 주택 구매... │
└──────────────────┴─────────────────────────┘
```

각 필드를 편집할 수 있도록 합니다.

버튼:

```text
[수정]
[확인 완료 → 거래정보 확정]
```

OCR 결과는 은행원이 원본과 직접 대조하여 확인합니다.

---

# 28. 화면 3 - 거래 문맥 분석 / 사유코드

확정된 거래정보를 표시합니다.

```text
송금 목적
해외 주택 구매 목적으로 계약금 송금하려고 함

송금금액
USD 150,000

수취국가
US

수취은행
CHASE BANK N.A.

SWIFT
BKTRUS33XXX
```

Ollama 분석 결과:

```text
거래 유형
해외부동산

거래 행위
취득

거래 성격
자본거래

정규화 거래 목적
해외부동산 취득
```

사유코드 후보:

```text
추천 사유코드

FX-0003
해외부동산 취득

관련 키워드:
부동산 / 주택 / 구매 / 계약금
```

은행원이 확인할 수 있도록 합니다.

---

# 29. 화면 4 - 법령 및 필요서류

### 관련 법령

```text
📚 관련 법령

외국환거래규정

관련 조문:
제○조 ...

출처:
외국환거래규정.pdf
p. 35
```

### 필요서류

```text
📄 필요서류

☐ 부동산 매매계약서
☐ 자금 증빙서류
☐ 기타 필요서류
```

은행원이 실제 서류를 확인한 후 체크합니다.

> **[구현 변경]** 체크리스트를 전부 체크해야 "다음 → SWIFT 조회" 버튼이
> 활성화됩니다. 자세한 내용은 섹션 41.10 참고.

---

# 30. 화면 5 - SWIFT

```text
수취은행 SWIFT

BKTRUS33XXX

[조회]
```

조회 결과를 카드 형태로 표시합니다.

```text
CHASE BANK N.A.

국가
US

SWIFT
BKTRUS33XXX

제재 데이터
정상

예상 소요시간
T+1
```

> **[구현 변경]** SWIFT BIC를 조회한 뒤 입력값을 다시 수정하면, 새로
> 조회하기 전까지 "다음" 버튼이 비활성화됩니다(이전 코드의 결과가 화면에
> 남은 채로 넘어가는 것을 방지). 섹션 41.10 참고.

---

# 31. 화면 6 - 최종 처리 요약

전체 거래 정보를 한 화면에서 보여줍니다.

```text
외환거래 처리 요약

[고객]
홍길동
개인 / 거주자

[송금]
USD 150,000

[수취인]
US REALTY LLC
US

[수취은행]
CHASE BANK N.A.
BKTRUS33XXX

[거래 분석]
해외부동산 취득
자본거래

[사유코드]
FX-0003
해외부동산 취득

[SWIFT]
제재 데이터 정상
예상 소요시간 T+1

[필요서류]
☑ 부동산 매매계약서
☑ 자금 증빙서류

────────────────────────

[처리 완료]
```

> **[구현 변경]** SWIFT 조회 결과가 제재 데이터 등재 은행이거나 필요서류
> 체크가 남아있으면, "위 사항을 확인했으며..." 체크박스를 직접 눌러야만
> [처리 완료] 버튼이 활성화됩니다(자동으로 막지는 않고, 은행원의 명시적
> 확인을 요구 - 섹션 18/32 원칙과 일치). 섹션 41.10 참고.

---

# 32. UI 디자인 원칙

은행 내부 업무 시스템과 유사한 형태로 구현합니다.

- 과도한 애니메이션 사용 금지
- 지나치게 화려한 디자인 금지
- 정보 밀도가 높지만 읽기 쉽게 구성
- 확인 필요 항목을 명확하게 표시
- 원본 신청서와 OCR 결과를 쉽게 비교
- AI 결과는 은행원이 확인할 수 있도록 구성
- AI가 법률적 최종 판단을 하는 것처럼 표현하지 않음
- AI가 실제 송금 승인을 자동 결정하는 것처럼 표현하지 않음

---

# 33. 오류 처리

## OCR 실패

```text
OCR 분석에 실패했습니다.

신청서 이미지의 해상도 또는 촬영 상태를 확인해주세요.

[다시 업로드]
```

## SWIFT 조회 실패

```text
⚠️ SWIFT 정보를 조회할 수 없습니다.

등록되지 않은 SWIFT Code이거나
DB에 해당 데이터가 존재하지 않습니다.

은행원 확인이 필요합니다.
```

## RAG 검색 실패

```text
관련 법령 또는 규정 정보를 찾지 못했습니다.

최신 내부 규정 확인이 필요합니다.
```

## Ollama 연결 실패

```text
⚠️ AI 분석 서비스를 사용할 수 없습니다.

Ollama 실행 상태와 모델 설정을 확인해주세요.

[다시 시도]
```

Mock LLM 모드를 제공하여 Ollama가 실행되지 않아도 전체 UI를 테스트할 수 있도록 합니다.

---

# 34. 프로젝트 디렉토리 구조

다음과 유사한 구조로 구현합니다.

> **[구현 변경, 41.22에서 재변경]** 아래는 실제 구현된 구조입니다. 가상환경
> 폴더명은 관례적인 `venv`가 아니라 **`fixar`**로 만들었습니다
> (`python -m venv fixar`) - 프로젝트가 FIXAR로 명명되기 전에는 `project`라는
> 이름을 썼으나(41.1), 브랜드명이 FIXAR로 확정된 뒤(41.14) `fixar`로
> 다시 만들었습니다(41.22 참고). 원본 프롬프트 파일
> (`fx-trade-assistant-ai_prompt.md`)과 셋업 스크립트(`setup.ps1`/`setup.sh`)는
> 저장소 최상위에 함께 둡니다. 자세한 내용은 섹션 41.11 참고. **팀 작업
> 분담(RAG/프론트엔드)에 맞춰 `services/rag/` → `rag/`, `ui/` →
> `frontend/`로 최상위 디렉토리를 분리했습니다 - 섹션 41.16 참고.**

```text
fx-remittance-ai/
│
├── app.py
├── requirements.txt
├── setup.ps1                # 원클릭 셋업 - Windows: pip install + Ollama 설치 확인/설치 + 모델 pull + DB seed
├── setup.sh                 # 원클릭 셋업 - macOS/Linux: setup.ps1과 동일한 절차
├── .env.example
├── .env                     # git 추적 안 함 (.gitignore)
├── README.md
│
├── config/
│   └── settings.py
│
├── database/
│   ├── connection.py
│   ├── models.py
│   └── seed.py
│
├── schemas/
│   ├── customer.py
│   ├── transaction.py
│   ├── system_lookup.py
│   ├── reason_code.py
│   ├── swift.py
│   └── analysis.py
│
├── rag/                     # [팀 담당: RAG] services/rag/에서 최상위로 이동(41.16)
│   ├── document_loader.py
│   ├── chunker.py
│   ├── embedder.py
│   ├── retriever.py
│   └── sample_regulations.py  # RAG_MODE=mock용 샘플 규정 데이터
│
├── services/
│   ├── ollama_client.py     # LLM/임베딩 공용 Ollama Client 생성 헬퍼 (로컬/Cloud, API Key)
│   ├── embedding_client.py  # 사유코드/RAG 공용 Embedding 클라이언트 (Ollama ↔ 해시 폴백) - rag 전용이 아니라 공용이라 그대로 유지
│   │
│   ├── ocr/
│   │   ├── base.py
│   │   ├── mock_ocr.py
│   │   └── vision_ocr.py        # 실제 구현: Ollama Vision (JPG/PNG/PDF, PDF는 첫 페이지만 - 41.23)
│   │
│   ├── llm/
│   │   ├── base.py
│   │   ├── ollama_service.py
│   │   └── mock_llm.py
│   │
│   ├── reason_code/
│   │   └── mapper.py
│   │
│   ├── swift/
│   │   └── service.py
│   │
│   └── system_lookup/
│       ├── base.py
│       └── mock_service.py
│
├── data/
│   ├── reason_codes.csv
│   ├── generate_reason_codes.py   # reason_codes.csv 생성 스크립트 (1회성)
│   ├── swift_sanction_master.csv
│   ├── forms/                     # 참고용 실제 은행 서식(PDF) - 41.12
│   │   └── README.md
│   └── regulations/
│       └── README.md
│
├── static/
│   └── fonts/                # 하나체(Hana2) TTF 6종 - .streamlit/config.toml 참고
│
├── frontend/                 # [팀 담당: 프론트엔드] ui/에서 최상위로 이동(41.16)
│   ├── theme.py              # 네이비 사이드바 + 화이트 카드 디자인 테마/헬퍼
│   ├── upload.py
│   ├── ocr_result.py
│   ├── transaction_analysis.py
│   ├── regulation.py
│   ├── swift.py
│   └── summary.py
│
├── tests/
│   ├── conftest.py
│   ├── test_ocr.py
│   ├── test_paddle_ocr.py
│   ├── test_llm.py
│   ├── test_reason_code.py
│   ├── test_rag.py
│   ├── test_swift.py
│   ├── test_validation.py
│   └── test_integration_flow.py
│
└── utils/
    ├── validation.py
    └── logging.py
```

---

# 35. 데이터베이스 설계

SQLAlchemy를 사용하여 DB 모델을 구현합니다.

주요 테이블:

```text
customer_profile
system_lookup_data
transaction_request
reason_codes
swift_sanction_master
rag_documents
rag_chunks
```

프로토타입에서는 SQLite를 사용해도 됩니다.

다만 PostgreSQL로 전환하기 쉬운 구조로 작성합니다.

---

# 36. Mock 데이터

API Key와 외부 시스템이 없어도 전체 프로젝트를 실행할 수 있어야 합니다.

## Mock 신청서 데이터

```text
고객: 홍길동
고객유형: 개인
거주자구분: 거주자
송금금액: USD 150,000
수취인: US REALTY LLC
수취국가: US
수취은행: CHASE BANK N.A.
SWIFT: BKTRUS33XXX
송금목적: 해외 주택 구매 목적으로 계약금 송금하려고 함
```

## Mock system lookup

```json
{
  "annual_accumulated_usd": 35000.00,
  "is_bank_designated": true,
  "designated_purpose": "411",
  "is_delinquent_borrower": false
}
```

## Mock 사유코드

약 100개 수준으로 구성합니다.

## Mock SWIFT

정상 데이터와 제재 데이터 등 여러 케이스를 포함합니다.

## RAG

실제 국가법령정보센터 PDF가 `data/regulations/`에 없을 경우에도 UI와 검색 Pipeline을 테스트할 수 있도록 최소한의 Mock RAG 모드를 제공합니다.

단, 실제 법령처럼 오인할 수 있는 Mock 문서에는 명확히 `샘플 데이터`라고 표시합니다.

---

# 37. 테스트

## OCR

- 신청서 정상 OCR
- OCR 누락 필드
- OCR 오인식 필드
- 체크박스 인식
- SWIFT BIC 인식
- 은행원 수정

## LLM

- 거래 목적 구조화
- 해외부동산 거래
- 유학비
- 물품대금
- 기타 목적

## 사유코드

- 명확한 거래 목적
- 유사 거래 목적
- 복수 후보
- 매칭 결과 없음

## RAG

- 관련 법령 검색
- 관련 조문 검색
- 필요서류 검색
- 검색 결과 없음
- PDF 출처/페이지 표시

## SWIFT

- 정상 은행
- 제재 데이터 등재 은행
- 8자리 BIC
- 11자리 BIC
- 존재하지 않는 SWIFT

---

# 38. 구현 원칙

1. 실제 동작하는 Python 프로젝트를 작성합니다.
2. 단순 HTML 목업이 아니라 Streamlit에서 실제 상호작용이 가능해야 합니다.
3. OCR → 은행원 확인/수정 → 데이터 확정 → Ollama LLM → 사유코드 → RAG → SWIFT 조회의 전체 데이터 흐름이 실제로 연결되어야 합니다.
4. OCR은 외화송금신청서에서만 사용합니다.
5. 증빙서류에는 OCR을 사용하지 않습니다.
6. OCR 결과를 자동으로 승인/거절하지 않습니다.
7. OCR 정확성에 대한 최종 확인은 은행원이 합니다.
8. LLM은 Ollama를 사용합니다.
9. LLM 호출은 Service Layer로 분리합니다.
10. 실제 Ollama가 없어도 Mock LLM 모드로 UI를 실행할 수 있도록 합니다.
11. RAG 원문은 국가법령정보센터에서 제공하는 PDF를 사용합니다.
12. RAG 검색 결과에 가능한 범위에서 법령명, 조문, 파일명, 페이지 등 출처 정보를 표시합니다.
13. RAG가 법률적 최종 판단을 하는 구조로 만들지 않습니다.
14. 필요서류는 RAG로 안내하지만 실제 증빙서류 확인은 은행원이 직접 합니다.
15. 사유코드의 가중치를 임의의 숫자로 하드코딩하지 않습니다.
16. 사유코드는 DB에서 관리합니다.
17. SWIFT 조회는 SQL DB 조회 방식으로 구현합니다.
18. SWIFT 조회 결과만으로 실제 송금 가능 여부를 자동 확정하지 않습니다.
19. 고객정보, 거래정보, 시스템 조회정보를 데이터 구조상 분리합니다.
20. 실제 금융결제원, 은행 Core DB, 신용정보원 등은 프로토타입에서는 Mock Service로 추상화합니다.
21. 데이터와 코드를 분리합니다.
22. 예외 처리와 로그를 구현합니다.
23. 환경변수와 API/서비스 설정은 `.env` 또는 설정 파일로 관리합니다.
24. 타입 힌트와 적절한 docstring을 사용합니다.
25. README에 설치, 실행, Ollama 설정, RAG PDF 등록, DB 초기화, Mock 모드 사용법을 설명합니다.

---

# 39. 최종 산출물

최종 프로젝트에는 다음을 포함합니다.

- 실행 가능한 Python 프로젝트
- Streamlit 은행원 업무 화면
- 외화송금신청서 OCR Mock/실제 연동 구조
- OCR 결과 표시 및 은행원 확인/수정 기능
- 확정 거래정보 데이터 모델
- Ollama 기반 거래 문맥 분석
- 사유코드 DB 및 검색
- 약 100개 규모의 Mock 사유코드 데이터
- 국가법령정보센터 PDF 기반 RAG Pipeline
- 법령/조문 검색
- 필요서류 검색 및 체크리스트
- SWIFT/제재 DB
- SWIFT SQL 조회
- Mock System Lookup Service
- Mock OCR
- Mock LLM
- 테스트 데이터
- 테스트 코드
- README
- requirements.txt
- .env.example

---

# 40. 최종 시연 시나리오

프로젝트를 실행하면 다음 업무 흐름을 처음부터 끝까지 시연할 수 있어야 합니다.

```text
① 은행원이 외화송금신청서 업로드
        ↓
② OCR로 신청서 정보 추출
        ↓
③ 원본 신청서와 OCR 결과 비교
        ↓
④ 은행원이 필요한 항목 수정
        ↓
⑤ 거래정보 확정
        ↓
⑥ Mock System Lookup으로 고객 관련 시스템 정보 조회
        ↓
⑦ Ollama가 송금 목적/적요 분석
        ↓
⑧ 사유코드 후보 검색
        ↓
⑨ 은행원이 사유코드 확인
        ↓
⑩ 국가법령정보센터 PDF 기반 RAG 검색
        ↓
⑪ 관련 법령/조문 및 필요서류 표시
        ↓
⑫ 은행원이 실제 증빙서류 직접 확인
        ↓
⑬ 필요서류 체크
        ↓
⑭ OCR로 추출한 SWIFT BIC로 SWIFT DB 조회
        ↓
⑮ 은행 정보/제재 데이터/예상 소요시간 확인
        ↓
⑯ 최종 처리 요약 화면
        ↓
⑰ 은행원 최종 확인 및 처리 완료
```

최종적으로 이 프로젝트는 다음의 업무지원 흐름을 보여주는 것을 목표로 합니다.

> **수기 외화송금신청서 → OCR 자동 입력 → 은행원 확인 → Ollama 거래 문맥 분석 → 사유코드 → 국가법령정보센터 PDF RAG → 필요서류 안내 → SWIFT DB 조회 → 은행원 최종 처리**

---

# 41. 구현 변경 이력 (실제 구현 반영)

초기 구현 이후 대화를 통해 결정된 변경사항을 정리합니다. 각 섹션에도 관련
위치에 `[구현 변경]` 표시를 남겨두었습니다.

## 41.1 개발 환경

- 가상환경 폴더명을 `venv` 대신 **`project`**로 통일 (`python -m venv project`).
  Windows PowerShell 실행 정책 때문에 `Activate.ps1`이 막히는 경우가 있어,
  `project\Scripts\streamlit.exe run app.py`처럼 실행 파일을 직접 호출하는
  방법도 README에 함께 안내합니다.
- **원클릭 셋업 스크립트 `setup.ps1`** 추가: `pip install -r requirements.txt`
  + 로컬 Ollama 설치 여부 확인(없으면 공식 설치 스크립트 실행 여부를
  물어봄) + 임베딩 모델(`bge-m3`) pull + `.env` 생성 + DB seed까지 한 번에
  처리합니다. Ollama는 Python 패키지가 아니라 시스템 프로그램(백그라운드
  서비스 포함)이라 `requirements.txt`(pip 전용)에는 넣을 수 없어 별도
  스크립트로 오케스트레이션했습니다.
- **[구현 변경]** macOS/Linux용 `setup.sh` 추가 - `setup.ps1`과 동일한
  6단계를 Bash로 옮겼습니다. 자세한 내용은 섹션 41.11 참고. 이 저장소는
  특정 Python 버전을 강제로 고정하지 않으며(`pyproject.toml`/
  `.python-version` 없음), 두 스크립트 모두 PATH에 있는 `python`/`python3`
  를 그대로 사용해 가상환경을 만듭니다.

## 41.2 OCR - PaddleOCR 실제 구현 추가

> **41.18에서 PaddleOCR 자체를 프로젝트에서 완전히 제거**했습니다. 아래
> 내용은 당시 상황을 그대로 남긴 기록입니다.

- 기존에 Mock/Vision(Ollama) 두 모드만 있던 것에 **PaddleOCR 실제 구현**
  (`OCR_MODE=paddle`)을 추가하고 기본 모드로 채택했습니다.
- PaddleOCR은 이미지에서 텍스트 "줄"만 인식하므로, 별도의
  `text_field_mapper.py`가 "성명/SWIFT/금액/계좌번호" 등 라벨 키워드 근처
  텍스트를 찾아 신청서 필드로 매핑합니다(정규식 + 라벨 앵커 방식, 완벽한
  정확도를 보장하지 않으며 은행원 대조를 전제로 합니다).
- **버전 이슈**: 확인 환경(Windows CPU)에서 `paddleocr==2.7.3`(구버전)은
  `numpy<2` 전용 빌드라 프로젝트의 `numpy>=2` 의존성(chromadb 등)과 충돌해
  임포트 자체가 실패했습니다. 최신 `paddleocr==3.7.0`/`paddlepaddle==3.3.1`은
  numpy 2 호환이지만, 기본 oneDNN 가속 경로에서
  `NotImplementedError: ConvertPirAttribute2RuntimeAttribute...` 크래시가
  발생했습니다. `PaddleOCR(..., enable_mkldnn=False)`로 oneDNN만 비활성화하여
  해결했습니다(`services/ocr/paddle_ocr.py` 주석 참고). 다른 환경에서는 재현되지
  않을 수 있습니다.

## 41.3 LLM - Ollama Cloud 지원 + 엔드포인트 분리

- 로컬 Ollama뿐 아니라 **Ollama Cloud**(`https://ollama.com`, API Key 인증)도
  동일한 `OllamaLLMService`/`EmbeddingClient`로 지원합니다
  (`services/ollama_client.py`가 `OLLAMA_API_KEY`를 `Authorization: Bearer`
  헤더로 자동 첨부).
- LLM 분석과 임베딩(사유코드/RAG 검색)이 **서로 다른 Ollama 엔드포인트**를
  쓸 수 있도록 설정을 분리했습니다(`OLLAMA_EMBED_BASE_URL` /
  `OLLAMA_EMBED_API_KEY` / `OLLAMA_EMBED_MODEL`). 배경: Ollama Cloud는
  로컬에서 못 돌리는 대형 채팅 모델(120B급 등)을 서빙하는 서비스라
  임베딩 모델(가볍고 로컬에서도 잘 도는 종류)은 제공하지 않습니다. 그래서
  "LLM은 Cloud의 대형 모델, 임베딩은 로컬 Ollama의 경량 모델"처럼 섞어
  쓰는 구성을 지원합니다.
- 임베딩 기본 모델을 `nomic-embed-text`(영어 위주)에서 **`bge-m3`**
  (다국어, 한국어 포함 100개 이상 언어 지원)로 변경 권장 - 한국어 신청서/
  사유코드 검색 품질이 더 좋습니다.
- 로컬/Cloud Ollama가 응답하지 않으면 임베딩은 자동으로 경량 해시 기반
  임베딩(`services/embedding_client.py`)으로 폴백하여 앱 자체는 계속
  동작합니다(섹션 14 원칙 - 검색 품질만 낮아짐, 앱이 죽지 않음).
- LLM 시스템 프롬프트에 "모든 값은 한국어로 작성" 지시를 명시적으로
  추가했습니다 - 범용 클라우드 모델(예: `gpt-oss:120b-cloud`)이 영어로 응답할
  수 있어 안전장치를 걸었습니다.

## 41.4 사유코드/RAG 검색 - 태그 기반 필터링 보강

- 경량 해시 임베딩(Ollama 미연결 시 폴백)은 단어 그대로 겹치는 것만
  비슷하다고 판단하는 방식이라, "주택"과 "부동산"처럼 동의어에 가까운
  표현을 연결하지 못하는 한계가 확인되었습니다.
- 이를 보완하기 위해 RAG 검색(`RagRetriever.search`)에 사유코드의
  `regulation_tags`를 필터/우선순위 기준으로 추가했습니다: 태그가 겹치는
  후보만 남기고, 그 안에서 겹치는 태그 개수(1순위) → 임베딩 유사도(2순위,
  동점자 처리)로 정렬합니다. 임의의 숫자 가중치를 조합하는 점수식이 아니라
  명확한 필터/정렬 기준이므로 섹션 12 원칙에 위배되지 않습니다.

## 41.5 UI 디자인 - 사이드바 + 카드 레이아웃 (이후 하나은행 CI로 재변경)

- 사용자가 이전에 진행한 별도 프로젝트(순수 HTML/CSS/JS, 네이비 사이드바
  + 화이트 카드 + 파란 포인트 컬러)의 디자인 톤을 참고해 처음에는 네이비/
  블루 팔레트로 전면 재구성했습니다.
- 새로 추가된 `ui/theme.py`가 디자인 시스템을 담당: 사이드바 네비게이션
  (브랜드 로고, 6단계 메뉴, 실행 모드 뱃지, 완료 단계만 클릭해서 되돌아갈
  수 있음 - 처음엔 전체 자유 이동을 허용했다가 "엉뚱한 데로 튕기는" 부자연
  스러운 경험이라는 피드백을 받아 되돌림), 화이트 카드(둥근 모서리 + 옅은
  그림자), 번호 배지가 있는 섹션 헤더, eyebrow + 큰 제목의 페이지 헤더.
- Streamlit 내부 DOM 구조(`data-testid`, 내부 CSS 클래스)는 버전에 따라
  달라질 수 있어, 카드 스타일은 Streamlit이 자동 부여하는 클래스에
  의존하지 않고 `st.container(border=True, key="fx_card_...")`가 만들어주는
  안정적인 `st-key-<key>` 클래스만 신뢰하도록 구현했습니다.
- 원본 프롬프트(섹션 32)의 "과도한 애니메이션 금지" 원칙에 따라
  `st.balloons()` 같은 연출은 제거했습니다.
- **이후 요청으로 팔레트를 하나은행(KEB Hana Bank) CI 그린 톤으로
  재변경**했습니다(`--brand:#008485` 등, `ui/theme.py` 상단 `:root` 참고).
  공식 브랜드 가이드 문서를 직접 확인한 것이 아니라 일반적으로 알려진
  하나은행 그린으로 근사한 값입니다. `st.info()` 등 Streamlit이 기본
  제공하는 하늘색 알림 박스는 처음엔 안쪽 요소(`stAlertContentInfo`)만
  고쳤다가 실제로 눈에 보이는 배경은 바깥쪽 `stAlertContainer`가 그린다는
  것을 뒤늦게 발견해 두 곳 다 덮어쓰도록 수정했습니다. 아이콘(ℹ️)은 이모지라
  CSS `color`로 바꿀 수 없어, Streamlit의 Material 아이콘 문법
  (`icon=":material/info:"`)으로 교체해 실제로 색이 바뀌도록 했습니다.
- 사이드바 "완료/현재/예정" 단계 구분을 위해 비활성(예정) 버튼에
  `opacity:0.4`를 적용했는데, 현재 단계 강조 규칙과 특이도(specificity)가
  동점이 되면서 사이드바가 항상 메인 영역보다 DOM에서 먼저 나오는
  Streamlit 레이아웃 특성상 현재 단계까지 흐리게 보이는 버그가 있었습니다.
  현재 단계 강조 선택자에 `[data-testid="stButton"]`을 추가해 특이도를
  한 단계 더 높여 해결했습니다.
- **하나은행 서체(Hana2)**: 사용자가 TTF 파일 6종(Light/Regular/Medium/CM/
  Bold/Heavy)을 제공하여 `static/fonts/`에 배치하고, Streamlit 1.45+ 네이티브
  커스텀 폰트 기능(`.streamlit/config.toml`의 `[[theme.fontFaces]]` +
  `[theme].font`, `enableStaticServing=true`)으로 앱 전체 기본 폰트로
  등록했습니다. 처음엔 라이선스 조항을 확인하지 못한 상태라 `static/fonts/`를
  `.gitignore`에 넣어 저장소에는 커밋하지 않았는데, 이후 사용자가 실제
  하나체 라이선스 원문을 확인해준 결과 개인/기업 모두 상업적 용도로 무료
  사용이 가능하고 배포되는 형태 그대로 쓰는 한(수정·재판매·CI/BI 제작만
  금지) 재배포 제한이 없다는 게 확인되어, `.gitignore`에서 이 항목을
  제거하고 **TTF 파일 6종(42MB)을 실제로 `static/fonts/`에 커밋했습니다**.
  브라우저에서 `document.fonts`로 `family: "hana2"` 항목들이 실제
  `status: "loaded"`로 뜨는 것과, 폰트 파일 4종(Regular/CM/Bold/Heavy - 이
  화면에서 실제 사용된 굵기)이 네트워크 요청에서 200 OK로 응답하는 것까지
  확인했습니다(Light/Medium은 해당 화면에 쓰인 굵기가 아니라 지연 로딩되지
  않았을 뿐, `@font-face` 선언 자체는 6종 모두 등록되어 있습니다). 이제
  git clone만 하면 팀원 컴퓨터에도 폰트가 자동으로 딸려옵니다 - 더 이상
  별도로 구해서 넣을 필요가 없습니다.

## 41.6 테스트 스위트 격리

- RAG 재색인처럼 SQL 테이블을 지우고 다시 쓰는 테스트는 실제 개발 DB
  (`data/fx_remittance.db`)를 오염시키지 않도록 격리된 임시 SQLite DB를
  쓰도록 `tests/conftest.py`에 `make_isolated_get_session()` 헬퍼를
  추가했습니다.
- OCR 통합 테스트(`tests/test_integration_flow.py`)는 `.env`의 `OCR_MODE`
  설정과 무관하게 항상 `MockOCRService`를 직접 사용하도록 고정했습니다 -
  실제 PaddleOCR/Vision 엔진은 무겁고(모델 다운로드/추론 시간) 실제 이미지
  파일이 필요해 결정론적 단위 테스트에는 적합하지 않습니다.

## 41.7 실제 국가법령정보센터 PDF 반영

- 사용자가 실제 법제처 국가법령정보센터 PDF 2건(외국환거래규정, 외국환거래법)을
  제공하여 `data/regulations/`에 넣고 `.env`의 `RAG_MODE=pdf`로 전환했습니다.
  텍스트 추출 138페이지, 552개 청크로 색인됨(`is_sample=False`).
- 긴 조문이 여러 청크로 쪼개질 때 뒤쪽 청크에는 "제O조" 표시가 그 청크
  안에 없어 출처가 비는 문제를 발견해, 같은 문서 안에서 마지막으로 찾은
  조문 번호를 다음 청크에도 이어서 적용하도록 `RagRetriever._store_pdf_chunks`
  를 수정했습니다.
- 이 두 PDF는 정부(법제처) 공개 자료라 라이선스 문제가 없어
  `data/regulations/*.pdf` 는 (하나은행 폰트와 달리) `.gitignore`에 넣지
  않고 그대로 커밋합니다.

## 41.8 프로젝트 이름

- 앱 표시 이름을 "외환거래 업무 지원 AI 시스템"에서 **"FX Trade Assistant
  AI"** 로 변경했습니다(브라우저 탭 제목, 사이드바 브랜드명 - `app.py`의
  `st.set_page_config(page_title=...)`, `ui/theme.py`의 `render_sidebar()`).
  GitHub 저장소: https://github.com/kyzxyzxyz/foreign-exchange-ai-for-regtech
  (41.14 참고 - 이후 `fx-trade-assistant-ai`에서 개명)
- **[구현 변경, 41.14에서 재변경]** 이후 팀이 정식 명칭을 **"FIXAR
  (ForeIgn eXchange AI for RegTech)"** 로 확정하면서 "FX Trade Assistant
  AI"는 폐기되었습니다. 자세한 내용은 섹션 41.14 참고. GitHub 저장소
  이름/URL 자체는 그대로 유지했습니다(리포지토리 슬러그 변경은 clone
  URL이 바뀌는 등 영향 범위가 커서 별도 요청 시에만 진행).

## 41.9 SWIFT 마스터 데이터 - 실제 SWIFT/BIC 데이터셋 반영

- 섹션 21("오픈 SWIFT Code 데이터셋... 이용하여 로컬 DB를 구성할 수 있도록
  합니다")에 따라, 큐레이션 29건뿐이던 `data/swift_sanction_master.csv`에
  공개 저장소 [`maranemil/swift-bic-codes-allinone`](https://github.com/maranemil/swift-bic-codes-allinone)의
  `AllCountries_v1`(2019년 스냅샷, 232개국)을 가져와 병합했습니다. 최종
  109,037건(큐레이션 29건 + 외부 109,008건).
- **원본 CSV의 국가 컬럼은 스크래핑 오류로 신뢰할 수 없었습니다** - 전체
  134,628행 중 약 37%(50,268행)에서 국가 컬럼이 실제 BIC 코드가 가리키는
  국가와 달랐습니다(예: 파키스탄 은행 `ALFHPKKA...` 다수가 `AF`(아프가니스탄)
  파일 그룹에 잘못 들어가 있었음 - 국가별 폴더/페이지 단위로 스크래핑하며
  생긴 것으로 추정). 그래서 원본의 국가 컬럼은 버리고, BIC/ISO 9362
  표준상 코드 5~6번째 문자가 국가코드라는 규칙을 이용해 코드 자체에서
  국가를 재계산했습니다. 이 과정에서 완전 동일한 코드가 서로 다른(잘못된)
  국가로 최대 3중 중복 등록된 2.5만여 건도 함께 정리됐습니다.
- **`is_sanctioned`는 큐레이션 29건 중 6건(러시아 2·이란 2·북한·쿠바)에만
  `true`가 있고, 외부 109,008건은 전부 `false`입니다** - 실제 제재
  스크리닝을 거친 데이터가 아니라 은행 식별 정보(이름/국가)만 가져온
  것이므로, 제재 대상국(RU/IR/KP/CU 등) 은행이어도 큐레이션되지 않은
  건 전부 "정상"으로 조회됩니다. 섹션 18/32 원칙(SWIFT/제재 데이터 조회만
  으로 자동 확정하지 않음)에 따라 국가 단위로 임의 경고를 얹는 것도
  보류했습니다 - 제재는 국가 전체가 아니라 은행/개인 단위로 걸리는 경우가
  많아, 하드코딩된 "고위험국" 목록 자체가 시점에 따라 틀린 정보가 될 수
  있기 때문입니다(예: 시리아는 2025년 정권 교체 이후 제재가 상당 부분
  완화됨). `README.md` 3절에 이 한계를 명시했습니다.
- **은행명 컬럼은 String(100) 대비 최대 201자짜리 원본 값이 있어** 100자
  초과 시 단어 경계에서 잘랐습니다(SQLite 자체는 길이를 강제하지 않지만 표시
  일관성을 위해).
- `database/seed.py`의 `seed_swift_master()`를 ORM `session.add()` 1건씩
  넣던 방식에서 `session.execute(insert(...), rows)` **5,000건 단위 벌크
  삽입**으로 바꿨습니다 - 10만 건 이상을 1건씩 넣으면 지나치게 느려서입니다
  (실측 전체 시딩 약 4초).
- **회귀 발견 및 수정**: 실제 지점 데이터가 들어오면서 한 은행 아래
  Branch Code가 여러 개 등재되는 경우가 흔해졌고, 기존
  `SwiftService.lookup()`의 8자리 BIC 조회(섹션 22)가 `ORDER BY
  swift_code`만 쓰던 탓에 숫자 지점코드(`0`~`9`)가 알파벳상 `XXX`보다
  앞서 정렬되어 **본점이 아닌 임의 지점이 매칭**되는 문제가
  `tests/test_swift.py::test_8_digit_bic_resolves_to_11_digit_record`에서
  드러났습니다. SWIFT 관례상 지점코드 없는 8자리 BIC는 본점(`XXX`)을
  가리키므로, `services/swift/service.py`에 우선순위(`0`=정확히 일치,
  `1`=`{code}XXX`, `2`=그 외 지점)를 매기는 `CASE` 정렬을 추가해 고쳤습니다.
- **개발 환경**: 이 변경 검증을 macOS에서 진행하면서 `.claude/launch.json`
  이 Windows 경로(`project/Scripts/streamlit.exe`)만 갖고 있어 macOS에서
  실행이 안 되는 걸 발견했습니다. `project/bin/streamlit`(macOS/Linux venv
  경로)을 가리키는 `fx-trade-assistant-ai-streamlit-mac` 항목을 추가하고,
  기존 Windows 항목은 `fx-trade-assistant-ai-streamlit-windows`로 이름을
  명확히 했습니다(41.1의 `project` venv 규칙은 그대로 유지, 실행 파일 경로만
  OS별로 분리). **[구현 변경, 41.14 참고]** 이후 프로젝트명이 FIXAR/
  `foreign-exchange-ai-for-regtech`로 바뀌면서 이 두 항목 이름도
  `foreign-exchange-ai-for-regtech-mac`/`-windows`로 맞춰 변경했습니다.

## 41.10 화면 흐름 게이팅/에러 처리/캐싱 보강

SWIFT 마스터 데이터 확장(41.9) 이후 실제 Live 모드(Ollama + PaddleOCR + 실제
법령 PDF)로 OCR → LLM 분석 → 사유코드 → RAG → SWIFT → 요약 전체 흐름을
직접 실행해 검증하는 과정에서, 그리고 이어진 코드 리뷰(8개 각도, 40개 파일)
에서 발견된 실제 버그/누락을 고쳤습니다.

- **[회귀, 실제 재현]** `services/ocr/text_field_mapper.py`가 수취인
  `recipient_type`을 항상 `"CORPORATE"`로 하드코딩하고 있었습니다. Live
  PaddleOCR로 개인 수취인("JOHN SMITH") 신청서를 직접 업로드해 재현한
  뒤, `customer_type`과 동일하게 `_CORPORATE_RE`를 수취인명에 적용해
  법인 표시가 없으면 `INDIVIDUAL`로 판단하도록 고쳤습니다.
- 같은 파일의 계좌번호 폴백 정규식(`_ACCOUNT_RE`)이 "계좌번호" 라벨을
  인식하지 못한 경우 주민등록번호/사업자등록번호까지 계좌번호로 잘못
  잡을 수 있었습니다. `_find_account_number()`를 추가해 주민등록번호/
  사업자등록번호 패턴과 겹치는 후보는 제외하도록 고쳤습니다.
- `services/system_lookup/mock_service.py`의 Mock 신용정보(신용불량 여부,
  거래외국환은행 지정 등)가 화면에 "Mock" 표시 없이 실제 조회 결과처럼
  보였습니다. `frontend/transaction_analysis.py`의 해당 expander 제목과 경고
  문구에 "🧪 Mock 데이터" 표시를 추가했습니다.
- `frontend/regulation.py`의 필요서류 체크리스트, `frontend/swift.py`의 SWIFT 재조회,
  `frontend/summary.py`의 최종 처리 완료가 각각 은행원의 실제 확인 없이도 다음
  단계로 넘어갈 수 있었습니다(체크 안 해도 "다음" 버튼 활성화, SWIFT
  코드를 수정하고 재조회하지 않아도 이전 결과로 "다음" 버튼 활성화, 제재
  은행/서류 미비 상태에서도 "처리 완료" 버튼이 항상 활성화). 각각 버튼을
  `disabled` 처리하고, 요약 화면에는 제재/서류 미비가 있을 때만 별도
  확인 체크박스를 요구하도록 고쳤습니다(자동으로 막지는 않고 명시적
  확인을 요구하는 방식 - 섹션 18/32 원칙과 일치).
- 사이드바로 되돌아가 OCR 결과를 다시 수정·제출해도, 이전 확정 내용
  기준으로 만들어진 AI 분석/사유코드/법령 검색/SWIFT 조회 결과가
  세션에 그대로 남아있었습니다. `frontend/ocr_result.py`의 재제출 처리에서
  이후 단계 세션 상태를 전부 초기화하고, `frontend/regulation.py`에는 확정된
  사유코드가 바뀌면 캐시된 법령 검색/필요서류 결과도 다시 만들도록
  코드(`reason_code.code`) 비교 로직을 추가했습니다.
- `services/embedding_client.py`가 Ollama 연결 실패 시 조용히 경량 해시
  임베딩으로 폴백하는데, 이 사실이 화면 어디에도 표시되지 않아 사이드바의
  "Live" 배지만 보고 검색 품질까지 Live라고 오해할 수 있었습니다.
  `ReasonCodeMapper`/`RagRetriever`에 `embedding_backend` 프로퍼티를
  추가하고, 해시 폴백일 때 사유코드/법령 검색 화면에 경고 캡션을
  띄우도록 했습니다.
- `SwiftService.lookup()`, `RagRetriever()`+검색, `ReasonCodeMapper()`+검색,
  거래정보 DB 저장(`_persist_confirmed_transaction`) 호출에 OCR/LLM
  호출과 달리 예외 처리가 없어, 일시적인 DB 잠금이나 Chroma 오류가
  발생하면 화면이 그대로 죽었습니다. OCR/LLM과 동일한 수준의
  try/except + `st.error()` 안내를 추가했습니다.
- `ReasonCodeMapper`/`RagRetriever`가 버튼을 누를 때마다(디스크의 Chroma
  인덱스 재로딩 + Ollama 연결 재확인 포함) 매번 새로 생성되고 있었습니다.
  `@st.cache_resource`로 감싸 프로세스당 한 번만 생성하도록 캐싱했습니다.
- 위 수정을 검증하기 위해 `tests/test_paddle_ocr.py`에 회귀 테스트 4개를
  추가했습니다(수취인 개인/법인 판별, 계좌번호 폴백이 주민등록번호를
  잡지 않는지, 실제 계좌번호는 여전히 잡히는지). 전체 테스트 스위트는
  39건에서 48건으로 늘었고 전부 통과합니다.

## 41.11 macOS/Linux 원클릭 셋업 스크립트 추가

- 기존 `setup.ps1`(41.1)이 PowerShell 스크립트라 Windows 전용이었습니다 -
  macOS/Linux에도 `pwsh`(PowerShell Core)를 별도로 설치하면 이론적으로는
  돌아가지만, 저장소 어디에도 그 방법이 안내되어 있지 않았고 실제
  확인 환경(macOS)에도 `pwsh`가 설치되어 있지 않았습니다.
- `setup.ps1`과 동일한 6단계(가상환경 생성 → `requirements.txt` 설치 →
  `.env` 생성 → 로컬 Ollama 설치 확인/설치 → 임베딩 모델(`bge-m3`) pull →
  DB 초기화/시딩)를 그대로 옮긴 **`setup.sh`**를 추가했습니다. 차이점:
  - 가상환경 실행 파일 경로가 `project/Scripts/...`(Windows) 대신
    `project/bin/...`(macOS/Linux)입니다.
  - Ollama 설치 확인은 `Get-Command` 대신 `command -v`, 공식 설치
    스크립트는 `install.ps1` 대신 `install.sh`(`curl -fsSL
    https://ollama.com/install.sh | sh`)를 씁니다.
  - `ollama pull`은 로컬에 `ollama serve`가 떠 있어야 동작하는데,
    macOS/Linux는 Windows 설치본과 달리 백그라운드 서비스가 자동으로
    상시 실행되지 않는 경우가 있어(이 세션에서도 실제로 그랬습니다 -
    바이너리는 설치돼 있었지만 서버 프로세스는 꺼져 있었습니다), pull
    직전에 `http://localhost:11434/api/version`을 확인해 응답이 없으면
    `ollama serve`를 백그라운드로 잠깐 띄우는 단계를 추가했습니다(Windows
    설치본에는 없는, macOS/Linux 전용 보완).
  - 플래그명은 PowerShell 관례(`-SkipOllama`/`-Yes`) 대신 Bash 관례
    (`--skip-ollama`/`--yes`)를 따릅니다.
- 실제로 `./setup.sh --yes`를 이 저장소에서 실행해 검증했습니다 - 이미
  `project/`/`.env`/Ollama/임베딩 모델이 갖춰진 상태에서 전 단계가
  에러 없이 스킵/완료되는 것까지 확인했습니다.
- **파이썬 버전**: 두 스크립트 모두 특정 버전을 강제하지 않고 PATH의
  `python`/`python3`를 그대로 씁니다(저장소에 `pyproject.toml`/
  `.python-version` 없음). 이 세션은 macOS + Python 3.13.13으로 PaddleOCR
  실기 인식 + Ollama Live + 실제 법령 PDF RAG까지 전부 정상 동작을
  확인했지만, 이건 "확인된 조합"이지 "고정된 요구사항"은 아닙니다.

## 41.12 실제 하나은행 서식 기준 OCR 필드 매핑 점검 및 수정

> **41.18에서 PaddleOCR 자체를 프로젝트에서 완전히 제거**하면서 이 섹션에서
> 다루는 `text_field_mapper.py`/`paddle_ocr.py`도 함께 삭제되었습니다. 아래
> 내용은 당시 상황을 그대로 남긴 기록입니다.

사용자가 실제 하나은행 외화송금신청서 PDF(서식번호 3-09-0131, 2026.05
개정, 2페이지)를 제공해 `text_field_mapper.py`가 이 서식을 어떻게
처리할지 점검했습니다. 손글씨나 실제 고객 정보가 없는 빈 템플릿이라
`data/forms/하나은행_외화송금신청서_3-09-0131.pdf`로 저장소에 커밋했습니다
(자세한 내용은 `data/forms/README.md` 참고). 필드 매핑 결과는 README
"9. OCR 필드 매핑"에 정리했습니다.

**참고 - `swift_bic`은 화면 하나가 아니라 세 화면을 거쳐가는 필드입니다**:
README 표는 ①업로드 단계(OCR)에서 이 값이 처음 채워지는 출처를 정리한
것이고, 이후 ②OCR 결과 확인(`frontend/ocr_result.py`)에서 은행원이 원본과
대조해 고칠 수 있으며, ⑤SWIFT 조회(`frontend/swift.py:59`)는 이 값을 새로
채우는 게 아니라 `default_code = transaction.recipient_info.swift_bic`로
입력창에 미리 띄워준 뒤 그대로 SWIFT/제재 DB 조회에 씁니다(여기서도
은행원이 고쳐서 재조회 가능). 즉 OCR → 은행원 확인 → SWIFT 조회가 같은
필드 하나를 순서대로 이어받는 구조이며, README 표는 그중 ①(출처)만을
나타냅니다. 사용자가 "5. SWIFT 조회에서 채워넣는 거 아니었어?"라고 물어봐서
README에도 각주로 명시했습니다.

- 이 서식에는 **같은 라벨이 다른 의미로 두 번씩** 나오는 필드가 있었습니다.
  - SWIFT/은행코드: "결제은행"(송금인 미지정 시 은행이 임의로 정하는
    중계은행) 섹션에 `은행코드(SWIFT BIC)` 라벨이, 정작 원하는 "받으실분
    거래은행"(수취은행) 섹션에는 `은행코드(BANK CODE)` 라벨이 있었습니다.
    결제은행 쪽이 문서 앞쪽에 먼저 나와서, 라벨만 보고 값을 채우면
    엉뚱한 중계은행 코드가 수취은행 SWIFT로 잘못 들어갑니다.
  - 계좌번호: "보내는분 계좌번호"와 "수취인 계좌번호"에 똑같이
    "계좌번호" 라벨이 쓰였습니다. 우리 스키마(`RecipientInfo`)에는
    수취인 계좌번호를 담을 자리가 없어서, 이 값이 먼저 인식되면 송금인
    본인 계좌번호 자리에 잘못 채워집니다.
- `services/ocr/text_field_mapper.py`의 `_find_after_label()`에
  `exclude_context` 옵션을 추가했습니다: 라벨과 같은 줄 또는 바로 위
  줄(`exclude_lookback`, 기본 1줄)에 지정된 문맥 단어가 있으면 그 라벨은
  건너뜁니다. SWIFT 라벨엔 `["결제은행", "중계은행", "REIMBURS"]`,
  계좌번호 라벨엔 `["수취인", "BNF", "BENEFICIARY"]`를 지정했습니다.
  `은행코드`/`BANK CODE`도 `_SWIFT_LABELS`에 추가했습니다(이 서식의
  수취은행 필드가 실제로 이 라벨을 씁니다).
  - 룩백 범위를 처음엔 3줄로 했다가, 테스트 중 "수취인"이라는 단어가
    앞쪽 줄에 한 번 나오면 그 뒤 3줄 이내의 다른 정상 라벨(보내는분
    계좌번호)까지 통째로 걸러지는 과잉 제외 문제를 발견해 1줄로
    줄였습니다.
- 위 수정과 별개로, `_find_after_label()`이 "계좌번호(A/C NO)"처럼 라벨
  바로 뒤에 괄호로 된 영문 약어만 붙어있는 경우 그 괄호 문자열
  (`"(A/C NO)"`)을 실제 값으로 잘못 반환하는 기존 버그도 이번에 함께
  발견해 고쳤습니다 - 값을 찾을 때 라벨 뒤 텍스트에서 끝의 괄호 그룹을
  먼저 떼어내고, 그래도 남는 게 없으면 다음 줄에서 값을 찾도록 했습니다.
- `tests/test_paddle_ocr.py`에 두 회귀 테스트를 추가했습니다(결제은행
  문맥 건너뛰기, 수취인 계좌번호 문맥 건너뛰기). 전체 테스트는 48건에서
  50건으로 늘었습니다.
- **검증**: 이 서식 1페이지 텍스트 순서를 그대로 재현하고 손글씨로
  채워졌을 법한 값을 끼워 넣어 `map_lines_to_ocr_fields()`를 직접
  실행해봤습니다. `account_number`는 정확히 송금인 계좌(수취인 계좌
  아님), `swift_bic`은 정확히 수취은행 코드(결제은행 아님)로 잡히는 것을
  확인했습니다.
- **알려진 잔여 한계**: 같은 시뮬레이션에서 성명/송금목적 등 다른
  필드는 여전히 깨졌습니다(예: `받으실분 (Beneficiary) 수취인 계좌번호
  (BNF's A/C No.)`처럼 라벨 여러 개가 한 줄에 밀집된 레이아웃에서
  `_find_after_label()`의 "라벨 뒤 텍스트/다음 줄" 가정이 깨짐). 이번
  요청 범위(SWIFT/계좌번호 오인식)는 고쳤지만, 이 잔여 문제는 고치지
  않았고 README "9. OCR 필드 매핑"에 한계로 명시했습니다 - 별도 후속
  작업이 필요합니다.

## 41.13 섹션 제목 아이콘·텍스트 수직 정렬 버그 수정

- 사용자가 업로드 화면(①)의 원 아이콘이 "신청서 업로드" 글자보다 위로
  치우쳐 보인다고 지적해 확인했습니다. 6개 Wizard 화면(①~⑥)이 전부
  공유하는 `theme.section_title()`이 `<h2>` 태그를 그대로 쓰는데,
  Streamlit이 마우스오버 시 나오는 "링크" 앵커 아이콘을 위한 여백으로
  모든 `<h2>`에 기본 `padding-top:16px`을 자동으로 넣습니다. 기존
  `.fx-section-title h2{margin:0;...}` 규칙은 `margin`만 리셋하고
  `padding`은 안 건드려서, 원형 배지(아이콘)는 flex 컨테이너 맨 위에
  붙는데 실제 글자는 그 16px만큼 아래로 밀려 보였습니다.
- `frontend/theme.py`(당시 경로는 `ui/theme.py` - 41.16에서 이동)의 `.fx-section-title h2` 규칙에 `padding:0`을 추가해
  해결했습니다. 6개 화면이 전부 같은 CSS 클래스를 공유하므로 이 한 줄
  수정으로 전체가 고쳐집니다.
- 브라우저에서 배지/제목 요소의 `getBoundingClientRect()`를 직접 측정해
  수정 전(배지 top=h2 top이지만 h2 실제 텍스트는 padding 때문에 16px
  아래) → 수정 후(패딩 0, 배지와 제목 텍스트 줄이 상단 기준으로 정렬)를
  확인했고, ①/④/⑥ 화면을 실제로 렌더링해 시각적으로도 확인했습니다.

## 41.14 프로젝트 명칭 확정: FIXAR

- 팀이 정식 프로젝트명을 **FIXAR (ForeIgn eXchange AI for RegTech)** 로
  확정했습니다. 41.8에서 "외환거래 업무 지원 AI 시스템" → "FX Trade
  Assistant AI"로 한 번 바꿨던 표시 이름을 FIXAR로 다시 변경했습니다.
  ("FIXAA (ForeIgn eXchange AI Assistant)"로 먼저 논의됐다가 커밋하기
  전에 팀 내부에서 다시 논의해 FIXAR로 최종 확정되어, 커밋 이력에는
  FIXAA가 남지 않습니다.)
- 변경 지점:
  - `app.py`: `st.set_page_config(page_title="FIXAR")`(브라우저 탭 제목),
    모듈 docstring.
  - `frontend/theme.py`(당시 경로는 `ui/theme.py` - 41.16에서 이동)의 `render_sidebar()`: 사이드바 브랜드 마크(`.fx-brand-mark`)
    텍스트를 `FX` → `FIXAR`로, 브랜드명 굵은 글씨를 `FX Trade Assistant AI`
    → `FIXAR`로 변경. `FIXAR`(5자)가 42×42px 정사각 배지에 들어가도록
    `.fx-brand-mark`의 `font-size`를 14px → 9px로 줄였습니다(브라우저에서
    `scrollWidth`/`clientWidth`로 안 잘리는 것 확인). 배지 아래 부제
    ("외화송금신청서 처리 지원")는 기능 설명이라 그대로 유지했습니다.
  - `setup.ps1`/`setup.sh` 스크립트 상단 설명 주석.
  - `README.md`/`fx-trade-assistant-ai_prompt.md` 제목(H1)에 "FIXAR
    (ForeIgn eXchange AI for RegTech)" 병기.
- **[구현 변경]** 이후 GitHub 저장소 이름도 `fx-trade-assistant-ai` →
  **`foreign-exchange-ai-for-regtech`** 로 변경했습니다(`gh repo rename`,
  케밥 케이스 관례를 따름 - 대안으로 `fixar`/`fixar-ai`도 검토했으나,
  최종적으로 이 이름으로 확정). 로컬 `origin` 리모트 URL도
  `git remote set-url`로 함께 갱신했고, `git fetch`로 새 URL 연결까지
  확인했습니다. GitHub이 예전 URL(`.../fx-trade-assistant-ai`)을 새
  이름으로 자동 리다이렉트해주지만, 다른 곳에서 이 저장소를 이미
  clone해둔 사람은 각자 `git remote set-url origin
  https://github.com/kyzxyzxyz/foreign-exchange-ai-for-regtech.git`로
  갱신해야 합니다.
- 이 프롬프트 파일명(`fx-trade-assistant-ai_prompt.md`) 자체는 바꾸지
  않았습니다 - 이번 세션에서 여러 문서에 걸어둔 상대 경로 참조가 전부
  깨지므로, 명시적으로 요청받으면 별도로 진행하기로 했습니다.
- **[구현 변경]** `.claude/launch.json`의 프리뷰 설정 이름도 저장소명에
  맞춰 `fx-trade-assistant-ai-streamlit-mac`/`-windows` →
  `foreign-exchange-ai-for-regtech-mac`/`-windows`로 변경했습니다(섹션
  41.10 근처 인라인 표시 참고).
- **로컬 폴더명 변경(`mv`)에 관한 중요한 함정**: 사용자가 로컬 폴더를
  `~/Desktop/fx-trade-assistant-ai` → `~/Desktop/foreign-exchange-ai-for-regtech`
  로 직접 바꿨습니다(Finder/터미널에서 `mv`). `git`/`pwd`/Claude Code
  세션 기록은 문제없이 새 경로를 따라갔지만(세션 내내 파일 조작이 전부
  정상 동작), **`project/` 가상환경의 `pip`이 만든 실행 스크립트
  (`streamlit`, `pytest`, `pip` 등 `project/bin/` 아래 전부)는 셔뱅
  (shebang, 스크립트 첫 줄 `#!/절대경로/python3`)에 옛 절대경로가
  하드코딩되어 있어서 전부 깨졌습니다** (`project/bin/python`을 직접
  실행하는 건 괜찮았는데 - `pyvenv.cfg`를 참조해 경로를 다시 계산하는
  방식이라 - `project/bin/streamlit`처럼 pip이 생성한 wrapper 스크립트는
  셔뱅이 정적 문자열이라 안 그렇습니다). `grep -rl <옛경로> project/bin/`
  로 걸린 파일 전부(`activate*` 포함)와 `project/pyvenv.cfg`를
  `sed -i`로 일괄 치환해 해결했습니다. **가상환경을 만든 뒤에 그 상위
  폴더 이름을 바꾸는 경우 항상 재현되는 문제이므로, 폴더명을 바꾼
  뒤에는 가상환경을 지우고 새로 만들거나(`setup.sh`/`setup.ps1`
  재실행) 이 방법으로 셔뱅을 일괄 치환해야 합니다.** README "8. 알려진
  제약"에도 이 내용을 남겼습니다.

## 41.15 PaddleOCR PDF 지원 추가

> **41.18에서 PaddleOCR 자체를 프로젝트에서 완전히 제거**했습니다. 아래
> 내용은 당시 상황을 그대로 남긴 기록입니다.

- `services/ocr/paddle_ocr.py`가 `_SUPPORTED_SUFFIXES = {".jpg", ".jpeg",
  ".png"}`로 PDF를 명시적으로 막고 있었는데, 사용자가 실제 PDF 업로드
  시도 후 "왜 안 되냐"고 질문해 확인한 결과 **이건 PaddleOCR 라이브러리
  자체의 한계가 아니라 이 프로젝트 코드가 걸어둔 제한**이었습니다.
  설치된 `paddlex`(PaddleOCR 3.x 내부 엔진) 패키지 안에
  `inference/utils/io/readers.py`의 `PDFReader`/`PDFReaderBackend`,
  `inference/utils/pdfium_lock.py`가 이미 `pypdfium2` 기반 PDF
  페이지별 렌더링을 지원하는 것을 소스 코드에서 직접 확인했습니다.
- `_SUPPORTED_SUFFIXES`에 `.pdf`를 추가하고, 에러 메시지/docstring을
  갱신했습니다. `tests/test_paddle_ocr.py`에 회귀 테스트를 추가했는데
  (`test_paddle_ocr_service_rejects_unsupported_file_type`을 `.pdf` 대신
  `.gif`로 바꾸고, `test_paddle_ocr_supports_pdf_suffix`로 `.pdf`가
  `_SUPPORTED_SUFFIXES`에 있는지만 확인) 무거운 실제 엔진 호출 없이
  빠르게 검증되도록 확장자 검사만 테스트했습니다.
- **실제 검증**: `data/forms/`에 있는 실제 하나은행 서식 PDF(2페이지)로
  `PaddleOCRService().extract()`를 직접 호출해봤습니다. 크래시 없이
  약 5분 만에 끝까지 처리됐습니다(엔진 초기화 + 2페이지 전체 파이프라인).
  다만 필드 매핑 품질은 41.12에서 이미 확인한 "라벨이 한 줄에 밀집된
  레이아웃" 한계 때문에 다수 필드가 깨졌는데, 이건 PDF 지원 자체와는
  무관한 기존 한계라 이번 수정 범위에 포함하지 않았습니다.
- 여러 페이지가 있으면 페이지별 인식 결과를 페이지 구분 없이 하나의
  텍스트 줄 목록으로 합쳐서 `map_lines_to_ocr_fields()`에 넘기므로,
  서로 다른 페이지의 라벨/값이 섞일 수 있다는 점을 docstring에
  명시했습니다.

## 41.16 팀 작업 분담에 맞춘 디렉토리 분리: `rag/`, `frontend/`

- 이 프로젝트가 팀 프로젝트이고 팀원별로 RAG와 프론트엔드를 나눠
  맡고 있어, 각자 담당 영역을 프로젝트 최상위에서 바로 찾을 수 있도록
  `services/rag/` → **`rag/`**, `ui/` → **`frontend/`** 로 옮겼습니다
  (`git mv`로 히스토리 보존). 파일 내용/동작은 전혀 바꾸지 않았고,
  import 경로만 갱신했습니다.
- 변경한 import:
  - `rag/retriever.py` 내부: `from services.rag.X import ...` →
    `from rag.X import ...` (4곳 - chunker/document_loader/embedder/
    sample_regulations).
  - `frontend/regulation.py`: `from services.rag.retriever import
    RagRetriever` → `from rag.retriever import RagRetriever`.
  - `frontend/*.py` 6개 파일의 `from ui import theme` →
    `from frontend import theme`.
  - `app.py`의 `from ui import ocr_result, regulation, ...` →
    `from frontend import ocr_result, regulation, ...`.
  - `tests/test_integration_flow.py`, `tests/test_rag.py`(4곳).
  - `services/embedding_client.py` 독스트링, `.streamlit/config.toml`
    주석 - 코드 동작과 무관한 경로 언급도 같이 갱신.
- **`services/embedding_client.py`와 `services/reason_code/`는 옮기지
  않았습니다** - RAG 전용이 아니라 사유코드 검색과도 공유하는 인프라라,
  `rag/` 밑으로 옮기면 오히려 사유코드 쪽에서 `rag.embedding_client`처럼
  어색한 역참조가 생깁니다. `app.py`(Streamlit 진입점)와 `static/`(폰트)도
  그대로 루트에 뒀습니다 - `app.py`를 옮기면 `streamlit run` 실행
  경로와 `enableStaticServing`의 `static/` 상대 경로 규칙이 같이
  꼬일 위험이 있어 분리 범위를 코드 폴더(`rag/`, `frontend/`)로만
  한정했습니다.
- **검증**: `python -c "import app"` 정상, `pytest` 51건 전체 통과,
  Streamlit 앱을 실제로 재기동해 업로드 화면이 정상 렌더링되는 것과,
  별도 단독 스크립트로 `frontend.regulation`/`frontend.theme`를 직접
  렌더링해 이동된 `rag.retriever.RagRetriever`가 실제 법령 PDF 검색
  결과(외국환거래규정 제102조, 유사도 71%)를 그대로 반환하는 것까지
  라이브로 확인했습니다.
- README "5. 프로젝트 구조"에 새 트리와 팀 담당 표시를 반영했고, 이
  파일의 섹션 34(프로젝트 디렉토리 구조) 트리도 동일하게 갱신했습니다.
  이번 세션 이전 changelog 항목(41.5/41.8 등)에 남아있는 `ui/theme.py`
  같은 옛 경로 언급은 그 시점 기준 정확한 기록이라 그대로 뒀고, 41.13/
  41.14처럼 최근 항목은 현재 경로(`frontend/theme.py`)를 병기했습니다.

## 41.17 실사용 OCR 모드를 `paddle`에서 `vision`(qwen2.5vl)으로 변경

사용자가 "PaddleOCR이 너무 느리고 정확도도 떨어진다"며 Vision 모드로
전환을 요청해, 실제 손글씨로 작성한 예시 서식(`data/forms/하나은행_
외화송금신청서_3-09-0131_예시.pdf` - 성명/주민번호/계좌번호 등은 전부
테스트용으로 지어낸 값, 실제 개인정보 아님)으로 세 방식을 직접
비교했습니다.

| 방식 | 소요 시간 | 결과 |
|---|---|---|
| `paddle` (PaddleOCR) | 약 5분(2페이지) | 라벨이 밀집된 레이아웃(예: `받으실분 (Beneficiary) 수취인 계좌번호...`처럼 여러 항목이 한 줄에 이어 붙은 곳)에서 성명·목적 등 다수 필드가 깨짐(41.12에서 이미 확인한 한계와 동일 양상) |
| `vision` + `llava` | 약 29초 | **완전 실패** - 이미지를 읽지 않고 프롬프트에 적어둔 JSON 스키마의 필드 설명 문구를 그대로 베낌(예: `name_ko`가 실제 이름이 아니라 문자열 그대로 `"고객 한글명"`, `remittance_amount`는 실제 30000인데 `100`으로 나옴) |
| `vision` + `qwen2.5vl` | 약 17초 *(주: 아래 41.20에서 이 17초가 캐시 재사용 시 수치이고, 콜드 스타트는 70~90초대임을 재측정으로 확인함)* | 이름(한글/영문)·주민등록번호·계좌번호·수취인명·수취은행명·SWIFT BIC·송금액·송금목적까지 **거의 전부 정확히 추출**(사용자가 직접 확인한 원본 값과 대조 완료) |

- `llava`(4.7GB)는 삭제하고 `qwen2.5vl`(6.0GB)로 교체했습니다
  (`ollama rm llava` → `ollama pull qwen2.5vl`). `llava`는 영어 위주로
  학습된 비교적 작은 멀티모달 모델이라 한글이 섞인 조밀한 손글씨 문서에는
  근본적으로 약한 것으로 보이고, `qwen2.5vl`은 다국어(한국어 포함) 문서
  이해에 강한 것으로 알려진 모델입니다 - 즉 "Vision 방식이라고 다 잘
  되는 게 아니라 모델 자체의 역량 차이가 크다"는 걸 실측으로 확인했습니다.
- 변경 지점:
  - `config/settings.py`: `ollama_vision_model` 기본값 `"llava"` →
    `"qwen2.5vl"`.
  - `.env.example`: `OLLAMA_VISION_MODEL=llava` → `=qwen2.5vl`, `OCR_MODE`
    주석에 실측 비교 요약 추가.
  - `services/ocr/vision_ocr.py`, `services/ocr/paddle_ocr.py`: 독스트링에
    권장 모드/모델과 실측 근거를 남겼습니다(코드 동작 자체는 변경 없음 -
    두 서비스 모두 이미 있었고, 팩토리(`services/ocr/__init__.py`)에서
    `OCR_MODE` 값으로 그대로 선택함).
  - 로컬 `.env`도 `OCR_MODE=vision`, `OLLAMA_VISION_MODEL=qwen2.5vl`로
    변경해 실제로 라이브 검증했습니다.
  - README "2. 실행 모드"의 OCR 모드 표/Ollama 설정 안내, "9. OCR 필드
    매핑" 도입부에 위 비교 결과와 "Vision 모드에는 PaddleOCR 특유의 라벨
    밀집 문제가 해당하지 않는다"는 점을 반영했습니다.
- **PaddleOCR 구현 자체는 지우지 않았습니다** - `OCR_MODE=paddle`로 여전히
  선택 가능한 3번째 옵션으로 남겨뒀습니다. Ollama를 아예 못 쓰는
  완전 오프라인 환경을 위한 대안이라는 위치로 재정의했을 뿐, 코드/
  `requirements.txt`의 `paddlepaddle`/`paddleocr` 의존성은 그대로입니다.
  완전히 제거를 원하면 별도로 요청해야 합니다.
- **검증**: `pytest` 51건 전체 통과(OCR 모드 변경은 기본값/문서만 바뀐
  것이라 테스트 대상 로직 자체는 변경 없음). Vision 모드 실제 호출은
  위 표의 세 가지 케이스를 전부 실제 Ollama 서버에 대고 직접 실행해서
  확인했습니다(단위 테스트로 자동화하지는 않음 - 무거운 실제 모델 호출이
  필요해 기존 `test_paddle_ocr.py`/`test_rag.py` 등과 같은 이유로 CI성
  테스트 대상에서 제외).

## 41.18 PaddleOCR 완전 제거 + 원클릭 셋업의 LLM/Vision 모델 자동 pull

41.17에서 "완전히 제거를 원하면 별도로 요청해야 합니다"라고 남겨둔 옵션을
사용자가 이번에 실제로 요청("paddleocr 파일도 용량 크니까 삭제해줘")해
PaddleOCR 관련 코드/패키지/캐시를 전부 정리했습니다. 삭제 범위를
"다운로드된 모델 캐시만" vs "패키지+코드+문서 전체"로 미리 물어봤고,
사용자가 **전체 제거**를 선택했습니다.

**삭제한 것**

- 다운로드된 모델 가중치 캐시: `~/.paddlex`(142MB) - `rm -rf`.
- venv(`project/`) pip 패키지: `paddlepaddle`(3.3.1) / `paddleocr`(3.7.0) /
  `paddlex`(3.7.2), 합쳐서 약 450MB - `pip uninstall`.
- 코드: `services/ocr/paddle_ocr.py`, `services/ocr/text_field_mapper.py`
  (PaddleOCR이 뽑은 텍스트 줄을 신청서 필드로 매핑하는 규칙 기반 로직 -
  `paddle_ocr.py`에서만 쓰였으므로 같이 삭제), `tests/test_paddle_ocr.py`
  (텍스트 매퍼 회귀 테스트 12건 포함). 전체 테스트는 51건 → **39건**으로
  줄었습니다(로직이 없어진 만큼 테스트도 없앤 것이라 커버리지 손실이
  아닙니다).
- `requirements.txt`의 `paddlepaddle==3.3.1`/`paddleocr==3.7.0`과 관련
  주석(oneDNN 우회 설명).
- `config/settings.py`: `ocr_mode: Literal["mock", "vision", "paddle"]` →
  `Literal["mock", "vision"]`, `paddleocr_lang`/`paddleocr_use_gpu` 필드
  삭제.
- `.env.example`: `PADDLEOCR_LANG`/`PADDLEOCR_USE_GPU` 섹션 삭제, `OCR_MODE`
  주석에서 `paddle` 설명을 "과거에 있었으나 제거함" 한 줄로 축약.
- `services/ocr/__init__.py`: 팩토리에서 `paddle` 분기 삭제, 독스트링에
  제거 사실과 근거(41.17/41.18 참고) 명시.
- `app.py`/`frontend/upload.py`의 OCR 모드 표시 라벨 딕셔너리에서
  `"paddle": "PaddleOCR"` 항목 삭제.
- `tests/test_integration_flow.py` 상단 주석의 "OCR_MODE(예: paddle)"를
  "OCR_MODE(예: vision)"로, "PaddleOCR/Vision 엔진"을 "Vision 엔진"으로
  수정.
- README.md: OCR 모드 표에서 `paddle` 행 삭제(이제 `mock`/`vision` 두
  줄), 3-way 실측 비교표는 "과거 PaddleOCR 모드는 제거했습니다" 인용구
  안으로 옮겨 왜 제거했는지 근거로 남김. PaddleOCR 고유의 라벨 밀집
  한계를 설명하던 "8. 알려진 제약"의 항목과, `text_field_mapper.py`의
  필드별 매핑 규칙을 설명하던 "9. OCR 필드 매핑" 섹션 전체를 삭제했습니다
  (둘 다 이제 존재하지 않는 코드에 대한 설명이라 남겨두면 오히려
  혼란을 줌 - 그 세부 내용은 이 프롬프트 md의 섹션 41.12/41.15에 역사
  기록으로 남아 있습니다).

**추가한 것 - 원클릭 셋업의 LLM/Vision 모델 자동 pull**

PaddleOCR 삭제와 별개로, 사용자가 "처음 원클릭 셋업할 때 qwen2.5vl도
설치되는 거 맞지?"라고 질문해 확인해보니 **아니었습니다** -
`setup.sh`/`setup.ps1`은 그동안 임베딩 모델(`bge-m3`, 사유코드/RAG
검색에 `RAG_MODE`/`LLM_MODE`와 무관하게 항상 쓰이므로 무조건 pull)만
받았고, `OLLAMA_MODEL`(LLM)이나 `OLLAMA_VISION_MODEL`(Vision, 기본
`qwen2.5vl`)은 전혀 pull하지 않았습니다.

- 두 스크립트에 임베딩 모델 pull 스텝 바로 뒤, `.env`를 다시 읽어
  `LLM_MODE=live`면 `OLLAMA_MODEL`을, `OCR_MODE=vision`이면
  `OLLAMA_VISION_MODEL`을 pull하는 단계를 추가했습니다(`setup.sh`는
  Bash 함수 `env_value()`, `setup.ps1`은 `Get-EnvValue` 함수로 `.env`
  값을 읽고, 없으면 각각 `llama3.1`/`qwen2.5vl` 기본값 사용).
- **기본값(`mock`/`mock`)일 때는 pull하지 않도록 조건부로 만들었습니다**
  - LLM 모델(수 GB)과 Vision 모델(`qwen2.5vl` 6GB)은 가볍지 않아서,
    Mock 모드로만 시연할 사람에게 무조건 받게 하면 "API Key/Ollama 없이도
    동작"이라는 1번 섹션의 취지와 어긋납니다. 대신 `.env`를 먼저
    `LLM_MODE=live`/`OCR_MODE=vision`으로 채운 뒤 스크립트를 (다시)
    실행하면 그때 필요한 모델이 자동으로 받아지도록 했습니다.
- README "1. 빠른 시작"에 이 조건부 동작을 설명하는 안내문을 추가했습니다.
- **검증**: PaddleOCR 제거 후 `pytest tests/ -q` 재실행 - **39건 전체
  통과**(12건 감소는 삭제한 `test_paddle_ocr.py`와 정확히 일치). 남은
  `paddle` 문자열은 `grep`으로 전수 확인했고, 전부 "과거에 이런 모드가
  있었다/제거했다"는 의도적인 역사 기록(이 파일의 41.2/41.12/41.15 안내
  문구, `.env.example`/`services/ocr/vision_ocr.py`/
  `services/ocr/__init__.py`의 비교 설명 독스트링, README의 "제거했습니다"
  인용구)뿐이고, 실제로 그 코드를 가리키거나 import하는 곳은 없습니다.

## 41.19 Vision 모델 재검토: `qwen2.5vl` 유지 결정 (`qwen3-vl`/`qwen3.8` 실측)

41.17에서 `qwen2.5vl`을 채택한 이후, 사용자가 "qwen3.5vl도 있는 걸로
아는데 qwen2.5vl 쓰는 이유가 있냐"고 질문해 최신 Ollama Vision 모델
라인업을 다시 조사하고 실측 비교했습니다(2026년 8월 기준).

**조사 결과 - 후보 정리**

| 모델 | Ollama 태그 | 용량 | 비고 |
|---|---|---|---|
| Qwen2.5-VL (기존) | `qwen2.5vl` | 6.0GB | OCR 지원 언어 10개 |
| Qwen3-VL | `qwen3-vl:8b` | 6.1GB | 전용 VL 계열 최신판, OCR 지원 언어 32개로 확대 |
| Qwen3.5 | `qwen3.5:9b` | 6.6GB | 텍스트+비전 통합 학습 모델(별도 `-vl` 접미사 없음 - 사용자가 말한 "qwen3.5vl"은 이 모델을 가리키는 것으로 추정) |
| Qwen3.8 | `qwen3.8:27b` | 18GB | 2026-08-13/14 출시. vision 내장이지만 27B/18GB로, 공식 권장 사양이 24GB+ 통합메모리 |

이 컴퓨터는 RAM 16GB라 Qwen3.8(18GB)은 배제하고, 동급 용량인
`qwen3-vl:8b`로 실측 비교를 진행했습니다(`qwen3.5:9b`는 이번엔 테스트하지
않음 - 필요시 후속 검토).

**실측: `qwen2.5vl` vs `qwen3-vl:8b`(같은 예시 이미지, 같은 프롬프트)**

| 모델 | 소요 시간 | 결과 |
|---|---|---|
| `qwen2.5vl` | 78초 | 이름(한글/영문)·주민번호·계좌번호·수취인·수취은행·SWIFT·금액·목적 등 **14개 필드 거의 전부 정확** |
| `qwen3-vl:8b` | 175~250초 (3회 시도 모두) | **전부 실패** - `content`가 빈 문자열로 반환됨 |

- `qwen3-vl:8b`는 기본적으로 "thinking" 모드가 내장돼 있어, 파이썬
  `ollama` 클라이언트에 `think=False`를 넘겨도 여전히 긴 `<think>...</think>`
  추론 블록을 영어로 생성했습니다. `response.model_dump()`로 원본을
  까봐서 확인한 결과 `done_reason: "length"`, `eval_count: 1832`로 -
  **실제 JSON 답변에 도달하기 전에 응답 토큰 한도를 다 써버린 것**이
  원인이었습니다(`thinking` 필드에 "Okay, let's tackle this problem
  step by step..."로 시작하는 영어 추론이 중간에 끊겨 있었습니다).
- 토큰 한도(`num_predict`)를 크게 늘리면 될 수도 있지만, 이미 175초가
  넘게 걸리는 상황에서 더 늘리면 실사용에 부적합할 정도로 느려질
  것이므로 시도하지 않았습니다. 현재 vision_ocr.py의 "프롬프트 하나로
  JSON 한 번에 뽑기" 방식과는 `qwen3-vl:8b`의 thinking 모드가 근본적으로
  안 맞는다고 판단했습니다.

**결론**: `qwen2.5vl`을 계속 사용합니다. 코드/설정 변경 없음(순수 비교
검증만 수행). 테스트용으로 받았던 `qwen3-vl:8b`(6.1GB)는 사용자가 "지금
안 쓰는 모델이니 용량만 차지한다"며 삭제를 선택해 `ollama rm qwen3-vl:8b`로
지웠습니다.

## 41.20 `vision`(qwen2.5vl) 소요 시간 재측정: 콜드 스타트 vs 캐시 재사용

41.19 비교 도중 사용자가 "아까는 17초 걸렸다며?"(직전에 78초가 나온 것에
대한 질문)라고 물어봐서, 41.17에서 문서화한 "`vision`(`qwen2.5vl`) 약
17초"라는 수치가 정확히 뭘 잰 건지 다시 측정해봤습니다.

**실측 (같은 이미지로 2번 연속 호출, `response.model_dump()`로 Ollama가
반환하는 시간 필드를 직접 확인)**

| | 총 소요 시간 | `load_duration`(모델 로딩) | `prompt_eval_duration`(이미지+프롬프트 처리) | `eval_duration`(답변 생성) |
|---|---|---|---|---|
| 1번째 호출(콜드 - 직전에 모델이 메모리에서 내려간 상태) | 74.2초 | 5.4초 | **50.2초**(2895 토큰) | 18.4초 |
| 2번째 호출(1번째 직후, 완전히 동일한 이미지+프롬프트) | 17.6초 | 0초 | **0.1초** | 17.3초 |

**결론**: 소요 시간 대부분(약 50초)은 텍스트를 생성하는 시간이 아니라
**이미지+프롬프트를 인코딩하는 처리 시간**(`prompt_eval_duration`)이
차지합니다. Ollama는 직전 요청과 이미지·프롬프트가 완전히 동일하면 이
처리 결과(KV 캐시)를 재사용해서 건너뛰므로, 같은 이미지를 바로 다시
요청한 2번째 호출만 17초대로 나온 것입니다. **실사용에서는 은행원이
매번 다른 신청서 이미지를 업로드하므로 캐시 재사용이 일어나지 않고,
매번 콜드 스타트(약 70~90초)가 기본값입니다.** 41.17에서 측정한 "약
17초"는 아마 같은 이미지로 여러 번 테스트하던 중 캐시가 재사용된
값이었을 가능성이 높습니다 - 그 세션 로그까지 다시 확인하지는 않았지만,
이번 재측정 결과가 메커니즘상 더 신뢰할 수 있는 수치라 문서(README "2.
실행 모드", 이 파일 섹션 8 마커, 41.17 표)를 "콜드 스타트 약 70~90초 /
캐시 재사용 시 약 17초"로 모두 고쳤습니다. PaddleOCR(약 5분)과 비교하면
콜드 스타트 기준으로도 여전히 3~4배 이상 빠릅니다.

같은 대화에서 이어서, 사이드바 모드 배지가 "LLM: Live(Ollama)", "OCR:
Vision(Ollama)"처럼 실제 어떤 모델을 쓰는지 안 보여주는 문제도
지적받아 고쳤습니다.

- `app.py`의 `_MODE_LABELS`에서 `live`/`vision` 항목을 제거하고,
  `_model_mode_label(mode, model_name)` 헬퍼를 추가했습니다: `live`/
  `vision`이면 `f"{model_name} (Ollama)"`(예: `qwen2.5vl (Ollama)`,
  `llama3.1 (Ollama)`)를 반환하고, 그 외(`mock`/`pdf`)는 기존
  `_MODE_LABELS` 딕셔너리 값을 그대로 씁니다.
- `mode_badges` 구성에서 `settings.ollama_model`(LLM용)과
  `settings.ollama_vision_model`(OCR용)을 각각 넘겨줍니다. RAG 배지는
  모델이 아니라 데이터 소스 구분(Mock 샘플 텍스트 vs 실제 PDF)이라
  그대로 `Mock`/`PDF`로 남겨뒀습니다.
- **검증**: Streamlit 프리뷰를 다시 띄워 사이드바에 "LLM: llama3.1
  (Ollama)", "OCR: qwen2.5vl (Ollama)"로 정확히 표시되는 것을 확인했고,
  서버 에러 로그도 없었습니다.

이 라벨 변경 덕분에 사이드바에서 바로 확인이 됐는데, 사이드바가
"LLM: llama3.1 (Ollama)"로 뜨는 걸 보고 사용자가 "처음엔 gpt-oss:120b
쓰기로 한 거 아니었냐"고 질문했습니다. git 히스토리를 전수 확인한 결과
`gpt-oss:120b-cloud`는 `.env.example`/README/이 파일 어디에서도 "Ollama
Cloud 모델은 `-cloud` 접미사를 쓴다"는 **네이밍 예시**로만 등장했을 뿐,
실제 기본값으로 채택된 적은 없었습니다(`.env.example`의
`OLLAMA_MODEL=llama3.1`은 첫 커밋부터 지금까지 그대로).

다만 로컬 `.env`(git 비추적)를 열어보니 `OLLAMA_BASE_URL=http://localhost
:11434`/`OLLAMA_MODEL=llama3.1`인데 `OLLAMA_API_KEY`엔 Cloud용 키가 그대로
남아있는 상태였습니다 - 과거 어느 시점에 Ollama Cloud + `gpt-oss:120b-cloud`로
쓰다가 로컬로 되돌리면서 키 정리만 빠뜨린 것으로 보입니다(이 파일이
git 추적 대상이 아니라 정확한 시점은 추적 불가). 사용자가 Cloud +
`gpt-oss:120b-cloud`로 되돌리는 쪽을 선택해 로컬 `.env`의
`OLLAMA_BASE_URL`을 `https://ollama.com`, `OLLAMA_MODEL`을
`gpt-oss:120b-cloud`로 변경했습니다. 실제 API Key로 `client.chat()`을
직접 호출해 0.9초 만에 정상 응답("안녕")을 받는 것으로 키가 아직
유효함을 확인했고, Streamlit 사이드바에도 "LLM: gpt-oss:120b-cloud
(Ollama)"로 반영되는 것을 확인했습니다. 이 시점에는 `config/settings.py`의
기본값(`llama3.1`)은 그대로 두고 로컬 `.env`에만 적용했으나, **바로 이어서
41.21에서 사용자가 공용 기본값도 바꾸기로 결정**했습니다.

## 41.21 LLM 기본 모델을 프로젝트 공용 기본값까지 `gpt-oss:120b-cloud`로 변경

41.20에서 로컬 `.env`만 Cloud로 바꾼 뒤, 사용자가 "`gpt-oss:120b-cloud`가
`llama3.1`보다 성능이 더 좋은지" 물어봐서 실측/공개 벤치마크로
확인했습니다.

**벤치마크 비교 (Artificial Analysis, OpenAI 모델 카드)**

| | `gpt-oss:120b` | `llama3.1`(8B 기본 태그) |
|---|---|---|
| 종합 지능 지수 | **24** | 7 |
| 코딩 벤치마크 | **21.2** | 5.4 |
| 컨텍스트 길이 | **131,072 토큰** | 16,384 토큰 |
| 한국어(MMMLU-KO) | 75~83점(추론 강도별) | 자료 없음(구형 모델) |
| 구조 | MoE, 117B 중 5.1B만 활성화 | Dense 8B |
| 비용 | $0.20/1M 토큰(Cloud) | $0.02/1M 토큰(또는 로컬 무료) |

`gpt-oss:120b`는 2025-08 OpenAI가 공개한 오픈소스 대형 모델, `llama3.1`은
2024-07 나온 구형 8B 모델로 세대/체급 차이가 명확했고, 한국어 성능도
MMMLU 기준 75~83점으로 이 프로젝트(거래 목적 한국어 분석/분류)에 특히
중요한 부분에서 준수했습니다. 사용자가 "그러면 LLM_MODE=live일 때
gpt-oss:120b-cloud로 돌아가게 하자"고 결정했습니다.

**구조적 문제 발견 및 해결**: 단순히 `ollama_model` 기본값만 바꾸면
안 되는 이유가 있었습니다 - `services/ocr/vision_ocr.py`가 LLM과
**같은** `ollama_base_url`/`ollama_api_key`를 공유해서 썼기 때문에,
`ollama_base_url` 기본값을 Cloud로 바꾸면 Vision OCR도 덩달아 Cloud로
가버립니다. 그런데 Ollama Cloud는 `qwen2.5vl` 같은 Vision 모델을
제공하지 않으므로, 그대로 두면 **OCR_MODE=vision 기본값이 조용히
깨집니다.** 로컬 `.env`에서 처음 겪었던 것과 똑같은 "모델은 바꿨는데
엔드포인트가 안 맞는" 문제가 이번엔 프로젝트 공용 기본값에서 재발할
뻔했습니다.

- 이미 임베딩(`OLLAMA_EMBED_BASE_URL`/`OLLAMA_EMBED_API_KEY`, 41.3)에
  적용돼 있던 "LLM과 별도 엔드포인트, 비워두면 LLM 것 폴백" 패턴을
  Vision에도 그대로 적용했습니다: `config/settings.py`에
  `ollama_vision_base_url`/`ollama_vision_api_key`(둘 다 기본 `None`,
  `build_ollama_client()`가 `None`이면 `ollama_base_url`/`ollama_api_key`로
  폴백) 필드를 추가했습니다.
- `services/ocr/vision_ocr.py`가 `build_ollama_client(settings)` 대신
  `build_ollama_client(settings, host=settings.ollama_vision_base_url,
  api_key=settings.ollama_vision_api_key)`를 쓰도록 변경했습니다.
- `config/settings.py`: `ollama_base_url` 기본값 `http://localhost:11434`
  → `https://ollama.com`, `ollama_model` 기본값 `llama3.1` →
  `gpt-oss:120b-cloud`.
- `.env.example`: Ollama 섹션을 "LLM 분석 전용"/"Vision 전용"으로 명확히
  나누고, `OLLAMA_VISION_BASE_URL=http://localhost:11434`/
  `OLLAMA_VISION_API_KEY=`를 **명시적으로 로컬 값으로 커밋**했습니다
  (임베딩의 `OLLAMA_EMBED_BASE_URL`처럼 - `None` 폴백에 기대지 않고
  템플릿 자체에 안전한 값을 박아둠). 무료로 쓰고 싶은 사람을 위한
  "OLLAMA_BASE_URL=http://localhost:11434 + OLLAMA_MODEL=llama3.1로
  바꾸면 됨" 안내도 추가했습니다.
- 로컬 `.env`도 같은 구조로 맞췄습니다(`OLLAMA_VISION_BASE_URL`/
  `OLLAMA_VISION_API_KEY`를 로컬로 명시 추가). 이제 안 쓰는
  `PADDLEOCR_LANG`/`PADDLEOCR_USE_GPU` 두 줄도 로컬 `.env`에서
  정리했습니다(41.18에서 `.env.example`은 이미 정리했었으나 로컬
  `.env`는 각자 파일이라 별도로 지워야 했음).
- `setup.sh`/`setup.ps1`의 LLM 모델 pull 폴백 기본값도
  `llama3.1`→`gpt-oss:120b-cloud`로 맞췄습니다. `-cloud` 모델은
  `ollama pull`해도 매니페스트만 받아 수 초 내로 끝나는 것을 실측으로
  확인했지만(가중치는 Ollama 서버에서 실행 - 로컬 디스크/용량 변화
  없음 확인), Cloud 계정/API Key가 없는 팀원은 pull이 인증 오류로
  실패할 수 있습니다. `setup.sh`는 `set -euo pipefail`이라 이 실패가
  스크립트 전체를 중단시키므로, LLM/Vision 모델 pull 두 곳 모두 실패를
  잡아서 경고만 띄우고 계속 진행하도록 고쳤습니다(`setup.ps1`도 동일하게
  `$LASTEXITCODE` 체크로 경고만 띄우도록 맞춤 - PowerShell은 원래
  네이티브 명령 실패로 자동 중단되진 않지만, 명시적 경고 메시지를 위해
  추가).
- README "1. 빠른 시작" 안내문과 "2. 실행 모드 > Ollama 설정"을
  LLM(Cloud 기본)/Vision(로컬 고정)/임베딩(로컬 고정) 3분할 구조로
  다시 썼습니다.

**검증**:
- `config.settings.get_settings()`로 세 접속 정보가 각각
  `LLM base_url=https://ollama.com, model=gpt-oss:120b-cloud` /
  `Vision base_url(resolved)=http://localhost:11434, model=qwen2.5vl` /
  `Embed base_url(resolved)=http://localhost:11434, model=bge-m3`로
  정확히 분리되는 것을 확인했습니다.
- `get_llm_service()`로 실제 `OllamaLLMService`를 얻어 "해외 부동산 매입
  대금 송금"을 분석시켜 `https://ollama.com/api/chat`으로 정상 호출되고
  올바른 구조화 결과(`해외부동산`/`취득`/`자본거래`)를 받는 것을
  확인했습니다.
- `get_ocr_service()`로 얻은 `VisionOCRService`의 내부 클라이언트가
  여전히 `http://localhost:11434`를 가리키는 것을 직접 확인했습니다 -
  LLM 기본값 변경이 Vision에 새어 들어가지 않았음을 검증.
- `bash -n setup.sh`로 문법 확인, `pytest tests/ -q` 39건 전체 통과.

사이드바에 "LLM: gpt-oss:120b-cloud (Ollama)"가 뜬 걸 보고 사용자가 표시가
이상하다고 지적했습니다 - 실제로는 모델명이 `llama3.1`보다 길어지면서
`frontend/theme.py`의 `.fx-vc-row`(라벨/값을 `justify-content:space-between`
으로 한 줄에 배치하는 CSS)가 값이 길 때 라벨과 값 사이 간격이 없어지고
"(Ollama)" 부분만 어색하게 다음 줄로 줄바꿈되는 문제였습니다.

- `.fx-vc-row`를 가로 배치(`justify-content:space-between`)에서 세로
  배치(`flex-direction:column`, 라벨을 작게 위에, 값을 굵게 아래에)로
  바꿨습니다. 값에 `word-break:break-word`도 추가해 아무리 긴 모델명이
  와도 카드 밖으로 안 튀어나가게 했습니다.
- **주의**: CSS를 고친 뒤 브라우저 새로고침만으로는 반영되지 않았습니다 -
  `frontend/theme.py`의 CSS 문자열이 이미 실행 중인 Streamlit 프로세스의
  `sys.modules` 캐시에 남아있어서였습니다(Streamlit의 자동 재실행은
  스크립트를 다시 실행하지만, 이미 import된 모듈까지 다시 읽어오지는
  않음). `pkill -f "streamlit run app.py"`로 서버를 완전히 재시작해야
  변경이 반영됐습니다 - 이번처럼 Python 모듈 최상단의 CSS/상수 문자열을
  고칠 때는 브라우저 새로고침이 아니라 서버 재시작이 필요하다는 점을
  기억해둘 만합니다.
- **검증**: 서버 재시작 후 스크린샷으로 "LLM" 위에 "gpt-oss:120b-cloud
  (Ollama)"가 한 덩어리로 깔끔하게 나오는 것을 확인했고, `pytest` 39건도
  다시 통과시켰습니다.

## 41.22 가상환경 폴더명을 `project`에서 `fixar`로 변경

사용자가 "가상환경 이름이 지금 project인거지?"라고 확인한 뒤 "전부다
fixar로 바꿀 수 있나?"라고 요청했습니다. 프로젝트가 FIXAR로 명명되기
전(41.1)에 `project`라는 이름으로 만들었던 관례가 그대로 남아있던
것인데, 이제 브랜드명이 확정됐으니 맞추기로 했습니다.

41.14에서 이미 겪은 "가상환경을 만든 뒤 상위 폴더 이름을 바꾸면 pip이
만든 실행 스크립트의 셔뱅이 깨진다"는 문제가 여기도 그대로 적용되므로,
단순히 폴더명만 `mv`로 바꾸지 않고 **`project/`를 완전히 지우고
`fixar/`로 새로 만드는 방식**으로 진행했습니다(README "8. 알려진 제약"에
이미 이 방식이 권장 해법으로 문서화돼 있었음). `project/`는
`.gitignore`에 걸려 git 추적 대상이 아니므로 안전하게 지울 수 있었습니다.

**변경한 것**

- `rm -rf project && python3 -m venv fixar && fixar/bin/pip install -r
  requirements.txt`로 가상환경을 새로 생성.
- `setup.sh`/`setup.ps1`: `VENV_PYTHON`/`$venvPython` 경로, `python3 -m
  venv project` → `fixar`, 안내 문구/주석의 `project/` 전부 `fixar/`로
  치환.
- `.claude/launch.json`: 두 프리뷰 설정의 `runtimeExecutable`을
  `project/bin/streamlit` → `fixar/bin/streamlit`,
  `project/Scripts/streamlit.exe` → `fixar/Scripts/streamlit.exe`로 변경.
- `.gitignore`: `/project/` → `/fixar/`.
- README.md: "1. 빠른 시작"의 스크립트 설명, 수동 설치 커맨드 블록,
  "가상환경 폴더명은 `fixar`로 통일" 문구, git clone 시 빠지는 파일
  표, "8. 알려진 제약"의 셔뱅 깨짐 설명과 예시 커맨드까지 전부 `project`
  → `fixar`로 치환.
- 이 파일 섹션 34의 `[구현 변경]` 마커도 현재 상태(`fixar`)로 갱신하고,
  왜 이름이 두 번 바뀌었는지(관례적 `project` → 브랜드 확정 후 `fixar`)
  경위를 남겼습니다.
- 섹션 41.1/41.9/41.11/41.14 등 과거에 `project`가 실제 이름이었을 때
  작성된 changelog 항목은 **그 시점 기준 정확한 기록이라 그대로
  뒀습니다**(41.13/41.14가 `ui/theme.py` 옛 경로를 그대로 둔 것과 같은
  원칙).

**검증**: `fixar/bin/pytest tests/ -q` 39건 전체 통과. `foreign-exchange-
ai-for-regtech-mac` 프리뷰 설정으로 Streamlit을 재시작해 `fixar/bin/
streamlit`으로 정상 기동하고 사이드바까지 정상 렌더링되는 것을
확인했습니다(서버 에러 로그 없음).

## 41.23 Vision OCR에 PDF 지원 추가 + Ollama 타임아웃 부족 버그 수정

README "8. 알려진 제약"의 "Vision OCR은 이미지(JPG/PNG)만 지원하며 PDF는
지원하지 않습니다" 문구를 사용자가 보고 "PDF도 안 되냐"고 물어봤습니다.
문구 자체는 정확했지만(`services/ocr/vision_ocr.py`의
`_SUPPORTED_SUFFIXES`가 실제로 PDF를 막고 있었음), 확인하다가 더 큰
문제를 하나 발견했습니다: [frontend/upload.py](frontend/upload.py)의
업로드 위젯이 `OCR_MODE`와 무관하게 `_ALLOWED_TYPES = ["pdf", "jpg",
"jpeg", "png"]`로 고정돼 있어서, vision 모드에서도 PDF 업로드 자체는
받아지고 "OCR 분석 시작"을 누른 뒤에야 `OCRError`로 실패하는 뒤늦은
실패(late failure) 구조였습니다.

두 가지 해결책(업로드 위젯에서 PDF를 막기 vs Vision OCR이 PDF를 실제로
처리하게 만들기) 중, 사용자가 "pdf도 가능하게 하면 되는거 아니야?"라고
결정해 **후자로 구현**했습니다.

**구현**

- `pypdfium2`를 다시 추가했습니다(41.18에서 PaddleOCR과 함께 제거된
  전이 의존성 - poppler 등 시스템 패키지 없이 PDFium 바이너리를 직접
  배포하므로 추가 설치 부담이 없음).
- `services/ocr/vision_ocr.py`:
  - `_SUPPORTED_SUFFIXES`에 `.pdf`를 추가했습니다.
  - `_rasterize_first_page()`를 새로 만들었습니다: PDF **첫 페이지만**
    약 144DPI(스케일 2.0배)로 PNG 렌더링해 임시 파일로 저장하고, (경로,
    전체 페이지 수)를 반환합니다. Vision 모델은 한 번의 대화 호출에
    이미지 1장만 넘기는 구조라, PaddleOCR처럼 여러 페이지 텍스트를
    합치는 방식이 아니라 "필요한 정보가 다 있는 첫 페이지만 쓴다"는
    단순한 접근을 택했습니다 - 외화송금신청서는 실제로 1페이지에 필요한
    정보가 다 있고 2페이지는 자동화기기 이용 신청 등 무관한 내용이라
    (41.12 참고) 실사용에 문제가 없습니다.
  - `extract()`가 PDF면 임시 이미지로 변환 후 그 경로를 Ollama에
    넘기고, 호출이 끝나면(성공/실패 무관) `finally`에서 임시 파일을
    삭제합니다.
  - 페이지가 2장 이상이면 결과 `warnings`에 "N페이지 중 1페이지만
    인식에 사용했습니다" 경고를 추가해, 은행원이 OCR 결과 확인 화면에서
    바로 알 수 있게 했습니다.
- `tests/test_vision_ocr.py`를 새로 만들었습니다: 실제 Ollama 모델 호출
  없이 확인 가능한 두 가지만 테스트합니다(`.pdf`가 `_SUPPORTED_SUFFIXES`에
  있는지, `_rasterize_first_page()`가 저장소에 커밋된 실제 빈 서식 PDF
  (`data/forms/하나은행_외화송금신청서_3-09-0131.pdf`, 2페이지)로 유효한
  이미지 파일과 정확한 페이지 수(2)를 반환하는지). `VisionOCRService.
  extract()` 전체 흐름은 여전히 무거운 실제 Ollama 호출이 필요해 자동
  테스트 대상에서 제외했습니다(`test_integration_flow.py`와 같은 원칙).

**버그 발견 및 수정: `OLLAMA_TIMEOUT` 부족**

실제 PDF(`data/forms/..._예시.pdf`)로 첫 end-to-end 테스트를 돌렸더니
`httpx.ReadTimeout`으로 실패했습니다. 41.20에서 이미 "Vision OCR 콜드
스타트는 70~90초 걸릴 수 있다"는 걸 실측해놓고도, `OLLAMA_TIMEOUT`
기본값이 여전히 `config/settings.py`는 30초, `.env.example`/`.env`는
60초로 남아있어서 실제로 재현된 것입니다 - 41.20의 발견을 타임아웃
설정에 반영하지 않았던 게 이번에 드러난 셈입니다.

- `config/settings.py`: `ollama_timeout` 기본값 `30` → `120`.
- `.env.example`/`.env`: `OLLAMA_TIMEOUT=60` → `120`, 콜드 스타트 근거를
  주석에 명시했습니다.
- LLM(Cloud) 호출은 0.9초로 매우 빠르므로(41.20/41.21) 타임아웃을
  늘려도 실사용에 지연이 생기지 않습니다 - "얼마나 기다릴지"의 상한선만
  올린 것이라 안전한 변경입니다.

**검증**: 타임아웃을 120초로 올린 뒤 `VisionOCRService().extract()`로
`data/forms/하나은행_외화송금신청서_3-09-0131_예시.pdf`를 직접
처리했습니다. 성명(최기영/Kiyoung Choi)·주민등록번호(980317-1234567)·
계좌번호(123-456-1890)·수취인(SANGWOO HAHM)·수취은행
(BANK OF AMERICA/BOFAUS3N)·송금액(30000)·송금목적(해외 법인 설립)까지
사용자가 직접 확인한 원본 값과 **전부 정확히 일치**했습니다(소요 20초 -
모델이 직전 테스트로 메모리에 남아있어 캐시 재사용 케이스에 가까웠음).
1페이지짜리 PDF라 다중 페이지 경고는 뜨지 않는 것도 확인했습니다.
`tests/test_vision_ocr.py` 2건을 포함해 `pytest tests/ -q` 41건 전체
통과했습니다. README "2. 실행 모드"의 OCR 모드 표(지원 파일 컬럼)와
"8. 알려진 제약"의 PDF 미지원 문구를 PDF 지원(첫 페이지만)으로
갱신했습니다. 또한 이 파일 섹션 34의 디렉토리 트리에 41.18에서
지웠어야 할 `paddle_ocr.py`/`text_field_mapper.py` 항목이 그대로
남아있던 것을 발견해 함께 제거했습니다.

**놓친 부분 - `frontend/upload.py`의 별도 라벨 표시**: 사용자가 업로드
화면의 "현재 OCR 모드: Vision OCR (Ollama)" 안내 문구가 사이드바(41.20
에서 "qwen2.5vl (Ollama)"로 고친 부분)와 다르게 아직도 모델명 없이
"Vision OCR (Ollama)"로만 뜬다고 지적했습니다. `frontend/upload.py`가
`app.py`의 `_model_mode_label()`과는 완전히 별개인 자체 `mode_label`
딕셔너리(`{"mock": "Mock OCR", "vision": "Vision OCR (Ollama)"}`)를
쓰고 있어서, 41.20에서 사이드바만 고치고 이 화면은 놓쳤던 것입니다.
`"vision"` 값을 `f"Vision OCR - {settings.ollama_vision_model}
(Ollama)"`로 바꿔 "Vision OCR - qwen2.5vl (Ollama)"로 표시되도록
고쳤습니다. `grep`으로 "Vision OCR (Ollama)"/"Live(Ollama)" 등 같은
패턴의 하드코딩이 다른 곳에 더 없는지 전수 확인했고(문서/독스트링
설명 문구 제외), 없는 것을 확인했습니다. 프리뷰 재기동으로 화면
반영과 서버 에러 없음을 확인했고, `pytest` 41건 재통과시켰습니다.

**RAG 배지도 LLM/OCR과 같은 패턴으로 통일**: 사용자가 사이드바에서 LLM/
OCR은 "모델명 (Ollama)"로 뜨는데 RAG만 그냥 "PDF"라고만 뜬다고
지적했습니다. `rag/retriever.py`를 확인해보니 `RAG_MODE`(mock/pdf)는
색인하는 원문이 샘플 텍스트냐 실제 PDF냐만 결정할 뿐, 검색 자체는
어느 쪽이든 항상 같은 임베딩 모델(`OLLAMA_EMBED_MODEL`, 기본
`bge-m3`)이 담당하고 있었습니다 - 즉 LLM/OCR과 마찬가지로 "실제 이
배지 뒤에서 일하는 모델"이 있는데 그것만 안 보여주고 있던 것입니다.

- `app.py`에 `_rag_mode_label(mode, embed_model)` 헬퍼를 추가했습니다:
  `f"{embed_model} ({label})"` 형태로 반환해(`_model_mode_label()`이
  `f"{model_name} (Ollama)"` 형태를 반환하는 것과 같은 패턴) "bge-m3
  (PDF)"/"bge-m3 (Mock)"로 표시됩니다.
- `mode_badges`의 RAG 항목이 `_MODE_LABELS.get(...)` 대신
  `_rag_mode_label(settings.rag_mode, settings.ollama_embed_model)`을
  쓰도록 변경했습니다.
- **검증**: `pytest` 41건 통과, 프리뷰 스크린샷으로 사이드바에 "RAG:
  bge-m3 (PDF)"로 정확히 표시되는 것을 확인했습니다(서버 에러 없음).

사용자가 이어서 "bge-m3는 텍스트를 벡터로 바꾸는 역할인데, 그 벡터로
검색하는 건 어떤 기능이냐"고 물어봐서 `rag/retriever.py`를 다시
확인했습니다. bge-m3(임베딩)와 실제 벡터 검색(유사도 계산 + 최근접
검색)은 별개 구성요소였습니다 - 검색은 **ChromaDB**
(`chromadb.PersistentClient`, `data/chroma/`에 저장, `hnsw:space:
cosine`로 코사인 유사도 기준 HNSW 인덱스 검색)가 담당합니다. 사용자가
"그러면 bge-m3 + ChromaDB (PDF)로 표시했어야지"라고 해서 라벨을 그렇게
바꿨습니다.

- `_rag_mode_label()`이 `f"{embed_model} ({label})"` 대신
  `f"{embed_model} + ChromaDB ({label})"`을 반환하도록 수정했습니다.
- **검증**: `pytest` 41건 재통과, 프리뷰 스크린샷으로 사이드바에 "RAG:
  bge-m3 + ChromaDB (PDF)"로 정확히 표시되고 레이아웃이 깨지지 않는
  것을 확인했습니다(서버 에러 없음).

## 41.24 프론트엔드 전체의 "지금 어떤 기능 사용중인지" 표시 하드코딩 전수 점검

사용자가 "프론트엔드 전체에서 LLM/OCR/RAG 지금 어떤 기능 사용중인지
표시하는 거 하드코딩된 거 없는지 확인해줘 - 로컬 환경에서 목업으로만
돌리는데도 qwen2.5vl 이렇게 나오면 안 되잖아"라고 요청해 `frontend/`
전체를 훑었습니다. 실제로 두 가지를 더 찾았습니다(사이드바는 41.20/
41.24-RAG 파트에서 이미 손봄).

**① RAG 배지가 진짜 사용 중인 임베딩 방식을 반영하지 못함**: 방금 만든
`_rag_mode_label()`이 `RAG_MODE`만 보고 항상 "bge-m3 + ChromaDB"를
보여주고 있었는데, `services/embedding_client.py`를 다시 확인하니
Ollama 임베딩을 시도하는 조건이 `RAG_MODE`가 아니라 **`LLM_MODE ==
"live"`** 였습니다(`RAG_MODE`는 색인 원문 - 샘플 텍스트 vs 실제 PDF -
만 결정). 즉 `LLM_MODE=mock`이면 `RAG_MODE`가 뭐든 임베딩은 항상 경량
해시 폴백인데, 배지는 그 상태에서도 "bge-m3"라고 거짓 표시하고
있었습니다.
  - `_rag_mode_label(rag_mode, llm_mode, embed_model)`로 시그니처를
    바꿔, `llm_mode == "live"`일 때만 `"{embed_model} + ChromaDB"`를,
    아니면 `"해시 임베딩 + ChromaDB"`를 앞부분에 쓰도록 고쳤습니다.
  - 4가지 조합(`rag_mode`×`llm_mode`)을 직접 호출해 각각 "해시 임베딩 +
    ChromaDB (Mock)" / "해시 임베딩 + ChromaDB (PDF)" / "bge-m3 +
    ChromaDB (Mock)" / "bge-m3 + ChromaDB (PDF)"로 정확히 나오는 것을
    확인했습니다.
  - 다만 이 배지도 "설정값 기준"이라는 한계는 LLM/OCR 배지와 동일합니다
    - `LLM_MODE=live`인데 Ollama 연결이 런타임에 실패해 해시로 폴백하는
      경우까지는 배지가 못 잡아냅니다(그건 아래 화면별 경고 문구가
      담당).
- **② `frontend/transaction_analysis.py`의 스피너/제목이 `LLM_MODE`와
  무관하게 항상 "Ollama"라고 표시**: "🤖 AI 거래 문맥 분석 시작" 버튼을
  누르면 `LLM_MODE`와 무관하게 스피너가 "Ollama LLM으로 거래 목적을
  분석하는 중입니다..."라고 뜨고, 결과 제목도 "🤖 Ollama 분석
  결과"였습니다. 실제로는 `_run_analysis()`가 `get_llm_service()`로
  `llm_mode`에 따라 `MockLLMService`(규칙 기반 키워드 매칭, Ollama
  호출 없음)와 `OllamaLLMService`를 갈라 쓰는데, 화면 문구는 그 구분을
  전혀 안 하고 있었습니다.
  - `llm_mode == "live"`면 `f"Ollama({settings.ollama_model})"`, 아니면
    `"Mock 규칙 기반"`이 되는 `llm_label`을 만들어 스피너/제목 둘 다에
    반영했습니다(예: "Mock 규칙 기반으로 거래 목적을 분석하는
    중입니다...", "🤖 Mock 규칙 기반 분석 결과").
- **③ 두 화면의 폴백 경고 문구가 옛 사이드바 표기를 가리킴**:
  `frontend/transaction_analysis.py`와 `frontend/regulation.py` 둘 다
  "⚠️ Ollama 임베딩 연결에 실패해 경량 해시 임베딩으로 검색했습니다 -
  사이드바가 'Live'로 표시되어도..."라는 문구가 있었는데, 41.20에서
  사이드바 라벨을 "Live(Ollama)"에서 실제 모델명으로 바꾼 뒤로 이제
  존재하지 않는 표기("Live")를 가리키고 있었습니다. "사이드바의 RAG
  배지가 'bge-m3 + ChromaDB'로 표시되어도..."로 두 파일 모두 고쳤습니다.
- `grep`으로 `frontend/summary.py`/`swift.py`/`ocr_result.py`에는 같은
  패턴의 하드코딩이 없는 것을 확인했습니다.
- **검증**: `_model_mode_label()`/`_rag_mode_label()`을 직접 호출해
  mock/live 조합 8가지 출력을 전부 확인했고, `frontend.transaction_
  analysis`/`frontend.regulation`/`app` import가 정상인지 확인했으며,
  `pytest tests/ -q` 41건 전체 통과, 프리뷰 재기동으로 현재 설정
  (`LLM_MODE=live`) 기준 사이드바가 "RAG: bge-m3 + ChromaDB (PDF)"로
  올바르게 나오는 것을 확인했습니다(서버 에러 없음). ③ 화면(거래 문맥
  분석)의 Mock 분기 문구는 실제 Mock 서비스 호출 없이 로직만 별도로
  검증했습니다(실제 화면 클릭 시연은 OCR 단계부터 거쳐야 해서 생략).

## 41.25 사이드바 게이팅 제거 - ①~⑥ 자유 이동 + 빈 서식 렌더링

사용자가 "사이드바에서 1 2 3 4 5 6 비활성화 하지 말고 눌러서 이동할 수
있게 하면 안돼? 그 전단계에서 입력한게 없으면 그냥 빈 서식으로 나오도록
- 너무 불편해"라고 요청했습니다. 기존엔 아직 도달하지 못한 단계(사이드바
번호가 `current_step`보다 큰 단계)는 버튼을 아예 `disabled=True`로 막아둔
채, 각 화면 진입 시 필요한 세션 데이터가 없으면 `st.warning` + 이전
단계로 강제 리다이렉트하는 안전장치가 있었습니다(예: OCR 결과 화면은
`ocr_result is None`이면 무조건 ①로 돌려보냄).

- **사이드바(`frontend/theme.py: render_sidebar`)**: 모든 단계 버튼을
  항상 클릭 가능하게 바꿨습니다(현재 위치 버튼만 눌러도 의미 없으니
  비활성 유지). `disabled` 상태에서 `cursor: not-allowed`가 뜨던 것도
  `cursor: default`로 고쳤습니다(사용자가 "현재 위치한 목차 위에 커서가
  있으면 금지 표시 나오는데 이건 없애"라고 별도 지적).
- **`ocr_result.py`/`transaction_analysis.py`/`swift.py`/`summary.py`**:
  진입 시 필요 데이터가 없으면 강제 리다이렉트하던 로직을 없애고, 대신
  `CustomerProfile()`/`TransactionRequest()` 같은 기본값 빈 객체로 폼을
  그대로 렌더링하도록 바꿨습니다(두 스키마 모두 전 필드에 default가 있어
  인자 없이 생성 가능). 화면 상단에 "아직 ~가 없습니다, 지금 바로
  입력/실행해도 됩니다" 안내를 추가했습니다.
- **`regulation.py`**: 필요서류/법령 검색은 확정된 사유코드가 있어야만
  의미가 있어서(사유코드 기준으로 RAG 쿼리와 필요서류 목록을 만듦),
  사유코드가 없으면 검색 자체를 실행하지 않고 "사유코드 확인하면
  여기 채워집니다"라는 빈 상태만 보여주도록 분기했습니다. "다음" 버튼도
  사유코드가 없으면(체크할 항목 자체가 없으므로) 막지 않고 통과시킵니다.
- **완료 표시(✅) 재정의**: `num < current_step`이면 무조건 체크로
  표시하던 기존 로직은, 사이드바로 아무 단계나 눌러 이동할 수 있게 되면서
  "그냥 번호가 작은 단계"와 "실제로 완료한 단계"가 달라지는 문제가
  생겼습니다(사용자가 "사이드바에서 왔다갔다하는데 뭐 안해도 이동한
  목차 이전의 모든 항목들이 완료 체크 표시돼"라고 재현). `st.session_
  state.max_step_reached`(기본값 1)를 새로 도입해, 각 화면의 실제
  제출/확정 액션이 `step`을 다음 번호로 넘길 때만 `max(..., N+1)`로
  갱신하고, 사이드바 클릭 자체는 이 값을 건드리지 않도록 분리했습니다.
  체크 조건도 `num < max_step_reached`로 바꿨습니다(처음엔 `num <=
  max_step_reached`+ 초기값 1로 잘못 짜서 1단계가 아무것도 안 해도
  항상 완료로 뜨는 버그가 있었고, 실제 재현 테스트로 잡아 `<`로 고침).
  OCR 결과 재확정처럼 이후 단계 데이터를 초기화하는 지점에서는
  `max_step_reached`도 그 시점 단계로 다시 낮춥니다.
- **검증**: 서버를 재시작한 새 세션에서 ①에서 사이드바로 바로 ⑥까지
  점프해 ②~⑤가 빈 서식/빈 상태로 에러 없이 렌더링되는 것, 그 상태로
  사이드바에 ②~⑤가 체크 없이 번호만 뜨는 것, 서버 로그에 예외가 없는
  것을 스크린샷으로 확인했습니다.

## 41.26 화면별 이전/다음 액션 버튼 통일 + SWIFT 조회 Enter 키 지원

여러 화면(②~⑤)의 이전/다음류 버튼 이름·색·위치가 화면마다 제각각이라
사용자가 화면별로 하나씩 통일을 요청했습니다.

- **텍스트 통일**: "확인 완료 → 거래정보 확정" → "다음", "← 다시
  업로드"/"← 사유코드 다시 확인"/"← 법령/필요서류 다시 보기" → "이전",
  "다음 → SWIFT 조회"/"다음 → 최종 처리 요약" → "다음", "🤖 AI 거래
  문맥 분석 시작" → "분석 시작"(이모지 제거).
- **배치**: "이전"은 카드 왼쪽 아래, "다음"은 카드 오른쪽 아래로
  통일했습니다. ② 화면은 `st.form`(우측 열) 안의 제출 버튼과 좌측 열의
  일반 버튼 높이를 맞춰야 해서, "이전" 버튼 컨테이너에 `margin-top:
  auto`를 줘 Streamlit 컬럼이 같은 행에서 높이가 늘어나는(stretch)
  특성을 이용해 우측 열 맨 아래와 정렬시켰습니다. ④/⑤ 화면은 `st.form`이
  없어 더 단순하게, 맨 아래에 좌우 2열을 새로 만들어 각각 배치했습니다.
  "다음"을 카드 오른쪽 끝까지 붙일 때 처음엔 `use_container_width=True`로
  버튼 자체를 늘렸는데 사용자가 "크기는 키우지 말고 아까 크기 그대로
  유지해"라고 해서, 대신 버튼을 감싼 element-container에
  `width:100%; display:flex; justify-content:flex-end` CSS를 걸어
  버튼 크기는 그대로 두고 컨테이너 안에서만 오른쪽으로 밀었습니다(처음엔
  `[data-testid="stButton"]`에 flex를 걸었다가, 그 wrapper 자체가 이미
  버튼 크기로 줄어들어 있어서 밀 공간이 없었던 걸 나중에 발견하고
  element-container 쪽에 다시 걸어 고침).
- **색상 통일**: 처음엔 "이전"/"다음"을 사이드바와 같은 진한 그린
  (`--brand-dark`)으로 통일했다가, 사용자가 "AI 거래 문맥 분석 시작
  버튼과 같은 색으로"라고 다시 요청해 일반 primary 버튼 색(`--brand`)으로
  바꿨습니다. 이 과정에서 `st.form_submit_button(type="primary")`이
  일반 `st.button(type="primary")`과 다른 `data-testid`
  (`stBaseButton-primaryFormSubmit`, 일반은 `stBaseButton-primary`)를
  쓴다는 걸 발견해서, 폼 제출 버튼이 기본 Streamlit 빨간색으로 나오던
  버그를 같이 고쳤습니다 - 전역 primary 버튼 규칙(`frontend/theme.py`)에
  두 testid를 모두 포함하도록 해서, 앞으로 폼 안에 넣는 primary 버튼도
  자동으로 올바른 색이 나오게 일반화했습니다.
- **SWIFT 조회 화면 - Enter로 "조회" 실행**: 사용자가 "SWIFT BIC 입력하고
  엔터치면 다음이 아니라 조회를 실행하게 해줘"라고 요청했습니다. SWIFT BIC
  입력창 + "조회" 버튼을 `st.form`으로 묶어, 입력창에서 Enter를 누르면
  그 폼 안의 유일한 `form_submit_button`("조회")이 제출되도록 했습니다
  ("이전"/"다음"은 폼 밖에 남겨둬서 Enter와 무관). 이 화면은 재조회 강제
  게이팅도 41.25 원칙에 맞춰 없애 "다음"이 항상 활성화되도록 같이
  바꿨습니다(재조회가 필요하면 캡션으로만 안내).
- **검증**: 실제로 SWIFT BIC(BOFAUS3N)를 입력하고 Enter를 눌러 "조회"가
  실행되고 "다음"으로는 넘어가지 않는 것, 이전/다음 버튼의 배경색이
  `rgb(0, 132, 133)`(`--brand`)로 동일한 것, 폼 제출 버튼 색 수정 전/후
  DOM의 `data-testid`와 computed background-color를 브라우저에서 직접
  확인했습니다.

## 41.27 ⑦ 처리 로그 신설 + "처리 완료" 미확정 데이터 버그 수정

사용자가 "지금 6번에서 아무것도 없는데 처리 완료 누르면 거래 처리가
완료 처리되었습니다 이렇게 나오는데 이거 수정해야 할것 같아. 그리고 7번
새로운 목차로 처리 로그 만들고 처리 완료된 정보 들어가도록 만들어줘"라고
요청했습니다.

- **버그**: `summary.py`의 "처리 완료" 클릭 핸들러가
  `st.session_state.db_transaction_id`가 없어도(= ②단계에서 거래정보를
  확정한 적이 없어 DB에 저장할 레코드 자체가 없어도) 무조건
  `st.success("거래 처리가 완료 처리되었습니다.")`를 띄우고 있었습니다
  - 실제로는 아무 DB 업데이트도 안 일어나는데 성공한 것처럼 보이는
    상태였습니다.
- **수정**: `db_transaction_id`가 없으면 "✅ 처리 완료" 버튼 자체를
  비활성화하고 "확정된 거래정보가 없어 처리를 완료할 수 없습니다.
  ②단계에서 거래정보를 먼저 확정하세요" 캡션을 띄웁니다. 클릭 시에도
  실제 DB 업데이트 성공 여부(`saved` 플래그)에 따라 성공/에러 메시지를
  분기합니다.
- **⑦ 처리 로그(`frontend/processing_log.py`, 신규 파일)**:
  `TransactionStatus.COMPLETED`인 `TransactionRequest` 행을 최신순으로
  조회해 표(처리일시/고객명/고객유형/거주자구분/통화/금액/수취인/
  수취은행/SWIFT BIC/사유코드/필요서류 체크현황)로 보여줍니다.
  `get_session()`은 `expire_on_commit=True`(기본값)이라 세션이 닫히면
  `row.customer` 같은 관계 접근이 끊기므로, 세션 블록 안에서 순수
  파이썬 dict로 전부 꺼내둔 뒤 `pandas.DataFrame`으로 `st.dataframe`에
  넘기는 방식을 썼습니다. `app.py`의 `STEPS`/`_STEP_RENDERERS`에 7번을
  추가하고, "처리 완료" 성공 시 `max_step_reached`도 7로 올려 사이드바
  ⑥에 완료 체크가 뜨도록 연결했습니다.
- **⑦은 마법사 순번이 아님**: 사용자가 "처리 로그는 다음 버튼으로
  이동할 수 있는게 아니니까 7. 숫자 빼도 될거 같아"라고 해서, 사이드바
  라벨에서 이 항목만 번호(`f"{num}. {label}"`)를 안 붙이고 `label`
  그대로 쓰도록 분기했습니다. "6. 최종 처리 요약"과 "처리 로그" 사이에도
  `st.divider()`를 넣어 마법사 흐름과 시각적으로 구분했습니다.
- **검증**: 빈 데이터 상태에서 "처리 완료"가 비활성화되고 안내 캡션이
  뜨는 것, ⑦ 처리 로그에 과거 테스트 중 실제로 완료 처리됐던 거래 1건이
  고객명/금액/SWIFT BIC/사유코드/필요서류(3/3 체크)까지 정확히 표시되는
  것을 스크린샷으로 확인했습니다. 이 로그의 완료 체크는 DB 전체 이력
  기준이라, 세션이 새로 시작되면(= `max_step_reached`가 초기화되면)
  사이드바 ⑥의 체크 표시는 이번 세션에서 완료한 적이 없으면 안 뜨는게
  맞다는 것도 확인했습니다(둘은 별개 개념: DB 이력 vs 이번 세션 진행도).

## 41.28 ② OCR 결과 화면 PDF 미리보기 지원

기존엔 원본 신청서가 PDF면 `_render_original_preview()`가 "PDF
미리보기는 지원하지 않습니다. 파일명으로 대조하세요"라는 안내만
띄웠습니다. 사용자가 "OCR 결과에서 pdf 미리보기 못 만들어?"라고
질문해서, Vision OCR(`services/ocr/vision_ocr.py`)이 이미 PDF 1페이지를
이미지로 변환할 때 쓰는 `pypdfium2`(PDFium 바이너리 동봉, 별도 시스템
패키지 불필요)를 그대로 재사용해 구현했습니다. `_render_pdf_preview()`를
새로 만들어 1페이지를 2.0배율로 렌더링한 뒤 `st.image`로 보여주고,
여러 페이지가 있으면 "1페이지만 표시합니다(Vision OCR 인식 범위와
동일)" 캡션을 덧붙입니다. 렌더링 실패(손상된 PDF 등)는 예외를 잡아
에러 메시지로 안내합니다.

- **검증**: `data/regulations/`의 실제 22페이지 PDF로 렌더링 함수를
  직접 호출해 1190×1684 이미지가 정상 생성되는 것을 확인했고, 실제
  브라우저에서도 신청서 PDF 업로드 후 미리보기가 뜨는 것을 확인했습니다.

## 41.29 UI 디테일 정리 - 입력창 배경, 안내 배너, 이모지 폰트 폴백

한 화면씩 짚어가며 나온 자잘한 UI 지적들을 모았습니다.

- **입력창이 비활성처럼 보임**: 사용자가 "OCR 인식 결과에서 입력 정보들이
  수정 가능한데 다 회색박스라서 비활성화된것처럼 보여"라고 지적했습니다.
  Streamlit 기본 입력창 배경(`#F0F2F6` 계열 회색)에 배경색 지정이 아예
  없어서 그대로 노출된 것이었는데, `stTextInput`/`stTextArea`/
  `stNumberInput`/`stSelectbox`에 `background: white`를 명시하고, 진짜
  `disabled=True`인 필드(거래 문맥 분석 화면의 원문 참고용 텍스트 등)만
  `:disabled` 규칙으로 다시 회색 처리해 구분했습니다.
- **안내 배너 폰트 크기가 반대로 느껴짐**: 상단 "이 화면의 AI 분석/검색
  결과는..." 배너(`.fx-notice`, 12px)가 "현재 OCR 모드: ..." 같은
  `st.info()` 박스(기본 16px)보다 작아서 사용자가 "글씨가 너무 작아 ...
  이 글씨랑 크기 서로 바꿔"라고 요청, 두 폰트 크기를 맞바꿨습니다
  (`.fx-notice`는 16px로, `st.info()` 박스는 12px로).
- **안내 배너 아이콘을 st.info()와 통일**: `.fx-notice`가 쓰던 밋밋한
  `ℹ` 유니코드 문자를, `st.info()`가 실제로 쓰는 아이콘과 통일해달라는
  요청("i에 동그라미 테두리 있는 이걸로 못바꾸나?")을 받아 DOM을
  확인해보니 Streamlit이 "Material Symbols Rounded"라는 아이콘 폰트의
  리거처(`info`라는 텍스트가 그 폰트에서 원형 정보 아이콘 글리프로
  그려짐)를 쓰고 있었습니다. Streamlit이 이 폰트를 전역으로 이미
  로드해두므로, `.fx-notice-icon` 클래스에 같은 폰트/텍스트만 지정해
  동일한 아이콘을 재사용했습니다.
- **이모지가 텍스트/깨진 글리프로 나옴**: "🤖 Ollama(...) 분석 결과" 같은
  헤딩의 이모지가 안 뜨는 문제를 사용자가 발견했습니다. DOM에는 실제
  이모지 문자가 정상적으로 들어있었지만(데이터 문제 아님), 하나체
  (Hana2)엔 이모지 글리프가 없고 폴백 체인에도 이모지 폰트가 없어서
  깨진 대체 글리프가 보인 것이었습니다. `body`에만 이모지 폴백 폰트를
  추가하는 걸로는 안 고쳐졌는데, Streamlit이 h1~h6 등에 `font-family:
  hana2, "Source Sans", sans-serif`를 상속이 아니라 요소마다 직접
  지정해버려서 - 직접 지정된 값은 상속보다 항상 우선하므로 `!important`를
  건 `body` 규칙조차 못 이겼습니다. 결국 전체 요소(`*`)에 이모지 폴백
  폰트(`Segoe UI Emoji`/`Apple Color Emoji`/`Noto Color Emoji`)를
  `!important`로 강제하고, 대신 Streamlit 아이콘 폰트를 쓰는 요소
  (`[data-testid="stIconMaterial"]`, `[data-testid="stAlertDynamicIcon"]`,
  `.fx-notice-icon`)만 "Material Symbols Rounded"로 다시 지정해 예외
  처리했습니다. 사용자가 실제 화면에서 데이터를 입력하며 테스트 중이라,
  서버를 재시작하기 전에 브라우저에 같은 CSS를 임시 주입해 이모지가
  제대로 나오고 기존 아이콘(사이드바 화살표 등)이 안 깨지는 것부터
  확인한 뒤, "일단 지금 재시작해"라는 확인을 받고 나서야 서버를
  재시작해 정식 반영했습니다.
- **검증**: 각 항목을 브라우저 DOM(`getComputedStyle`,
  `document.styleSheets` 순회)으로 직접 확인했고, 최종적으로는 서버를
  재시작한 새 세션에서 아이콘/이모지가 모두 정상 렌더링되는 것과 서버
  로그에 에러가 없는 것을 확인했습니다.

## 41.30 README - "실행" 단계 누락 보완

사용자가 "readme 봤을때 원클릭 셋업까지는 있는데 실행하는 방법은
없는것 같은데?"라고 지적했습니다. 확인해보니 `setup.ps1`/`setup.sh`
원클릭 셋업 섹션 바로 다음엔 각 스크립트 옵션 설명만 있고, 정작
`streamlit run app.py` 실행 명령은 훨씬 아래 "수동 설치" 섹션의
코드블록 안에만 있어서, 원클릭 셋업만 따라간 사람은 못 보고 지나치기
쉬운 구조였습니다. "원클릭 셋업" 바로 다음에 "실행" 섹션을 새로 넣어
`fixar\Scripts\streamlit.exe run app.py`(Windows)/`fixar/bin/streamlit
run app.py`(macOS/Linux)와 `localhost:8501` 접속 안내를 배치하고,
"수동 설치" 섹션 끝의 중복되던 안내 문구는 "위 실행 섹션과 동일"로
정리했습니다.

## 41.31 ② OCR 결과 화면 - 고객유형/거주자구분/수취인유형 기본값을 빈칸으로 변경 + 필수 선택 검증

세 개의 `st.selectbox`(고객유형/거주자구분/수취인유형)가 OCR 인식값이
없어도 첫 번째 옵션(예: `INDIVIDUAL`)이 기본 선택된 상태로 떠서, 은행원이
아무것도 고르지 않아도 실수로 값이 채워진 채 "다음"을 누를 수 있는
문제가 있었습니다. 사용자가 "고객유형 거주자구분 수취인유형은 빈칸을
디폴트로 해줘 은행원이 선택하게"라고 요청했고, 처음엔 셀렉트박스
placeholder로 "선택하세요"를 넣었으나 "선택하세요가 아니라 그냥 - 로
표시해"라는 후속 요청을 받아 빈 문자열 옵션 + `format_func`으로 `-`만
보이게 바꿨습니다. `_CUSTOMER_TYPES`/`_RESIDENCE_STATUSES`/
`_RECIPIENT_TYPES` 앞에 빈 문자열을 추가하고 `index=` 강제 지정을
제거해 항상 빈 선택으로 시작하게 했습니다. 이어서 "고객유형과
거주자구분은 반드시 선택해야 합니다. 수취인 유형은 왜 빼먹었어?"라는
지적을 받아, 처음엔 두 필드만 검증하던 걸 수취인 유형까지 포함한 3개
필드 전부로 넓히고 `st.form_submit_button` 클릭 시 셋 중 하나라도
비어있으면 `st.error`로 막고 저장하지 않도록 했습니다.

## 41.32 ⑦ 처리 로그 - 검색 기능 + OCR 수정 내역 추적

"처리로그 검색 기능 넣어줘" 요청으로 처리일시/고객명/고객유형/거주자구분/
통화/금액/수취인/수취은행/SWIFT BIC/사유코드 전체 컬럼을 훑는 단일
검색창을 추가했습니다. 처음 구현에서 "처리일시랑 필요서류는 검색 안되는거
같은데?"라는 지적을 받아 확인해보니 `_SEARCHABLE_COLUMNS`가 표시 컬럼과
분리되어 있어 일부만 포함하고 있었고, 필요서류는 원래 "3/3체크" 같은
문자열이라 검색 자체는 됐지만 표시가 어색했습니다("3/3체크 말고 3/3
이렇게 나오게 수정해"로 수정). 이후 "OCR 결과가 완벽하지 않잖아? 그래서
은행원이 수정해서 입력하면 수정 사항을 로그에 남길 수 있나?"라는 질문에
답하며 OCR 인식값과 은행원 확정값을 필드별로 비교하는
`_diff_ocr_corrections()`를 `frontend/ocr_result.py`에 추가하고,
`TransactionRequest`에 `ocr_corrections`(JSON) 컬럼을 새로 만들어
저장했습니다. 기존 `create_all` 기반 마이그레이션은 이미 있는 테이블에
컬럼을 추가해주지 않으므로, `database/connection.py`에
`_ensure_new_columns()`를 만들어 `ALTER TABLE ... ADD COLUMN`으로
보강했습니다. 처리 로그 화면에는 "OCR 수정" 컬럼(수정 개수)과 "OCR 수정
내역 상세" 섹션(거래 선택 → 필드별 OCR 인식값/확정값 대조표)을 추가했고,
"OCR 수정 갯수도 검색할 수 있게 해줘" 요청에 맞춰 검색 대상 컬럼에도
포함했습니다. 컬럼을 늘리다 보니 폭이 좁아져 한때 고객유형+거주자구분,
통화+금액을 합친 컬럼으로 시도했지만 "컬럼 다시 합치지 말고 돌려
필요서류 컬럼은 없애고"라는 피드백을 받아 되돌리고 필요서류 컬럼만
제거했습니다.

## 41.33 SWIFT 마스터 - 외부 데이터 109,008건 제거, 수기 큐레이션 29건만 유지

사용자가 "SWIFT 데이터에 대해 다시 설명해줘"라고 물어 기존 구성(수기
큐레이션 29건 + 공개 저장소
[`maranemil/swift-bic-codes-allinone`](https://github.com/maranemil/swift-bic-codes-allinone)에서
가져온 109,008건)을 설명했는데, 그 외부 데이터가 은행명/국가만 있고
`is_sanctioned`가 전부 `false`라 실제 제재 대상이어도 "정상"으로
조회된다는 문제(예: 러시아 은행만 2,691건이 섞여 있는데도 전부 정상
표시)를 짚자 "수기 큐레이션 말고 다른 데이터 다 지워"라고 결정했습니다.
`data/swift_sanction_master.csv`를 109,038줄(헤더+109,037행)에서
30줄(헤더+29행)로 잘라내고, `pytest`(41개)로 회귀가 없는지 확인했습니다.
출처 라이선스가 불명확하고 2019년 스냅샷이라 오래된 점도 제거 이유였습니다.

## 41.34 ⑧ 고객 데이터 신설 - 당행 등록 고객 마스터 100건 (재설계 포함)

"근데 처음 프로젝트 md에 고객 데이터 얘기하지 않았나?"라는 질문에
답하다가 "처리 로그 밑에 고객 데이터 만들어"라는 요청을 받아, 처음엔
신청서로 매번 생기는 `customer_profile`(거래 이력)을 모아 보여주는
화면으로 잘못 만들었습니다. 사용자가 바로 정정했습니다: "니가 프롬프트를
잘못 이해한것 같아 여기서 외화송금신청한 고객을 등록하는게 아니지 내가
원한건 당행에 등록돼있는 고객들의 데이터를 생성해서 schemas/customer.py에
등록해놓고 중간에 조회과정에서 고객의 신용도나 송금 한도 이런걸
판단하려는데 쓰려했어 결론적으로 여기 등록돼있는 데이터는 지우고 임의의
고객데이터 100개 만들어줘". 즉 신청서 OCR 결과가 아니라 **은행이 사전에
보유한 고정 고객 마스터**가 필요했던 것이라, 다음을 새로 만드는 재설계를
했습니다: `RegisteredCustomerMaster` ORM(신용등급/연간한도/누계액/
지정거래은행/지정목적/체납여부/등록일), `RegisteredCustomer` Pydantic
스키마, `data/generate_registered_customers.py`(seed 20260101 고정 난수로
100건 재현 가능하게 생성, 데모 식별번호 1건 고정 포함),
`database/seed.py`의 `seed_registered_customers()`, `⑧ 고객 데이터`
화면(`frontend/customer_data.py`, 식별번호 마스킹 표시). 기존
`services/system_lookup/mock_service.py`(해시 기반 Mock)는 이 마스터를
먼저 조회하고 없을 때만(미등록/신규 고객) 해시 Mock으로 폴백하도록
바꿨습니다. 스키마에 새 필드를 추가하는 동안 세션에 이미 저장돼 있던 옛
`SystemLookupData` 객체가 새 필드를 못 찾아 `AttributeError`가 실제
브라우저 세션에서 3번 발생했는데, `getattr(obj, "field", default)`
방어 패턴으로 우선 막고 "지금 재시작"이라는 확인을 받은 뒤 서버를
재시작해 정식 반영했습니다. 회사명 생성 로직(어간×종류 조합)에서 30건
추첨 중에도 생일 문제로 "(주)태평양실업"이 두 번 나온 걸 사용자가
발견해("고객 데이터에 (주)태평양실업 왜 두개야?"), `used_names` 집합으로
중복 재추첨하도록 고쳤습니다.

## 41.35 기존지정목적 3자리 코드 체계 + 연간한도 통일 + ④ 화면 고객 조회 정보

"고객 데이터의 연간한도는 다 100000으로 통일하고 당해누적은
연간누계액으로 바꿔줘 기존지정목적은 대분류 중분류 소분류가 있는데 니가
임의로 3자리 코드로 100명 각각 겹치지 않게 데이터 만들어줘"라는 요청에
따라 연간한도를 전원 $100,000으로 고정하고, "대분류(1자리)+중분류
(1자리)+소분류(1자리)" 체계(대분류 4개 × 중분류 5개 × 소분류 5개 =
정확히 100가지)를 설계해 100명에게 서로 겹치지 않는 코드를 하나씩
셔플·배정했습니다("식별번호 소팅할때 주민번호랑 사업자번호 따로따로
필터 걸어서 볼 수 있나?"라는 요청으로 고객유형 필터 라디오 버튼도 함께
추가). 이 값들이 실제 규정 수치가 아니라는 점("여기서 연간 한도는
임의로 정한거지?", "기존지정목적은 무슨 말이지?")을 사용자가 확인차
물어 그대로 인정하고 설명했습니다. 이어서 "거래 문맥 분석에서 법령
필요서류로 넘어올때 해당하는 고객의 데이터 칼럼 가져와서 보여줄 수
있어?"라는 요청으로 ③단계에서 이미 조회해둔 `session_state.system_lookup`을
④ 법령·필요서류 화면에서도 재사용해 신용등급/한도/사용률/지정목적 등을
보여주는 카드를 추가했습니다. "연간 송금 한도(USD)은 연간한도(USD)
당해연도 누적 미제출 송금액(USD)은 연간누계액(USD)로 바꾸라니까"라는
재요청으로 두 화면의 라벨을 통일했습니다.

## 41.36 ⑦/⑧ 화면 UI 정리 - 검색창 레이아웃, 카드 폭, 사이드바 번호

SWIFT 조회 화면의 "입력창이 남는 공간을 채우고 조회 버튼은 같은 크기로
우측 끝에 고정"되는 레이아웃을 사용자가 마음에 들어해서("5번에서
수취은행 SWIFT BIC 박스에서 조회를 입력창 밑 말고 오른쪽으로 옮겨" →
"조회 버튼 크기는 이전 다음이랑 똑같이 만들어" → "조회가 오른쪽 제일
끝에 붙게" → "입력 사이즈는 왜 그대로야 조회까지 늘어나야지"의 시행착오
끝에 완성), "같은 방식으로 처리 로그랑 고객 데이터에서도 입력창 오른쪽에
같은 크기로 조회 버튼 만들어"로 확장했습니다. 두 화면이 검색 박스를 하나씩만
쓰므로 `fx_search_row`/`fx_search_btn` 컨테이너 키를 공유해도 안전하다고
보고 재사용했습니다. 이어 "카드 좌우 폭 좀 넓혀줘 지금 처리 로그랑 고객
데이터 보기가 힘들어 창을 줄였을때는 말줄임표로 처리하고 가급적이면
잘리지 않고 다 나올 정도로 폭 넓혀"라는 요청에 답하며, 원인이 두
가지였음을 발견했습니다 - 전역 카드 폭 상한(1200px)과 `column_config`가
모든 컬럼을 `width="small"`로 강제하던 것. `theme.widen_main_container()`
(호출한 화면에서만 1600px로 넓히는 페이지 스코프 CSS)를 새로 만들고,
좁은 폭 강제 설정을 제거해 Streamlit이 컬럼 폭을 자동으로 맞추게 했습니다.
마지막으로 "처리로그랑 고객데이터에서는 7번 8번 번호 없애 워크플로우에
들어가는게 아니까"라는 요청으로, 사이드바 렌더링에 `_UTILITY_STEPS`
집합을 도입해 이 두 화면(과 이후 추가된 사유코드/지정목적코드)은
번호 없이 구분선 아래에 표시하도록 바꿨습니다.

## 41.37 ⑨ 사유코드 / ⑩ 지정목적코드 조회 화면 신설

"고객 데이터 아래에 사유코드 그 아래에는 지정목적코드 이렇게 만들어서
각각 사유코드와 지정목적코드 검색할 수 있게 해줘"라는 요청으로 ⑦/⑧과
같은 성격의 조회 전용 화면 두 개를 추가했습니다. ⑨ 사유코드
(`frontend/reason_codes.py`)는 DB의 `ReasonCode` 테이블(100건)을 그대로
조회·검색합니다. ⑩ 지정목적코드는 41.35에서 만든 3자리 코드 체계가
`data/generate_registered_customers.py`(앱 실행 시 임포트되지 않는
1회성 스크립트) 안에만 정의돼 있어 화면에서 재사용할 수 없었으므로,
같은 정의를 `services/designated_purpose_codes.py`로 옮겨(원본 생성
스크립트는 그대로 두고 값만 복제 - 두 파일이 갈라지지 않도록 값이
바뀌면 함께 고쳐야 한다는 주석을 남김) `frontend/purpose_codes.py`가
이를 임포트해 100가지 조합 전체를 보여주도록 만들었습니다. 두 값
집합이 정확히 일치하는지 파이썬으로 직접 대조해(`csv_codes ==
module_codes`) 확인했습니다. `app.py`의 `STEPS`/`_STEP_RENDERERS`와
`frontend/theme.py`의 `_STEP_HEADERS`/`_UTILITY_STEPS`에 9/10번을
추가했는데, Streamlit 파일워처가 여러 파일이 한꺼번에 바뀐 상황에서
`theme.py` 변경만 못 잡아 사이드바에 번호가 계속 남아있는 문제가
있었고, 서버를 재시작해 모든 모듈을 새로 임포트하게 해서 해결했습니다.

## 41.38 거래외국환은행 지정을 불리언에서 3단계(당행/타행/미지정)로 재설계

41.35에서 ④ 법령·필요서류 화면에 다시 넣은 "거래외국환은행 지정"
항목은 원래 "예/아니오" 불리언이었습니다. 사용자가 "지정거래은행도
수정해야하는데 당행 지정거래은행이면 예 인데 타행이 지정거래은행이거나
아예 지정거래은행이 없는 경우는 어떻게 분류해야 할까"라고 질문했고,
기존 `is_bank_designated` 불리언이 "타행 지정"과 "미지정"을 구분하지
못한다는 걸 짚었습니다. 실제
외국환거래규정의 "거래외국환은행 지정제도"를 반영해 `designated_
bank_status`("SELF"=당행/"OTHER"=타행/"NONE"=미지정) 3단계로
재설계하자고 제안했고, 사용자가 비율(당행 70%/타행 20%/미지정 10%)과
데모 고정 고객 처리(당행 지정 유지) 둘 다 추천안을 선택했습니다.
`RegisteredCustomerMaster`/`SystemLookupData`(ORM) 양쪽에 새 컬럼을
추가하되, 레거시 `is_bank_designated`(NOT NULL, DB 레벨 기본값 없음)
컬럼은 삭제하지 않고 저장 시점에 자동 계산해 호환을 유지했습니다.
`database/connection.py`의 `_ensure_new_columns()`에 두 테이블용
`ALTER TABLE`+백필 UPDATE를 추가하고, `data/generate_registered_
customers.py`를 다시 실행해 CSV를 재생성한 뒤(실제 분포 70/23/7),
`registered_customer_master` 테이블을 초기화 후 재시딩했습니다. 미지정
고객은 지정 자체가 없으므로 기존지정목적 코드도 함께 비웠습니다.
`schemas/`, `services/system_lookup/mock_service.py`,
`frontend/ocr_result.py`, `frontend/customer_data.py`, ④ 법령·필요서류
화면까지 전 구간을 3단계 값으로 맞추고, 타행 지정 고객을 조회하면
"지정거래외국환은행 변경 절차가 필요할 수 있습니다" 경고가 뜨도록
했습니다. 브라우저로 직접 재현하기 번거로운 케이스(타행 지정 고객
조회)는 Streamlit `AppTest`로 `system_lookup`을 미리 채운 세션을
헤드리스로 실행해 경고 문구와 메트릭 값을 직접 검증했습니다.

## 41.39 ③/④ 시스템 조회 정보 UI 정리 + 자잘한 라벨 수정

"접었다 펼 수 있는 기능은 고객 시스템 조회에서는 필요 없어 그냥
보여주고 4번의 관련 법령은 기니까 접었다 펴는 기능 넣고 기본은
접은상태 누르면 상세 내용 볼 수 있도록 수정해"라는 요청으로 ③/④의
"시스템 조회 정보" `st.expander`를 일반 헤더+컨테이너로 바꿔 항상
펼쳐진 채로 보이게 하고, ④의 "관련 법령" 목록은 반대로 항목별
`st.expander(expanded=False)`로 감싸 기본은 접힌 채 법령명만 보이다가
클릭하면 본문이 펼쳐지도록 했습니다. 이어서 "3번에서는 시스템 조회
정보 (참고) · 🧪 Mock 데이터 이거 없애자 4번에 있으니까"라는 요청으로
③의 시스템 조회 블록 자체를 완전히 삭제했습니다(같은 정보가 ④에도
있어 중복). ④ 카드는 "🔎 시스템 조회 정보"로 이름을 줄이고 Mock
안내 문구도 이모지 없이 다시 쓰고, 메트릭 배치를 "연간한도(USD)·
연간누계액(USD)·잔여한도액(USD)" / "기존지정목적·신용등급·체납여부"
2행 구성으로 재정렬했습니다(41.38에서 지정거래은행 항목을 다시 추가).
그 외 "사유코드 확인 -> 다음" 버튼의 이모지·화살표를 없애 "사유코드
확인"으로 정리하고, ③ 화면의 "송금금액" 메트릭이 값이 없을 때 다른
두 메트릭(수취국가/수취은행)과 달리 빈칸으로 보이던 걸 "-"로 통일했습니다.
- **검증**: 매 변경마다 `pytest`(41개) 전체 통과를 확인했고, Streamlit
  파일워처가 파일 변경을 놓치는 경우가 반복적으로 발생해 여러 차례
  서버를 재시작해 최신 코드가 실제로 반영된 상태에서 브라우저로
  최종 확인했습니다.

## 41.40 타행 지정 고객의 "기존지정목적"이 채워져 있던 데이터 모순 수정

41.38에서 "미지정(NONE) 고객은 기존지정목적 코드도 함께 비웠다"고
기록했지만, 실제로는 **타행(OTHER) 지정 고객**에게도 목적코드가
그대로 채워져 있었습니다. 사용자가 "지정거래은행 없음/당행/타행 세
가지는 이해했는데, 기존지정목적이 타행인 경우엔 당행이 알 수 없는 것
아니냐"고 정확히 짚었습니다 - 이 마스터 자체가 "당행이 보유한" 고객
정보를 흉내낸 것이므로, 고객이 타행을 지정거래은행으로 등록했다면 그
지정목적은 타행에 등록된 정보고 당행 시스템(이 프로젝트가 흉내내는
Mock)이 알 도리가 없습니다. `OTHER`인데 `designated_purpose`에 값이
있으면 "당행이 타행 내부 정보를 갖고 있다"는 앞뒤가 안 맞는 상태였던
것입니다.

- `data/generate_registered_customers.py`의 `_purpose_code_for()`가
  `bank_status != "NONE"`(SELF·OTHER 둘 다 배정)이던 조건을
  `bank_status == "SELF"`(SELF만 배정)로 수정하고, 관련 docstring/주석
  (모듈 상단 설명, 코드 배정 루프 주석)도 같이 고쳤습니다.
- `services/system_lookup/mock_service.py`의 미등록 고객용 해시 기반
  폴백 경로에도 **같은 버그가 독립적으로 존재**했습니다
  (`designated_purpose = ... if bank_status != "NONE" else None`) -
  등록 고객 마스터에 없는 고객을 조회할 때 쓰이는 별도 로직이라
  CSV 재생성만으로는 안 고쳐지는 부분이었습니다. 같은 방식으로
  `bank_status == "SELF"` 조건으로 수정했습니다.
- `python -m data.generate_registered_customers`로 CSV를
  재생성한 뒤, 재생성된 CSV를 직접 집계해 SELF 70건 전부
  `designated_purpose` 있음 / OTHER 23건·NONE 7건 전부 없음을
  확인했습니다. `python -m database.seed --reset`으로 재시딩했습니다.
- README "5. 프로젝트 구조" 근처의 관련 설명 문단도 "미지정 고객만
  비운다"에서 "SELF인 경우에만 채우고 OTHER·NONE은 비운다"로
  고쳤습니다.
- **검증**: `pytest` 41건 통과. 고객 데이터 화면에서 검색창에 "타행"을
  입력해 23건으로 정확히 필터링되는 것을 확인했고, 그 23건 전부
  "기존지정목적" 컬럼이 "-"로 표시되는 것을 스크린샷으로 확인했습니다
  (서버 에러 없음).

## 41.41 ④ 법령·필요서류 화면에 지급 절차 판정(제4-2/4-3조, 제10-9/10-11조) 추가

사용자가 다음 규칙을 제시하며 "이 조항들 모두 법령 PDF에 있을 거야 RAG로
분석해서 판단하는 거 4번에 넣을 수 있어?"라고 요청했습니다: 지정거래은행이
당행/타행/미지정인 각 경우에 증빙·무증빙 송금이 어떻게 다른지(증빙은 연간
누계 미포함, 무증빙은 포함), 타행·미지정은 무증빙이 건당 5천불 이하만
가능하고 그 이상 보내려면 지정은행 변경/신규 신청이 필요하다는 것, 그리고
모든 경우 공통으로 연간 누계가 10만불을 넘으면 서류가 다시 필요하다는 것
(예: 누계 7만불 + 3.5만불 송금 = 10.5만불 초과 → 서류 필요).

**법령 원문 확인**: `pypdf`로 `data/regulations/`의 두 PDF를 텍스트로
추출해 직접 검색한 결과, 이 규칙들은 실제로 존재했습니다 - 다만 사용자가
설명한 "당행/타행/미지정" 3분기 형태로 한 조문에 몰려 있는 게 아니라
여러 조문의 조합이었습니다:
- **제4-2조(지급등의 절차)** ①: 원칙적으로 증빙서류 제출. ⑤: 거래외국환은행을
  지정한 경우 그 은행을 통해서만 지급.
- **제4-3조(거주자의 지급등 절차 예외)** ①1호: 신고 불요 거래로 연간
  누계금액 미화 10만불 이내면 무증빙 가능(외국환업무취급기관 전체 합산
  기준). ①2호: 누계 초과 시 가목(건당 미화 5천불 이내) 또는 나목(서류로
  내용 확인 가능)이면 예외.
- **제10-9조(사후관리절차 등)** ①: 거래외국환은행을 지정한 경우 그
  지정은행이 사후관리를 한다(당행이 지정은행이 아니면 당행은 사후관리를
  할 수 없다는 근거).
- **제10-11조(거래외국환은행 지정 등)** ①: 해외직접투자·해외부동산취득·
  증권발행·자금차입 등 열거된 항목만 지정이 법적으로 필요하다(사용자가
  말한 "5천불 넘으면 무조건 지정 필요"가 아니라, 특정 거래 유형에 한함).
  ⑤: 지정 변경은 현재 지정 은행을 경유해 새 은행의 확인을 받아야 한다
  ("변경 절차"의 정확한 근거).

즉 사용자가 설명한 규칙은 은행 창구에서 통용되는 실무 SOP를 여러 조문에서
종합한 것으로 판단되며, "왜 그런지"까지 조문으로 재구성하면: 사후관리가
필요한(제10-11조 열거) 거래는 지정된 은행만 처리할 수 있고(제10-9조),
지정이 안 된 은행은 고객의 다른 은행 거래까지 합산한 연간 누계(제4-3조
①1호 본문)를 확인할 방법이 없어 무증빙 한도를 통째로 못 주고 건당
5천불(①2호가목)만 준다 - 라는 논리로 사용자의 세 갈래 규칙과 정확히
맞아떨어졌습니다.

**설계 결정 - 사전 확인 질문**: 구현 전에 두 가지를 사용자에게 확인했습니다
(사유코드 마스터 100개가 전부 `required_documents`를 갖고 있어 "증빙/
무증빙"을 사유코드만으로 구분할 수 없었고, "사후관리 필요"를 판단할 필드도
따로 없었기 때문):
1. 증빙/무증빙 구분 - 은행원이 ④화면에서 직접 선택(라디오) vs 사유코드에
   새 플래그 추가 → **은행원 직접 선택**을 선택(실제 은행 창구에서도
   그 자리에서 결정하는 것이 제4-2/4-3조의 실제 구조와 일치).
2. 사후관리 필요 판단 기준 - `category == "자본거래"`로 근사 vs 사유코드
   100개 전체를 제10-11조 목록과 개별 대조 → **근사**를 선택(정확하지만
   느린 개별 대조 대신, 근사임을 화면에 명시하고 은행원 재확인을
   전제로 함).

**구현**

- `services/payment_procedure.py` 신설: `evaluate_payment_procedure()`
  결정론적 함수 + `PaymentProcedureResult` dataclass. 판정 순서:
  (1) 사후관리 필요 + 지정은행 ≠ SELF면 증빙 여부 무관하게 처리 불가(변경/
  신규 지정 안내) → (2) 증빙이면 항상 가능, 누계 미반영 → (3) 무증빙이면
  금액 미확인 시 판정 불가, 지정은행 ≠ SELF면서 건당 5천불 초과 시 불가,
  (반영 후 누계) > 10만불이면 불가, 그 외엔 가능(누계 반영). 금액 상수
  (`ANNUAL_CUMULATIVE_LIMIT_USD=100000`, `PER_TRANSACTION_LIMIT_USD=5000`)와
  각 분기의 조문 인용을 모듈 docstring/주석에 명시했습니다. 사유코드
  Vector Search의 "임의의 숫자 가중치를 조합한 점수식이 아니다"(섹션 12)
  원칙과 같은 이유로, 이 판정도 LLM/RAG의 산술이 아니라 결정론적 코드로
  구현했습니다.
- `frontend/regulation.py`: "시스템 조회 정보" 카드 뒤에 "📐 지급 절차
  판정" 카드를 새로 추가. 증빙/무증빙 라디오(`payment_procedure_is_
  documented` 세션 키), 사유코드 category로 근사한 `is_capital`, `system_
  lookup`의 지정은행 상태·누계액, `transaction_request`의 송금액을 모아
  `evaluate_payment_procedure()`를 호출하고 성공/경고 배너 + 근거 조문
  캡션으로 표시. 송금 통화가 USD/달러가 아니면 "환전 없이 USD로 간주"
  안내를 추가로 띄웁니다(이 프로젝트에 환전 기능이 없어서).
- 근거 조문을 실제로 확인할 수 있도록, 기존 "관련 법령"(사유코드
  `regulation_tags` 기준 필터 검색)과는 별개로 이 절차 전용 고정
  검색어("지급등의 절차 예외 증빙서류 연간 누계금액 미화 10만불 5천불
  거래외국환은행 지정 사후관리")로 `RagRetriever.search()`를 한 번 더
  호출해 "📖 관련 조문 원문 확인" 펼침 메뉴에 표시합니다. 결과는
  `st.session_state.payment_procedure_citations`에 캐싱(쿼리가 고정이라
  세션당 한 번만 검색). `app.py`의 `_init_state()`에 이 키를 추가했습니다.
- `tests/test_payment_procedure.py` 신설(12건): SELF/OTHER/NONE ×
  증빙/무증빙 × 금액/누계 조합, 사용자가 직접 든 예시(누계 7만+3.5만=
  10.5만 → 서류 필요), 건당 5천불 이내라도 누계가 10만불을 넘으면
  여전히 막힌다는 공통 규칙까지 전부 검증.

**검증**

- `pytest tests/ -q` 53건 전체 통과.
- 브라우저 파일 업로드 위젯은 이 자동화 환경에서 직접 조작할 수 없어
  (OS 파일 선택 대화상자 필요), 41.38에서 이미 쓴 것과 같은 방식으로
  Streamlit `AppTest`를 헤드리스로 실행해 5가지 시나리오(사용자 예시
  그대로 포함)를 직접 검증했습니다 - 전부 예외 없이 기대한 성공/경고
  문구가 정확히 렌더링됐습니다.
- `RAG_MODE=pdf`인 실제 환경에서 `payment_procedure_citations` 검색이
  실제 PDF에서 제4-3조 본문("연간 누계금액이 미화 10만불", "건당 미화
  5천불", "제4-3조제1항제...")을 정확히 찾아오는 것을 직접 확인했습니다
  (청커가 인접 조문 경계에서 article 라벨을 살짝 잘못 붙이는 경우는
  있었지만 - 예: 본문은 제4-3조인데 라벨이 "제7-2조"로 나옴 - 내용
  자체는 정확했음, 별도 이슈로 남겨둠).

사용자가 이어서 "라디오로 증빙/무증빙 선택한다는 게 무슨 말이냐"고 물어봐서
설명하는 과정에서, 왼쪽 "필요서류" 체크리스트와 이 라디오가 서로 연동돼
있지 않다는 걸 스스로 발견했습니다 - "무증빙"을 선택해도(제4-3조 예외라
애초에 증빙서류가 필요 없는 거래) 사유코드의 필요서류 체크리스트를 여전히
전부 체크해야 "다음" 버튼이 풀리는 모순이 있었습니다. 사용자에게 "무증빙이면
체크 생략 가능하게 할지, 아니면 그대로 독립적으로 둘지" 확인했고, **생략
가능하게**를 선택했습니다.

- `frontend/regulation.py`: `is_documented`를 함수 상단에서 `True`로
  초기화해두고(사유코드가 없거나 지급 절차 판정 섹션이 아직 없을 때의
  안전한 기본값), 지급 절차 판정 라디오에서 실제 값으로 덮어쓰도록
  했습니다. "다음" 버튼 비활성화 조건을 `not all_checked`에서
  `require_doc_check and not all_checked`로 바꿨습니다(`require_doc_
  check = reason_code is not None and is_documented`) - 무증빙을
  선택하면 체크 여부와 무관하게 다음으로 진행할 수 있습니다.
- 무증빙 선택 시 필요서류 체크리스트 위에 "참고용이며 전부 체크하지
  않아도 다음 단계로 진행할 수 있습니다" 안내 캡션을 추가했고, 기존
  "실제 제출된 서류를 은행원이 직접 확인한 후 체크하세요" 캡션은
  증빙일 때만 뜨도록 조건을 추가했습니다.
- **검증**: 같은 사유코드(필요서류 2건, 둘 다 미체크)로 `AppTest`를
  두 번 실행해 - 증빙 선택 시 "다음" 버튼 `disabled=True`, 무증빙 선택
  시 `disabled=False`인 것을 직접 확인했습니다. `pytest tests/ -q`
  53건 재통과했습니다.
