"""사유코드 Vector Search 테스트 (섹션 37 - 사유코드).

임의의 숫자 가중치 점수식을 쓰지 않는다는 원칙(섹션 12)에 따라, 여기서는
Embedding 유사도 기반 Top-K 검색이 그럴듯한 후보를 반환하는지만 검증한다.
"""

from __future__ import annotations

from services.reason_code import mapper as mapper_module
from services.reason_code.mapper import ReasonCodeMapper, build_required_documents_result
from services import embedding_client as embedding_client_module


def test_clear_purpose_returns_matching_top_candidate():
    """명확한 거래 목적: 해외부동산 취득 문맥이 부동산 관련 사유코드를 1순위로 반환한다."""

    mapper = ReasonCodeMapper()
    candidates = mapper.search("해외 주택 구매 목적으로 계약금 송금하려고 함", top_k=5)

    assert candidates
    assert "부동산" in candidates[0].reason_code.name or "REAL_ESTATE" in candidates[0].reason_code.regulation_tags


def test_similar_purpose_matches_study_abroad_category():
    """유사 거래 목적: 표현이 달라도(등록금/학비) 유학 관련 사유코드가 후보에 포함된다."""

    mapper = ReasonCodeMapper()
    candidates = mapper.search("미국 대학교 등록금 납부 목적의 송금", top_k=5)

    codes_and_names = [(c.reason_code.code, c.reason_code.name) for c in candidates]
    assert any("유학" in name or "학비" in name for _, name in codes_and_names)


def test_multiple_candidates_are_distinct():
    """복수 후보: Top-K 검색은 서로 다른 사유코드를 여러 건 반환한다."""

    mapper = ReasonCodeMapper()
    candidates = mapper.search("수입 물품대금 결제", top_k=5)

    assert len(candidates) >= 2
    codes = [c.reason_code.code for c in candidates]
    assert len(set(codes)) == len(codes)  # 중복 없음
    for c in candidates:
        assert 0.0 <= c.score <= 1.0


def test_no_match_when_reason_code_table_is_empty(monkeypatch, tmp_path):
    """매칭 결과 없음: 사유코드가 하나도 없으면 검색 결과도 빈 리스트다."""

    class _FakeResult:
        def scalars(self):
            return self

        def all(self):
            return []

    class _FakeSession:
        def execute(self, *_args, **_kwargs):
            return _FakeResult()

    class _FakeSessionCtx:
        def __enter__(self):
            return _FakeSession()

        def __exit__(self, *_exc):
            return False

    import config.settings as config_settings

    fake_settings = config_settings.Settings(chroma_persist_dir=str(tmp_path / "chroma_empty_test"))

    monkeypatch.setattr(mapper_module, "get_session", lambda: _FakeSessionCtx())
    monkeypatch.setattr(mapper_module, "get_settings", lambda: fake_settings)
    monkeypatch.setattr(embedding_client_module, "get_settings", lambda: fake_settings)

    mapper = ReasonCodeMapper()
    count = mapper.build_index(force=True)

    assert count == 0
    assert mapper.search("아무 의미 없는 질의") == []


def test_required_documents_result_from_reason_code():
    mapper = ReasonCodeMapper()
    candidates = mapper.search("해외 주택 구매 목적으로 계약금 송금하려고 함", top_k=1)
    result = build_required_documents_result(candidates[0].reason_code)

    assert result.items
    assert all(item.checked is False for item in result.items)


def test_required_documents_are_extracted_from_rag_core_article():
    """RAG 핵심 조문에서 신고서 + 번호 목록을 체크리스트로 변환한다."""

    from schemas.analysis import RegulationMatch
    from schemas.reason_code import ReasonCode
    from services.reason_code.mapper import build_required_documents_result

    reason_code = ReasonCode(
        code="FX-0054",
        name="해외직접투자(법인설립)",
        category="자본거래",
        description="해외직접투자 관련 거래",
        keywords=["해외직접투자", "법인설립"],
        required_documents=["CSV 테스트 서류"],
        regulation_tags=["FDI"],
    )
    match = RegulationMatch(
        law_name="외국환거래규정",
        article="제9-5조",
        file_name="regulation.pdf",
        content=(
            "제9-5조(해외직접투자의 신고 등) ③ 해외직접투자를 하고자 하는 자는 "
            "별지 제9-1호 서식의 해외직접투자신고서(보고서)에 다음 각 호의 서류를 "
            "첨부하여 외국환은행의 장에게 제출하여야 한다.\n"
            "1. 사업계획서(자금조달 및 운용계획 포함)\n"
            "2. 조세체납이 없음을 입증하는 서류"
        ),
        score=0.7,
    )

    result = build_required_documents_result(reason_code, [match])
    names = [item.name for item in result.items]

    assert "해외직접투자신고서(보고서)" in names
    assert "사업계획서(자금조달 및 운용계획 포함)" in names
    assert "조세체납이 없음을 입증하는 서류" in names
    assert "CSV 테스트 서류" not in names
    assert "제9-5조" in (result.source_note or "")


def test_institution_reporting_article_falls_back_to_reason_code_documents():
    """기관장이 제출하는 보고서는 고객 필요서류로 오인하지 않는다."""

    from schemas.analysis import RegulationMatch
    from schemas.reason_code import ReasonCode
    from services.reason_code.mapper import build_required_documents_result

    reason_code = ReasonCode(
        code="FX-TEST",
        name="테스트 거래",
        category="자본거래",
        description="테스트",
        required_documents=["기존 테스트 서류"],
    )
    match = RegulationMatch(
        law_name="외국환거래규정",
        article="제9-22조",
        file_name="regulation.pdf",
        content="한국수출입은행장은 보고서를 작성하여 재정경제부장관에게 제출하여야 한다.",
        score=0.6,
    )

    result = build_required_documents_result(reason_code, [match])
    assert [item.name for item in result.items] == ["기존 테스트 서류"]
    assert "테스트용 목록" in (result.source_note or "")


def test_parenthesized_real_estate_form_name_is_extracted():
    """부동산취득신고(수리)서처럼 괄호가 포함된 별지 서식명도 추출한다."""

    from schemas.analysis import RegulationMatch
    from schemas.reason_code import ReasonCode
    from services.reason_code.mapper import build_required_documents_result

    reason_code = ReasonCode(
        code="FX-0048",
        name="해외부동산 취득(주택)",
        category="자본거래",
        description="해외부동산 취득",
        required_documents=["CSV 부동산 서류"],
    )
    match = RegulationMatch(
        law_name="외국환거래규정",
        article="제9-39조",
        file_name="regulation.pdf",
        content=(
            "거주자가 외국에 있는 부동산을 취득하고자 하는 경우에는 "
            "별지 제9-12호 서식의 부동산취득신고(수리)서를 작성하여 "
            "지정거래외국환은행의 장에게 신고하여 수리를 받아야 한다."
        ),
        score=0.7,
    )

    result = build_required_documents_result(reason_code, [match])
    assert [item.name for item in result.items] == ["부동산취득신고(수리)서"]
    assert result.extraction_status == "PARTIAL"


def test_mixed_actor_parent_does_not_add_bank_report():
    """같은 조문에 거래 당사자 항과 은행 보고 항이 있어도 주체 범위를 섞지 않는다."""

    from schemas.analysis import RegulationMatch
    from schemas.reason_code import ReasonCode
    from services.reason_code.mapper import build_required_documents_result

    reason_code = ReasonCode(
        code="FX-MIXED",
        name="해외투자",
        category="자본거래",
        description="테스트",
        required_documents=["CSV fallback"],
    )
    match = RegulationMatch(
        law_name="외국환거래규정",
        article="제9-5조",
        file_name="regulation.pdf",
        content=(
            "③ 해외직접투자를 하고자 하는 자는 신고서에 다음 각 호의 서류를 첨부하여 제출한다.\n"
            "1. 사업계획서\n"
            "2. 조세체납이 없음을 입증하는 서류\n"
            "④ 외국환은행의 장은 다음 각 호의 보고서를 재정경제부장관에게 제출한다.\n"
            "1. 연간사업실적보고서"
        ),
    )
    result = build_required_documents_result(reason_code, [match])
    names = [item.name for item in result.items]
    assert "사업계획서" in names
    assert "연간사업실적보고서" not in names
    assert result.extraction_status == "COMPLETE"


def test_conditional_document_does_not_lose_condition_metadata():
    from schemas.analysis import RegulationMatch
    from schemas.reason_code import ReasonCode
    from services.reason_code.mapper import build_required_documents_result

    reason_code = ReasonCode(
        code="FX-CONDITIONAL",
        name="해외투자",
        category="자본거래",
        description="테스트",
        required_documents=[],
    )
    match = RegulationMatch(
        law_name="외국환거래규정",
        article="제9-5조",
        file_name="regulation.pdf",
        content=(
            "③ 거주자는 신고서에 다음 각 호의 서류를 첨부하여 제출한다.\n"
            "1. 사업계획서\n"
            "2. 기타 신고기관의 장이 필요하다고 인정하는 서류"
        ),
    )
    result = build_required_documents_result(reason_code, [match])
    conditional = next(item for item in result.items if "기타" in item.name)
    assert conditional.is_conditional is True
    assert "요구 시" in conditional.name
