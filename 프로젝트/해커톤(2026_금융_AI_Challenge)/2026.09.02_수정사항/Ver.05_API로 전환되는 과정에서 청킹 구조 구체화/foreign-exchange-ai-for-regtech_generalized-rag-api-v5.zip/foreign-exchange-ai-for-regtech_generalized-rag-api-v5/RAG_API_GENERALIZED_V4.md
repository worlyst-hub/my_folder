# 범용 필요서류 RAG + 국가법령정보 API V4

## 실행 설정

이 ZIP에는 실제 `.env`와 API 키를 포함하지 않는다. 기존 `.env`는 유지하고
다음 항목만 추가한다.

```dotenv
RAG_MODE=api
LAW_API_KEY=발급받은_OC_값
LAW_API_BASE_URL=https://www.law.go.kr/DRF
LAW_API_TIMEOUT=30
LAW_API_CACHE_DIR=./data/law_api_cache
LAW_API_REFRESH_HOURS=24
LAW_API_INCLUDE_APPENDICES=true
```

첫 실행은 API 동기화와 임베딩 때문에 시간이 걸릴 수 있다. 이후 질문은
로컬 snapshot/ChromaDB를 사용하므로 API를 반복 호출하지 않는다. 원문 갱신이
필요하면 `data/chroma/`의 V4 컬렉션과 API snapshot을 재생성하거나 코드에서
`build_index(force=True)`/`load_target_regulations(force_refresh=True)`를 사용한다.

## 검색 범위 분리

| 원문 | 역할 | 필요서류 유사도 검색 포함 |
|---|---|---|
| 외국환거래규정 조문 | 거래별 신고·첨부서류 검색 | 포함 |
| 외국환거래법 | 상위법 정확 근거 확인 | 제외 |
| 외국환거래법 시행령 | 상위법 정확 근거 확인 | 제외 |
| 별표·별지·서식 | `별지 제9-1호` 등 참조번호 정확 조회 | 제외 |

서식 API를 신청했더라도 서식 전체를 semantic 후보에 넣지 않는다. 조문이
가리키는 별지·별표 번호가 확인될 때만 별도 store에서 정확 조회하므로,
반복되는 `신고/제출/첨부` 문구가 조문 유사도를 과도하게 높이지 않는다.

## 필요서류 판정 순서

1. 사유코드명·분류·keywords·실제 거래목적으로 query를 만든다.
2. 외국환거래규정 Child 후보만 검색한다.
3. 거래 주제와 행위 단계(취득/설립/청산/회수 등)를 재정렬한다.
4. 실제 Parent를 다시 읽어 적용대상, 거래 당사자 주체, 제출의무를 검증한다.
5. 제한적 대상(예: 역외금융회사)이 현재 거래문맥에 없으면 해당 Parent를 제외한다.
6. 제출 anchor가 있는 Child와 번호 목록이 이어지는 sibling만 확장한다.
7. 같은 Parent에 기관 보고 항이 있어도 거래 당사자 항과 분리해 문서명을 추출한다.

결과 상태는 다음 네 가지다.

- `COMPLETE`: 제출서류 anchor와 번호 목록을 함께 확인함
- `PARTIAL`: 신고서/신청서는 찾았지만 첨부목록 완전성은 추가 확인 필요
- `AMBIGUOUS`: 제출 주체가 기관인지 거래 당사자인지 안정적으로 분리하지 못함
- `FAILED`: 법령에서 문서명을 추출하지 못함(CSV 테스트 목록 fallback)

`기타 신고기관의 장이 필요하다고 인정하는 서류`와 같은 항목은 `(요구 시)`로
표시하며 체크하지 않아도 다음 단계 버튼을 막지 않는다.

## 지급절차 조문

제4-2조, 제4-3조, 제10-9조, 제10-11조처럼 프로그램 규칙이 이미 정확한
조문번호를 알고 있는 경우 유사도 검색을 하지 않는다. 판정 결과가 실제로
사용한 조문번호만 exact lookup으로 표시하므로 제7-2조·제2-5조 같은 비관련
조문이 근거 화면에 나타나지 않는다.

## PDF fallback

API 키가 준비되지 않은 개발 환경에서는 `RAG_MODE=pdf`로 기존 PDF를 그대로
사용할 수 있다. Retrieval, Parent 검증, sibling 확장, 필요서류 추출 로직은
API/PDF가 동일하며 입력 loader만 다르다.
