"""LLM 거래 문맥 분석 및 RAG 검색 결과 스키마 (섹션 11, 16~18)."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class TransactionAnalysisInput(BaseModel):
    """LLM 거래 문맥 분석에 들어가는 입력 (섹션 11)."""

    raw_transaction_purpose: str
    remittance_currency: str | None = None
    remittance_amount: str | None = None
    recipient_name: str | None = None
    recipient_country: str | None = None
    recipient_type: str | None = None
    beneficiary_bank_name: str | None = None
    customer_type: str | None = None
    residence_status: str | None = None


class TransactionAnalysis(BaseModel):
    """Ollama LLM이 자연어 송금 목적을 구조화한 결과.

    LLM은 법률적 최종 판단을 내리지 않으며, 검색에 활용할 문맥 정리만
    수행한다.
    """

    transaction_category: str = Field(description="거래 유형 (예: 해외부동산)")
    transaction_action: str = Field(description="거래 행위 (예: 취득)")
    transaction_nature: str = Field(description="거래 성격 (예: 자본거래, 경상거래)")
    normalized_purpose: str = Field(description="정규화된 거래 목적 (예: 해외부동산 취득)")
    country: str | None = Field(default=None, description="관련 국가 (ISO 코드 또는 국가명)")
    important_facts: list[str] = Field(default_factory=list, description="핵심 키워드/사실")


class RegulationMatch(BaseModel):
    """RAG로 검색된 관련 법령/조문 1건."""

    law_name: str = Field(description="법령명 (예: 외국환거래규정)")
    article: str | None = Field(default=None, description="조문 (예: 제5-11조)")
    content: str = Field(description="검색된 본문 발췌")
    file_name: str
    page_number: int | None = None
    is_sample: bool = Field(default=False, description="샘플/Mock 데이터 여부")
    score: float = Field(default=0.0, description="Embedding 유사도 (참고용)")
    source_role: str = Field(
        default="regulation_article",
        description="필요서류 조문/상위법/서식의 분리된 색인 역할",
    )
    source_url: str | None = Field(default=None, description="국가법령정보 원문 URL")


class RequiredDocumentItem(BaseModel):
    name: str
    checked: bool = False
    is_conditional: bool = False
    source_article: str | None = None
    form_reference: str | None = None


class RequiredDocumentsResult(BaseModel):
    """RAG가 안내하는 필요서류 목록. 실제 확인/체크는 은행원이 수행한다."""

    items: list[RequiredDocumentItem] = Field(default_factory=list)
    is_sample: bool = False
    extraction_status: Literal["COMPLETE", "PARTIAL", "AMBIGUOUS", "FAILED"] = "FAILED"
    source_note: str | None = Field(
        default=None, description="근거가 된 법령/조문 등 참고 출처 설명"
    )
