"""국가법령정보 공동활용 Open API 로더와 last-good snapshot cache.

API의 역할은 최신 원문을 동기화하는 데 한정한다. 사용자의 검색마다 API를
호출하지 않고, 조문 단위로 정규화한 snapshot을 ChromaDB에 색인한다.

색인 역할도 분리한다.

* 외국환거래규정 조문: 필요서류 semantic retrieval의 1차 대상
* 외국환거래법/시행령 조문: 상위 근거의 정확 조문 조회 대상
* 별표/별지/서식: semantic 후보와 섞지 않고 참조번호로 정확 조회

인증값(OC)은 요청에만 사용하고 로그, URL, cache에는 저장하지 않는다.
"""

from __future__ import annotations

import html
import json
import re
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import parse_qs, parse_qsl, urlencode, urljoin, urlparse, urlunparse

import requests

from config.settings import get_settings
from utils.logging import get_logger

logger = get_logger(__name__)

TARGET_REGULATIONS: tuple[tuple[str, str, str], ...] = (
    ("외국환거래법", "law", "higher_law"),
    ("외국환거래법 시행령", "law", "higher_law"),
    ("외국환거래규정", "admrul", "regulation_article"),
)

_CACHE_VERSION = 3
_TAG_RE = re.compile(r"<[^>]+>")
_SCRIPT_STYLE_RE = re.compile(
    r"<(?:script|style)\b[^>]*>.*?</(?:script|style)>", re.IGNORECASE | re.DOTALL
)
_BR_RE = re.compile(r"<\s*br\s*/?\s*>", re.IGNORECASE)
_BLOCK_END_RE = re.compile(r"</(?:p|div|li|tr|h[1-6]|table)\s*>", re.IGNORECASE)
_SPACE_RE = re.compile(r"[ \t]+")
_ARTICLE_HEADING_RE = re.compile(
    r"(제\s*(\d+)(?:-(\d+))?\s*조(?:의\s*(\d+))?)\s*\(([^)]{1,100})\)"
)
_ARTICLE_RE = re.compile(r"제\s*\d+(?:-\d+)?\s*조(?:의\s*\d+)?")


class LawApiError(RuntimeError):
    """국가법령정보 API 조회/파싱 오류."""


@dataclass(frozen=True)
class LegalArticle:
    law_name: str
    target: str
    source_role: str
    article: str | None
    title: str
    text: str
    source_url: str
    identifier: str
    effective_date: str = ""
    chapter: str = ""
    section: str = ""


@dataclass(frozen=True)
class LegalForm:
    law_name: str
    target: str
    title: str
    form_number: str
    branch_number: str
    form_kind: str
    text: str
    source_url: str
    identifier: str


@dataclass(frozen=True)
class LawApiDocument:
    law_name: str
    target: str
    source_role: str
    source_url: str
    identifier: str
    effective_date: str
    articles: list[LegalArticle] = field(default_factory=list)
    forms: list[LegalForm] = field(default_factory=list)

    @property
    def text(self) -> str:
        """이전 API 버전과의 호환용 전체 조문 텍스트."""

        return "\n\n".join(article.text for article in self.articles)


def _clean_text(value: Any) -> str:
    text = html.unescape(str(value or ""))
    text = _SCRIPT_STYLE_RE.sub("", text)
    text = _BR_RE.sub("\n", text)
    text = _BLOCK_END_RE.sub("\n", text)
    text = _TAG_RE.sub("", text)
    text = text.replace("\r\n", "\n").replace("\r", "\n").replace("\xa0", " ")
    lines = [_SPACE_RE.sub(" ", line).strip() for line in text.splitlines()]
    return "\n".join(line for line in lines if line).strip()


def _as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def _walk_dicts(node: Any) -> Iterable[dict[str, Any]]:
    if isinstance(node, dict):
        yield node
        for value in node.values():
            yield from _walk_dicts(value)
    elif isinstance(node, list):
        for value in node:
            yield from _walk_dicts(value)


def _find_records(payload: Any, name_keys: tuple[str, ...]) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for item in _walk_dicts(payload):
        if any(key in item for key in name_keys):
            records.append(item)
    return records


def _first_scalar(record: dict[str, Any], *keys: str) -> str:
    for key in keys:
        value = record.get(key)
        if value is None or isinstance(value, (dict, list)):
            continue
        text = _clean_text(value)
        if text:
            return text
    return ""


def _normalize_name(value: str) -> str:
    return re.sub(r"\s+", "", _clean_text(value))


def _extract_query_identifier(link: str, key: str) -> str:
    if not link:
        return ""
    try:
        return parse_qs(urlparse(link).query).get(key, [""])[0]
    except Exception:
        return ""


def _safe_source_url(value: str) -> str:
    """사용자용 URL에서 인증 query parameter를 제거한다."""

    if not value:
        return "https://www.law.go.kr"
    absolute = urljoin("https://www.law.go.kr", value)
    parsed = urlparse(absolute)
    query = [(key, val) for key, val in parse_qsl(parsed.query) if key.upper() != "OC"]
    return urlunparse(parsed._replace(query=urlencode(query)))


def _collect_content_values(node: Any, wanted_keys: set[str]) -> list[str]:
    values: list[str] = []
    if isinstance(node, dict):
        for key, value in node.items():
            if key in wanted_keys:
                for child in _as_list(value):
                    if not isinstance(child, (dict, list)):
                        text = _clean_text(child)
                        if text:
                            values.append(text)
            if isinstance(value, (dict, list)):
                values.extend(_collect_content_values(value, wanted_keys))
    elif isinstance(node, list):
        for value in node:
            values.extend(_collect_content_values(value, wanted_keys))
    return values


def _dedupe(values: Iterable[str]) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for value in values:
        text = _clean_text(value)
        key = re.sub(r"\s+", "", text)
        if not key or key in seen:
            continue
        seen.add(key)
        result.append(text)
    return result


def _restore_structure_newlines(value: str) -> str:
    """한 줄 API 본문에 항·호·목 경계를 다시 넣는다.

    API JSON은 ``③ ... 한다.1. 사업계획서2. ...``처럼 구조기호를 붙여
    반환하기도 한다. 조문을 나눈 뒤 구조기호 앞에만 줄바꿈을 복원하면 기존
    Parent-Child chunker와 번호 목록 추출기를 PDF/API 양쪽에서 공통 사용한다.
    """

    text = str(value or "").strip()
    text = re.sub(r"(?<!\n)([①-⑳])", r"\n\1", text)
    text = re.sub(
        r"(?<![\d\n])(\d{1,2}\.\s*)(?=[0-9가-힣A-Za-z<「『])",
        r"\n\1",
        text,
    )
    text = re.sub(r"(?<![가-힣\n])([가-하]\.\s*)(?=[가-힣A-Za-z<「『])", r"\n\1", text)
    return re.sub(r"\n{2,}", "\n", text).strip()


def _render_law_article(unit: dict[str, Any]) -> tuple[str | None, str, str]:
    number = _first_scalar(unit, "조문번호")
    branch = _first_scalar(unit, "조문가지번호")
    title = _first_scalar(unit, "조문제목")
    article: str | None = None
    if number:
        article = f"제{number}조"
        if branch and branch not in {"0", "00"}:
            article += f"의{int(branch)}" if branch.isdigit() else f"의{branch}"

    header = f"{article}({title})" if article and title else article or title
    base = _first_scalar(unit, "조문내용")
    lines = [base or header]
    extras = _collect_content_values(unit.get("항"), {"항내용", "호내용", "목내용"})
    base_flat = re.sub(r"\s+", "", base)
    for extra in _dedupe(extras):
        if re.sub(r"\s+", "", extra) in base_flat:
            continue
        lines.append(extra)
    rendered = "\n".join(_dedupe(lines)).strip()
    if header and rendered and not _ARTICLE_RE.match(rendered):
        rendered = f"{header}\n{rendered}"
    return article, title, rendered


def _split_article_text(text: str) -> list[tuple[str | None, str, str]]:
    """줄바꿈 유무와 무관하게 행정규칙 본문을 조문별로 분리한다.

    실제 ``target=admrul`` JSON은 장·조·항·호를 줄바꿈 없이 한 문자열로
    반환할 수 있다. 단순히 ``제N조(...)``를 모두 경계로 쓰면 본문 속
    ``제2-6조(거주자가 ... 경우에 한한다)`` 같은 인용까지 조문으로 오인한다.
    행정규칙의 실제 조문번호가 전체 문서에서 증가한다는 구조를 이용해, 후보
    heading 중 가장 긴 strictly-increasing sequence만 경계로 채택한다.
    """

    normalized = _clean_text(text)
    if not normalized:
        return []

    candidates = list(_ARTICLE_HEADING_RE.finditer(normalized))
    if not candidates:
        article_match = _ARTICLE_RE.search(normalized)
        return [(article_match.group(0) if article_match else None, "", normalized)]

    # Longest increasing subsequence. 같은 조문번호가 본문 인용과 실제 heading에
    # 중복 등장해도 하나만 남고, 미래 조문 인용 뒤에 더 작은 실제 조문번호가
    # 나타나는 경우에는 그 인용 후보가 자동으로 제외된다.
    from bisect import bisect_left

    keys = [
        (
            int(match.group(2)),
            int(match.group(3) or 0),
            int(match.group(4) or 0),
        )
        for match in candidates
    ]
    tails: list[tuple[int, int, int]] = []
    tail_indexes: list[int] = []
    previous = [-1] * len(candidates)
    for index, key in enumerate(keys):
        position = bisect_left(tails, key)
        if position == len(tails):
            tails.append(key)
            tail_indexes.append(index)
        else:
            tails[position] = key
            tail_indexes[position] = index
        if position:
            previous[index] = tail_indexes[position - 1]

    selected_indexes: list[int] = []
    cursor = tail_indexes[-1]
    while cursor >= 0:
        selected_indexes.append(cursor)
        cursor = previous[cursor]
    selected_indexes.reverse()
    headings = [candidates[index] for index in selected_indexes]

    result: list[tuple[str | None, str, str]] = []
    for index, heading in enumerate(headings):
        start = heading.start()
        end = headings[index + 1].start() if index + 1 < len(headings) else len(normalized)
        value = _restore_structure_newlines(normalized[start:end])
        result.append(
            (
                _clean_text(heading.group(1)),
                _clean_text(heading.group(5)),
                value,
            )
        )
    return result


def parse_law_articles(
    payload: Any,
    *,
    law_name: str,
    target: str,
    source_role: str,
    source_url: str,
    identifier: str,
    effective_date: str = "",
) -> list[LegalArticle]:
    units: list[dict[str, Any]] = []
    for item in _walk_dicts(payload):
        if "조문단위" in item:
            units.extend(value for value in _as_list(item["조문단위"]) if isinstance(value, dict))
    if not units:
        units = [item for item in _walk_dicts(payload) if "조문번호" in item]

    rendered = [_render_law_article(unit) for unit in units]
    rendered = [value for value in rendered if value[2]]
    if not rendered:
        fallback = "\n\n".join(_dedupe(_collect_content_values(payload, {"조문내용"})))
        rendered = _split_article_text(fallback)

    return [
        LegalArticle(
            law_name=law_name,
            target=target,
            source_role=source_role,
            article=article,
            title=title,
            text=text,
            source_url=source_url,
            identifier=identifier,
            effective_date=effective_date,
        )
        for article, title, text in rendered
        if text
    ]


def parse_admrul_articles(
    payload: Any,
    *,
    law_name: str,
    target: str,
    source_role: str,
    source_url: str,
    identifier: str,
    effective_date: str = "",
) -> list[LegalArticle]:
    values = _dedupe(_collect_content_values(payload, {"조문내용"}))
    if not values:
        raise LawApiError("행정규칙 JSON 응답에서 조문내용을 찾지 못했습니다.")
    rendered: list[tuple[str | None, str, str]] = []
    for value in values:
        rendered.extend(_split_article_text(value))
    # 조문번호가 같은 nested 값을 중복 수집한 경우 긴 원문 하나만 남긴다.
    by_key: dict[str, tuple[str | None, str, str]] = {}
    order: list[str] = []
    for index, value in enumerate(rendered):
        key = re.sub(r"\s+", "", value[0] or f"generic-{index}")
        if key not in by_key:
            order.append(key)
        if key not in by_key or len(value[2]) > len(by_key[key][2]):
            by_key[key] = value
    return [
        LegalArticle(
            law_name=law_name,
            target=target,
            source_role=source_role,
            article=by_key[key][0],
            title=by_key[key][1],
            text=by_key[key][2],
            source_url=source_url,
            identifier=identifier,
            effective_date=effective_date,
        )
        for key in order
    ]


def parse_law_detail(payload: Any) -> str:
    """이전 테스트/호출부 호환용 법령 전체 텍스트 parser."""

    articles = parse_law_articles(
        payload,
        law_name="",
        target="law",
        source_role="higher_law",
        source_url="",
        identifier="",
    )
    return "\n\n".join(article.text for article in articles)


def parse_admrul_detail(payload: Any) -> str:
    """이전 테스트/호출부 호환용 행정규칙 전체 텍스트 parser."""

    articles = parse_admrul_articles(
        payload,
        law_name="",
        target="admrul",
        source_role="regulation_article",
        source_url="",
        identifier="",
    )
    return "\n\n".join(article.text for article in articles)


class LawApiClient:
    def __init__(self, session: requests.Session | None = None) -> None:
        settings = get_settings()
        self._api_key = (settings.law_api_key or "").strip()
        self._base_url = settings.law_api_base_url.rstrip("/")
        self._timeout = settings.law_api_timeout
        self._include_appendices = settings.law_api_include_appendices
        self._session = session or requests.Session()

    def _require_key(self) -> None:
        if not self._api_key:
            raise LawApiError(
                ".env의 LAW_API_KEY가 비어 있습니다. 발급받은 국가법령정보 API OC 값을 입력해주세요."
            )

    def _get_json(self, endpoint: str, params: dict[str, str | int]) -> Any:
        self._require_key()
        request_params = {"OC": self._api_key, "type": "JSON", **params}
        try:
            response = self._session.get(
                f"{self._base_url}/{endpoint}", params=request_params, timeout=self._timeout
            )
            response.raise_for_status()
            return response.json()
        except requests.RequestException:
            raise LawApiError("국가법령정보 공동활용 API에 연결하지 못했습니다.") from None
        except ValueError:
            raise LawApiError("국가법령정보 공동활용 API 응답이 JSON 형식이 아닙니다.") from None

    def _get_html(self, link: str) -> str:
        self._require_key()
        url = urljoin("https://www.law.go.kr", link)
        try:
            response = self._session.get(
                url, params={"OC": self._api_key}, timeout=self._timeout
            )
            response.raise_for_status()
        except requests.RequestException:
            logger.warning("별표/서식 본문 HTML을 가져오지 못했습니다: %s", _safe_source_url(url))
            return ""
        return _clean_text(response.text)

    def _search_exact(self, law_name: str, target: str) -> dict[str, Any]:
        payload = self._get_json(
            "lawSearch.do",
            {"target": target, "query": law_name, "search": 1, "display": 100},
        )
        name_keys = ("법령명한글", "법령명") if target == "law" else ("행정규칙명",)
        wanted = _normalize_name(law_name)
        exact = [
            record
            for record in _find_records(payload, name_keys)
            if _normalize_name(_first_scalar(record, *name_keys)) == wanted
        ]
        if not exact:
            raise LawApiError(f"API 검색 결과에서 '{law_name}'의 정확한 현행 항목을 찾지 못했습니다.")
        exact.sort(
            key=lambda record: (
                _first_scalar(record, "시행일자"),
                _first_scalar(record, "공포일자", "발령일자"),
            ),
            reverse=True,
        )
        return exact[0]

    def _detail_params(self, record: dict[str, Any], target: str) -> tuple[dict[str, str], str]:
        if target == "law":
            identifier = _first_scalar(record, "법령ID")
            mst = _first_scalar(record, "법령일련번호", "법령MST", "MST")
            link = _first_scalar(record, "법령상세링크", "상세링크")
            identifier = identifier or _extract_query_identifier(link, "ID")
            mst = mst or _extract_query_identifier(link, "MST")
            if identifier:
                return {"target": "law", "ID": identifier}, identifier
            if mst:
                return {"target": "law", "MST": mst}, mst
            raise LawApiError("법령 상세 조회용 ID/MST를 찾지 못했습니다.")

        serial = _first_scalar(record, "행정규칙일련번호")
        lid = _first_scalar(record, "행정규칙ID")
        link = _first_scalar(record, "행정규칙상세링크", "상세링크")
        serial = serial or _extract_query_identifier(link, "ID")
        lid = lid or _extract_query_identifier(link, "LID")
        if serial:
            return {"target": "admrul", "ID": serial}, serial
        if lid:
            return {"target": "admrul", "LID": lid}, lid
        raise LawApiError("행정규칙 상세 조회용 ID/LID를 찾지 못했습니다.")

    def _fetch_forms(self, law_name: str, parent_target: str) -> list[LegalForm]:
        if not self._include_appendices:
            return []
        target = "licbyl" if parent_target == "law" else "admbyl"
        payload = self._get_json(
            "lawSearch.do",
            {"target": target, "query": law_name, "search": 2, "display": 100},
        )
        records = _find_records(payload, ("별표명", "서식명"))
        forms: list[LegalForm] = []
        seen: set[str] = set()
        for record in records:
            related = _first_scalar(
                record, "관련법령명", "관련행정규칙명", "법령명한글", "행정규칙명"
            )
            if related and _normalize_name(related) != _normalize_name(law_name):
                continue
            title = _first_scalar(record, "별표명", "서식명")
            number = _first_scalar(record, "별표번호", "서식번호")
            branch = _first_scalar(record, "별표가지번호", "서식가지번호")
            kind = _first_scalar(record, "별표종류", "서식종류")
            identifier = _first_scalar(
                record, "별표일련번호", "서식일련번호", "별표ID", "서식ID"
            )
            link = _first_scalar(
                record,
                "별표행정규칙상세링크",
                "별표법령상세링크",
                "별표상세링크",
                "서식상세링크",
                "상세링크",
            )
            key = "|".join((law_name, kind, number, branch, title, identifier))
            if not title or key in seen:
                continue
            seen.add(key)
            body = self._get_html(link) if link else ""
            forms.append(
                LegalForm(
                    law_name=law_name,
                    target=target,
                    title=title,
                    form_number=number,
                    branch_number=branch,
                    form_kind=kind,
                    text=body,
                    source_url=_safe_source_url(link),
                    identifier=identifier,
                )
            )
        return forms

    def fetch_document(self, law_name: str, target: str, source_role: str) -> LawApiDocument:
        record = self._search_exact(law_name, target)
        detail_params, identifier = self._detail_params(record, target)
        payload = self._get_json("lawService.do", detail_params)
        link = _first_scalar(
            record,
            "법령상세링크" if target == "law" else "행정규칙상세링크",
            "상세링크",
        )
        source_url = _safe_source_url(link)
        effective_date = _first_scalar(record, "시행일자", "발령일자")
        parser = parse_law_articles if target == "law" else parse_admrul_articles
        articles = parser(
            payload,
            law_name=law_name,
            target=target,
            source_role=source_role,
            source_url=source_url,
            identifier=identifier,
            effective_date=effective_date,
        )
        if not articles:
            raise LawApiError(f"'{law_name}' 응답에서 색인할 조문을 찾지 못했습니다.")
        forms = self._fetch_forms(law_name, target)
        logger.info(
            "국가법령정보 API 동기화: %s 조문=%d 별표/서식=%d",
            law_name,
            len(articles),
            len(forms),
        )
        return LawApiDocument(
            law_name=law_name,
            target=target,
            source_role=source_role,
            source_url=source_url,
            identifier=identifier,
            effective_date=effective_date,
            articles=articles,
            forms=forms,
        )

    def fetch_target_regulations(self) -> list[LawApiDocument]:
        return [self.fetch_document(*target) for target in TARGET_REGULATIONS]


def _document_from_dict(value: dict[str, Any]) -> LawApiDocument:
    articles = [LegalArticle(**item) for item in value.get("articles", [])]
    forms = [LegalForm(**item) for item in value.get("forms", [])]
    data = {key: val for key, val in value.items() if key not in {"articles", "forms"}}
    return LawApiDocument(**data, articles=articles, forms=forms)


def _load_snapshot(path: Path) -> tuple[datetime | None, list[LawApiDocument]]:
    if not path.is_file():
        return None, []
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        if payload.get("version") != _CACHE_VERSION:
            return None, []
        synced_at = datetime.fromisoformat(payload["synced_at"])
        documents = [_document_from_dict(item) for item in payload.get("documents", [])]
        return synced_at, documents
    except Exception:
        logger.exception("법령 API snapshot을 읽지 못했습니다: %s", path)
        return None, []


def _save_snapshot(path: Path, documents: list[LawApiDocument]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "version": _CACHE_VERSION,
        "synced_at": datetime.now(timezone.utc).isoformat(),
        "documents": [asdict(document) for document in documents],
    }
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(path)


def load_target_regulations(
    *, force_refresh: bool = False, client: LawApiClient | None = None
) -> list[LawApiDocument]:
    """3개 외국환 법령을 API에서 동기화하거나 fresh/last-good cache로 읽는다."""

    settings = get_settings()
    snapshot_path = Path(settings.law_api_cache_dir) / "foreign_exchange_snapshot_v3.json"
    synced_at, cached = _load_snapshot(snapshot_path)
    now = datetime.now(timezone.utc)
    is_fresh = bool(
        synced_at
        and cached
        and (now - synced_at).total_seconds() < max(0, settings.law_api_refresh_hours) * 3600
    )
    if not force_refresh and is_fresh:
        return cached

    try:
        documents = (client or LawApiClient()).fetch_target_regulations()
        _save_snapshot(snapshot_path, documents)
        return documents
    except LawApiError:
        if cached:
            logger.exception("법령 API 갱신 실패 - 마지막 정상 snapshot을 사용합니다.")
            return cached
        raise
