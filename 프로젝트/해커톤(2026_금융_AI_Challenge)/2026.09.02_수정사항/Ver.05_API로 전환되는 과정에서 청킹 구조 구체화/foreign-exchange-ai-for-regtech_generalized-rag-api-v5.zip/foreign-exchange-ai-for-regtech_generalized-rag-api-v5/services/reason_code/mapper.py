"""사유코드 Embedding 기반 Vector Search (섹션 12~14).

임의의 숫자 가중치를 조합한 점수식을 사용하지 않는다. Embedding 코사인
유사도만으로 Top-K 후보를 뽑아 은행원에게 보여주고, 최종 채택은 은행원이
판단한다.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

import chromadb
from sqlalchemy import select

from config.settings import get_settings
from database.connection import get_session
from database.models import ReasonCode as ReasonCodeORM
from schemas.analysis import RegulationMatch, RequiredDocumentItem, RequiredDocumentsResult
from schemas.reason_code import ReasonCode, ReasonCodeCandidate
from services.embedding_client import EmbeddingClient
from utils.logging import get_logger

logger = get_logger(__name__)


def _index_text(rc: ReasonCodeORM) -> str:
    return f"{rc.name} {rc.description} {' '.join(rc.keywords)}"


def _to_schema(rc: ReasonCodeORM) -> ReasonCode:
    return ReasonCode(
        code=rc.code,
        name=rc.name,
        category=rc.category,
        description=rc.description,
        keywords=rc.keywords,
        required_documents=rc.required_documents,
        regulation_tags=rc.regulation_tags,
        is_active=rc.is_active,
    )


class ReasonCodeMapper:
    """사유코드 Vector Search 인덱스 빌드/검색을 담당."""

    def __init__(self) -> None:
        settings = get_settings()
        self._embedder = EmbeddingClient()
        chroma_client = chromadb.PersistentClient(path=settings.chroma_persist_dir)
        self._collection = chroma_client.get_or_create_collection(
            name=f"reason_codes_{self._embedder.backend_name}",
            metadata={"hnsw:space": "cosine"},
        )

    @property
    def embedding_backend(self) -> str:
        """실제 사용 중인 임베딩 백엔드("ollama"/"hash").

        ``LLM_MODE=live`` 여도 Ollama 연결에 실패하면 ``EmbeddingClient``가
        조용히 경량 해시 임베딩으로 폴백한다(섹션 14 원칙). 화면에서 이
        값을 실제로 노출해, 사이드바의 "Live" 배지만 보고 검색 품질까지
        Live라고 오해하지 않도록 한다.
        """

        return self._embedder.backend_name

    def build_index(self, force: bool = False) -> int:
        """DB의 활성 사유코드를 임베딩하여 Vector DB에 색인한다."""

        if self._collection.count() > 0:
            if not force:
                logger.info("사유코드 인덱스가 이미 존재합니다 (force=True로 재생성 가능)")
                return self._collection.count()
            existing_ids = self._collection.get()["ids"]
            if existing_ids:
                self._collection.delete(ids=existing_ids)

        with get_session() as session:
            reason_codes = (
                session.execute(select(ReasonCodeORM).where(ReasonCodeORM.is_active.is_(True)))
                .scalars()
                .all()
            )
            if not reason_codes:
                logger.warning("색인할 사유코드가 없습니다. 먼저 database.seed를 실행하세요.")
                return 0

            texts = [_index_text(rc) for rc in reason_codes]
            ids = [rc.code for rc in reason_codes]
            metadatas = [{"code": rc.code} for rc in reason_codes]
            embeddings = self._embedder.embed(texts)

        self._collection.add(ids=ids, embeddings=embeddings, documents=texts, metadatas=metadatas)
        logger.info(
            "사유코드 %d건 인덱싱 완료 (embedding backend=%s)", len(ids), self._embedder.backend_name
        )
        return len(ids)

    def search(self, query_text: str, top_k: int = 5) -> list[ReasonCodeCandidate]:
        """자연어 거래 문맥 텍스트로 사유코드 후보 Top-K를 검색한다."""

        if self._collection.count() == 0:
            self.build_index()
        if self._collection.count() == 0:
            return []

        query_embedding = self._embedder.embed([query_text])[0]
        n_results = min(top_k, self._collection.count())
        result = self._collection.query(query_embeddings=[query_embedding], n_results=n_results)

        codes = result["ids"][0]
        distances = result["distances"][0]

        candidates: list[ReasonCodeCandidate] = []
        with get_session() as session:
            for code, distance in zip(codes, distances):
                rc = session.execute(
                    select(ReasonCodeORM).where(ReasonCodeORM.code == code)
                ).scalar_one_or_none()
                if rc is None:
                    continue
                # cosine space 이므로 distance = 1 - cosine_similarity
                score = max(0.0, min(1.0, 1.0 - distance))
                matched_keywords = [kw for kw in rc.keywords if kw in query_text]
                candidates.append(
                    ReasonCodeCandidate(
                        reason_code=_to_schema(rc),
                        score=round(score, 4),
                        matched_keywords=matched_keywords,
                    )
                )
        return candidates


# ---------------------------------------------------------------------------
# 법령 RAG 원문 -> 필요서류 체크리스트
# ---------------------------------------------------------------------------

_DOCUMENT_NAME_CUES = (
    "신고서", "신청서", "계획서", "계약서", "확인서", "증명서", "허가서", "승인서",
    "보고서", "명세서", "내역서", "사본", "등본", "원본", "영수증", "증서", "재무제표",
    "정관", "회의록", "공증서", "번역문", "사업자등록증", "증빙서류", "입증서류", "서류",
)
_LIST_ITEM_RE = re.compile(r"^\s*(?:\d+\s*[.)]|[가-하]\s*[.)]|[①-⑳])\s*(.*)$")
_SUBMISSION_CUE_RE = re.compile(
    r"(?:다음\s*각\s*호의\s*서류|서류를\s*첨부|첨부하여\s*제출|"
    r"신고서.{0,100}제출|신청서.{0,100}제출|"
    r"별지\s*제[^\s]+\s*서식의.{0,120}?(?:작성|제출|신고)|"
    r"구비서류|증빙서류|입증서류)"
)
_PARTY_ACTOR_RE = re.compile(
    r"(?:거주자|비거주자|신고인|신청인|투자자|취득자|양수인|양도인|송금인|지급인)"
    r"[은는이가]|(?:하고자\s*하는|하려는|신고하는|신청하는)\s*자[는가]"
)
_INSTITUTION_SUBJECT_RE = re.compile(
    r"(?:외국환은행(?:의\s*장)?|지정거래외국환은행(?:의\s*장)?|한국은행(?:총재)?|"
    r"한국수출입은행(?:의\s*장)?|기획재정부장관|재정경제부장관|금융위원회|"
    r"금융감독원장|국세청장|관세청장|은행장)[은는이가]"
)
_PARAGRAPH_BOUNDARY_RE = re.compile(r"[①-⑳]")
_FORM_REFERENCE_RE = re.compile(
    r"((?:별지|별표)\s*제\s*\d+(?:[-의]\d+)?\s*호(?:의\s*\d+)?(?:\s*서식)?)"
)


@dataclass(frozen=True)
class _ExtractedDocument:
    name: str
    is_conditional: bool = False
    form_reference: str | None = None


@dataclass(frozen=True)
class _Extraction:
    documents: list[_ExtractedDocument]
    article: str | None
    status: str


def _normalize_text(value: str) -> str:
    value = str(value or "").replace("\r\n", "\n").replace("\r", "\n")
    return re.sub(r"[ \t]+", " ", value).strip()


def _looks_like_party_submission(text: str) -> bool:
    """기관 자체 보고의무가 아니라 거래 당사자의 제출 문맥인지 판단한다.

    법령 문체가 다양하므로 거래 당사자 주어를 반드시 요구하지는 않는다. 대신
    강한 제출서류 표현이 있고 기관이 주어인 문장만 있는 경우를 제외한다.
    ``외국환은행의 장에게 제출``처럼 기관이 목적어인 정상 문장은 제외되지 않는다.
    """

    compact = re.sub(r"\s+", " ", text or "")
    if not _SUBMISSION_CUE_RE.search(compact):
        return False

    party = bool(_PARTY_ACTOR_RE.search(compact))
    institution = bool(_INSTITUTION_SUBJECT_RE.search(compact))
    if institution and not party:
        return False
    return True


def _actor_before(value: str, position: int) -> str:
    """의무표현 앞에서 가장 가까운 주어가 당사자인지 기관인지 구분한다."""

    prefix = value[:position]
    party_positions = [match.start() for match in _PARTY_ACTOR_RE.finditer(prefix)]
    institution_positions = [match.start() for match in _INSTITUTION_SUBJECT_RE.finditer(prefix)]
    party = party_positions[-1] if party_positions else -1
    institution = institution_positions[-1] if institution_positions else -1
    if party < 0 and institution < 0:
        return "implicit"
    return "party" if party > institution else "institution"


def _paragraph_scope(value: str, position: int) -> str:
    """anchor가 속한 항(①...)만 잘라 다음 기관 보고 항과 섞이지 않게 한다."""

    boundaries = [match.start() for match in _PARAGRAPH_BOUNDARY_RE.finditer(value)]
    start = max((item for item in boundaries if item <= position), default=0)
    end = min((item for item in boundaries if item > position), default=len(value))
    return value[start:end].strip()


def _find_party_submission_scope(text: str) -> tuple[str | None, bool]:
    """거래 당사자 제출 anchor가 있는 항을 반환한다.

    두 번째 반환값은 제출 단서는 있으나 기관 주어밖에 없어 모호/부적합한
    후보가 있었는지를 나타낸다.
    """

    compact = _normalize_text(text)
    ambiguous = False
    for match in _SUBMISSION_CUE_RE.finditer(compact):
        scope = _paragraph_scope(compact, match.start())
        local_position = max(0, match.start() - compact.find(scope))
        actor = _actor_before(scope, local_position)
        if actor == "institution":
            ambiguous = True
            continue
        return scope, ambiguous
    return None, ambiguous


def _clean_document_name(value: str) -> str | None:
    text = _normalize_text(value)
    text = re.sub(r"^\s*(?:\d+\s*[.)]|[가-하]\s*[.)]|[①-⑳])\s*", "", text)
    # API가 삭제된 빈 호를 ``...사업계획서2. 3. 4. 다음서류``처럼 붙여
    # 반환한 경우 앞 문서명 끝에 남을 수 있는 빈 번호표시를 제거한다.
    text = re.sub(r"(?:\s*\d{1,2}\.)+\s*$", "", text)
    # 개정 이력/고시 주석은 문서명이 아니므로 잘라낸다.
    text = text.split("<", 1)[0].strip(" ·,:;.-")
    text = re.sub(r"\s+", " ", text).strip()
    if not text or text in {"삭제", "<삭제>", "해당없음"}:
        return None
    # "... 입증하는 서류. 다만, ..."처럼 문서명 뒤에 예외 설명이 길게
    # 이어지는 항목은 예외 문장 앞까지만 체크리스트 이름으로 사용한다.
    text = re.split(r"\.\s*다만[,，]?", text, maxsplit=1)[0].strip()
    if len(text) > 320:
        return None
    has_document_cue = any(cue in text for cue in _DOCUMENT_NAME_CUES)
    parenthesized_form = bool(
        re.search(r"(?:신고|신청)[^\s,.;]{0,30}서(?:\([^)]*\))?$", text)
    )
    if not has_document_cue and not parenthesized_form:
        return None

    # 목록 항목 뒤에 독립적인 법적 의무 문장이 붙은 경우 문서명 부분만 남긴다.
    # 괄호 안 설명(예: 자금조달 및 운용계획 포함)은 보존한다.
    for marker in ("하여야 한다", "해야 한다", "제출하여야", "신고하여야"):
        pos = text.find(marker)
        if pos > 0:
            text = text[:pos].rstrip(" ,.;")
    return text or None


def _extract_named_forms(text: str) -> list[str]:
    """제출문장 안에 직접 명시된 신고서/신청서 명칭을 추출한다."""

    results: list[str] = []
    compact = re.sub(r"\s+", " ", text or "")

    # "별지 제9-1호 서식의 해외직접투자신고서(보고서)에 ..." 및
    # "별지 제9-12호 서식의 부동산취득신고(수리)서를 ..." 형태를 처리한다.
    # 괄호가 '신고'와 '서' 사이에 들어가는 법령 서식명도 보존한다.
    for match in re.finditer(
        r"서식의\s+([^,.;]{2,100}?서(?:\([^)]*\))?)(?=[에를은는이가\s])",
        compact,
    ):
        name = _clean_document_name(match.group(1))
        if name:
            results.append(name)

    # 별지 표현이 없는 일반 "OO신고서/OO신청서"도 보완한다. 기관 보고서가
    # 잘못 들어가지 않도록 보고서는 위의 '서식의' 패턴에서만 허용한다.
    for match in re.finditer(
        r"([가-힣A-Za-z0-9·ㆍ()\-]{2,60}(?:신고서|신청서))",
        compact,
    ):
        name = _clean_document_name(match.group(1))
        if name and not any(existing.startswith(name) for existing in results):
            results.append(name)
    return results


def _form_reference_for_name(scope: str, name: str) -> str | None:
    position = scope.find(name)
    vicinity = scope[max(0, position - 100) : position + len(name) + 30] if position >= 0 else scope
    matches = list(_FORM_REFERENCE_RE.finditer(vicinity))
    return matches[-1].group(1) if matches else None


def _extract_numbered_document_items(text: str) -> list[str]:
    """'다음 각 호의 서류' 뒤에 이어지는 번호 목록에서 문서명만 추출한다."""

    compact = re.sub(r"[ \t]+", " ", text or "")
    anchor = re.search(r"다음\s*각\s*호의\s*서류", compact)
    if not anchor:
        # 강한 anchor가 없으면 번호 목록 전체를 문서목록으로 오인하기 쉬우므로
        # 여기서는 추출하지 않고 신고서/신청서 직접 명칭만 사용한다.
        return []

    tail = compact[anchor.end() :]
    lines = [line.strip() for line in tail.splitlines() if line.strip()]
    raw_items: list[str] = []
    current: list[str] = []

    def flush() -> None:
        nonlocal current
        if current:
            raw_items.append(" ".join(current).strip())
            current = []

    for line in lines:
        match = _LIST_ITEM_RE.match(line)
        if match:
            flush()
            current = [match.group(1).strip()]
        elif current:
            # 다음 조문 헤더가 나오면 현재 목록이 끝난 것으로 본다.
            if re.match(r"^제\s*\d+(?:-\d+)?\s*조|^[①-⑳]", line):
                flush()
                break
            if _INSTITUTION_SUBJECT_RE.search(line) and not _PARTY_ACTOR_RE.search(line):
                flush()
                break
            current.append(line)
    flush()

    results: list[str] = []
    for item in raw_items:
        cleaned = _clean_document_name(item)
        if cleaned:
            results.append(cleaned)
    return results


def _is_conditional_document(name: str) -> bool:
    compact = re.sub(r"\s+", "", name)
    return bool(
        ("기타" in compact or "추가" in compact)
        and ("필요하다고" in compact or "요구" in compact or "인정하는서류" in compact)
    )


def _dedupe_extracted(
    names: list[str], scope: str, max_documents: int
) -> list[_ExtractedDocument]:
    documents: list[_ExtractedDocument] = []
    seen: set[str] = set()
    for name in names:
        conditional = _is_conditional_document(name)
        label = f"{name} (요구 시)" if conditional and "요구 시" not in name else name
        key = re.sub(r"\s+", "", label)
        if not key or key in seen:
            continue
        # 괄호가 붙은 정식 서식명이 이미 있으면 그 부분명칭은 중복 추가하지 않는다.
        if any(existing.name.startswith(name) for existing in documents):
            continue
        seen.add(key)
        documents.append(
            _ExtractedDocument(
                name=label,
                is_conditional=conditional,
                form_reference=_form_reference_for_name(scope, name),
            )
        )
        if len(documents) >= max_documents:
            break
    return documents


def _extract_from_matches(
    regulation_matches: list[RegulationMatch] | None,
    *,
    max_documents: int = 15,
) -> _Extraction:
    saw_ambiguous = False
    for match in regulation_matches or []:
        if match.source_role not in {"regulation_article", "sample"}:
            continue
        text = _normalize_text(match.content)
        if not text:
            continue
        scope, ambiguous = _find_party_submission_scope(text)
        saw_ambiguous = saw_ambiguous or ambiguous
        if not scope:
            continue

        named = _extract_named_forms(scope)
        numbered = _extract_numbered_document_items(scope)
        documents = _dedupe_extracted(named + numbered, scope, max_documents)
        if not documents:
            continue

        has_anchor = bool(re.search(r"다음\s*각\s*호의\s*서류", scope))
        # 목록 anchor와 적어도 한 개의 번호 항목이 함께 있어야 완전 추출로 본다.
        # 신고서만 찾고 첨부목록이 잘린 결과는 PARTIAL로 숨기지 않는다.
        status = "COMPLETE" if has_anchor and numbered else "PARTIAL"
        return _Extraction(documents=documents, article=match.article, status=status)

    return _Extraction(
        documents=[],
        article=None,
        status="AMBIGUOUS" if saw_ambiguous else "FAILED",
    )


def extract_required_documents_from_regulations(
    regulation_matches: list[RegulationMatch] | None,
    *,
    max_documents: int = 15,
) -> tuple[list[str], list[str]]:
    """RAG가 고른 핵심 법령 원문에서 거래 당사자 제출서류 후보를 추출한다.

    특정 사유코드/조문 번호를 하드코딩하지 않는다. Retriever가 사유코드별로
    관련 조문을 고르고 같은 Parent의 인접 Child를 확장한 뒤, 여기서는 법령의
    제출 문장과 번호 목록을 체크리스트용 이름으로 변환한다.

    서로 다른 조문의 서류를 합치면 초기 신고서와 사후관리 보고서가 한 체크리스트에
    섞일 수 있으므로, RAG 순위상 가장 먼저 발견되는 '거래 당사자 제출' 핵심 조문
    하나에서만 목록을 만든다. 추출 실패 시 빈 목록을 반환하여 호출부가 기존 CSV
    테스트 목록으로 안전하게 폴백할 수 있게 한다.
    """

    extraction = _extract_from_matches(regulation_matches, max_documents=max_documents)
    articles = [extraction.article] if extraction.article else []
    return [item.name for item in extraction.documents], articles


def build_required_documents_result(
    reason_code: ReasonCode,
    regulation_matches: list[RegulationMatch] | None = None,
) -> RequiredDocumentsResult:
    """필요서류 체크리스트를 만든다.

    1) 관련 법령 RAG 원문에서 거래 당사자가 제출해야 하는 서류를 추출한다.
    2) RAG 결과가 없거나 문서명을 안정적으로 추출하지 못하면 기존
       ``reason_codes.csv``의 테스트용 목록으로 폴백한다.

    함수 시그니처는 기존 호출과 호환되도록 ``regulation_matches``를 선택 인자로
    두었다. UI 구성/체크박스 동작은 변경하지 않는다.
    """

    extraction = _extract_from_matches(regulation_matches)
    if extraction.documents:
        article_note = f" ({extraction.article})" if extraction.article else ""
        status_note = (
            "목록 anchor와 번호 항목을 함께 확인했습니다."
            if extraction.status == "COMPLETE"
            else "서식명은 확인했지만 첨부목록이 완전히 이어졌는지는 추가 확인이 필요합니다."
        )
        return RequiredDocumentsResult(
            items=[
                RequiredDocumentItem(
                    name=item.name,
                    checked=False,
                    is_conditional=item.is_conditional,
                    source_article=extraction.article,
                    form_reference=item.form_reference,
                )
                for item in extraction.documents
            ],
            is_sample=bool(regulation_matches) and all(m.is_sample for m in regulation_matches or []),
            extraction_status=extraction.status,
            source_note=(
                f"RAG 법령 원문에서 추출한 거래 당사자 제출서류 후보{article_note}. "
                f"{status_note} 실제 제출 필요 여부는 은행원이 원문과 함께 재확인하세요."
            ),
        )

    return RequiredDocumentsResult(
        items=[RequiredDocumentItem(name=doc, checked=False) for doc in reason_code.required_documents],
        is_sample=True,
        extraction_status=extraction.status,
        source_note=(
            f"RAG 추출 상태가 {extraction.status}라 사유코드 {reason_code.code} "
            f"({reason_code.name})의 테스트용 목록을 표시합니다."
        ),
    )
