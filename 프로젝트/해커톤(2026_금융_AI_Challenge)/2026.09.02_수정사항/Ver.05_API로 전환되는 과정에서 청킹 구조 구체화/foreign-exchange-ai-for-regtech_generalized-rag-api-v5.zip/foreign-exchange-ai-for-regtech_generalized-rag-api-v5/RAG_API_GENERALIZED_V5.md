# 범용 필요서류 RAG + 국가법령정보 API V5

V5는 국가법령정보 행정규칙 JSON이 전체 본문을 줄바꿈 없는 한 문자열로
반환하는 실제 형식을 반영한다.

## V4에서 수정된 핵심 문제

- 외국환거래규정 전체가 하나의 `제1-1조` Parent로 저장되던 문제 수정
- 줄바꿈이 없어도 `제9-5조(해외직접투자의 신고 등)` 형태로 조문 분리
- 본문 속 `제2-6조(거주자가 ... 경우에 한한다)` 같은 인용은 조문 heading에서 제외
- 항(①), 호(1.), 목(가.) 경계를 복원해 기존 Parent-Child chunker 재사용
- 삭제된 빈 호 `2. 3.`가 앞 문서명에 붙는 현상 제거
- 검색 실패 화면의 고정 `RAG_MODE=mock` 문구를 실제 실행 모드 기준으로 변경

실제 API 응답 검증 결과는 외국환거래법 43개, 시행령 71개,
외국환거래규정 206개 조문으로 분리됐다. 법인설립 질의에서는 제9-5조 한 건을
검색하고 필수서류 4건과 조건부 `(요구 시)` 서류 1건을 `COMPLETE`로 추출했다.

## 설정

기존 `.env`의 다른 값은 그대로 두고 다음 값을 사용한다.

```dotenv
RAG_MODE=api
LAW_API_KEY=발급받은_OC_값
LAW_API_BASE_URL=https://www.law.go.kr/DRF
LAW_API_TIMEOUT=30
LAW_API_CACHE_DIR=./data/law_api_cache
LAW_API_REFRESH_HOURS=24
LAW_API_INCLUDE_APPENDICES=true
```

실제 `.env`와 API 키는 ZIP에 포함하지 않는다.

## 기존 V4 캐시 처리

코드가 자동으로 새 파일과 컬렉션을 사용한다.

- snapshot: `foreign_exchange_snapshot_v3.json`
- Chroma collection/Parent/form store: `hierarchical_v5`/`v5`

따라서 기존 `snapshot_v2`와 V4 Chroma 파일을 직접 삭제할 필요가 없다. 새 버전
최초 실행 시 API 원문을 다시 받아 V5 인덱스를 생성하며, 이후에는 V3 snapshot과
V5 인덱스를 재사용한다.
