"""화면 4 - 관련 법령 및 필요서류 (섹션 29, 15~18).

RAG 검색 결과는 은행원의 업무 참고 정보이며 법률적 최종 판단이 아니다.
필요서류는 RAG(사유코드 기준)가 안내하되, 실제 서류 확인은 은행원이
직접 수행하고 화면에서 체크한다. 증빙서류 자체는 OCR로 읽지 않는다.
"""

from __future__ import annotations

from decimal import Decimal

import streamlit as st

from config.settings import get_settings
from database.connection import get_session
from database.models import TransactionRequest as TransactionORM
from schemas.analysis import RequiredDocumentItem, RequiredDocumentsResult
from rag.retriever import RagRetriever, build_required_document_query
from services.payment_procedure import evaluate_payment_procedure
from services.reason_code.mapper import build_required_documents_result
from frontend import theme
from utils.labels import DESIGNATED_BANK_STATUS_LABELS, label
from utils.logging import get_logger

logger = get_logger(__name__)


@st.cache_resource
def _get_rag_retriever() -> RagRetriever:
    """RagRetriever(Chroma client + Ollama 임베딩 클라이언트 보유)를 프로세스당
    한 번만 만들어 재사용한다 - ui/transaction_analysis.py의
    _get_reason_code_mapper()와 동일한 이유."""

    return RagRetriever()


def render() -> None:
    reason_code = st.session_state.confirmed_reason_code
    analysis = st.session_state.analysis
    transaction = st.session_state.transaction_request
    system_lookup = st.session_state.system_lookup

    # 이 화면의 법령 검색/필요서류는 확정된 사유코드를 기준으로 만들어지므로,
    # 사유코드가 없으면(③단계를 건너뛰고 바로 온 경우) 검색 자체를 실행하지
    # 않고 아래에서 빈 상태로 안내만 표시한다.
    if reason_code is not None:
        retriever = _get_rag_retriever()
        rag_cache_key = "|".join(
            [
                reason_code.code,
                analysis.normalized_purpose if analysis else "",
                analysis.transaction_action if analysis else "",
                transaction.raw_transaction_purpose if transaction else "",
                retriever.index_version,
            ]
        )
        # regulation_matches/required_documents는 확정된 사유코드 기준으로 만들어진다.
        # 캐시가 비어있는지만 볼 게 아니라, 마지막으로 만들어진 사유코드와 지금
        # 확정된 사유코드가 같은지도 확인해야 한다 - 사이드바로 되돌아가 사유코드를
        # 다른 걸로 다시 선택한 경우, 옛 사유코드 기준 결과가 그대로 남아있으면
        # 안 되기 때문이다.
        stale_cache = st.session_state.get("regulation_matches_for_code") != rag_cache_key
        if stale_cache:
            # 새 거래문맥 검색이 실패하더라도 이전 사유의 결과가 화면에 남지 않게
            # 먼저 stale 결과를 비운다.
            st.session_state.regulation_matches = []
            st.session_state.required_documents = None
        if not st.session_state.regulation_matches or stale_cache:
            # 해외직접투자 같은 특정 사유에 고정하지 않고, 현재 확정된 사유코드의
            # 이름/카테고리/키워드/거래문맥을 이용해 범용 필요서류 Query를 만든다.
            # 화면 구성은 그대로 두고 Retrieval 입력만 바뀐다.
            query_text = build_required_document_query(
                reason_name=reason_code.name,
                reason_category=reason_code.category,
                reason_description=reason_code.description,
                reason_keywords=reason_code.keywords,
                normalized_purpose=analysis.normalized_purpose if analysis else None,
                raw_purpose=transaction.raw_transaction_purpose if transaction else None,
            )
            try:
                with st.spinner("관련 법령/규정을 검색하는 중입니다..."):
                    st.session_state.regulation_matches = retriever.search(
                        query_text,
                        # UI는 결과 개수만큼 expander를 자동 생성한다. 최대 5개까지
                        # 허용하되 Retriever의 Parent 검증/상대점수 기준을 통과한
                        # 조문만 반환하므로 빈 칸 채우기식 결과는 만들지 않는다.
                        top_k=5,
                        regulation_tags=reason_code.regulation_tags,
                        search_intent="required_documents",
                        focus_terms=[
                            reason_code.name,
                            reason_code.category,
                            reason_code.description,
                            *(reason_code.keywords or []),
                            analysis.normalized_purpose if analysis else "",
                        ],
                        action_terms=[
                            reason_code.name,
                            analysis.transaction_action if analysis else "",
                        ],
                    )
                st.session_state.regulation_matches_for_code = rag_cache_key
                st.session_state.regulation_embedding_backend = retriever.embedding_backend
            except Exception:
                logger.exception("법령 RAG 검색 중 예기치 못한 오류")
                st.session_state.regulation_matches = []
                st.session_state.required_documents = None
                st.session_state.regulation_matches_for_code = rag_cache_key
                st.error("법령/규정 검색 중 오류가 발생했습니다. 새로고침 후 다시 시도해주세요.")

        if st.session_state.required_documents is not None:
            if st.session_state.get("required_documents_for_code") != rag_cache_key:
                st.session_state.required_documents = None

    # 아래 "필요서류 체크 = 다음 버튼 게이팅" 조건에 쓰인다. 지급 절차
    # 판정에서 은행원이 "무증빙"을 선택하면(제4-3조 예외 적용) 애초에
    # 증빙서류 자체가 필요 없는 거래이므로, 사유코드의 필요서류 체크를
    # 강제하지 않는다 - True(증빙)를 기본값으로 둬 사유코드가 없거나
    # 지급 절차 판정 섹션이 아직 렌더링되지 않은 경우에는 기존과 동일하게
    # 체크를 요구한다.
    is_documented = True

    with st.container(border=True, key="fx_card_regulation"):
        theme.section_title("④", "관련 법령 · 필요서류", "RAG 검색 근거와 필요서류를 확인하고, 실제 제출 서류는 직접 대조 후 체크하세요.")

        # ②단계 거래정보 확정 시 이미 조회해둔 system_lookup(당행 등록
        # 고객 마스터 또는 미등록 시 해시 Mock)을 그대로 재사용한다 - DB를
        # 다시 조회하지 않는다. 필요서류 판단 시 "이 고객이 이 목적으로
        # 이미 지정거래은행 등록이 돼 있는지" 참고하라는 의도.
        if system_lookup is not None:
            st.markdown("##### 🔎 시스템 조회 정보")
            with st.container(border=True, key="fx_card_reg_lookup"):
                st.caption(
                    "실제 금융결제원/신용정보원/은행 Core DB 연동이 아닌 프로토타입 시연용 "
                    "Mock 데이터입니다(당행 등록 고객 마스터 100건 또는 식별정보 해시 기반). "
                    "실제 신용/제재 조회 결과가 아니므로 업무 판단 근거로 사용하지 마세요."
                )

                # getattr로 읽는 이유는 transaction_analysis.py와 동일 -
                # 세션에 남은 옛 system_lookup 객체가 새 필드를 아직 갖고
                # 있지 않을 수 있어 방어적으로 접근한다.
                is_registered = getattr(system_lookup, "is_registered_customer", False)
                if is_registered:
                    st.caption("✅ 당행 등록 고객입니다.")
                else:
                    st.caption("🆕 당행 등록 고객 마스터에서 조회되지 않는 고객입니다(미등록/신규).")

                accumulated = system_lookup.annual_accumulated_usd
                limit = getattr(system_lookup, "annual_remittance_limit_usd", None)
                remaining = (limit - accumulated) if limit else None

                r1, r2, r3 = st.columns(3)
                r1.metric("연간한도(USD)", f"{limit:,.0f}" if limit else "-")
                r2.metric("연간누계액(USD)", f"{accumulated:,.0f}")
                r3.metric("잔여한도액(USD)", f"{remaining:,.0f}" if remaining is not None else "-")
                if remaining is not None and remaining < 0:
                    st.warning("🧪 Mock 데이터 기준 연간 송금 한도를 초과했습니다.")

                bank_status = getattr(system_lookup, "designated_bank_status", "NONE")

                c1, c2, c3, c4 = st.columns(4)
                c1.metric("지정거래은행", label(DESIGNATED_BANK_STATUS_LABELS, bank_status))
                c2.metric("기존지정목적", system_lookup.designated_purpose or "-")
                c3.metric("신용등급", getattr(system_lookup, "credit_rating", None) or "-")
                c4.metric("체납여부", "⚠️ 해당" if system_lookup.is_delinquent_borrower else "해당없음")
                if bank_status == "OTHER":
                    st.warning(
                        "⚠️ 타행이 지정거래은행입니다 - 당행에서 이 거래를 처리하려면 "
                        "지정거래외국환은행 변경 절차가 필요할 수 있습니다."
                    )

        if reason_code is not None:
            st.markdown("##### 📐 지급 절차 판정 (증빙/무증빙)")
            with st.container(border=True, key="fx_card_payment_procedure"):
                st.caption(
                    "외국환거래규정 제4-2조/제4-3조(지급등의 절차 및 예외)와 제10-9조/"
                    "제10-11조(사후관리, 거래외국환은행 지정) 기준 참고 정보입니다. "
                    "최종 처리 가능 여부는 은행원이 확인하세요."
                )
                is_documented = st.radio(
                    "이 송금에 대해 지급 사유를 입증하는 증빙서류를 제출/확인받습니까?",
                    options=[True, False],
                    format_func=lambda v: "예 (증빙)" if v else "아니오 (무증빙)",
                    horizontal=True,
                    key="payment_procedure_is_documented",
                )

                is_capital = reason_code.category == "자본거래"
                bank_status_pp = getattr(system_lookup, "designated_bank_status", "NONE") if system_lookup else "NONE"
                accumulated_usd = system_lookup.annual_accumulated_usd if system_lookup else Decimal("0")
                amount_usd = transaction.remittance_amount if transaction else None
                currency = (transaction.remittance_currency or "").strip().upper() if transaction else ""

                if currency and currency not in ("USD", "달러", "US DOLLAR"):
                    st.caption(
                        f"※ 송금 통화가 '{transaction.remittance_currency}'로 확인되나, "
                        "이 프로토타입은 환전 기능이 없어 금액을 그대로 USD로 간주해 판정합니다(참고용)."
                    )

                result = evaluate_payment_procedure(
                    designated_bank_status=bank_status_pp,
                    is_capital_transaction=is_capital,
                    is_documented=is_documented,
                    amount_usd=amount_usd,
                    accumulated_usd=accumulated_usd,
                )

                if result.can_proceed_as_selected:
                    st.success(f"✅ {result.message}")
                else:
                    st.warning(f"⚠️ {result.message}")
                st.caption(
                    f"근거: {result.citation}. (사후관리 필요 여부는 사유코드 대분류가 "
                    "\"자본거래\"인지로 근사한 것이라, 실제 제10-11조 해당 여부는 은행원이 "
                    "재확인하세요.)"
                )

                with st.expander("📖 관련 조문 원문 확인 (RAG 검색)", expanded=False):
                    citation_key = "|".join(result.citation_articles)
                    if (
                        st.session_state.payment_procedure_citations is None
                        or st.session_state.get("payment_procedure_citations_for_articles")
                        != citation_key
                    ):
                        try:
                            retriever = _get_rag_retriever()
                            st.session_state.payment_procedure_citations = retriever.get_articles(
                                result.citation_articles
                            )
                            st.session_state.payment_procedure_citations_for_articles = citation_key
                        except Exception:
                            logger.exception("지급 절차 근거 조문 RAG 검색 중 예기치 못한 오류")
                            st.session_state.payment_procedure_citations = []
                            st.error("근거 조문 검색 중 오류가 발생했습니다.")

                    proc_matches = st.session_state.payment_procedure_citations
                    if not proc_matches:
                        rag_mode = get_settings().rag_mode
                        if rag_mode == "mock":
                            message = (
                                "샘플 규정 텍스트에는 이 조문들이 포함되어 있지 않습니다. "
                                "RAG_MODE=pdf 또는 api로 실행하면 확인할 수 있습니다."
                            )
                        elif rag_mode == "api":
                            message = (
                                "API 원문 색인에서 해당 조문을 찾지 못했습니다. API 동기화 및 "
                                "조문 단위 색인 로그를 확인해주세요."
                            )
                        else:
                            message = "PDF 원문 색인에서 해당 조문을 찾지 못했습니다."
                        st.caption(f"관련 조문을 찾지 못했습니다. {message}")
                    else:
                        for m in proc_matches:
                            badge = " · 🧪 샘플 데이터" if m.is_sample else ""
                            st.markdown(f"**{m.law_name} {m.article or ''}{badge}**")
                            st.write(m.content)
                            page_info = f", p.{m.page_number}" if m.page_number else ""
                            st.caption(f"출처: {m.file_name}{page_info} (유사도 참고값 {m.score:.0%})")
                            st.divider()

        if reason_code is None:
            st.info("아직 확인된 사유코드가 없습니다. 아래는 빈 상태로 표시되며, ③단계에서 사유코드를 확인하면 관련 법령/필요서류가 채워집니다.")

        col_docs, col_law = st.columns([1.08, 0.92])

        required: RequiredDocumentsResult | None = None
        updated_items: list[RequiredDocumentItem] = []
        all_checked = True

        with col_docs:
            st.markdown("##### 📄 필요서류 (은행원 직접 확인)")

            if reason_code is None:
                st.caption("사유코드를 확인하면 이 사유코드에 필요한 서류 목록이 여기에 표시됩니다.")
            else:
                if not is_documented:
                    st.caption(
                        "ℹ️ 위 지급 절차 판정에서 \"무증빙\"을 선택했습니다 - 제4-3조 예외에 "
                        "해당하는 거래는 증빙서류 없이 처리할 수 있으므로, 아래 체크는 "
                        "참고용이며 전부 체크하지 않아도 다음 단계로 진행할 수 있습니다."
                    )

                if st.session_state.required_documents is None:
                    # UI는 그대로 유지하되, 체크박스 데이터는 우선 RAG로 검색된
                    # 관련 법령 원문에서 추출한다. 추출 실패 시 mapper 내부에서
                    # 기존 reason_codes.csv 테스트 목록으로 자동 폴백한다.
                    st.session_state.required_documents = build_required_documents_result(
                        reason_code,
                        regulation_matches=st.session_state.regulation_matches,
                    )
                    st.session_state.required_documents_for_code = rag_cache_key

                required = st.session_state.required_documents
                st.caption(required.source_note or "")

                for item in required.items:
                    checked = st.checkbox(item.name, value=item.checked, key=f"doc_{item.name}")
                    updated_items.append(item.model_copy(update={"checked": checked}))
                required.items = updated_items

                # '(요구 시)' 조건부 서류는 체크하지 않아도 다음 단계 진행을 막지 않는다.
                all_checked = all(item.checked or item.is_conditional for item in updated_items)
                if updated_items and not all_checked and is_documented:
                    st.caption("※ 실제 제출된 서류를 은행원이 직접 확인한 후 체크하세요.")

        with col_law:
            st.markdown("##### 📚 관련 법령")
            if reason_code is None:
                st.caption("사유코드를 확인하면 관련 법령 검색 결과가 여기에 표시됩니다.")
            else:
                if st.session_state.get("regulation_embedding_backend") == "hash":
                    st.caption(
                        "⚠️ Ollama 임베딩 연결에 실패해 경량 해시 임베딩으로 검색했습니다 - "
                        "사이드바의 RAG 배지가 'bge-m3 + ChromaDB'로 표시되어도 이 검색 결과의 "
                        "정확도는 낮을 수 있습니다."
                    )
                matches = st.session_state.regulation_matches
                if not matches:
                    st.warning("관련 법령 또는 규정 정보를 찾지 못했습니다. 최신 내부 규정 확인이 필요합니다.")
                else:
                    for idx, m in enumerate(matches):
                        badge = " · 🧪 샘플 데이터" if m.is_sample else ""
                        with st.expander(f"{m.law_name} {m.article or ''}{badge}", expanded=False):
                            st.write(m.content)
                            page_info = f", p.{m.page_number}" if m.page_number else ""
                            st.caption(f"출처: {m.file_name}{page_info} (유사도 참고값 {m.score:.0%})")
                    if any(m.is_sample for m in matches):
                        st.caption(
                            "🧪 샘플 데이터로 표시된 항목은 실제 국가법령정보센터 PDF가 아닌 시연용 예시입니다. "
                            "실제 업무에는 최신 법령 원문을 확인하세요."
                        )

        # 무증빙(제4-3조 예외)을 선택했으면 애초에 증빙서류가 필요 없는
        # 거래이므로, 사유코드의 필요서류 체크는 게이팅 조건에서 뺀다.
        require_doc_check = reason_code is not None and is_documented

        st.divider()
        if require_doc_check and not all_checked:
            st.caption("⚠️ 필요서류를 모두 체크해야 다음 단계로 진행할 수 있습니다.")

        foot_left, foot_right = st.columns([1.08, 0.92])
        with foot_left:
            back_clicked = st.button("이전", type="primary", key="fx_reg_prev")
        with foot_right:
            # 버튼 자체 크기는 그대로 두고(container_width로 늘리지 않고),
            # CSS로 이 버튼의 wrapper만 오른쪽 끝에 붙인다.
            next_clicked = st.button(
                "다음", type="primary", key="fx_reg_next",
                disabled=(require_doc_check and not all_checked),
            )

    if next_clicked:
        if required is not None:
            st.session_state.required_documents = required
            if st.session_state.db_transaction_id:
                with get_session() as session:
                    row = session.get(TransactionORM, st.session_state.db_transaction_id)
                    if row is not None:
                        row.required_documents_checked = {i.name: i.checked for i in updated_items}
        st.session_state.step = 5
        st.session_state.max_step_reached = max(st.session_state.max_step_reached, 5)
        st.rerun()

    if back_clicked:
        st.session_state.step = 3
        st.rerun()
