"""RAG 검색 Pipeline 오케스트레이션 (섹션 15~17).

국가법령정보센터 PDF(``RAG_MODE=pdf``) 또는 샘플 규정 데이터
(``RAG_MODE=mock``)를 읽어 Chunking → Embedding → Vector DB 색인을 수행하고,
질의에 대해 관련 법령/조문을 검색한다.

RAG 결과는 은행원의 업무 참고 정보이며 법률적 최종 판단으로 표현하지 않는다.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path

import chromadb
from sqlalchemy import select

from config.settings import get_settings
from database.connection import get_session
from database.models import RagChunk, RagDocument
from schemas.analysis import RegulationMatch
from rag.chunker import chunk_pages
from rag.document_loader import load_all_regulation_pdfs
from rag.embedder import ChunkEmbedder
from rag.sample_regulations import SAMPLE_FILE_NAME, SAMPLE_REGULATIONS
from utils.logging import get_logger

logger = get_logger(__name__)


# 필요서류 검색은 단순 의미 유사도만으로 정렬하면 "해외직접투자의 수단"처럼
# 거래 주제는 맞지만 제출서류와 무관한 조문이 상위에 오를 수 있다. 아래 표현은
# 법령에서 실제 제출/첨부 의무를 나타낼 때 반복적으로 쓰이는 문구만 모아 둔 것이다.
_REQUIRED_DOCUMENT_STRONG_CUES = (
    "다음 각호의 서류",
    "다음 각 호의 서류",
    "서류를 첨부",
    "서류를 첨부하여",
    "첨부하여 제출",
    "신고서",
    "신청서",
    "구비서류",
    "증빙서류",
    "제출하여야",
    "제출해야",
    "별지 제",
)
_REQUIRED_DOCUMENT_WEAK_CUES = ("서류", "첨부", "제출", "신고", "신청", "입증")
# 이 화면의 '필요서류'는 현재 거래를 실행/신고할 때 확인할 서류가 목적이다.
# 사후관리·청산·변경 보고 문구는 완전히 제외하지는 않고 동점 시 뒤로 보내는
# 정도의 작은 패널티만 준다.
_REQUIRED_DOCUMENT_POST_CUES = (
    "사후관리",
    "청산",
    "변경사항",
    "내용을 변경",
    "사후보고",
    "연간사업실적보고",
)
_REQUIRED_DOCUMENT_SPECIAL_CUES = (
    "규정에도 불구하고",
    "에도 불구하고",
)
_FOCUS_STOPWORDS = {
    "관련", "거래", "송금", "지급", "사유", "목적", "자본거래", "경상거래",
    "신고", "신청", "제출", "서류", "필요서류", "증빙서류", "첨부서류",
}
_FOCUS_TOKEN_RE = re.compile(r"[가-힣A-Za-z0-9]+")


@dataclass(frozen=True)
class _SearchCandidate:
    metadata: dict
    document: str
    semantic_score: float
    rank_score: float
    tag_overlap: int
    topic_overlap: int
    has_document_cue: bool


def _normalize_focus_terms(values: list[str] | None) -> list[str]:
    """사유코드명 등에서 검색 주제를 나타내는 짧은 핵심어를 뽑는다."""

    terms: list[str] = []
    seen: set[str] = set()
    for value in values or []:
        for token in _FOCUS_TOKEN_RE.findall(str(value or "")):
            token = token.strip()
            if len(token) < 2 or token in _FOCUS_STOPWORDS or token in seen:
                continue
            seen.add(token)
            terms.append(token)
    return terms[:12]


def _required_document_rank_score(
    *,
    text: str,
    semantic_score: float,
    focus_terms: list[str],
) -> tuple[float, bool]:
    """필요서류 목적에 맞게 Child 후보를 재정렬할 점수를 만든다.

    임베딩 유사도는 그대로 핵심 신호로 유지하되, 실제 법령 문장에
    '신고서에 서류를 첨부하여 제출' 같은 제출 의무 표현이 있는 Child를
    우선한다. RegulationMatch.score에는 이 점수가 아니라 기존 의미 유사도를
    그대로 노출하므로 UI의 '유사도 참고값' 의미도 바뀌지 않는다.
    """

    normalized = re.sub(r"\s+", " ", text or "")
    strong_hits = sum(1 for cue in _REQUIRED_DOCUMENT_STRONG_CUES if cue in normalized)
    weak_hits = sum(1 for cue in _REQUIRED_DOCUMENT_WEAK_CUES if cue in normalized)
    post_hits = sum(1 for cue in _REQUIRED_DOCUMENT_POST_CUES if cue in normalized)
    special_hits = sum(1 for cue in _REQUIRED_DOCUMENT_SPECIAL_CUES if cue in normalized)
    topic_hits = sum(1 for term in focus_terms if term in normalized)

    # 강한 제출의무 표현은 크게, 단순 '신고/제출' 출현은 작게 반영한다.
    intent_bonus = min(0.55, strong_hits * 0.11 + weak_hits * 0.025)
    topic_bonus = min(0.24, topic_hits * 0.08)
    post_penalty = min(0.18, post_hits * 0.06)
    special_penalty = min(0.12, special_hits * 0.06)
    rank_score = semantic_score + intent_bonus + topic_bonus - post_penalty - special_penalty
    return rank_score, bool(strong_hits or weak_hits >= 2)


class RagRetriever:
    def __init__(self) -> None:
        settings = get_settings()
        self._settings = settings
        self._embedder = ChunkEmbedder()
        chroma_client = chromadb.PersistentClient(path=settings.chroma_persist_dir)
        self._collection = chroma_client.get_or_create_collection(
            # 기존 고정-window 인덱스와 섞이지 않도록 실험 버전을 별도 collection으로 둔다.
            name=f"rag_chunks_hierarchical_v1_{self._embedder.backend_name}",
            metadata={"hnsw:space": "cosine"},
        )

        # rag_v2_ordered와 같은 원칙으로 긴 Parent 조문을 모든 Child metadata에
        # 반복 저장하지 않는다. Child에는 parent_id만 두고 Parent는 JSON에 1회 저장한다.
        self._parent_store_path = Path(settings.chroma_persist_dir) / (
            f"rag_parents_hierarchical_v1_{self._embedder.backend_name}.json"
        )
        self._parents = self._load_parent_store()

    @property
    def embedding_backend(self) -> str:
        """실제 사용 중인 임베딩 백엔드("ollama"/"hash"). services/reason_code/mapper.py의
        동일 프로퍼티 참고 - Ollama 연결 실패 시 조용히 해시 임베딩으로 폴백하는 것을
        화면에 노출하기 위함이다."""

        return self._embedder.backend_name

    def _load_parent_store(self) -> dict[str, dict]:
        if not self._parent_store_path.is_file():
            return {}
        try:
            with self._parent_store_path.open("r", encoding="utf-8") as f:
                data = json.load(f)
            return data if isinstance(data, dict) else {}
        except Exception:
            logger.exception("RAG Parent 저장소 읽기 실패: %s", self._parent_store_path)
            return {}

    def _save_parent_store(self) -> None:
        self._parent_store_path.parent.mkdir(parents=True, exist_ok=True)
        temp_path = self._parent_store_path.with_suffix(self._parent_store_path.suffix + ".tmp")
        with temp_path.open("w", encoding="utf-8") as f:
            json.dump(self._parents, f, ensure_ascii=False, indent=2)
        temp_path.replace(self._parent_store_path)

    def _register_parent(
        self,
        *,
        parent_id: str | None,
        content: str,
        law_name: str,
        article: str | None,
        file_name: str,
        page_number: int | None,
    ) -> str:
        resolved_id = parent_id or f"{file_name}:{article or 'generic'}:{len(self._parents)}"
        self._parents[resolved_id] = {
            "content": content,
            "law_name": law_name,
            "article": article or "",
            "file_name": file_name,
            "page_number": page_number or 0,
        }
        return resolved_id

    # ------------------------------------------------------------------
    # 색인
    # ------------------------------------------------------------------

    def build_index(self, force: bool = False) -> int:
        if self._collection.count() > 0:
            if not force and self._parents:
                logger.info("RAG 인덱스가 이미 존재합니다 (force=True로 재생성 가능)")
                return self._collection.count()
            if not force and not self._parents:
                logger.warning("Child 인덱스는 있으나 Parent 저장소가 없어 자동 재생성합니다.")
            existing_ids = self._collection.get()["ids"]
            if existing_ids:
                self._collection.delete(ids=existing_ids)

        # 재색인 시 Parent도 새 원문 기준으로 다시 구성한다.
        self._parents = {}

        # SQL의 rag_documents/rag_chunks는 "가장 최근에 색인한 한 벌"만 원문 출처로
        # 보존한다. 임베딩 백엔드(Mock 해시 ↔ Ollama)를 변경해 컬렉션 이름이
        # 바뀌면 이전 컬렉션의 벡터는 그대로 남지만 SQL 원문은 새로 색인한
        # 데이터로 교체된다 - 프로토타입 범위에서는 이 제약을 감수한다.
        with get_session() as session:
            session.execute(RagChunk.__table__.delete())
            session.execute(RagDocument.__table__.delete())

        chunk_rows = self._build_source_chunks()
        if not chunk_rows:
            logger.warning("색인할 RAG 문서가 없습니다.")
            return 0

        texts = [row["content"] for row in chunk_rows]
        embeddings = self._embedder.embed(texts)

        self._collection.add(
            ids=[str(row["chunk_id"]) for row in chunk_rows],
            embeddings=embeddings,
            documents=texts,
            metadatas=[
                {
                    "law_name": row["law_name"],
                    "article": row["article"] or "",
                    "file_name": row["file_name"],
                    "page_number": row["page_number"] or 0,
                    "is_sample": row["is_sample"],
                    "regulation_tags": "|".join(row.get("regulation_tags") or []),
                    # Child 벡터가 검색되면 조문 전체 Parent를 복원하기 위한 연결 정보.
                    "parent_id": row.get("parent_id") or "",
                    "child_index": row.get("child_index", 0),
                    "child_count": row.get("child_count", 1),
                }
                for row in chunk_rows
            ],
        )
        self._save_parent_store()
        logger.info(
            "RAG 청크 %d건 / Parent %d건 인덱싱 완료 (embedding backend=%s)",
            len(chunk_rows),
            len(self._parents),
            self._embedder.backend_name,
        )
        return len(chunk_rows)

    def _build_source_chunks(self) -> list[dict]:
        """PDF(있으면) 또는 샘플 규정 데이터를 SQL(RagDocument/RagChunk)에 저장하고,
        Chroma 색인에 필요한 정보를 함께 반환한다."""

        if self._settings.rag_mode == "pdf":
            pages = load_all_regulation_pdfs(self._settings.regulation_pdf_dir)
            if pages:
                return self._store_pdf_chunks(pages)
            logger.warning(
                "RAG_MODE=pdf 이지만 data/regulations/ 에 PDF가 없어 샘플 규정으로 대체합니다."
            )

        return self._store_sample_chunks()

    def _store_pdf_chunks(self, pages) -> list[dict]:
        """PDF를 파일 단위로 묶어 조(Parent) → Child 계층 청킹한다.

        기존에는 각 PDF 페이지를 독립적으로 600자 슬라이딩 윈도우로 잘랐기
        때문에 하나의 조문이 페이지를 넘기면 문맥이 끊겼다. 이제 같은 파일의
        페이지들을 순서대로 ``chunk_pages``에 넘겨 조문 전체 Parent를 먼저 만들고,
        항·호·목/재귀 분할로 만든 Child만 임베딩 대상으로 저장한다.
        """

        rows: list[dict] = []
        pages_by_file: dict[str, list] = {}
        for page in pages:
            pages_by_file.setdefault(page.file_name, []).append(page)

        with get_session() as session:
            for file_name, file_pages in pages_by_file.items():
                file_pages = sorted(file_pages, key=lambda page: page.page_number)

                doc = RagDocument(
                    file_name=file_name,
                    title=file_name,
                    is_sample=False,
                )
                session.add(doc)
                session.flush()

                chunks = chunk_pages(
                    file_pages,
                    source_name=file_name,
                )

                for i, chunk in enumerate(chunks):
                    row = RagChunk(
                        document_id=doc.id,
                        chunk_index=i,
                        page_number=chunk.page_number,
                        article=chunk.article,
                        # SQL에는 실제 검색 단위인 Child를 보존한다.
                        content=chunk.content,
                    )
                    session.add(row)
                    session.flush()

                    parent_id = self._register_parent(
                        parent_id=chunk.parent_id,
                        content=chunk.parent_content or chunk.content,
                        law_name=doc.title or doc.file_name,
                        article=row.article,
                        file_name=doc.file_name,
                        page_number=row.page_number,
                    )
                    rows.append(
                        {
                            "chunk_id": row.id,
                            "content": row.content,
                            "law_name": doc.title or doc.file_name,
                            "article": row.article,
                            "file_name": doc.file_name,
                            "page_number": row.page_number,
                            "is_sample": False,
                            "regulation_tags": [],
                            "parent_id": parent_id,
                            "child_index": chunk.child_index,
                            "child_count": chunk.child_count,
                        }
                    )
        return rows

    def _store_sample_chunks(self) -> list[dict]:
        rows: list[dict] = []
        with get_session() as session:
            doc = RagDocument(file_name=SAMPLE_FILE_NAME, title="외국환거래규정 (샘플)", is_sample=True)
            session.add(doc)
            session.flush()

            for i, sample in enumerate(SAMPLE_REGULATIONS):
                row = RagChunk(
                    document_id=doc.id,
                    chunk_index=i,
                    page_number=None,
                    article=sample.article,
                    content=sample.content,
                )
                session.add(row)
                session.flush()
                parent_id = self._register_parent(
                    parent_id=f"sample:{sample.law_name}:{sample.article}",
                    content=row.content,
                    law_name=sample.law_name,
                    article=row.article,
                    file_name=doc.file_name,
                    page_number=None,
                )
                rows.append(
                    {
                        "chunk_id": row.id,
                        "content": row.content,
                        "law_name": sample.law_name,
                        "article": row.article,
                        "file_name": doc.file_name,
                        "page_number": None,
                        "is_sample": True,
                        "regulation_tags": sample.regulation_tags,
                        "parent_id": parent_id,
                        "child_index": 0,
                        "child_count": 1,
                    }
                )
        return rows

    # ------------------------------------------------------------------
    # 검색
    # ------------------------------------------------------------------

    def search(
        self,
        query_text: str,
        top_k: int = 5,
        regulation_tags: list[str] | None = None,
        *,
        search_intent: str = "general",
        focus_terms: list[str] | None = None,
    ) -> list[RegulationMatch]:
        """관련 법령/조문을 검색한다.

        ``search_intent="required_documents"`` 인 경우에는 임베딩 유사도로
        후보를 넉넉히 가져온 뒤, '신고서/신청서 + 첨부/제출/서류'처럼 실제
        제출 의무가 나타나는 Child를 재정렬한다. 이 단계는 PDF/API 원문 형식과
        무관한 Retrieval 로직이므로 나중에 국가법령정보 공동활용 API로 입력원을
        바꿔도 그대로 재사용할 수 있다.

        ``regulation_tags`` 는 샘플 문서처럼 metadata에 태그가 있는 경우에만
        필터로 사용한다. 현재 PDF 색인에는 태그가 없으므로 PDF 검색 정확도는
        ``search_intent``/``focus_terms``와 임베딩 결과가 담당한다.
        """

        if self._collection.count() == 0:
            self.build_index()
        collection_count = self._collection.count()
        if collection_count == 0:
            return []

        query_embedding = self._embedder.embed([query_text])[0]

        # 기존 일반 검색(지급 절차 근거 조문 등)은 동작을 바꾸지 않기 위해 전체
        # 후보를 그대로 조회한다. 필요서류 검색만 재정렬에 충분한 후보(최소 30개)를
        # 가져와 비용을 제한한다.
        if search_intent == "required_documents":
            candidate_count = min(collection_count, max(top_k * 12, 30))
        else:
            candidate_count = collection_count
        result = self._collection.query(
            query_embeddings=[query_embedding], n_results=candidate_count
        )

        requested_tags = set(regulation_tags or [])
        normalized_focus_terms = _normalize_focus_terms(focus_terms)
        candidates: list[_SearchCandidate] = []

        for distance, metadata, document in zip(
            result["distances"][0], result["metadatas"][0], result["documents"][0]
        ):
            semantic_score = max(0.0, min(1.0, 1.0 - distance))
            metadata_tags = set(filter(None, (metadata.get("regulation_tags") or "").split("|")))
            tag_overlap = len(requested_tags & metadata_tags) if requested_tags else 0

            if search_intent == "required_documents":
                rank_score, has_document_cue = _required_document_rank_score(
                    text=document,
                    semantic_score=semantic_score,
                    focus_terms=normalized_focus_terms,
                )
            else:
                rank_score = semantic_score
                has_document_cue = True

            topic_overlap = sum(1 for term in normalized_focus_terms if term in document)
            candidates.append(
                _SearchCandidate(
                    metadata=metadata,
                    document=document,
                    semantic_score=semantic_score,
                    rank_score=rank_score,
                    tag_overlap=tag_overlap,
                    topic_overlap=topic_overlap,
                    has_document_cue=has_document_cue,
                )
            )

        # 태그 metadata가 실제로 존재하면서 요청 태그와 겹치는 후보가 있을 때만
        # 기존처럼 태그 범위를 우선한다. PDF는 태그가 비어 있으므로 여기서 잘못
        # 전부 탈락하지 않고 전체 후보를 그대로 사용한다.
        if requested_tags and any(candidate.tag_overlap > 0 for candidate in candidates):
            candidates = [candidate for candidate in candidates if candidate.tag_overlap > 0]

        if search_intent == "required_documents":
            # 사유코드 핵심어(예: 해외직접투자)가 실제 본문에 등장하는 후보가 있으면
            # 우선 그 주제 안으로 범위를 좁힌다. 핵심어가 법령 표현과 달라 한 건도
            # 안 잡히는 경우에는 자동으로 전체 후보에 폴백한다.
            if normalized_focus_terms:
                topic_candidates = [candidate for candidate in candidates if candidate.topic_overlap > 0]
                if topic_candidates:
                    candidates = topic_candidates

            # 제출서류 신호가 있는 후보가 하나라도 있으면 그 후보군 안에서만 Top-K를
            # 고른다. 없을 때는 임베딩 결과로 폴백하여 빈 화면이 되는 것을 막는다.
            document_candidates = [candidate for candidate in candidates if candidate.has_document_cue]
            if document_candidates:
                candidates = document_candidates

            candidates.sort(
                key=lambda candidate: (
                    candidate.tag_overlap,
                    candidate.rank_score,
                    candidate.semantic_score,
                ),
                reverse=True,
            )
        else:
            candidates.sort(
                key=lambda candidate: (candidate.tag_overlap, candidate.semantic_score),
                reverse=True,
            )

        matches: list[RegulationMatch] = []
        seen_parents: set[str] = set()
        for candidate in candidates:
            metadata = candidate.metadata
            parent_key = (
                metadata.get("parent_id")
                or f"{metadata.get('file_name', '')}:{metadata.get('article', '')}"
            )
            if parent_key in seen_parents:
                continue
            seen_parents.add(parent_key)

            matches.append(
                RegulationMatch(
                    law_name=metadata.get("law_name") or "",
                    article=metadata.get("article") or None,
                    # Child 반환 원칙은 유지한다. 재정렬도 Child 기준으로 수행하므로
                    # 사용자가 펼쳐보는 원문은 실제로 점수를 받은 바로 그 Child다.
                    content=candidate.document,
                    file_name=metadata.get("file_name") or "",
                    page_number=(metadata.get("page_number") or None),
                    is_sample=bool(metadata.get("is_sample")),
                    score=round(candidate.semantic_score, 4),
                )
            )
            if len(matches) >= top_k:
                break

        return matches
