"""법령 RAG용 계층적 Parent-Child + 재귀 Chunking.

기존의 ``고정 문자 수 슬라이딩 윈도우``를 다음 구조로 교체한다.

1. 법령의 조(Article) 전체를 Parent로 보존한다.
2. Parent 내부에서는 항·호·목 경계를 우선하여 검색용 Child를 만든다.
3. 하나의 구조 단위가 너무 길 때만 문단 → 줄 → 문장 → 공백 순으로
   재귀 분할한다.
4. 위 경계로도 나눌 수 없는 긴 텍스트만 마지막 수단으로 overlap 창을 쓴다.
5. 검색은 Child 임베딩으로 수행하고, 검색 결과/LLM 입력도 검색된 Child를
   사용한다. ``parent_content``와 ``parent_id``는 계층 연결과 중복 제거를 위해
   함께 보존한다.

현재 프로젝트의 임베딩 계층(EmbeddingClient/Ollama 또는 hash)은 그대로
유지하기 위해 크기 기준은 문자 수를 사용한다. 추후 임베딩 모델의 tokenizer를
RAG 계층에 노출하면 같은 구조를 토큰 수 기준으로 바꿀 수 있다.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from typing import Iterable, Sequence

# 외국환거래규정은 ``제4-2조`` 형태를 많이 사용하고, 일반 법령은
# ``제7조의2`` 형태도 사용하므로 둘 다 인식한다.
_ARTICLE_RE = re.compile(r"제\s*\d+(?:-\d+)?\s*조(?:의\s*\d+)?")
_ARTICLE_START_RE = re.compile(
    r"^(제\s*\d+(?:-\d+)?\s*조(?:의\s*\d+)?)(?:\s*\(([^)]*)\))?"
)
_CHAPTER_RE = re.compile(r"^제\s*\d+\s*장(?:\s+.*)?$")
_SECTION_RE = re.compile(r"^제\s*\d+\s*절(?:\s+.*)?$")

# 항·호·목 경계. PDF 추출 결과에서 흔히 보이는 표현을 함께 수용한다.
_STRUCTURE_RE = re.compile(
    r"^(?:"
    r"[①-⑳]"  # 항
    r"|제\s*\d+\s*항"
    r"|\d+\s*[.)]"  # 호
    r"|[가-하]\s*[.)]"  # 목
    r")"
)

_DEFAULT_MAX_CHARS = 1200
_DEFAULT_MIN_CHARS = 450
_DEFAULT_OVERLAP = 120


@dataclass
class Chunk:
    """Chroma에 임베딩할 Child와 연결된 Parent 정보를 함께 담는다.

    기존 코드가 사용하던 ``content/page_number/article`` 필드는 그대로 유지한다.
    따라서 Retriever 외의 기존 호출부와도 호환된다.
    """

    content: str
    page_number: int | None
    article: str | None
    parent_content: str | None = None
    parent_id: str | None = None
    child_index: int = 0
    child_count: int = 1
    chapter: str | None = None
    section: str | None = None


@dataclass(frozen=True)
class _SourceLine:
    text: str
    page_number: int | None


@dataclass
class _Parent:
    content: str
    article: str | None
    chapter: str | None
    section: str | None
    page_number: int | None
    lines: list[_SourceLine]
    parent_id: str


@dataclass(frozen=True)
class _Unit:
    text: str
    page_number: int | None


def _normalize_text(text: str) -> str:
    text = str(text or "")
    text = text.replace("\r\n", "\n").replace("\r", "\n").replace("\x00", "")
    lines = [line.rstrip() for line in text.splitlines()]
    return re.sub(r"\n{3,}", "\n\n", "\n".join(lines)).strip()


def _detect_article(text: str) -> str | None:
    match = _ARTICLE_RE.search(text)
    return match.group(0) if match else None


def _stable_id(*values: object) -> str:
    raw = "|".join(str(value) for value in values)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _sliding_window(text: str, max_chars: int, overlap: int) -> list[str]:
    """모든 구조 경계가 실패했을 때만 사용하는 최후 수단 분할."""

    text = text.strip()
    if not text:
        return []
    if len(text) <= max_chars:
        return [text]

    overlap = max(0, min(overlap, max_chars - 1))
    step = max(max_chars - overlap, 1)
    chunks: list[str] = []
    for start in range(0, len(text), step):
        piece = text[start : start + max_chars].strip()
        if piece:
            chunks.append(piece)
        if start + max_chars >= len(text):
            break
    return chunks


def _recursive_split(
    text: str,
    max_chars: int,
    overlap: int,
    separators: Sequence[str] | None = None,
) -> list[str]:
    """문단 → 줄 → 문장 → 공백 순으로 큰 단위를 재귀적으로 분할한다."""

    text = text.strip()
    if not text:
        return []
    if len(text) <= max_chars:
        return [text]

    if separators is None:
        separators = ("\n\n", "\n", ". ", " ")

    if not separators:
        return _sliding_window(text, max_chars=max_chars, overlap=overlap)

    separator = separators[0]
    parts = text.split(separator)
    if len(parts) == 1:
        return _recursive_split(text, max_chars, overlap, separators[1:])

    chunks: list[str] = []
    current_parts: list[str] = []

    for part in parts:
        part = part.strip()
        if not part:
            continue

        candidate_parts = current_parts + [part]
        candidate = separator.join(candidate_parts)
        if len(candidate) <= max_chars:
            current_parts = candidate_parts
            continue

        if current_parts:
            chunks.append(separator.join(current_parts).strip())
            current_parts = []

        if len(part) > max_chars:
            chunks.extend(_recursive_split(part, max_chars, overlap, separators[1:]))
        else:
            current_parts = [part]

    if current_parts:
        chunks.append(separator.join(current_parts).strip())

    return chunks


def _build_source_lines(
    pages: Iterable[tuple[int | None, str]],
) -> list[_SourceLine]:
    lines: list[_SourceLine] = []
    for page_number, text in pages:
        normalized = _normalize_text(text)
        for raw_line in normalized.splitlines():
            lines.append(_SourceLine(text=raw_line.strip(), page_number=page_number))
    return lines


def _parse_parents(
    source_lines: list[_SourceLine],
    source_name: str = "",
) -> list[_Parent]:
    """여러 페이지를 이어 읽으며 조문 전체를 Parent로 만든다."""

    parents: list[_Parent] = []
    current_lines: list[_SourceLine] = []
    current_chapter: str | None = None
    current_section: str | None = None

    def flush() -> None:
        nonlocal current_lines
        if not current_lines:
            return

        non_empty = [line for line in current_lines if line.text]
        if not non_empty:
            current_lines = []
            return

        first = non_empty[0]
        article = _detect_article(first.text)
        content = _normalize_text("\n".join(line.text for line in current_lines))
        parent_id = _stable_id(source_name, article or "generic", content)
        parents.append(
            _Parent(
                content=content,
                article=article,
                chapter=current_chapter,
                section=current_section,
                page_number=first.page_number,
                lines=list(current_lines),
                parent_id=parent_id,
            )
        )
        current_lines = []

    for source_line in source_lines:
        line = source_line.text.strip()
        if not line:
            if current_lines:
                current_lines.append(source_line)
            continue

        if _CHAPTER_RE.match(line):
            flush()
            current_chapter = line
            current_section = None
            continue

        if _SECTION_RE.match(line):
            flush()
            current_section = line
            continue

        if _ARTICLE_START_RE.match(line):
            flush()
            current_lines = [source_line]
            continue

        if current_lines:
            current_lines.append(source_line)

    flush()
    return parents




def _article_header(parent: _Parent) -> str:
    """Child에 반복해서 붙일 최소 조문 헤더(번호 + 제목)만 추출한다."""

    if not parent.lines:
        return parent.article or ""
    first_line = parent.lines[0].text.strip()
    match = _ARTICLE_START_RE.match(first_line)
    if match:
        return first_line[: match.end()].strip()
    return parent.article or first_line


def _structural_units(parent: _Parent, max_chars: int, overlap: int) -> list[_Unit]:
    """Parent 안에서 항·호·목을 우선 경계로 만들고 긴 단위만 재귀 분할한다."""

    non_empty_lines = [line for line in parent.lines if line.text.strip()]
    if not non_empty_lines:
        return []

    article_line = non_empty_lines[0]
    body_lines = list(non_empty_lines[1:])

    # PDF에서는 ``제1조(목적) 이 법은 ...``처럼 조문 헤더와 본문 첫 문장이
    # 한 줄에 붙어 추출되는 경우가 많다. 헤더 뒤의 나머지 문장을 버리지 않고
    # 첫 번째 본문 단위로 되돌려 넣는다.
    header = _article_header(parent)
    first_line_tail = article_line.text[len(header):].strip() if header else ""
    if first_line_tail:
        body_lines.insert(
            0,
            _SourceLine(text=first_line_tail, page_number=article_line.page_number),
        )

    # 조문 제목만 있고 별도 본문이 없는 예외 문서는 헤더 자체를 검색 단위로 둔다.
    if not body_lines:
        return [_Unit(text=header or parent.content, page_number=parent.page_number)]

    raw_units: list[list[_SourceLine]] = []
    current: list[_SourceLine] = []

    for line in body_lines:
        if _STRUCTURE_RE.match(line.text) and current:
            raw_units.append(current)
            current = [line]
        else:
            current.append(line)
    if current:
        raw_units.append(current)

    split_units: list[_Unit] = []
    for lines in raw_units:
        unit_text = _normalize_text("\n".join(line.text for line in lines))
        unit_page = next((line.page_number for line in lines if line.text), parent.page_number)
        for piece in _recursive_split(unit_text, max_chars, overlap):
            split_units.append(_Unit(text=piece, page_number=unit_page))

    # 검색 Child에 조문 번호가 항상 들어가도록 각 Child 앞에 조문 헤더를 붙일 예정이다.
    # 따라서 여기서는 실제 본문 조각들끼리 최대 크기 안에서 다시 묶는다.
    units: list[_Unit] = []
    current_texts: list[str] = []
    current_page: int | None = None

    # 조문 헤더 길이를 child budget에서 미리 제외한다.
    header = _article_header(parent)
    body_max = max(80, max_chars - len(header) - 1)

    for unit in split_units:
        candidate = "\n".join(current_texts + [unit.text])
        if len(candidate) <= body_max:
            if not current_texts:
                current_page = unit.page_number
            current_texts.append(unit.text)
            continue

        if current_texts:
            units.append(_Unit(text="\n".join(current_texts), page_number=current_page))
        current_texts = [unit.text]
        current_page = unit.page_number

    if current_texts:
        units.append(_Unit(text="\n".join(current_texts), page_number=current_page))

    # Header까지 포함하면 여전히 너무 큰 조각이 생길 수 있으므로 한 번 더 방어한다.
    final_units: list[_Unit] = []
    for unit in units:
        available = max(80, max_chars - len(header) - 1)
        for piece in _recursive_split(unit.text, available, overlap):
            final_units.append(_Unit(text=piece, page_number=unit.page_number))

    return final_units


def _children_from_parent(
    parent: _Parent,
    max_chars: int,
    min_chars: int,
    overlap: int,
) -> list[Chunk]:
    units = _structural_units(parent, max_chars=max_chars, overlap=overlap)
    if not units:
        return []

    # 짧은 마지막 조각은 앞 조각과 합칠 수 있을 때만 합친다.
    if len(units) >= 2 and len(units[-1].text) < min_chars:
        previous = units[-2]
        last = units[-1]
        article_header = _article_header(parent)
        combined_body = f"{previous.text}\n{last.text}".strip()
        combined_with_header = f"{article_header}\n{combined_body}".strip()
        if len(combined_with_header) <= max_chars:
            units[-2] = _Unit(text=combined_body, page_number=previous.page_number)
            units.pop()

    article_header = _article_header(parent)
    children: list[Chunk] = []
    total = len(units)
    for index, unit in enumerate(units):
        child_content = (
            unit.text.strip()
            if article_header and unit.text.lstrip().startswith(article_header)
            else f"{article_header}\n{unit.text}".strip()
        )
        children.append(
            Chunk(
                content=child_content,
                page_number=unit.page_number or parent.page_number,
                article=parent.article,
                parent_content=parent.content,
                parent_id=parent.parent_id,
                child_index=index,
                child_count=total,
                chapter=parent.chapter,
                section=parent.section,
            )
        )
    return children


def chunk_pages(
    pages: Sequence[object],
    *,
    source_name: str = "",
    max_chars: int = _DEFAULT_MAX_CHARS,
    min_chars: int = _DEFAULT_MIN_CHARS,
    overlap: int = _DEFAULT_OVERLAP,
) -> list[Chunk]:
    """한 법령 파일의 여러 페이지를 조문 기준 Parent/Child로 청킹한다.

    ``pages``는 ``page_number``와 ``text`` 속성이 있는 PdfPage 같은 객체를
    받는다. 페이지 단위 호출이 아니라 문서 전체를 한 번에 넘기므로 조문이
    다음 페이지로 이어져도 같은 Parent로 유지할 수 있다.
    """

    if max_chars <= 0:
        raise ValueError("max_chars는 1 이상이어야 합니다.")
    if min_chars < 0:
        raise ValueError("min_chars는 0 이상이어야 합니다.")
    if overlap < 0 or overlap >= max_chars:
        raise ValueError("overlap은 0 이상 max_chars 미만이어야 합니다.")

    page_pairs: list[tuple[int | None, str]] = []
    for page in pages:
        page_number = getattr(page, "page_number", None)
        text = getattr(page, "text", "")
        if str(text or "").strip():
            page_pairs.append((page_number, str(text)))

    source_lines = _build_source_lines(page_pairs)
    parents = _parse_parents(source_lines, source_name=source_name)

    if parents:
        chunks: list[Chunk] = []
        for parent in parents:
            chunks.extend(
                _children_from_parent(
                    parent,
                    max_chars=max_chars,
                    min_chars=min_chars,
                    overlap=overlap,
                )
            )
        return chunks

    # 법령 조문 구조를 전혀 찾지 못했으면 일반 문서 재귀 청킹으로 폴백한다.
    chunks: list[Chunk] = []
    whole_text = _normalize_text("\n".join(text for _, text in page_pairs))
    pieces = _recursive_split(whole_text, max_chars=max_chars, overlap=overlap)
    article = _detect_article(whole_text)
    parent_id = _stable_id(source_name, "generic", whole_text)
    first_page = page_pairs[0][0] if page_pairs else None
    for index, piece in enumerate(pieces):
        chunks.append(
            Chunk(
                content=piece,
                page_number=first_page,
                article=_detect_article(piece) or article,
                parent_content=whole_text,
                parent_id=parent_id,
                child_index=index,
                child_count=len(pieces),
            )
        )
    return chunks


def chunk_text(
    text: str,
    page_number: int | None = None,
    max_chars: int = _DEFAULT_MAX_CHARS,
    overlap: int = _DEFAULT_OVERLAP,
    min_chars: int | None = None,
) -> list[Chunk]:
    """단일 텍스트용 호환 함수.

    기존 테스트/호출부를 깨지 않기 위해 이름과 주요 인자를 유지한다.
    실제 PDF 색인은 ``chunk_pages``를 사용해 문서 전체의 조문 계층을 보존한다.
    """

    if min_chars is None:
        min_chars = min(_DEFAULT_MIN_CHARS, max_chars // 2)

    class _Page:
        def __init__(self, number: int | None, value: str) -> None:
            self.page_number = number
            self.text = value

    return chunk_pages(
        [_Page(page_number, text)],
        source_name="single_text",
        max_chars=max_chars,
        min_chars=min_chars,
        overlap=overlap,
    )
