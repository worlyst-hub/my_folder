"""국가법령정보 API JSON parser 회귀 테스트(실제 네트워크 호출 없음)."""

from rag.law_api import parse_admrul_articles, parse_law_articles


def test_law_json_is_normalized_per_article():
    payload = {
        "법령": {
            "조문": {
                "조문단위": [
                    {"조문번호": "1", "조문제목": "목적", "조문내용": "이 법은 목적을 정한다."},
                    {
                        "조문번호": "7",
                        "조문가지번호": "2",
                        "조문제목": "신고",
                        "조문내용": "거주자는 신고하여야 한다.",
                    },
                ]
            }
        }
    }
    articles = parse_law_articles(
        payload,
        law_name="외국환거래법",
        target="law",
        source_role="higher_law",
        source_url="https://www.law.go.kr",
        identifier="TEST",
    )
    assert [article.article for article in articles] == ["제1조", "제7조의2"]
    assert all(article.source_role == "higher_law" for article in articles)


def test_administrative_rule_long_value_is_split_per_article():
    payload = {
        "행정규칙": {
            "조문": {
                "조문내용": (
                    "제9-5조(해외직접투자의 신고 등)\n거주자는 서류를 제출한다.\n"
                    "제9-6조(변경신고)\n거주자는 변경신고를 한다."
                )
            }
        }
    }
    articles = parse_admrul_articles(
        payload,
        law_name="외국환거래규정",
        target="admrul",
        source_role="regulation_article",
        source_url="https://www.law.go.kr",
        identifier="TEST",
    )
    assert [article.article.replace(" ", "") for article in articles] == ["제9-5조", "제9-6조"]
    assert "변경신고" not in articles[0].text
