# FIXAR (ForeIgn eXchange AI for RegTech) - 외환거래 업무 지원 AI 시스템 (프로토타입)

은행 창구 직원의 외환거래 업무를 지원하는 Streamlit 프로토타입입니다.

고객이 수기로 작성한 외화송금신청서를 OCR로 구조화하고, 은행원이 결과를
확인/수정한 뒤, Ollama LLM 문맥 분석 → 사유코드 검색 → 국가법령정보센터 PDF
기반 RAG → SWIFT/제재 DB 조회까지 이어지는 업무 흐름을 시연합니다.

> 이 시스템은 은행원의 업무를 **지원**하는 도구입니다. AI가 법률적 최종
> 판단이나 실제 송금 승인 여부를 자동으로 결정하지 않으며, 모든 최종 확인은
> 은행원이 수행합니다.

---

## 1. 빠른 시작 (API Key / Ollama 없이도 동작)

두 스크립트 모두 동일한 절차를 처리합니다: `fixar/` 가상환경 생성 →
`requirements.txt` 설치 → `.env` 생성 → 로컬 Ollama 설치 확인(없으면 설치
여부를 물어봄) → 임베딩 모델(`bge-m3`) pull → DB 초기화/시딩까지 한 번에
처리합니다.

> **참고**: 임베딩 모델(`bge-m3`)은 사유코드/RAG 검색에 항상 쓰이므로
> 무조건 pull합니다. 반면 LLM 모델(`OLLAMA_MODEL`, 기본 `gpt-oss:120b-cloud`)과
> Vision 모델(`OLLAMA_VISION_MODEL`, 기본 `qwen2.5vl`)은 `.env`를 먼저 채운
> 뒤 스크립트를 실행해야 자동으로 받아집니다 - `.env`의 `LLM_MODE=live`일
> 때만 LLM 모델을, `OCR_MODE=vision`일 때만 Vision 모델을 pull합니다
> (기본값인 `mock`/`mock` 상태로 실행하면 두 모델 모두 건너뜁니다 - 수 GB
> 모델을 불필요하게 받지 않기 위함입니다). 나중에 모드를 바꾸고 스크립트를
> 다시 실행해도 됩니다. LLM 기본 모델(`gpt-oss:120b-cloud`)은 Ollama Cloud
> 모델이라 pull 자체는 수 초면 끝나지만(가중치는 로컬에 받지 않음)
> Ollama Cloud 계정/`OLLAMA_API_KEY`가 없으면 인증 오류가 날 수 있습니다 -
> 이 경우 셋업이 중단되지 않고 경고만 뜨고 계속 진행되며, `.env`를
> `OLLAMA_MODEL=llama3.1` + `OLLAMA_BASE_URL=http://localhost:11434`로
> 바꾸면 무료로 로컬에서 쓸 수 있습니다.

> **파이썬 버전**: 이 저장소는 특정 Python 버전을 강제로 고정하지 않습니다
> (`pyproject.toml`/`.python-version` 없음). 아래 스크립트는 그냥 PATH에 있는
> `python`(Windows) 또는 `python3`(macOS/Linux) 명령을 그대로 써서 `fixar/`
> 가상환경을 만듭니다. 이 세션에서는 macOS + **Python 3.13.13**으로 전체
> 플로우(Vision OCR 실기 인식 + Ollama Live + 실제 법령 PDF RAG)까지 정상
> 동작하는 것을 확인했습니다 - 다만 강제된 버전은 아니므로, 사용하시는
> Python이 너무 오래된 버전(3.9 이하 등)이면 문제가 생길 수 있습니다. 미리
> `python3 --version`으로 확인해주세요(3.10 이상 권장).

### Windows - 원클릭 셋업 (권장)

```powershell
powershell -ExecutionPolicy Bypass -File .\setup.ps1
```

- Ollama 설치를 건너뛰려면: `.\setup.ps1 -SkipOllama`
- 모든 확인 프롬프트 없이 바로 진행하려면: `.\setup.ps1 -Yes`

### macOS/Linux - 원클릭 셋업 (권장)

```bash
chmod +x setup.sh   # 최초 1회만
./setup.sh
```

- Ollama 설치를 건너뛰려면: `./setup.sh --skip-ollama`
- 모든 확인 프롬프트 없이 바로 진행하려면: `./setup.sh --yes`

`setup.ps1`을 macOS/Linux용 Bash로 그대로 옮긴 스크립트입니다 - 가상환경
경로만 `fixar/bin/...`로 다르고 나머지 단계는 동일합니다. Ollama가 없으면
[공식 설치 스크립트](https://ollama.com/install.sh)를 실행할지 물어보고,
pull 전에 로컬 Ollama 서버(`ollama serve`)가 안 떠 있으면 백그라운드로 잠깐
띄워줍니다.

(Ollama는 Python 패키지가 아니라 백그라운드 서비스가 딸린 시스템 프로그램이라
`requirements.txt`/pip로는 설치할 수 없어, 스크립트가 공식 설치 스크립트를
별도로 실행합니다. Ollama 없이도 앱은 Mock 모드로 정상 동작합니다.)

### 실행 (원클릭 셋업을 마쳤다면)

가상환경을 활성화하지 않고 실행 파일을 직접 호출하면 됩니다.

```powershell
.\fixar\Scripts\streamlit.exe run app.py   # Windows
```

```bash
fixar/bin/streamlit run app.py             # macOS/Linux
```

브라우저에서 `http://localhost:8501` 로 접속합니다. `.env`의 기본값
(`LLM_MODE=mock`, `OCR_MODE=mock`, `RAG_MODE=mock`)만으로 Ollama/PDF 없이
전체 업무 흐름을 처음부터 끝까지 시연할 수 있습니다. 다음에 다시 실행할 때도
`setup.ps1`/`setup.sh`를 또 돌릴 필요 없이 이 명령만 실행하면 됩니다(이미
설치된 건 건드리지 않고 그대로 스킵하는 멱등적인 스크립트이긴 하지만,
매번 pip install/모델 pull 확인 과정을 거치므로 이후에는 이 쪽이 더 빠릅니다).

### 수동 설치 (직접 단계별로 제어하고 싶을 때)

```bash
python -m venv fixar
fixar\Scripts\activate       # Windows (PowerShell 실행 정책 오류가 나면 아래 "직접 실행" 참고)
# source fixar/bin/activate  # macOS/Linux

pip install -r requirements.txt

copy .env.example .env         # Windows (또는 cp .env.example .env)

python -m database.seed        # 사유코드 100건 + SWIFT 마스터 + 등록 고객 마스터 100건 적재

streamlit run app.py
```

가상환경 폴더명은 `fixar` 로 통일했습니다 (활성화 없이 바로 실행하려면
`fixar\Scripts\streamlit.exe run app.py`(Windows) 또는
`fixar/bin/streamlit run app.py`(macOS/Linux)처럼 실행 파일을 직접
호출해도 됩니다 - Windows PowerShell 실행 정책 때문에 `activate.ps1`이
막힐 때 특히 유용합니다). 이후 접속 방법은 위 "실행" 섹션과 동일합니다.

데모 시 업로드 파일명에 다음 키워드를 포함하면 Mock OCR이 다른 시나리오를
보여줍니다 (파일명 어디에 포함되어도 됩니다):

| 파일명 키워드 | 시나리오 |
|---|---|
| (키워드 없음) | 해외부동산 취득 (홍길동) |
| `study` / `유학` | 해외유학비 (김유학) |
| `trade` / `무역` | 물품수입대금 (중국 거래처) |
| `sanction` / `제재` | 제재 데이터 등재 은행 케이스 (러시아) |

### git clone으로 받은 팀원은 바로 실행되나요?

**네, 바로 실행은 됩니다 - 단, Mock 위주 상태로 시작합니다.** 아래 두 가지는
`.gitignore`에 걸려있어 저장소에 포함되지 않고, 각자 로컬에서 준비해야 합니다.
(하나체 폰트는 `static/fonts/`에 TTF 6종이 저장소에 커밋되어 있어 git
clone만 하면 자동으로 딸려옵니다 - 별도로 구할 필요 없습니다.)

| 빠지는 것 | 이유 | 없으면 어떻게 되나 |
|---|---|---|
| `.env` | 개인 Ollama Cloud API 키 등 민감정보가 들어있음 | `.env.example`의 기본값(`LLM_MODE=mock`, `OCR_MODE=mock`, `RAG_MODE=mock`)으로 동작 - **앱 자체는 정상 실행됨** |
| `fixar/` 가상환경 | 애초에 커밋 대상이 아님 | `setup.ps1`/`setup.sh` 또는 수동 설치로 각자 생성 |

> **하나체(Hana2) 폰트 라이선스**: 개인/기업 모두 상업적 용도로 무료
> 사용을 허용하며, 배포되는 형태 그대로 쓰는 한(수정·재판매·CI/BI 제작
> 금지) 재배포 제한이 없어 `static/fonts/*.ttf`를 저장소에 그대로
> 커밋해뒀습니다.

**작성자(이 프로젝트를 처음 만든 사람)와 완전히 동일한 상태**(Vision OCR 실제
인식 + Ollama Cloud LLM(`gpt-oss:120b-cloud`) + 로컬 bge-m3 임베딩)로
맞추려면, `copy .env.example .env` 후 `LLM_MODE=live`/`OCR_MODE=vision`으로
바꾸고 본인의 Ollama Cloud API 키를 `OLLAMA_API_KEY`에 채워주세요 -
모델명(`OLLAMA_MODEL`/`OLLAMA_VISION_MODEL`)과 접속 주소는 이미 기본값으로
맞춰져 있습니다(자세한 내용은 "2. 실행 모드" 섹션 참고). 하나체는 이미
저장소에 포함되어 있어 별도 작업이 필요 없습니다.

이걸 안 해도 **Mock 모드로 전체 업무 흐름(OCR→분석→사유코드→법령→SWIFT→요약)
을 처음부터 끝까지 시연하는 데는 전혀 문제가 없습니다.**

---

## 2. 실행 모드 (.env)

`.env.example` 참고. 세 가지 모드를 독립적으로 켜고 끌 수 있습니다.

| 변수 | 값 | 설명 |
|---|---|---|
| `LLM_MODE` | `mock` (기본) / `live` | `live`면 Ollama로 거래 문맥 분석 + 사유코드/RAG 임베딩까지 수행 |
| `OCR_MODE` | `mock` (기본) / `vision` | 아래 "OCR 모드" 참고 |
| `RAG_MODE` | `mock` (기본) / `pdf` / `api` | `api`면 국가법령정보 API의 최신 원문 snapshot을 색인 |

### OCR 모드

| 모드 | 방식 | 지원 파일 | 비고 |
|---|---|---|---|
| `mock` | 파일명 키워드로 고정된 시나리오 반환 | 무관 | 아무 설치 없이 바로 시연 가능 |
| `vision` **(권장)** | Ollama Vision(멀티모달 LLM)이 이미지에서 직접 구조화된 JSON 추출 | JPG/PNG/PDF(PDF는 첫 페이지만) | Ollama + Vision 모델(`qwen2.5vl` 권장) 설치 필요 |

> **과거 PaddleOCR 모드는 제거했습니다.** 실제 손글씨 신청서 예시
> (`data/forms/`)로 직접 비교한 결과입니다:
>
> | 모드 | 소요 시간 | 정확도 |
> |---|---|---|
> | PaddleOCR(제거됨) | 약 5분(2480×3507px 이미지 1장 기준) | 라벨이 밀집된 레이아웃에서 다수 필드가 깨짐(성명·목적 등) |
> | `vision` (`qwen2.5vl`) | **콜드 스타트 약 70~90초** / 캐시 재사용 시 약 17초 | 이름·주민번호·계좌번호·SWIFT·금액 등 거의 전부 정확히 추출 |
> | `vision` (`llava`) | 약 29초 | ❌ 이미지를 읽지 않고 프롬프트의 필드 설명 문구를 그대로 베낌 - **사용 비권장** |
>
> PaddleOCR은 신청서 레이아웃을 이해하는 게 아니라 "성명/SWIFT/금액" 같은
> 라벨 주변 텍스트를 규칙으로 찾는 방식이라 라벨이 밀집된 실제 서식에서
> 부정확했고, 처리 시간도 vision보다 훨씬 길어 삭제했습니다(패키지
> 450MB + 다운로드된 모델 캐시 142MB 정리, 자세한 내용은 프롬프트 md
> 41.18 참고). `vision` 모드는 모델이 이미지 전체를 한 번에 이해해서
> JSON을 바로 뽑아내지만, **모델 자체의 성능 차이가 결과에 큰 영향을
> 줍니다** - 작고 영어 위주로 학습된 모델(`llava`)은 한글이 섞인 조밀한
> 문서에서 거의 못 씁니다.
>
> **`qwen2.5vl` 소요 시간에 대한 참고**: 대부분 시간(약 50초)은 실제
> 텍스트 생성이 아니라 **이미지+프롬프트를 처리하는 단계**(Ollama의
> `prompt_eval_duration`)에서 씁니다. Ollama는 직전 요청과 이미지·프롬프트가
> 완전히 동일하면 이 처리 결과를 캐시해서 재사용하므로, 같은 이미지를
> 바로 다시 요청하면 그 부분을 건너뛰고 약 17초로 끝납니다. 하지만
> 실사용에서는 은행원이 매번 다른 신청서 이미지를 업로드하므로 캐시가
> 재사용될 일이 없고, **매번 콜드 스타트(70~90초 안팎)로 봐야 실제
> 체감 속도에 가깝습니다.** 자세한 실측은 프롬프트 md 41.20 참고.

인식이 틀리거나 비어 있는 필드는 OCR 결과 확인 화면에서 은행원이 직접
채우거나 고치면 됩니다(원래 그 화면의 목적입니다).

세 모드는 서로 섞어 쓸 수 있습니다 (예: OCR은 Mock, LLM은 실제 Ollama).

### Ollama 설정 (LLM_MODE=live / OCR_MODE=vision)

LLM/Vision/임베딩이 각각 완전히 독립된 접속 정보(`OLLAMA_*` /
`OLLAMA_VISION_*` / `OLLAMA_EMBED_*`)를 쓰므로, 셋을 서로 다른 곳에
자유롭게 조합할 수 있습니다. 기본값은 **LLM은 Ollama Cloud, Vision/임베딩은
로컬 Ollama**입니다(Ollama Cloud는 Vision/임베딩 모델을 제공하지 않기
때문 - 아래 참고).

**LLM 분석 (`OLLAMA_BASE_URL` / `OLLAMA_MODEL` / `OLLAMA_API_KEY`)**

- **기본값: Ollama Cloud + `gpt-oss:120b-cloud`.** `llama3.1`(8B, 로컬)과
  실측 비교한 결과 종합 지능/코딩/한국어 이해 전부 확실히 앞서서(섹션
  "2. 실행 모드" 위쪽 표는 OCR 기준이지만 LLM도 같은 방식으로 비교함,
  자세한 수치는 프롬프트 md 41.21 참고) 기본 모델로 채택했습니다.
  [ollama.com](https://ollama.com)에서 계정을 만들고 API Key를 발급받아
  `OLLAMA_API_KEY`에 채워주세요.
- **무료로 쓰고 싶다면**: `OLLAMA_BASE_URL=http://localhost:11434`,
  `OLLAMA_MODEL=llama3.1`, `OLLAMA_API_KEY`는 비워두고 로컬에
  `ollama pull llama3.1`.

**Vision OCR (`OLLAMA_VISION_BASE_URL` / `OLLAMA_VISION_MODEL` / `OLLAMA_VISION_API_KEY`, `OCR_MODE=vision`일 때만)**

```bash
ollama pull qwen2.5vl
```

- **항상 로컬 Ollama가 기본값입니다** - 위 LLM 기본값이 Cloud로
  바뀐 것과 무관하게, Ollama Cloud는 Vision 모델을 제공하지 않으므로
  `OLLAMA_VISION_BASE_URL=http://localhost:11434`로 고정해뒀습니다.
- `llava`도 선택은 가능하지만, 실제 한글 손글씨 서식으로 검증한 결과
  이미지를 제대로 읽지 못하고 프롬프트의 필드 설명 문구를 그대로 베끼는
  문제가 있어 **권장하지 않습니다**(위 "OCR 모드" 실측 비교 참고).
- 비워두면(즉 값을 지우면) 위 LLM용 접속 정보(`OLLAMA_BASE_URL`/
  `OLLAMA_API_KEY`)를 그대로 씁니다 - 다만 기본값이 Cloud라 Vision
  모델을 못 찾을 것이므로, 값을 지우지 말고 그대로 두는 걸 권장합니다.

**임베딩 - 사유코드/RAG 검색 (`OLLAMA_EMBED_BASE_URL` / `OLLAMA_EMBED_MODEL` / `OLLAMA_EMBED_API_KEY`)**

- Ollama Cloud는 임베딩 모델도 제공하지 않으므로(대형 채팅 모델 전용
  서비스), Vision과 마찬가지로 **로컬 Ollama**가 기본값입니다.
- 다국어(한국어 포함) 검색 품질이 좋은 `bge-m3`를 권장합니다:
  ```bash
  ollama pull bge-m3
  ```
- 비워두면 위 LLM용 접속 정보(`OLLAMA_BASE_URL`/`OLLAMA_API_KEY`)를 그대로
  씁니다.

Ollama(로컬/Cloud 모두) 연결이 실패하면 LLM 분석은 화면에 오류 메시지가
표시되고, 임베딩(사유코드/RAG 검색)은 자동으로 경량 해시 기반 임베딩으로
폴백하여 검색 파이프라인 자체는 계속 동작합니다 (정확도는 낮아질 수
있습니다).

### 국가법령정보 공동활용 API (RAG_MODE=api, 최종 권장)

기존 `.env`의 다른 값을 바꾸지 말고 `.env.example` 하단의 API 블록을
추가한 뒤 아래 두 값만 설정합니다.

```dotenv
RAG_MODE=api
LAW_API_KEY=발급받은_OC_값
```

앱은 외국환거래법·시행령·외국환거래규정만 동기화하며, 매 검색마다 API를
호출하지 않습니다. 최신 응답을 `data/law_api_cache/`에 last-good snapshot으로
저장한 뒤 ChromaDB를 검색합니다. API 장애 시 정상 snapshot이 있으면 그것을
사용합니다. 법/시행령/규정/서식은 서로 다른 역할로 분리되어 필요서류 검색에
불필요한 상위법이나 서식 본문이 섞이지 않습니다. 자세한 내용은
[`RAG_API_GENERALIZED_V4.md`](RAG_API_GENERALIZED_V4.md)를 참고하세요.

### RAG용 국가법령정보센터 PDF 등록 (RAG_MODE=pdf)

[국가법령정보센터](https://www.law.go.kr)에서 내려받은 외국환거래법령 PDF를
`data/regulations/` 에 넣고 `.env`의 `RAG_MODE=pdf` 로 변경하면, 다음 인덱싱
시 해당 PDF들을 자동으로 읽어 Chunking → Embedding → Vector DB 색인을
수행합니다. 자세한 내용은 [`data/regulations/README.md`](data/regulations/README.md)
참고.

PDF가 없거나 `RAG_MODE=mock`인 경우, 시스템은 시연용 **샘플 규정 텍스트**로
RAG 파이프라인 자체는 그대로 보여주되 화면에 "🧪 샘플 데이터"로 명확히
표시합니다. 샘플 데이터는 실제 법령 원문이 아닙니다.

---

## 3. DB 초기화 / 재적재

SQLite 파일(`data/fx_remittance.db`)을 사용하며, 최초 실행 시 `app.py`가
자동으로 테이블을 생성합니다. 사유코드/SWIFT Mock 데이터는 아래 명령으로
적재합니다 (이미 데이터가 있으면 건너뜁니다).

```bash
python -m database.seed            # 최초 1회 (또는 데이터가 비어있을 때)
python -m database.seed --reset    # 기존 데이터를 지우고 CSV로 다시 적재
```

사유코드/SWIFT 원본 데이터는 코드가 아닌 `data/reason_codes.csv`,
`data/swift_sanction_master.csv` 에서 관리합니다. `data/reason_codes.csv`는
`data/generate_reason_codes.py` 로 생성된 약 100건의 테스트용 사유코드입니다
(실제 은행 사유코드 체계가 아닌 프로토타입 시연용 데이터입니다).

`data/swift_sanction_master.csv`(총 29건)는 데모 시나리오용으로 직접
작성한 수기 큐레이션 데이터입니다 - 정상 은행 23건과 제재 은행 6건
(러시아 2·이란 2·북한·쿠바, OFAC/UN 제재 케이스)이 예상 소요시간·처리
유의사항까지 채워져 있습니다. `services/ocr/mock_ocr.py` 데모 시나리오,
`tests/test_swift.py`, `tests/test_integration_flow.py`가 이 데이터를
사용합니다.

> 한때는 공개 저장소([`maranemil/swift-bic-codes-allinone`](https://github.com/maranemil/swift-bic-codes-allinone))에서
> 가져온 실제 SWIFT/BIC 데이터 109,008건을 은행명/국가 조회용으로 추가
> 적재했었지만, `is_sanctioned`가 전부 `false`로만 채워져 있어 실제 제재
> 여부와 무관하게 일괄 "정상"으로 조회되는 문제가 있었고(예: 러시아(RU)
> 은행만 2,691건이 섞여 있었음), 출처 라이선스도 불명확하고 2019년
> 스냅샷이라 오래되어 제거했습니다. 지금은 데모 시나리오와 정확히 맞는
> 수기 큐레이션 29건만 남아있습니다.

8자리 BIC로 조회하면(Branch Code 미포함) `services/swift/service.py`가
한 은행의 여러 지점 중 관례상 본점을 뜻하는 `XXX` Branch Code를 우선
매칭하고, 없으면 등재된 지점 중 하나로 폴백합니다.

`data/registered_customers.csv`(총 100건, `data/generate_registered_
customers.py`로 생성)는 **당행에 이미 등록되어 있는 고객 마스터** Mock
데이터입니다. 신청서 OCR로 매번 새로 생기는 `customer_profile`(거래
이력)과는 완전히 별개로, 은행이 사전에 보유한 고정 고객 목록을 흉내낸
것입니다. ②단계에서 거래정보를 확정하면 `services/system_lookup`이
신청서의 식별번호로 이 마스터를 먼저 조회합니다 - 있으면 그 고객의
신용등급(1~10)·연간 송금한도(USD)를 그대로 쓰고, 없으면(당행 미등록/
신규 고객) 신용등급/한도는 비운 채 나머지 항목(거래외국환은행 지정 등)만
식별정보를 해시한 결정론적 Mock 값으로 채웁니다. ⑧ 고객 데이터 화면에서
전체 100건을 조회할 수 있습니다(식별번호는 마스킹 표시).

거래외국환은행 지정(`designated_bank_status`)은 단순 Y/N이 아니라 실제
"거래외국환은행 지정제도"를 반영해 **당행(SELF) 70% · 타행(OTHER) 20% ·
미지정(NONE) 10%** 3단계로 Mock 배정했습니다. 기존지정목적 코드는
**당행 지정(SELF)인 경우에만** 채우고 타행(OTHER)·미지정(NONE)은
비워둡니다 - 고객이 타행을 지정거래은행으로 등록했다면 그 지정목적은
타행에 등록된 정보라 당행 시스템이 알 수 있는 값이 아니기 때문입니다.
④ 법령·필요서류 화면에서 타행 지정 고객을 조회하면 "지정거래외국환은행
변경 절차가 필요할 수 있습니다" 경고가 함께 뜹니다. 기존지정목적 3자리
코드 체계(대분류/중분류/소분류, `services/designated_purpose_codes.py`)는
실제 외국환거래 목적코드가 아니라 이 프로젝트에서 임의로 만든 것이며,
⑩ 지정목적코드 화면에서 전체 100가지 조합을 조회할 수 있습니다.

③ 거래 문맥 분석에서 후보로 추천되는 사유코드 마스터(`ReasonCode`, DB
`reason_codes` 테이블) 전체는 ⑨ 사유코드 화면에서 검색해 조회할 수
있습니다.

**④ 법령·필요서류 화면의 "지급 절차 판정"**(`services/payment_procedure.py`)은
외국환거래규정 **제4-2조/제4-3조**(지급등의 절차 및 예외 - 증빙서류 없이
가능한 연간 누계 미화 10만불, 초과 시 건당 미화 5천불 예외)와
**제10-9조/제10-11조**(사후관리, 거래외국환은행 지정 - 지정된 은행만
사후관리 가능, 변경 시 현재 지정 은행을 경유)를 근거로, 지정거래은행
상태(당행/타행/미지정) · 증빙/무증빙 여부(은행원이 화면에서 직접 선택) ·
송금액 · 연간 누계액을 조합해 처리 가능 여부를 판정합니다. 예: 누계
7만불 고객이 3.5만불을 무증빙으로 보내려 하면 반영 후 10.5만불로 10만불을
초과해 "증빙서류 필요"로 안내됩니다.

- 정확한 금액 비교(미화 5천불/10만불)는 RAG나 LLM이 아니라 **결정론적
  Python 코드**로 계산합니다 - 이 프로젝트는 임의의 숫자 가중치를 조합한
  점수식이나 LLM의 산술 판단에 기대지 않는다는 원칙(사유코드 Vector
  Search와 동일)을 여기에도 적용했습니다. 최종 처리 가능 여부는 은행원이
  확인합니다.
- "사후관리 필요(제10-11조 지정 대상) 여부"는 사유코드 대분류가
  "자본거래"인지로 근사합니다 - 화면에도 이 근사를 명시하고, 정확한 해당
  여부는 은행원이 재확인하도록 안내합니다.
- 판정과 별개로, 근거가 된 조문 원문을 실제로 확인할 수 있도록 이 절차
  전용 검색어("지급등의 절차 예외 증빙서류 연간 누계금액..." 등)로 RAG
  검색을 한 번 더 실행해 "관련 조문 원문 확인" 펼침 메뉴에 보여줍니다
  (사유코드의 `regulation_tags`로 필터링하는 기존 "관련 법령" 검색과는
  별개 - 이 절차 조문은 거래 유형 태그와 무관하게 항상 적용되기 때문).
- 이 프로토타입은 환전 기능이 없어 송금 통화를 그대로 USD로 간주해
  계산합니다(통화가 USD/달러가 아니면 화면에 안내 문구가 뜹니다).
- **왼쪽 "필요서류" 체크리스트와의 연동**: "무증빙"을 선택하면(제4-3조
  예외 대상 - 애초에 증빙서류가 필요 없는 거래) 사유코드의 필요서류를
  전부 체크하지 않아도 "다음" 버튼이 활성화됩니다. 체크박스 자체는
  참고용으로 계속 보여주되, 진행을 막지는 않습니다. "증빙"을 선택하면
  기존과 동일하게 전부 체크해야 다음 단계로 진행할 수 있습니다.

사유코드/RAG의 Vector 인덱스(Chroma, `data/chroma/`)는 화면에서 검색이 처음
호출될 때 자동으로 생성됩니다. DB를 재적재한 뒤에는 아래로 강제 재색인할 수
있습니다.

```bash
python -c "from services.reason_code.mapper import ReasonCodeMapper; ReasonCodeMapper().build_index(force=True)"
python -c "from rag.retriever import RagRetriever; RagRetriever().build_index(force=True)"
```

> 임베딩 백엔드(Mock 해시 ↔ Ollama)를 바꾸면(=`.env`의 `LLM_MODE` 변경) 벡터
> 차원이 달라지므로 위 명령으로 재색인해야 합니다.

---

## 4. 테스트

```bash
pytest
```

`tests/conftest.py`가 세션 시작 시 DB 시딩을 보장하며, RAG 재색인처럼 SQL을
지우고 다시 쓰는 테스트는 격리된 임시 SQLite DB를 사용해 실제 개발 DB
(`data/fx_remittance.db`)를 건드리지 않습니다.

| 파일 | 범위 |
|---|---|
| `tests/test_ocr.py` | Mock OCR 정상/누락/오인식 필드, 체크박스형 필드, SWIFT 인식, 은행원 수정 |
| `tests/test_llm.py` | Mock LLM 거래 문맥 구조화 (부동산/유학/무역/기타) |
| `tests/test_reason_code.py` | 사유코드 Vector Search (명확/유사 목적, 복수 후보, 매칭 없음) |
| `tests/test_rag.py` | Chunking, PDF 로더, 법령/조문 검색, 검색 없음, PDF 출처·페이지 표시 |
| `tests/test_swift.py` | 정상/제재 은행, 8자리/11자리 BIC, 미등록 SWIFT |
| `tests/test_integration_flow.py` | OCR→확정→분석→사유코드→RAG→SWIFT 전체 흐름 |

---

## 5. 프로젝트 구조

팀 작업 분담에 맞춰 **RAG(`rag/`)와 프론트엔드(`frontend/`)를 프로젝트 최상위
디렉토리로 분리**했습니다 - 원래 각각 `services/rag/`, `ui/` 안에 있던
것을 그대로 옮긴 것으로, 파일 내용이나 동작은 바뀌지 않았습니다(내부 import
경로만 `services.rag.*` → `rag.*`, `ui.*` → `frontend.*`로 갱신).

```text
app.py                      # Streamlit 진입점 (Wizard 라우팅)
setup.ps1                   # 원클릭 셋업 - Windows (pip install + Ollama 설치 확인 + 모델 pull + DB seed)
setup.sh                    # 원클릭 셋업 - macOS/Linux (setup.ps1과 동일한 절차)
config/settings.py          # 환경변수 기반 전역 설정
database/                   # SQLAlchemy 모델·연결·시딩
schemas/                    # Pydantic 데이터 구조 (고객/거래/사유코드/SWIFT/분석)
rag/                        # [팀 담당: RAG] PDF 로더 · Chunker · Embedder · Retriever
services/
  ollama_client.py          # LLM·임베딩 공용 Ollama Client 헬퍼 (로컬/Cloud, API Key)
  embedding_client.py       # 사유코드·RAG 공용 Embedding 클라이언트
  ocr/                      # OCR Service (Mock / Ollama Vision)
  llm/                      # LLM Service (Mock / Ollama)
  reason_code/              # 사유코드 Vector Search
  swift/                    # SWIFT SQL 조회
  system_lookup/            # Mock System Lookup (금융결제원/Core DB/신용정보원 가정)
  designated_purpose_codes.py  # 기존지정목적 3자리 코드 체계 (대분류/중분류/소분류, 시연용 임의 정의)
data/                       # Mock 데이터(CSV), RAG 원문 PDF, SQLite, Chroma 인덱스, 참고용 실제 서식(forms/)
static/fonts/                # 하나체(Hana2) TTF 6종 - .streamlit/config.toml의 [[theme.fontFaces]]가 참조
frontend/                   # [팀 담당: 프론트엔드] Streamlit 화면
  theme.py                  # 디자인 테마 (네이비 사이드바 + 화이트 카드)
  upload.py / ocr_result.py / transaction_analysis.py / regulation.py / swift.py / summary.py
  processing_log.py         # ⑦ 처리 로그 - COMPLETED 처리된 거래를 DB에서 조회(마법사 순번 아님)
  customer_data.py          # ⑧ 고객 데이터 - 당행 등록 고객 마스터 100건 조회(마법사 순번 아님)
  reason_codes.py           # ⑨ 사유코드 - 사유코드 마스터 100건 조회(마법사 순번 아님)
  purpose_codes.py          # ⑩ 지정목적코드 - 기존지정목적 코드 100가지 조회(마법사 순번 아님)
tests/                      # pytest
```

> `rag/`는 `services/` 바깥에 있지만 여전히 일반 Python 패키지라서
> `from rag.retriever import RagRetriever`처럼 그냥 임포트하면 됩니다.
> 마찬가지로 `frontend/`도 `from frontend import theme`처럼 씁니다.
> `services/embedding_client.py`(임베딩 공용 클라이언트)와
> `services/reason_code/`(사유코드 검색)는 RAG 전용이 아니라 다른
> 서비스와도 공유되는 인프라라 `rag/`로 옮기지 않고 그대로 뒀습니다.

---

## 6. 화면 흐름의 은행원 확인 장치

- **사이드바 자유 이동**: ①~⑥ 마법사와 ⑦~⑩ 조회 화면 어느 단계든 사이드바에서 바로 클릭해 이동할
  수 있습니다 - 이전엔 아직 도달하지 못한 단계로 가면 안전장치가 앞 단계로
  강제로 되돌려버렸지만, 은행원이 정보를 미리 알고 있어 특정 단계를 먼저
  확인/입력하고 싶은 경우가 많아 이동 자체는 항상 허용하도록 바꿨습니다.
  이전 단계 데이터 없이 어떤 단계로 바로 가면 그 화면은 빈 서식으로
  렌더링됩니다(④ 법령/필요서류처럼 사유코드가 있어야만 의미 있는 검색은
  사유코드가 없으면 실행하지 않고 빈 상태만 보여줍니다). 사이드바의
  "✅ 완료" 표시는 지금 보고 있는 단계 번호가 아니라, 각 화면의 실제
  제출/확정 액션을 거쳐 도달한 단계(`max_step_reached`) 기준이라 번호만
  옮겨 다닌 단계까지 완료로 잘못 표시되지 않습니다.
- **필요서류 체크리스트**: 하나라도 체크하지 않으면 "다음" 버튼이
  비활성화됩니다.
- **최종 처리 완료**: ②단계에서 거래정보를 확정한 적이 없으면(DB에 저장할
  레코드 자체가 없음) "✅ 처리 완료" 버튼이 비활성화되고 이유가 안내됩니다.
  SWIFT 조회 결과가 제재 데이터 등재 은행이거나 필요서류 체크가 남아있으면,
  "위 사항을 확인했으며..." 체크박스를 직접 눌러야만 버튼이 활성화됩니다
  (자동으로 막지는 않고, 은행원이 명시적으로 확인하도록 요구합니다 -
  섹션 6의 "자동 확정하지 않음" 원칙과 일치). 완료 처리되면 ⑦ 처리
  로그에서 확인할 수 있습니다.
- **SWIFT 재조회 안내**: SWIFT BIC를 조회한 뒤 입력값을 다시 수정하면
  "다시 조회해주세요" 캡션이 뜹니다 - 다만 사이드바 자유 이동 원칙과
  맞춰 "다음" 버튼 자체를 막지는 않으므로(⑥으로 그냥 넘어갈 수도 있음),
  최종 판단은 은행원 몫입니다. 입력창에서 Enter를 누르면 "다음"이 아니라
  "조회"가 실행됩니다(`st.form`으로 감싸 폼 안의 유일한 제출 버튼에
  Enter가 연결되도록 함).
- **OCR 데이터 재확정 시 이후 단계 초기화**: 사이드바로 되돌아가 OCR 결과를
  고쳐서 다시 제출하면, 이전에 만들어진 AI 분석/사유코드/법령 검색/SWIFT
  조회 결과가 전부 초기화됩니다 - 수정 전 데이터를 기준으로 만들어진 참고
  정보가 수정 후 화면에 그대로 남아있지 않도록 합니다.
- **⑦ 처리 로그**: ①~⑥ 마법사와 달리 "다음"으로 순서대로 도달하는 단계가
  아니라 언제든 들어가는 별도 조회 화면입니다(사이드바에도 번호 없이
  구분선 아래에 표시). `TransactionStatus.COMPLETED`로 완료 처리된 거래를
  DB에서 최신순으로 보여주며, 브라우저 세션을 새로고침하거나 "새 거래
  시작"을 눌러도 DB 기록이라 사라지지 않습니다. 다만 SWIFT 제재 조회
  결과처럼 세션에만 있고 DB 컬럼이 없는 일부 정보는 로그에 포함되지
  않습니다.
- **⑧~⑩ 조회 화면**: 고객 데이터/사유코드/지정목적코드도 ⑦ 처리 로그와
  같은 성격의 조회 전용 화면입니다(마법사 순번 아님, 사이드바에 번호 없이
  표시). 각각 검색창으로 필터링할 수 있습니다.
- **원본 신청서 PDF 미리보기**: ② OCR 결과 확인 화면에서 PDF를 업로드하면
  Vision OCR과 동일하게 `pypdfium2`로 1페이지를 이미지로 렌더링해
  보여줍니다(여러 페이지가 있어도 1페이지만).
- **Mock 시스템 조회 데이터 라벨링**: 신용정보원/금융결제원 연동을 흉내 낸
  Mock 데이터(`services/system_lookup/mock_service.py`)는 "🧪 Mock 데이터"로
  명확히 표시됩니다 - 실제 신용정보 조회 결과처럼 보이지 않도록 하기
  위함입니다.
- **임베딩 폴백 표시**: `LLM_MODE=live`인데 Ollama 임베딩 연결이 실패해
  경량 해시 임베딩으로 자동 전환된 경우, 사유코드/법령 검색 화면에 경고
  캡션이 표시됩니다 - 사이드바의 RAG 배지가 "bge-m3 + ChromaDB"로
  표시되어도 실제 검색은 해시 임베딩으로 이뤄졌을 수 있다는 걸 알리기
  위함입니다.

---

## 7. 범위 밖 (구현하지 않음)

- 증빙서류 OCR / 자동 분류 / 자동 진위 판정 (실제 서류는 은행원이 직접 확인합니다)
- OCR/사유코드에 대한 자동 승인·거절, confidence 임계치 기반 자동 통과
- 임의의 숫자 가중치를 조합한 사유코드 점수식
- SWIFT/제재 데이터 조회만으로의 송금 가능 여부 자동 확정
- 실제 금융결제원 / 은행 Core DB / 신용정보원 연동 (Mock Service로 대체)

## 8. 알려진 제약

- Vision OCR(`OCR_MODE=vision`)은 PDF를 지원하지만 **첫 페이지만
  인식에 사용합니다**(`pypdfium2`로 첫 페이지를 이미지로 변환 후 처리).
  여러 페이지가 있으면 2페이지 이후 내용은 반영되지 않으며, 이 경우 OCR
  결과 확인 화면에 경고가 함께 표시됩니다. 외화송금신청서는 1페이지에
  필요한 정보가 모두 있어 실사용에는 문제가 없습니다(2페이지는 자동화기기
  이용 신청 등 무관한 내용).
- 콘솔에 한글 로그가 깨져 보이면 터미널 인코딩이 UTF-8이 아닌 경우입니다
  (Windows `cmd`/PowerShell에서는 `chcp 65001` 실행 권장).
- Mock 모드의 경량 해시 임베딩은 실제 의미 기반 검색만큼 정교하지 않습니다.
  정확한 검색 품질 확인은 `LLM_MODE=live`(Ollama) 환경에서 확인하세요.
- SWIFT 마스터 데이터는 데모 시나리오용 수기 큐레이션 29건(정상 23 ·
  제재 6)만 있습니다. 그 외 실제 은행 BIC 코드는 등록되어 있지 않아
  조회하면 "등록되지 않은 SWIFT Code"로 뜹니다 - 실제 은행 DB 조회를
  대체하는 게 아니라 제재 조회 UX/로직 시연용입니다. 자세한 내용은
  "3. DB 초기화 / 재적재" 참고.
- **`fixar/` 가상환경을 만든 뒤 프로젝트 폴더 이름을 바꾸면
  (`mv`/Finder 이름 변경) `fixar/bin/streamlit`, `pytest`, `pip` 등
  pip이 만든 실행 스크립트가 전부 깨집니다** - 이 스크립트들의 첫 줄
  (셔뱅)에 파이썬 절대경로가 하드코딩되어 있어서입니다. 증상: 폴더명을
  바꾼 뒤 `streamlit run app.py`는 되는데 `fixar/bin/streamlit run
  app.py`나 `pytest`가 "Command not found"/"No such file or directory"로
  실패합니다. 해결: 가장 간단한 방법은 `fixar/`를 지우고
  `setup.sh`/`setup.ps1`을 다시 실행해 새로 만드는 것입니다. 가상환경을
  다시 만들기 번거로우면 아래처럼 셔뱅과 `pyvenv.cfg`의 경로를 일괄
  치환해도 됩니다(macOS/Linux 기준):
  ```bash
  OLD=/절대/경로/옛폴더명
  NEW=/절대/경로/새폴더명
  grep -rl "$OLD" fixar/bin/ | xargs sed -i '' "s|$OLD|$NEW|g"
  sed -i '' "s|$OLD|$NEW|g" fixar/pyvenv.cfg
  ```

