"""법령 원문 표시 형식 회귀 테스트."""

from frontend.regulation import _format_law_text_for_display


def test_display_preserves_original_list_numbers_and_deleted_markers():
    source = "③ 제출서류\n1. 사업계획서\n2. <삭 제>\n3. <삭제>\n④ <삭 제>\n⑤ 사후신고"

    rendered = _format_law_text_for_display(source)

    assert "1\\. 사업계획서" in rendered
    assert "2\\. 삭제" in rendered
    assert "3\\. 삭제" in rendered
    assert "④ 삭제" in rendered
    assert "⑤ 사후신고" in rendered
    assert "<삭 제>" not in rendered
    assert "<삭제>" not in rendered
