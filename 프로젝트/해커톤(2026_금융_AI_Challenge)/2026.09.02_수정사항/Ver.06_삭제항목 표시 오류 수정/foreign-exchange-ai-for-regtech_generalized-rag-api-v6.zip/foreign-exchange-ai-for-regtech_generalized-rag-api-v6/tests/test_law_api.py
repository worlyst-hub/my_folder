"""국가법령정보 API JSON parser 회귀 테스트(실제 네트워크 호출 없음)."""

from rag.law_api import parse_admrul_articles, parse_law_articles


def test_law_json_is_normalized_per_article():
    payload = {
        "법령": {
            "조문": {
                "조문단위": [
                    {"조문번호": "1", "조문제목": "목적", "조문내용": "이 법은 목적을 정한다."},
                    {
                        "조문번호": "7",
                        "조문가지번호": "2",
                        "조문제목": "신고",
                        "조문내용": "거주자는 신고하여야 한다.",
                    },
                ]
            }
        }
    }
    articles = parse_law_articles(
        payload,
        law_name="외국환거래법",
        target="law",
        source_role="higher_law",
        source_url="https://www.law.go.kr",
        identifier="TEST",
    )
    assert [article.article for article in articles] == ["제1조", "제7조의2"]
    assert all(article.source_role == "higher_law" for article in articles)


def test_administrative_rule_long_value_is_split_per_article():
    payload = {
        "행정규칙": {
            "조문": {
                "조문내용": (
                    "제9-5조(해외직접투자의 신고 등)\n거주자는 서류를 제출한다.\n"
                    "제9-6조(변경신고)\n거주자는 변경신고를 한다."
                )
            }
        }
    }
    articles = parse_admrul_articles(
        payload,
        law_name="외국환거래규정",
        target="admrul",
        source_role="regulation_article",
        source_url="https://www.law.go.kr",
        identifier="TEST",
    )
    assert [article.article.replace(" ", "") for article in articles] == ["제9-5조", "제9-6조"]
    assert "변경신고" not in articles[0].text


def test_administrative_rule_without_newlines_ignores_inline_article_citation():
    """실제 API처럼 본문 전체가 한 줄이어도 인용 조문을 heading으로 오인하지 않는다."""

    payload = {
        "행정규칙": {
            "조문내용": (
                "제2-3조(외국환의 매각) 본문에서 라. 제2-6조(거주자가 담보 또는 "
                "보증을 제공한 경우에 한한다)를 인용한다."
                "제2-4조(외국환은행 등과의 외국환매매) 두 번째 실제 조문이다."
                "제2-5조(외화자금차입 및 증권발행) 세 번째 실제 조문이다."
                "제2-6조(대출) 네 번째 실제 조문이다."
                "제9-5조(해외직접투자의 신고 등)① 거주자는 신고서에 다음 각 호의 "
                "서류를 첨부하여 제출한다.1. 사업계획서2. 조세증명서"
            )
        }
    }
    articles = parse_admrul_articles(
        payload,
        law_name="외국환거래규정",
        target="admrul",
        source_role="regulation_article",
        source_url="https://www.law.go.kr",
        identifier="TEST",
    )
    assert [article.article.replace(" ", "") for article in articles] == [
        "제2-3조",
        "제2-4조",
        "제2-5조",
        "제2-6조",
        "제9-5조",
    ]
    assert articles[3].title == "대출"
    assert "\n①" in articles[-1].text
    assert "\n1. 사업계획서" in articles[-1].text
    assert "\n2. 조세증명서" in articles[-1].text


def test_administrative_rule_preserves_deleted_paragraphs_and_items():
    """``<삭제>``는 HTML tag가 아니라 법령 구조 정보이므로 보존한다."""

    payload = {
        "행정규칙": {
            "조문내용": (
                "제9-5조(해외직접투자의 신고 등)③ 다음 각 호의 서류를 제출한다."
                "1. 사업계획서2. <삭 제>3. <삭제>4. 신용정보 확인서류"
                "④ <삭 제>⑤ 사후신고를 할 수 있다.⑥ <삭제>"
            )
        }
    }
    articles = parse_admrul_articles(
        payload,
        law_name="외국환거래규정",
        target="admrul",
        source_role="regulation_article",
        source_url="https://www.law.go.kr",
        identifier="TEST",
    )

    assert len(articles) == 1
    text = articles[0].text
    assert "\n2. 삭제" in text
    assert "\n3. 삭제" in text
    assert "\n④ 삭제" in text
    assert "\n⑤ 사후신고를 할 수 있다." in text
    assert "\n⑥ 삭제" in text
