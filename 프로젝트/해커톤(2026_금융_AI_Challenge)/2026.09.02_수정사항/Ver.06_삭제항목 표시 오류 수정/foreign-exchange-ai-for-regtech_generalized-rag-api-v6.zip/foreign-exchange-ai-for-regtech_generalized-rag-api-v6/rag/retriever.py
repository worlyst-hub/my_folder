"""RAG 검색 Pipeline 오케스트레이션 (섹션 15~17).

국가법령정보센터 PDF(``RAG_MODE=pdf``) 또는 샘플 규정 데이터
(``RAG_MODE=mock``)를 읽어 Chunking → Embedding → Vector DB 색인을 수행하고,
질의에 대해 관련 법령/조문을 검색한다.

RAG 결과는 은행원의 업무 참고 정보이며 법률적 최종 판단으로 표현하지 않는다.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace

import chromadb
from sqlalchemy import select

from config.settings import get_settings
from database.connection import get_session
from database.models import RagChunk, RagDocument
from schemas.analysis import RegulationMatch
from rag.chunker import chunk_pages
from rag.document_loader import load_all_regulation_pdfs
from rag.embedder import ChunkEmbedder
from rag.law_api import load_target_regulations
from rag.sample_regulations import SAMPLE_FILE_NAME, SAMPLE_REGULATIONS
from utils.logging import get_logger

logger = get_logger(__name__)


# 필요서류 검색은 단순 의미 유사도만으로 정렬하면 "해외직접투자의 수단"처럼
# 거래 주제는 맞지만 제출서류와 무관한 조문이 상위에 오를 수 있다. 아래 표현은
# 법령에서 실제 제출/첨부 의무를 나타낼 때 반복적으로 쓰이는 문구만 모아 둔 것이다.
_REQUIRED_DOCUMENT_STRONG_CUES = (
    "다음 각호의 서류",
    "다음 각 호의 서류",
    "서류를 첨부",
    "서류를 첨부하여",
    "첨부하여 제출",
    "신고서",
    "신청서",
    "구비서류",
    "증빙서류",
    "제출하여야",
    "제출해야",
    "별지 제",
)
_REQUIRED_DOCUMENT_WEAK_CUES = (
    "서류",
    "첨부",
    "제출",
    "신고",
    "신청",
    "입증",
    "증빙",
    "별지",
)
# 제출서류 목록이 다음 Child로 이어질 때 그 Child에는 ``첨부/제출`` 같은
# 동사가 없이 문서명만 나오는 경우가 많다. Ranking 신호와 분리해서 sibling
# 확장에만 사용하는 문서명 단서다.
_DOCUMENT_NAME_CUES = (
    "신고서", "신청서", "계획서", "계약서", "확인서", "증명서", "허가서",
    "승인서", "보고서", "명세서", "내역서", "사본", "등본", "원본", "영수증",
    "증서", "재무제표", "정관", "회의록", "공증서", "번역문", "사업자등록증",
)
# 이 화면의 '필요서류'는 현재 거래를 실행/신고할 때 확인할 서류가 목적이다.
# 사후관리·청산·변경 보고 문구는 완전히 제외하지는 않고 동점 시 뒤로 보내는
# 정도의 작은 패널티만 준다.
_REQUIRED_DOCUMENT_POST_CUES = (
    "사후관리",
    "청산",
    "변경사항",
    "내용을 변경",
    "사후보고",
    "연간사업실적보고",
)
_REQUIRED_DOCUMENT_SPECIAL_CUES = (
    "규정에도 불구하고",
    "에도 불구하고",
)

# '제출'이라는 단어만으로는 고객 제출의무인지 기관의 보고의무인지 구별할 수
# 없다. 예를 들어 "한국수출입은행장은 ... 보고서를 제출하여야 한다"는 문장은
# 필요서류 검색에는 부적절하다. 주어가 거래 당사자/신고인인 경우에는 가점을,
# 기관장인 경우에는 감점을 준다. 단, "외국환은행의 장에게 제출"처럼 기관이
# 목적어인 문장은 감점되지 않도록 조사(은/는/이/가)가 붙은 주어형만 잡는다.
_PARTY_ACTOR_RE = re.compile(
    r"(?:"
    r"거주자|비거주자|신고인|신청인|지급인|송금인|투자자|취득자|양수인|양도인"
    r")[은는이가]|(?:하고자\s*하는|하려는|신고하는|신청하는)\s*자[는가]"
)
_INSTITUTION_ACTOR_RE = re.compile(
    r"(?:"
    r"외국환은행(?:의\s*장)?|지정거래외국환은행(?:의\s*장)?|한국은행(?:총재)?|"
    r"한국수출입은행(?:의\s*장)?|기획재정부장관|재정경제부장관|금융위원회|"
    r"금융감독원장|국세청장|관세청장|은행장"
    r")[은는이가]"
)

# 거래 단계가 다른 조문이 상위로 섞이는 것을 줄이기 위한 범용 행위어 집합.
# 특정 사유코드나 특정 조문 번호를 하드코딩하지 않고, 확정된 사유코드명과
# 거래 분석 결과에서 실제 등장한 행위어만 사용한다.
_ACTION_VOCAB = (
    "취득", "구매", "매입", "처분", "매각", "회수", "임대", "설립", "설치",
    "지분인수", "인수", "증자", "출자", "투자", "청약", "대여", "차입", "도입",
    "상환", "청산", "보증", "증여", "상속", "반출", "송금", "지급", "수입", "수출",
    "등록", "납부", "운영", "사후관리", "변경",
)

_ACTION_CONFLICTS: dict[str, set[str]] = {
    "취득": {"처분", "매각", "회수", "청산"},
    "구매": {"처분", "매각", "회수", "청산"},
    "매입": {"처분", "매각", "회수", "청산"},
    "설립": {"청산", "매각", "회수"},
    "설치": {"청산", "폐쇄", "회수"},
    "지분인수": {"매각", "회수", "청산"},
    "인수": {"매각", "회수", "청산"},
    "증자": {"감자", "청산", "회수"},
    "출자": {"회수", "청산", "매각"},
    "투자": {"회수", "청산"},
    "처분": {"취득", "구매", "매입"},
    "매각": {"취득", "구매", "매입"},
    "회수": {"취득", "설립", "증자", "출자"},
    "차입": {"대여"},
    "대여": {"차입"},
    "도입": {"상환"},
    "상환": {"도입"},
}
_FOCUS_STOPWORDS = {
    "관련", "거래", "송금", "지급", "사유", "목적", "자본거래", "경상거래",
    "신고", "신청", "제출", "서류", "필요서류", "증빙서류", "첨부서류",
    "대한", "위한", "해외", "비용", "대금", "자금", "투자",
}
_FOCUS_TOKEN_RE = re.compile(r"[가-힣A-Za-z0-9]+")

# 조문 번호나 사유코드를 하드코딩하지 않고, 제한적 적용대상을 나타내는
# 표현이 현재 거래문맥에도 있을 때만 해당 Parent를 허용한다.
_RESTRICTED_SCOPE_TERMS = (
    "역외금융회사",
    "현지법인금융기관",
    "외국금융기관",
    "금융ㆍ보험업",
    "금융·보험업",
)


@dataclass(frozen=True)
class _SearchCandidate:
    metadata: dict
    document: str
    semantic_score: float
    rank_score: float
    tag_overlap: int
    topic_overlap: int
    structure_overlap: int
    action_overlap: int
    actor_score: float
    direction_score: float
    has_document_cue: bool


def build_required_document_query(
    *,
    reason_name: str,
    reason_category: str | None = None,
    reason_description: str | None = None,
    reason_keywords: list[str] | None = None,
    normalized_purpose: str | None = None,
    raw_purpose: str | None = None,
) -> str:
    """사유코드 종류와 무관한 '거래 당사자 필요서류' 검색 Query를 만든다.

    해외직접투자, 해외부동산, 증권, 금전대차 등 특정 거래유형을 코드에
    하드코딩하지 않는다. 확정된 사유코드/거래 문맥을 그대로 주제로 사용하고,
    검색 목적만 "거래 당사자가 신고·신청 시 제출할 서류"로 고정한다.

    나중에 PDF Loader를 국가법령정보 공동활용 API Loader로 교체해도 이 Query
    생성 로직과 아래 Retrieval/Reranking은 그대로 재사용할 수 있다.
    """

    topic_parts = [
        reason_name,
        reason_category or "",
        reason_description or "",
        " ".join(reason_keywords or []),
        normalized_purpose or "",
        raw_purpose or "",
    ]
    intent = (
        "거래 당사자 거주자 신고인 신청인이 해당 거래를 하기 위하여 "
        "외국환은행 또는 관계기관에 신고 신청할 때 제출하여야 하는 "
        "신고서 신청서 첨부서류 구비서류 증빙서류 입증서류 별지 서식 "
        "다음 각 호의 서류 서류를 첨부하여 제출"
    )
    return " ".join(part.strip() for part in topic_parts + [intent] if part and part.strip())


def _normalize_focus_terms(values: list[str] | None) -> list[str]:
    """사유코드명 등에서 검색 주제를 나타내는 짧은 핵심어를 뽑는다."""

    terms: list[str] = []
    seen: set[str] = set()
    for value in values or []:
        for token in _FOCUS_TOKEN_RE.findall(str(value or "")):
            token = token.strip()
            if len(token) < 2 or token in _FOCUS_STOPWORDS or token in seen:
                continue
            seen.add(token)
            terms.append(token)

            # 일반어 '해외' 자체는 너무 넓어 제외하지만, 해외부동산/해외직접투자
            # 같은 복합어는 법령 원문에서 '외국에 있는 부동산'/ '직접투자'처럼
            # 다른 표현으로 쓰일 수 있다. 특정 사유코드 하드코딩 없이 접두어만
            # 정규화해 법령 표현 차이를 흡수한다.
            if token.startswith("해외") and len(token) > 2:
                tail = token[2:]
                for variant in (tail, f"외국{tail}"):
                    if len(variant) >= 2 and variant not in _FOCUS_STOPWORDS and variant not in seen:
                        seen.add(variant)
                        terms.append(variant)
    return terms[:18]


def _normalize_action_terms(values: list[str] | None) -> list[str]:
    """사유코드/거래 분석 문맥에서 실제 거래 행위어만 추린다."""

    joined = " ".join(str(value or "") for value in values or [])
    terms = [term for term in _ACTION_VOCAB if term in joined]
    # '해외직접투자 청산대금 회수'에서 넓은 주제어인 투자 때문에 청산/회수가
    # 반대 단계처럼 처리되지 않게, 더 구체적인 행위가 있으면 투자만 제거한다.
    if "투자" in terms and any(term != "투자" for term in terms):
        terms.remove("투자")
    return terms


def _actor_relevance_score(text: str) -> float:
    """거래 당사자의 제출의무인지, 기관의 보고의무인지 구분하는 보정값."""

    party_hits = len(_PARTY_ACTOR_RE.findall(text))
    institution_hits = len(_INSTITUTION_ACTOR_RE.findall(text))
    return min(0.24, party_hits * 0.08) - min(0.45, institution_hits * 0.15)


def _detect_direction(values: list[str] | None) -> str | None:
    """거래 문맥이 국외 대상인지 국내 대상인지 최소한의 방향성만 추출한다."""

    joined = " ".join(str(value or "") for value in values or [])
    if any(term in joined for term in ("해외", "국외", "외국에 있는", "외국소재")):
        return "outbound"
    if any(term in joined for term in ("국내", "국내에 있는")):
        return "domestic"
    return None


def _direction_relevance_score(text: str, direction: str | None) -> float:
    """해외 거래인데 '국내에 있는 부동산' 조문이 섞이는 식의 역방향 오탐을 감점."""

    if direction == "outbound":
        positive = any(
            term in text
            for term in (
                "외국에 있는", "외국부동산", "해외소재", "해외부동산",
                "해외직접투자", "해외지사",
            )
        )
        negative = any(
            term in text
            for term in (
                "국내에 있는", "국내부동산", "국내지사", "국내에 지점",
                "외국기업등의 국내",
            )
        )
    elif direction == "domestic":
        positive = any(term in text for term in ("국내에 있는", "국내부동산", "국내지사"))
        negative = any(
            term in text
            for term in (
                "외국에 있는", "외국부동산", "해외소재", "해외부동산",
                "해외직접투자", "해외지사",
            )
        )
    else:
        return 0.0

    score = 0.10 if positive else 0.0
    if negative:
        score -= 0.30
    return score


def _action_relevance(
    text: str,
    action_terms: list[str],
) -> tuple[int, int]:
    """현재 거래 단계와의 일치 수 / 반대 단계 표현 수를 반환한다."""

    overlap = sum(1 for term in action_terms if term in text)
    conflicts: set[str] = set()
    for term in action_terms:
        conflicts.update(_ACTION_CONFLICTS.get(term, set()))
    conflict_hits = sum(1 for term in conflicts if term in text)
    return overlap, conflict_hits


def _required_document_rank_score(
    *,
    text: str,
    structure_text: str,
    semantic_score: float,
    focus_terms: list[str],
    action_terms: list[str],
    direction: str | None,
) -> tuple[float, bool, int, int, float, float]:
    """필요서류 목적에 맞게 Child 후보를 재정렬할 점수를 만든다.

    임베딩 유사도는 그대로 핵심 신호로 유지하되, 실제 법령 문장에
    '신고서에 서류를 첨부하여 제출' 같은 제출 의무 표현이 있는 Child를
    우선한다. RegulationMatch.score에는 이 점수가 아니라 기존 의미 유사도를
    그대로 노출하므로 UI의 '유사도 참고값' 의미도 바뀌지 않는다.
    """

    normalized = re.sub(r"\s+", " ", text or "")
    normalized_structure = re.sub(r"\s+", " ", structure_text or "")
    strong_hits = sum(1 for cue in _REQUIRED_DOCUMENT_STRONG_CUES if cue in normalized)
    weak_hits = sum(1 for cue in _REQUIRED_DOCUMENT_WEAK_CUES if cue in normalized)
    # 사후관리/청산/변경은 일반 거래에서는 후순위가 맞지만, 현재 사유 자체가
    # 그 단계이면 오히려 핵심이다. 사유코드/거래문맥에서 실제 단계가 확인된
    # 경우에는 해당 post cue를 감점하지 않는다.
    active_post_cues: set[str] = set()
    if "청산" in action_terms or "회수" in action_terms:
        active_post_cues.add("청산")
    if "사후관리" in action_terms:
        active_post_cues.update({"사후관리", "사후보고", "연간사업실적보고"})
    if "변경" in action_terms:
        active_post_cues.update({"변경사항", "내용을 변경"})
    post_hits = sum(
        1
        for cue in _REQUIRED_DOCUMENT_POST_CUES
        if cue in normalized and cue not in active_post_cues
    )
    special_hits = sum(1 for cue in _REQUIRED_DOCUMENT_SPECIAL_CUES if cue in normalized)
    topic_hits = sum(1 for term in focus_terms if term in normalized)
    structure_hits = sum(1 for term in focus_terms if term in normalized_structure)
    action_hits, conflict_hits = _action_relevance(normalized, action_terms)
    actor_score = _actor_relevance_score(normalized)
    direction_score = _direction_relevance_score(
        f"{normalized_structure} {normalized}".strip(), direction
    )

    # 강한 제출의무 표현은 크게, 단순 '신고/제출' 출현은 작게 반영한다.
    intent_bonus = min(0.55, strong_hits * 0.11 + weak_hits * 0.025)
    topic_bonus = min(0.24, topic_hits * 0.08)
    structure_bonus = min(0.30, structure_hits * 0.10)
    action_bonus = min(0.16, action_hits * 0.08)
    post_penalty = min(0.18, post_hits * 0.06)
    special_penalty = min(0.12, special_hits * 0.06)
    conflict_penalty = min(0.20, conflict_hits * 0.08)
    rank_score = (
        semantic_score
        + intent_bonus
        + topic_bonus
        + structure_bonus
        + action_bonus
        + actor_score
        + direction_score
        - post_penalty
        - special_penalty
        - conflict_penalty
    )
    return (
        rank_score,
        bool(strong_hits or weak_hits >= 2),
        structure_hits,
        action_hits,
        actor_score,
        direction_score,
    )


class RagRetriever:
    INDEX_VERSION = "hierarchical_v6_api_deleted_markers"

    def __init__(self) -> None:
        settings = get_settings()
        self._settings = settings
        self._embedder = ChunkEmbedder()
        chroma_client = chromadb.PersistentClient(path=settings.chroma_persist_dir)
        self._collection = chroma_client.get_or_create_collection(
            # 기존 고정-window 인덱스와 섞이지 않도록 실험 버전을 별도 collection으로 둔다.
            # v2: chapter/section 구조 metadata를 함께 저장해, '해외부동산' 검색이
            # '비거주자의 국내부동산' 조문으로 새는 문제를 구조적으로 줄인다.
            # 기존 v1 인덱스와 섞이지 않도록 별도 collection을 사용한다.
            name=(
                f"rag_chunks_hierarchical_v6_{settings.rag_mode}_"
                f"{self._embedder.backend_name}"
            ),
            metadata={"hnsw:space": "cosine"},
        )

        # rag_v2_ordered와 같은 원칙으로 긴 Parent 조문을 모든 Child metadata에
        # 반복 저장하지 않는다. Child에는 parent_id만 두고 Parent는 JSON에 1회 저장한다.
        self._parent_store_path = Path(settings.chroma_persist_dir) / (
            f"rag_parents_hierarchical_v6_{settings.rag_mode}_{self._embedder.backend_name}.json"
        )
        self._parents = self._load_parent_store()
        self._form_store_path = Path(settings.chroma_persist_dir) / (
            f"rag_forms_v6_{settings.rag_mode}.json"
        )
        self._forms = self._load_form_store()

    @property
    def embedding_backend(self) -> str:
        """실제 사용 중인 임베딩 백엔드("ollama"/"hash"). services/reason_code/mapper.py의
        동일 프로퍼티 참고 - Ollama 연결 실패 시 조용히 해시 임베딩으로 폴백하는 것을
        화면에 노출하기 위함이다."""

        return self._embedder.backend_name

    @property
    def index_version(self) -> str:
        """화면 session cache가 RAG 로직 버전까지 구분하도록 공개한다."""

        return f"{self.INDEX_VERSION}:{self._settings.rag_mode}:{self._embedder.backend_name}"

    def _load_parent_store(self) -> dict[str, dict]:
        if not self._parent_store_path.is_file():
            return {}
        try:
            with self._parent_store_path.open("r", encoding="utf-8") as f:
                data = json.load(f)
            return data if isinstance(data, dict) else {}
        except Exception:
            logger.exception("RAG Parent 저장소 읽기 실패: %s", self._parent_store_path)
            return {}

    def _save_parent_store(self) -> None:
        self._parent_store_path.parent.mkdir(parents=True, exist_ok=True)
        temp_path = self._parent_store_path.with_suffix(self._parent_store_path.suffix + ".tmp")
        with temp_path.open("w", encoding="utf-8") as f:
            json.dump(self._parents, f, ensure_ascii=False, indent=2)
        temp_path.replace(self._parent_store_path)

    def _load_form_store(self) -> list[dict]:
        if not self._form_store_path.is_file():
            return []
        try:
            data = json.loads(self._form_store_path.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        except Exception:
            logger.exception("RAG 서식 저장소 읽기 실패: %s", self._form_store_path)
            return []

    def _save_form_store(self) -> None:
        self._form_store_path.parent.mkdir(parents=True, exist_ok=True)
        temp_path = self._form_store_path.with_suffix(self._form_store_path.suffix + ".tmp")
        temp_path.write_text(
            json.dumps(self._forms, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        temp_path.replace(self._form_store_path)

    def _register_parent(
        self,
        *,
        parent_id: str | None,
        content: str,
        law_name: str,
        article: str | None,
        file_name: str,
        page_number: int | None,
        chapter: str | None = None,
        section: str | None = None,
        source_role: str = "regulation_article",
        source_url: str = "",
        effective_date: str = "",
    ) -> str:
        resolved_id = parent_id or f"{file_name}:{article or 'generic'}:{len(self._parents)}"
        self._parents[resolved_id] = {
            "content": content,
            "law_name": law_name,
            "article": article or "",
            "file_name": file_name,
            "page_number": page_number or 0,
            "chapter": chapter or "",
            "section": section or "",
            "source_role": source_role,
            "source_url": source_url,
            "effective_date": effective_date,
        }
        return resolved_id

    # ------------------------------------------------------------------
    # 색인
    # ------------------------------------------------------------------

    def build_index(self, force: bool = False) -> int:
        if self._collection.count() > 0:
            if not force and self._parents:
                logger.info("RAG 인덱스가 이미 존재합니다 (force=True로 재생성 가능)")
                return self._collection.count()
            if not force and not self._parents:
                logger.warning("Child 인덱스는 있으나 Parent 저장소가 없어 자동 재생성합니다.")
            existing_ids = self._collection.get()["ids"]
            if existing_ids:
                self._collection.delete(ids=existing_ids)

        # 재색인 시 Parent도 새 원문 기준으로 다시 구성한다.
        self._parents = {}
        self._forms = []

        # SQL의 rag_documents/rag_chunks는 "가장 최근에 색인한 한 벌"만 원문 출처로
        # 보존한다. 임베딩 백엔드(Mock 해시 ↔ Ollama)를 변경해 컬렉션 이름이
        # 바뀌면 이전 컬렉션의 벡터는 그대로 남지만 SQL 원문은 새로 색인한
        # 데이터로 교체된다 - 프로토타입 범위에서는 이 제약을 감수한다.
        with get_session() as session:
            session.execute(RagChunk.__table__.delete())
            session.execute(RagDocument.__table__.delete())

        chunk_rows = self._build_source_chunks()
        if not chunk_rows:
            logger.warning("색인할 RAG 문서가 없습니다.")
            return 0

        texts = [row["content"] for row in chunk_rows]
        embeddings = self._embedder.embed(texts)

        self._collection.add(
            ids=[str(row["chunk_id"]) for row in chunk_rows],
            embeddings=embeddings,
            documents=texts,
            metadatas=[
                {
                    "law_name": row["law_name"],
                    "article": row["article"] or "",
                    "file_name": row["file_name"],
                    "page_number": row["page_number"] or 0,
                    "is_sample": row["is_sample"],
                    "regulation_tags": "|".join(row.get("regulation_tags") or []),
                    # Child 벡터가 검색되면 조문 전체 Parent를 복원하기 위한 연결 정보.
                    "parent_id": row.get("parent_id") or "",
                    "child_index": row.get("child_index", 0),
                    "child_count": row.get("child_count", 1),
                    "chapter": row.get("chapter") or "",
                    "section": row.get("section") or "",
                    # 필요서류 semantic search / 상위법 exact lookup / 서식 exact
                    # lookup을 같은 후보군에 섞지 않기 위한 source 역할.
                    "source_role": row.get("source_role") or "regulation_article",
                    "source_url": row.get("source_url") or "",
                    "effective_date": row.get("effective_date") or "",
                }
                for row in chunk_rows
            ],
        )
        self._save_parent_store()
        self._save_form_store()
        logger.info(
            "RAG 청크 %d건 / Parent %d건 인덱싱 완료 (embedding backend=%s)",
            len(chunk_rows),
            len(self._parents),
            self._embedder.backend_name,
        )
        return len(chunk_rows)

    def _build_source_chunks(self) -> list[dict]:
        """PDF(있으면) 또는 샘플 규정 데이터를 SQL(RagDocument/RagChunk)에 저장하고,
        Chroma 색인에 필요한 정보를 함께 반환한다."""

        if self._settings.rag_mode == "api":
            return self._store_api_chunks(load_target_regulations())

        if self._settings.rag_mode == "pdf":
            pages = load_all_regulation_pdfs(self._settings.regulation_pdf_dir)
            if pages:
                return self._store_pdf_chunks(pages)
            logger.warning(
                "RAG_MODE=pdf 이지만 data/regulations/ 에 PDF가 없어 샘플 규정으로 대체합니다."
            )

        return self._store_sample_chunks()

    def _store_api_chunks(self, documents) -> list[dict]:
        """API snapshot의 조문만 semantic/exact article index에 저장한다.

        별표·별지·서식은 별도 JSON store에 보존하며 벡터 후보로 넣지 않는다.
        따라서 서식 본문의 반복적인 '제출/첨부' 표현이 필요서류 조문 순위를
        오염시키지 않는다.
        """

        rows: list[dict] = []
        with get_session() as session:
            for document in documents:
                file_name = (
                    f"국가법령정보API_{document.law_name}_{document.identifier or 'current'}.json"
                )
                doc = RagDocument(
                    file_name=file_name,
                    title=document.law_name,
                    is_sample=False,
                )
                session.add(doc)
                session.flush()

                chunk_index = 0
                for article in document.articles:
                    chunks = chunk_pages(
                        [SimpleNamespace(page_number=None, text=article.text)],
                        source_name=(
                            f"api:{document.law_name}:{document.identifier}:{article.article or chunk_index}"
                        ),
                    )
                    for chunk in chunks:
                        row = RagChunk(
                            document_id=doc.id,
                            chunk_index=chunk_index,
                            page_number=None,
                            article=article.article or chunk.article,
                            content=chunk.content,
                        )
                        session.add(row)
                        session.flush()
                        parent_id = self._register_parent(
                            parent_id=chunk.parent_id,
                            content=chunk.parent_content or article.text,
                            law_name=document.law_name,
                            article=row.article,
                            file_name=file_name,
                            page_number=None,
                            chapter=article.chapter or chunk.chapter,
                            section=article.section or chunk.section,
                            source_role=document.source_role,
                            source_url=article.source_url or document.source_url,
                            effective_date=article.effective_date or document.effective_date,
                        )
                        rows.append(
                            {
                                "chunk_id": row.id,
                                "content": row.content,
                                "law_name": document.law_name,
                                "article": row.article,
                                "file_name": file_name,
                                "page_number": None,
                                "is_sample": False,
                                "regulation_tags": [],
                                "parent_id": parent_id,
                                "child_index": chunk.child_index,
                                "child_count": chunk.child_count,
                                "chapter": article.chapter or chunk.chapter,
                                "section": article.section or chunk.section,
                                "source_role": document.source_role,
                                "source_url": article.source_url or document.source_url,
                                "effective_date": article.effective_date or document.effective_date,
                            }
                        )
                        chunk_index += 1

                for form in document.forms:
                    self._forms.append(
                        {
                            "law_name": form.law_name,
                            "target": form.target,
                            "title": form.title,
                            "form_number": form.form_number,
                            "branch_number": form.branch_number,
                            "form_kind": form.form_kind,
                            "text": form.text,
                            "source_url": form.source_url,
                            "identifier": form.identifier,
                        }
                    )
        return rows

    def _store_pdf_chunks(self, pages) -> list[dict]:
        """PDF를 파일 단위로 묶어 조(Parent) → Child 계층 청킹한다.

        기존에는 각 PDF 페이지를 독립적으로 600자 슬라이딩 윈도우로 잘랐기
        때문에 하나의 조문이 페이지를 넘기면 문맥이 끊겼다. 이제 같은 파일의
        페이지들을 순서대로 ``chunk_pages``에 넘겨 조문 전체 Parent를 먼저 만들고,
        항·호·목/재귀 분할로 만든 Child만 임베딩 대상으로 저장한다.
        """

        rows: list[dict] = []
        pages_by_file: dict[str, list] = {}
        for page in pages:
            pages_by_file.setdefault(page.file_name, []).append(page)

        with get_session() as session:
            for file_name, file_pages in pages_by_file.items():
                file_pages = sorted(file_pages, key=lambda page: page.page_number)
                source_role = (
                    "regulation_article"
                    if "외국환거래규정" in file_name
                    else "higher_law"
                )
                if "외국환거래규정" in file_name:
                    law_name = "외국환거래규정"
                elif "시행령" in file_name:
                    law_name = "외국환거래법 시행령"
                elif "외국환거래법" in file_name:
                    law_name = "외국환거래법"
                else:
                    law_name = file_name

                doc = RagDocument(
                    file_name=file_name,
                    title=law_name,
                    is_sample=False,
                )
                session.add(doc)
                session.flush()

                chunks = chunk_pages(
                    file_pages,
                    source_name=file_name,
                )

                for i, chunk in enumerate(chunks):
                    row = RagChunk(
                        document_id=doc.id,
                        chunk_index=i,
                        page_number=chunk.page_number,
                        article=chunk.article,
                        # SQL에는 실제 검색 단위인 Child를 보존한다.
                        content=chunk.content,
                    )
                    session.add(row)
                    session.flush()

                    parent_id = self._register_parent(
                        parent_id=chunk.parent_id,
                        content=chunk.parent_content or chunk.content,
                        law_name=doc.title or doc.file_name,
                        article=row.article,
                        file_name=doc.file_name,
                        page_number=row.page_number,
                        chapter=chunk.chapter,
                        section=chunk.section,
                        source_role=source_role,
                    )
                    rows.append(
                        {
                            "chunk_id": row.id,
                            "content": row.content,
                            "law_name": doc.title or doc.file_name,
                            "article": row.article,
                            "file_name": doc.file_name,
                            "page_number": row.page_number,
                            "is_sample": False,
                            "regulation_tags": [],
                            "parent_id": parent_id,
                            "child_index": chunk.child_index,
                            "child_count": chunk.child_count,
                            "chapter": chunk.chapter,
                            "section": chunk.section,
                            "source_role": source_role,
                            "source_url": "",
                            "effective_date": "",
                        }
                    )
        return rows

    def _store_sample_chunks(self) -> list[dict]:
        rows: list[dict] = []
        with get_session() as session:
            doc = RagDocument(file_name=SAMPLE_FILE_NAME, title="외국환거래규정 (샘플)", is_sample=True)
            session.add(doc)
            session.flush()

            for i, sample in enumerate(SAMPLE_REGULATIONS):
                row = RagChunk(
                    document_id=doc.id,
                    chunk_index=i,
                    page_number=None,
                    article=sample.article,
                    content=sample.content,
                )
                session.add(row)
                session.flush()
                parent_id = self._register_parent(
                    parent_id=f"sample:{sample.law_name}:{sample.article}",
                    content=row.content,
                    law_name=sample.law_name,
                    article=row.article,
                    file_name=doc.file_name,
                    page_number=None,
                    chapter=None,
                    section=None,
                    source_role="sample",
                )
                rows.append(
                    {
                        "chunk_id": row.id,
                        "content": row.content,
                        "law_name": sample.law_name,
                        "article": row.article,
                        "file_name": doc.file_name,
                        "page_number": None,
                        "is_sample": True,
                        "regulation_tags": sample.regulation_tags,
                        "parent_id": parent_id,
                        "child_index": 0,
                        "child_count": 1,
                        "chapter": None,
                        "section": None,
                        "source_role": "sample",
                        "source_url": "",
                        "effective_date": "",
                    }
                )
        return rows

    # ------------------------------------------------------------------
    # 검색
    # ------------------------------------------------------------------

    def _verify_parent(
        self,
        candidate: _SearchCandidate,
        *,
        focus_terms: list[str],
        action_terms: list[str],
        direction: str | None,
        context_text: str,
    ) -> tuple[bool, float]:
        """Child가 속한 실제 Parent의 주제·단계·주체·적용범위를 재검증한다."""

        parent_id = candidate.metadata.get("parent_id") or ""
        parent = self._parents.get(parent_id, {})
        parent_text = str(parent.get("content") or candidate.document)
        structure = " ".join(
            filter(
                None,
                [
                    str(parent.get("chapter") or ""),
                    str(parent.get("section") or ""),
                    parent_text[:500],
                ],
            )
        )
        compact_parent = re.sub(r"\s+", " ", parent_text)
        compact_context = re.sub(r"\s+", "", context_text)

        # '역외금융회사' 등 제한적 적용대상이 Parent의 제목/도입부에 명시된
        # 조문은 현재 거래에도 같은 표현이 있을 때만 통과시킨다.
        for scope in _RESTRICTED_SCOPE_TERMS:
            if scope in structure and re.sub(r"\s+", "", scope) not in compact_context:
                return False, -1.0

        party = bool(_PARTY_ACTOR_RE.search(compact_parent))
        institution = bool(_INSTITUTION_ACTOR_RE.search(compact_parent))
        if institution and not party:
            return False, -1.0

        direction_score = _direction_relevance_score(structure, direction)
        if direction_score <= -0.25:
            return False, direction_score

        topic_hits = sum(1 for term in focus_terms if term in structure)
        action_hits, conflict_hits = _action_relevance(compact_parent, action_terms)
        if action_terms and conflict_hits >= 2 and not (action_hits or candidate.action_overlap):
            return False, -0.6

        document_anchor = any(
            cue in compact_parent for cue in _REQUIRED_DOCUMENT_STRONG_CUES
        )
        bonus = min(0.18, topic_hits * 0.04) + min(0.10, action_hits * 0.04)
        bonus += 0.06 if party else 0.0
        bonus += 0.05 if document_anchor else -0.08
        bonus += direction_score - min(0.16, conflict_hits * 0.05)
        return True, bonus

    @staticmethod
    def _without_repeated_article_header(text: str, article: str) -> str:
        lines = str(text or "").strip().splitlines()
        if lines and article and article.replace(" ", "") in lines[0].replace(" ", ""):
            return "\n".join(lines[1:]).strip()
        return str(text or "").strip()

    def _expand_required_document_context(self, candidate: _SearchCandidate) -> str:
        """같은 Parent에서 제출서류 anchor와 실제 목록 continuation만 확장한다."""

        metadata = candidate.metadata
        parent_id = metadata.get("parent_id") or ""
        if not parent_id:
            return candidate.document
        try:
            siblings = self._collection.get(
                where={"parent_id": parent_id}, include=["documents", "metadatas"]
            )
        except Exception:
            logger.exception("같은 조문 Child 확장 실패: parent_id=%s", parent_id)
            return candidate.document

        ordered = sorted(
            (
                (int(meta.get("child_index") or 0), document, meta)
                for document, meta in zip(
                    siblings.get("documents") or [], siblings.get("metadatas") or []
                )
                if document
            ),
            key=lambda item: item[0],
        )
        if len(ordered) <= 1:
            return candidate.document
        position_by_index = {index: position for position, (index, _, _) in enumerate(ordered)}
        matched = position_by_index.get(int(metadata.get("child_index") or 0))
        if matched is None:
            return candidate.document

        article = str(metadata.get("article") or "").strip()

        def body(position: int) -> str:
            return self._without_repeated_article_header(ordered[position][1], article)

        def has_anchor(value: str) -> bool:
            return bool(
                re.search(r"다음\s*각\s*호의\s*서류|서류를\s*첨부|첨부하여\s*제출", value)
            )

        def starts_list(value: str) -> bool:
            return bool(re.match(r"^\s*(?:\d+\s*[.)]|[가-하]\s*[.)])", value))

        def starts_new_paragraph(value: str) -> bool:
            return bool(re.match(r"^\s*[①-⑳]", value))

        # 검색된 Child가 목록 조각이면 최대 2개 앞에서 그 목록의 제출 anchor를
        # 찾는다. anchor가 아닌 단순 인접 Child는 절대 포함하지 않는다.
        start = matched
        anchor_position: int | None = matched if has_anchor(body(matched)) else None
        if anchor_position is None and starts_list(body(matched)):
            for position in range(matched - 1, max(-1, matched - 3), -1):
                if has_anchor(body(position)):
                    anchor_position = position
                    start = position
                    break

        end = matched
        if anchor_position is not None:
            end = max(end, anchor_position)
            for position in range(end + 1, min(len(ordered), anchor_position + 7)):
                value = body(position)
                # 새 항 또는 기관 자체 보고 문장에 진입하면 목록이 끝난 것이다.
                if starts_new_paragraph(value):
                    break
                if _INSTITUTION_ACTOR_RE.search(value) and not _PARTY_ACTOR_RE.search(value):
                    break
                doc_names = sum(1 for cue in _DOCUMENT_NAME_CUES if cue in value)
                if starts_list(value) or doc_names > 0:
                    end = position
                    continue
                break

        selected = ordered[start : end + 1]
        parts: list[str] = []
        for index, (_, document, _) in enumerate(selected):
            value = document.strip()
            if index > 0:
                value = self._without_repeated_article_header(value, article)
            if value:
                parts.append(value)
        expanded = "\n".join(parts).strip()
        return expanded if expanded and len(expanded) <= 6500 else candidate.document

    @staticmethod
    def _normalize_article_reference(value: str) -> str:
        match = re.search(r"제\s*\d+(?:-\d+)?\s*조(?:의\s*\d+)?", value or "")
        return re.sub(r"\s+", "", match.group(0)) if match else ""

    def get_articles(
        self,
        article_references: list[str] | tuple[str, ...],
        *,
        law_name: str = "외국환거래규정",
    ) -> list[RegulationMatch]:
        """알려진 근거 조문을 semantic 검색 없이 조문번호로 정확 조회한다."""

        if self._collection.count() == 0:
            self.build_index()
        wanted = [self._normalize_article_reference(value) for value in article_references]
        wanted = [value for value in wanted if value]
        if not wanted:
            return []
        result = self._collection.get(include=["documents", "metadatas"])
        by_article: dict[str, dict] = {}
        for document, metadata in zip(
            result.get("documents") or [], result.get("metadatas") or []
        ):
            if metadata.get("law_name") != law_name:
                continue
            article = self._normalize_article_reference(metadata.get("article") or "")
            if article not in wanted:
                continue
            parent_id = metadata.get("parent_id") or ""
            parent = self._parents.get(parent_id, {})
            by_article.setdefault(
                article,
                {
                    "metadata": metadata,
                    "content": parent.get("content") or document,
                },
            )

        matches: list[RegulationMatch] = []
        for article in wanted:
            found = by_article.get(article)
            if not found:
                continue
            metadata = found["metadata"]
            matches.append(
                RegulationMatch(
                    law_name=metadata.get("law_name") or law_name,
                    article=metadata.get("article") or None,
                    content=found["content"],
                    file_name=metadata.get("file_name") or "",
                    page_number=metadata.get("page_number") or None,
                    is_sample=bool(metadata.get("is_sample")),
                    score=1.0,
                    source_role=metadata.get("source_role") or "regulation_article",
                    source_url=metadata.get("source_url") or None,
                )
            )
        return matches

    def get_forms_by_reference(
        self, reference: str, *, law_name: str | None = None
    ) -> list[dict]:
        """'별지 제9-1호' 같은 참조번호로 별표/서식을 정확 조회한다."""

        compact = re.sub(r"\s+", "", reference or "")
        number_match = re.search(r"제?([0-9]+(?:[-의][0-9]+)?)호", compact)
        number = number_match.group(1).replace("의", "-") if number_match else ""
        if not number:
            return []
        results: list[dict] = []
        for form in self._forms:
            if law_name and form.get("law_name") != law_name:
                continue
            stored = str(form.get("form_number") or "").replace("의", "-")
            branch = str(form.get("branch_number") or "")
            joined = f"{stored}-{branch}".rstrip("-") if branch and branch != "0" else stored
            haystack = re.sub(r"\s+", "", f"{joined} {form.get('title', '')}")
            if number == joined or number in haystack:
                results.append(form)
        return results

    def search(
        self,
        query_text: str,
        top_k: int = 5,
        regulation_tags: list[str] | None = None,
        *,
        search_intent: str = "general",
        focus_terms: list[str] | None = None,
        action_terms: list[str] | None = None,
    ) -> list[RegulationMatch]:
        """관련 법령/조문을 검색한다.

        ``search_intent="required_documents"`` 인 경우에는 임베딩 유사도로
        후보를 넉넉히 가져온 뒤, '신고서/신청서 + 첨부/제출/서류'처럼 실제
        제출 의무가 나타나는 Child를 재정렬한다. 이때 확정된 사유코드의 주제와
        거래 행위(취득/처분/설립/상환 등), 그리고 문장의 의무 주체가 거래
        당사자인지도 함께 반영한다. 이 단계는 PDF/API 원문 형식과 무관한
        Retrieval 로직이므로 나중에 국가법령정보 공동활용 API로 입력원을 바꿔도
        그대로 재사용할 수 있다.

        ``regulation_tags`` 는 샘플 문서처럼 metadata에 태그가 있는 경우에만
        필터로 사용한다. 현재 PDF 색인에는 태그가 없으므로 PDF 검색 정확도는
        ``search_intent``/``focus_terms``와 임베딩 결과가 담당한다.
        """

        if self._collection.count() == 0:
            self.build_index()
        collection_count = self._collection.count()
        if collection_count == 0:
            return []

        query_embedding = self._embedder.embed([query_text])[0]

        # 기존 일반 검색(지급 절차 근거 조문 등)은 동작을 바꾸지 않기 위해 전체
        # 후보를 그대로 조회한다. 필요서류 검색은 장/절 구조와 의무 주체까지
        # 재정렬해야 하므로 후보를 넉넉히(최소 80개) 가져온다. 현재 PDF 규모에서는
        # 벡터 검색 비용이 작고, 여러 거래유형에 범용 적용할 때 recall을 확보하는
        # 편이 중요하다.
        if search_intent == "required_documents":
            # API에서는 외국환거래규정 조문만 1차 후보로 쓰므로 전체 법/시행령/
            # 서식을 한꺼번에 넓게 검색할 필요가 없다. recall을 확보하되 불필요한
            # 유사 후보 폭증을 막는 범위로 제한한다.
            candidate_count = min(collection_count, max(top_k * 10, 48))
        else:
            candidate_count = collection_count
        result = self._collection.query(
            query_embeddings=[query_embedding], n_results=candidate_count
        )

        requested_tags = set(regulation_tags or [])
        normalized_focus_terms = _normalize_focus_terms(focus_terms)
        normalized_action_terms = _normalize_action_terms(action_terms)
        search_direction = _detect_direction((focus_terms or []) + (action_terms or []))
        candidates: list[_SearchCandidate] = []
        seen_candidate_keys: set[tuple[str, int]] = set()

        for distance, metadata, document in zip(
            result["distances"][0], result["metadatas"][0], result["documents"][0]
        ):
            source_role = metadata.get("source_role") or "regulation_article"
            if search_intent == "required_documents" and source_role not in {
                "regulation_article",
                "sample",
            }:
                continue
            semantic_score = max(0.0, min(1.0, 1.0 - distance))
            metadata_tags = set(filter(None, (metadata.get("regulation_tags") or "").split("|")))
            tag_overlap = len(requested_tags & metadata_tags) if requested_tags else 0

            if search_intent == "required_documents":
                (
                    rank_score,
                    has_document_cue,
                    structure_overlap,
                    action_overlap,
                    actor_score,
                    direction_score,
                ) = _required_document_rank_score(
                    text=document,
                    structure_text=" ".join(
                        filter(None, [metadata.get("chapter") or "", metadata.get("section") or ""])
                    ),
                    semantic_score=semantic_score,
                    focus_terms=normalized_focus_terms,
                    action_terms=normalized_action_terms,
                    direction=search_direction,
                )
            else:
                rank_score = semantic_score
                has_document_cue = True
                structure_overlap = 0
                action_overlap = 0
                actor_score = 0.0
                direction_score = 0.0

            topic_overlap = sum(1 for term in normalized_focus_terms if term in document)
            candidate_key = (
                metadata.get("parent_id") or "",
                int(metadata.get("child_index") or 0),
            )
            seen_candidate_keys.add(candidate_key)
            candidates.append(
                _SearchCandidate(
                    metadata=metadata,
                    document=document,
                    semantic_score=semantic_score,
                    rank_score=rank_score,
                    tag_overlap=tag_overlap,
                    topic_overlap=topic_overlap,
                    structure_overlap=structure_overlap,
                    action_overlap=action_overlap,
                    actor_score=actor_score,
                    direction_score=direction_score,
                    has_document_cue=has_document_cue,
                )
            )

        if search_intent == "required_documents" and normalized_focus_terms:
            # 임베딩 Top-N 밖으로 핵심 조문이 밀리는 경우를 대비한 좁은 lexical
            # recall 보완이다. 전체 조문을 후보로 쓰는 것이 아니라, 현재 거래
            # 핵심어와 제출서류 단서가 동시에 있는 외국환거래규정 Child만 추가한다.
            # 특히 Ollama 없이 hash 임베딩으로 실행해도 제9-5조 같은 명시적 조문을
            # 놓치지 않게 하며 법/시행령/서식은 source_role에서 이미 제외된다.
            lexical = self._collection.get(include=["documents", "metadatas"])
            for document, metadata in zip(
                lexical.get("documents") or [], lexical.get("metadatas") or []
            ):
                if (metadata.get("source_role") or "regulation_article") not in {
                    "regulation_article",
                    "sample",
                }:
                    continue
                candidate_key = (
                    metadata.get("parent_id") or "",
                    int(metadata.get("child_index") or 0),
                )
                if candidate_key in seen_candidate_keys:
                    continue
                structure_text = " ".join(
                    filter(None, [metadata.get("chapter") or "", metadata.get("section") or ""])
                )
                topic_overlap = sum(1 for term in normalized_focus_terms if term in document)
                structure_overlap = sum(
                    1 for term in normalized_focus_terms if term in structure_text
                )
                if not (topic_overlap or structure_overlap):
                    continue
                (
                    rank_score,
                    has_document_cue,
                    scored_structure_overlap,
                    action_overlap,
                    actor_score,
                    direction_score,
                ) = _required_document_rank_score(
                    text=document,
                    structure_text=structure_text,
                    semantic_score=0.0,
                    focus_terms=normalized_focus_terms,
                    action_terms=normalized_action_terms,
                    direction=search_direction,
                )
                if not has_document_cue:
                    continue
                metadata_tags = set(
                    filter(None, (metadata.get("regulation_tags") or "").split("|"))
                )
                candidates.append(
                    _SearchCandidate(
                        metadata=metadata,
                        document=document,
                        semantic_score=0.0,
                        rank_score=rank_score,
                        tag_overlap=len(requested_tags & metadata_tags) if requested_tags else 0,
                        topic_overlap=topic_overlap,
                        structure_overlap=scored_structure_overlap,
                        action_overlap=action_overlap,
                        actor_score=actor_score,
                        direction_score=direction_score,
                        has_document_cue=True,
                    )
                )
                seen_candidate_keys.add(candidate_key)

        # 태그 metadata가 실제로 존재하면서 요청 태그와 겹치는 후보가 있을 때만
        # 기존처럼 태그 범위를 우선한다. PDF는 태그가 비어 있으므로 여기서 잘못
        # 전부 탈락하지 않고 전체 후보를 그대로 사용한다.
        if requested_tags and any(candidate.tag_overlap > 0 for candidate in candidates):
            candidates = [candidate for candidate in candidates if candidate.tag_overlap > 0]

        if search_intent == "required_documents":
            # 법령의 장/절 제목은 본문보다 거래유형을 더 직접적으로 나타내는 경우가
            # 많다(예: '제1절 해외직접투자', '제4절 거주자의 외국부동산 취득').
            # v2 인덱스에서는 이 구조 정보를 보존하므로, 구조상 명확히 맞는 후보가
            # 있으면 다른 장/절의 우연한 키워드 언급을 먼저 제거한다.
            structure_candidates = [
                candidate for candidate in candidates if candidate.structure_overlap > 0
            ]
            if structure_candidates:
                max_structure_overlap = max(
                    candidate.structure_overlap for candidate in structure_candidates
                )
                min_structure_overlap = max(1, max_structure_overlap - 1)
                narrowed = [
                    candidate
                    for candidate in structure_candidates
                    if candidate.structure_overlap >= min_structure_overlap
                ]
                candidates = narrowed or structure_candidates

            # 사유코드 핵심어(예: 해외직접투자)가 실제 본문에 등장하는 후보가 있으면
            # 우선 그 주제 안으로 범위를 좁힌다. 단순히 핵심어 1개만 우연히 겹치는
            # 타 거래 조문이 섞이지 않도록, 여러 핵심어가 동시에 맞는 후보가 있으면
            # 그 최대 커버리지에 가까운 후보를 우선한다. 핵심어가 법령 표현과 달라
            # 한 건도 안 잡히는 경우에는 자동으로 전체 후보에 폴백한다.
            if normalized_focus_terms:
                topic_candidates = [candidate for candidate in candidates if candidate.topic_overlap > 0]
                if topic_candidates:
                    # '법인/설립' 같은 일반 단어를 많이 반복하는 특수 조문이
                    # 핵심 조문을 사전에 제거하지 않게 여기서는 최소 1개 일치만
                    # 요구한다. 세부 우선순위는 Parent 적용범위 검증과 rank score가
                    # 담당한다.
                    candidates = topic_candidates

            # 제출서류 신호가 있는 후보가 하나라도 있으면 그 후보군 안에서만 Top-K를
            # 고른다. 없을 때는 임베딩 결과로 폴백하여 빈 화면이 되는 것을 막는다.
            document_candidates = [candidate for candidate in candidates if candidate.has_document_cue]
            if document_candidates:
                candidates = document_candidates

            # 같은 조문에 속한 여러 Child 중 하나만 우연히 높은 점수를 받은 경우보다,
            # 같은 조문 안에서 제출서류 단서가 반복적으로 확인되는 경우를 조금 더
            # 신뢰한다. 결과 화면에서는 조문별 1개 카드만 유지한다.
            parent_groups: dict[str, list[_SearchCandidate]] = {}
            for candidate in candidates:
                parent_key = (
                    candidate.metadata.get("parent_id")
                    or f"{candidate.metadata.get('file_name', '')}:{candidate.metadata.get('article', '')}"
                )
                parent_groups.setdefault(parent_key, []).append(candidate)

            ranked_parents: list[tuple[float, _SearchCandidate, list[_SearchCandidate]]] = []
            for group in parent_groups.values():
                group.sort(
                    key=lambda candidate: (
                        candidate.tag_overlap,
                        candidate.rank_score,
                        candidate.structure_overlap,
                        candidate.topic_overlap,
                        candidate.action_overlap,
                        candidate.semantic_score,
                    ),
                    reverse=True,
                )
                best = group[0]
                accepted, parent_bonus = self._verify_parent(
                    best,
                    focus_terms=normalized_focus_terms,
                    action_terms=normalized_action_terms,
                    direction=search_direction,
                    context_text=" ".join(
                        [query_text, *(focus_terms or []), *(action_terms or [])]
                    ),
                )
                if not accepted:
                    continue
                repeated_doc_cues = sum(1 for candidate in group if candidate.has_document_cue)
                group_bonus = min(0.12, max(0, repeated_doc_cues - 1) * 0.03)
                parent_score = best.rank_score + group_bonus + parent_bonus
                ranked_parents.append((parent_score, best, group))

            ranked_parents.sort(
                key=lambda item: (
                    item[0],
                    item[1].tag_overlap,
                    item[1].structure_overlap,
                    item[1].topic_overlap,
                    item[1].action_overlap,
                    item[1].semantic_score,
                ),
                reverse=True,
            )

            # 정답 후보 하나가 매우 강한 경우에는 단지 top_k를 채우기 위해 특수 예외
            # 조문이나 기관 보고의무 조문을 억지로 섞지 않는다. 최고 Parent 점수에서
            # 일정 범위 안에 있는 조문만 유지하고, 너무 엄격해져 0건이 되는 경우에는
            # 최고 후보 1건으로 폴백한다.
            if ranked_parents:
                best_parent_score = ranked_parents[0][0]
                close_parents = [
                    item for item in ranked_parents if item[0] >= best_parent_score - 0.22
                ]
                ranked_parents = close_parents or ranked_parents[:1]

            candidates = [item[1] for item in ranked_parents]
        else:
            candidates.sort(
                key=lambda candidate: (candidate.tag_overlap, candidate.semantic_score),
                reverse=True,
            )

        matches: list[RegulationMatch] = []
        seen_parents: set[str] = set()
        for candidate in candidates:
            metadata = candidate.metadata
            parent_key = (
                metadata.get("parent_id")
                or f"{metadata.get('file_name', '')}:{metadata.get('article', '')}"
            )
            if parent_key in seen_parents:
                continue
            seen_parents.add(parent_key)

            matches.append(
                RegulationMatch(
                    law_name=metadata.get("law_name") or "",
                    article=metadata.get("article") or None,
                    # 일반 검색은 기존처럼 실제 검색된 Child를 그대로 반환한다.
                    # 필요서류 검색은 같은 조문의 인접 Child까지 확장해, 제출서류
                    # 목록이 Chunk 경계에서 잘리는 문제를 줄인다. UI 구조는 바뀌지
                    # 않고 카드 안에 표시되는 원문 범위만 더 완전해진다.
                    content=(
                        self._expand_required_document_context(candidate)
                        if search_intent == "required_documents"
                        else (
                            self._without_repeated_article_header(
                                candidate.document,
                                metadata.get("article") or "",
                            )
                            if int(metadata.get("child_index") or 0) > 0
                            else candidate.document
                        )
                    ),
                    file_name=metadata.get("file_name") or "",
                    page_number=(metadata.get("page_number") or None),
                    is_sample=bool(metadata.get("is_sample")),
                    score=round(candidate.semantic_score, 4),
                    source_role=metadata.get("source_role") or "regulation_article",
                    source_url=metadata.get("source_url") or None,
                )
            )
            if len(matches) >= top_k:
                break

        return matches
