# 범용 필요서류 RAG + 국가법령정보 API V6

V6는 V5의 범용 검색 구조와 UI를 유지하면서 국가법령정보 API 원문의 삭제된
항·호 표시를 정확하게 보존한다.

## V6 수정 내용

- API 원문의 `<삭제>`와 `<삭 제>`를 HTML tag로 제거하지 않고 `삭제`로 보존
- 제9-5조제3항제2호·제3호처럼 삭제된 호를 빈 줄이 아닌 `2. 삭제`, `3. 삭제`로 표시
- 삭제된 제4항·제6항도 `④ 삭제`, `⑥ 삭제`로 표시
- 유효한 제5항이 앞의 필요서류 목록에 붙어 보이지 않도록 구조 경계 보존
- Streamlit Markdown이 항마다 다시 시작하는 호 번호를 임의의 연속 번호로
  바꾸지 않도록 표시 문자열만 escape
- 화면 배치, Expander, 체크박스 및 사용자 동선은 변경하지 않음

필요서류 추출기는 `삭제` 항목을 문서로 취급하지 않는다. 따라서 삭제 이력은
오른쪽 법령 원문에서 확인할 수 있지만 왼쪽 필요서류 체크리스트에는 나타나지
않는다.

## 설정

기존 `.env`의 다른 값은 그대로 두고 다음 값을 사용한다.

```dotenv
RAG_MODE=api
LAW_API_KEY=발급받은_OC_값
LAW_API_BASE_URL=https://www.law.go.kr/DRF
LAW_API_TIMEOUT=30
LAW_API_CACHE_DIR=./data/law_api_cache
LAW_API_REFRESH_HOURS=24
LAW_API_INCLUDE_APPENDICES=true
```

실제 `.env`와 API 키는 ZIP에 포함하지 않는다.

## 캐시와 인덱스

삭제 표시가 이미 유실된 V5 캐시를 다시 사용하지 않도록 V6는 다음 새 이름을
사용한다.

- snapshot: `foreign_exchange_snapshot_v4.json`
- Chroma collection/Parent/form store: `hierarchical_v6`/`v6`

기존 캐시를 사용자가 직접 삭제할 필요는 없다. V6 최초 실행 시 API 원문을 다시
받아 새 snapshot과 인덱스를 만든다.
