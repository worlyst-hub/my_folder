import os
import pandas as pd

from detector import calculate_risk
from ml_model import predict_transaction
from rag import RegulationRAG
from report import (
    build_query,
    generate_report
)


# ============================================================
# 프로젝트 경로
# ============================================================

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)


# ============================================================
# 데이터 경로
# ============================================================

CSV_PATH = os.path.join(
    BASE_DIR,
    "data",
    "financial_dataset.csv"
)


# ============================================================
# Main
# ============================================================

def main():

    # ========================================================
    # 1. 데이터 로드
    # ========================================================

    print("=" * 60)
    print("1. 금융 거래 데이터 로드")
    print("=" * 60)

    try:

        df = pd.read_csv(
            CSV_PATH
        )

    except FileNotFoundError:

        print(
            "금융 거래 데이터 파일을 찾을 수 없습니다."
        )

        print(
            f"확인할 경로: {CSV_PATH}"
        )

        return

    except Exception as e:

        print(
            "금융 거래 데이터 로드 중 오류가 발생했습니다."
        )

        print(e)

        return


    print(
        "데이터 개수:",
        len(df)
    )


    print("\n컬럼:")

    print(
        list(df.columns)
    )


    print("\n데이터 헤드:")

    print(
        df.head()
    )


    # ========================================================
    # 2. RAG 구축
    # ========================================================

    print("\n")
    print("=" * 60)
    print("2. RAG 데이터 구축")
    print("=" * 60)

    try:

        rag = RegulationRAG()

        rag.load_documents()

    except Exception as e:

        print(
            "RAG 구축 중 오류가 발생했습니다."
        )

        print(e)

        return


    # ========================================================
    # 3. 분석 대상 거래 랜덤 선택
    # ========================================================

    print("\n")
    print("=" * 60)
    print("3. 분석 대상 거래 랜덤 선택")
    print("=" * 60)

    selected_transaction = (
        df
        .sample(
            n=1
        )
        .iloc[0]
    )

    transaction = (
        selected_transaction
        .to_dict()
    )

    print(
        "전체 금융 거래 데이터 중 "
        "랜덤으로 1건을 선택했습니다."
    )

    print(
        "\n선택된 거래:"
    )

    # --------------------------------------------------------
    # suspicious_label은 사용자 화면에 출력하지 않음
    # --------------------------------------------------------

    display_transaction = {
        key: value
        for key, value in transaction.items()
        if key != "suspicious_label"
    }

    print(
        display_transaction
    )


    # ========================================================
    # 4. Rule Engine
    # ========================================================

    print("\n")
    print("=" * 60)
    print("4. Rule Engine 위험 탐지")
    print("=" * 60)

    try:

        detection_result = calculate_risk(
            transaction
        )

    except Exception as e:

        print(
            "Rule Engine 실행 중 오류가 발생했습니다."
        )

        print(e)

        return


    print(
        "위험 점수:",
        detection_result["risk_score"]
    )

    print(
        "위험 등급:",
        detection_result["risk_level"]
    )

    print(
        "위험 요인:",
        detection_result["reasons"]
    )


    # ========================================================
    # 5. Random Forest ML
    # ========================================================

    print("\n")
    print("=" * 60)
    print("5. Random Forest ML 위험 예측")
    print("=" * 60)

    try:

        ml_result = predict_transaction(
            transaction
        )

        print(
            "ML 예측:",
            ml_result["ml_prediction"]
        )

        print(
            "ML 의심거래 확률:",
            ml_result["ml_probability"]
        )

    except Exception as e:

        print(
            "ML 모델 실행 실패:"
        )

        print(e)

        ml_result = None


    # ========================================================
    # 6. RAG 검색 Query 생성
    # ========================================================

    print("\n")
    print("=" * 60)
    print("6. RAG 검색 Query 생성")
    print("=" * 60)

    try:

        query = build_query(
            transaction,
            detection_result
        )

    except Exception as e:

        print(
            "RAG Query 생성 중 오류가 발생했습니다."
        )

        print(e)

        return


    print(
        "\n검색 Query:"
    )

    print(
        query
    )


    # ========================================================
    # 7. RAG 검색
    # ========================================================

    print("\n")
    print("=" * 60)
    print("7. 관련 규정 / 사례 검색")
    print("=" * 60)

    try:

        # ----------------------------------------------------
        # 법령 검색은 내부적으로 수행
        # 검색된 원문은 화면에 출력하지 않음
        # ----------------------------------------------------

        documents = rag.search(
            query,
            n_results=5
        )

    except Exception as e:

        print(
            "RAG 검색 중 오류가 발생했습니다."
        )

        print(e)

        documents = []


    if documents:

        print(
            f"관련 법령 자료 {len(documents)}건을 "
            "검색했습니다."
        )

        print(
            "검색된 법령 원문은 AI 분석을 위해 "
            "내부적으로 전달합니다."
        )

    else:

        print(
            "관련 법령 자료를 찾지 못했습니다."
        )


    # ========================================================
    # 8. Ollama Cloud AML 분석
    # ========================================================

    print("\n")
    print("=" * 60)
    print("8. Ollama Cloud AI AML 분석")
    print("=" * 60)

    try:

        report = generate_report(

            transaction,

            detection_result,

            documents,

            ml_result

        )

    except Exception as e:

        print(
            "AI AML 분석 리포트 생성 중 오류가 발생했습니다."
        )

        print(e)

        return


    # ========================================================
    # 9. 최종 결과
    # ========================================================

    print("\n")
    print("=" * 60)
    print("AI AML 분석 리포트")
    print("=" * 60)

    print(
        report
    )


# ============================================================
# 프로그램 시작
# ============================================================

if __name__ == "__main__":

    main()