import os
import glob
import chromadb


class RegulationRAG:

    def __init__(
        self,
        collection_name="financial_regulations"
    ):

        # ====================================================
        # 프로젝트 루트
        # ====================================================

        self.base_dir = os.path.dirname(
            os.path.dirname(
                os.path.abspath(__file__)
            )
        )


        # ====================================================
        # ChromaDB
        # ====================================================

        self.chroma_path = os.path.join(
            self.base_dir,
            "chroma_db"
        )

        self.client = chromadb.PersistentClient(
            path=self.chroma_path
        )

        self.collection = (
            self.client.get_or_create_collection(
                name=collection_name
            )
        )


    # ========================================================
    # 문서 로드
    # ========================================================

    def load_documents(
        self,
        directory=None
    ):

        if directory is None:

            directory = os.path.join(
                self.base_dir,
                "data",
                "regulations"
            )


        if not os.path.isdir(directory):

            print(
                f"RAG 문서 폴더가 없습니다:\n"
                f"{directory}"
            )

            return


        documents = []
        ids = []
        metadatas = []


        files = glob.glob(
            os.path.join(
                directory,
                "*.txt"
            )
        )


        print(
            f"RAG 문서 파일: {len(files)}개"
        )


        # ====================================================
        # 파일 처리
        # ====================================================

        for file_path in files:

            try:

                with open(
                    file_path,
                    "r",
                    encoding="utf-8"
                ) as f:

                    text = f.read()

            except Exception as e:

                print(
                    f"문서 읽기 실패: {file_path}"
                )

                print(e)

                continue


            # =================================================
            # Chunking
            # =================================================

            chunk_size = 800
            chunk_overlap = 100

            step = (
                chunk_size
                - chunk_overlap
            )


            file_name = os.path.basename(
                file_path
            )


            chunk_number = 0


            for start in range(
                0,
                len(text),
                step
            ):

                chunk = text[
                    start:start + chunk_size
                ]


                if not chunk.strip():

                    continue


                chunk_id = (
                    f"{file_name}_{chunk_number}"
                )


                documents.append(
                    chunk
                )


                ids.append(
                    chunk_id
                )


                # ---------------------------------------------
                # Chunk 번호는 DB 내부 metadata로만 저장
                # ---------------------------------------------

                metadatas.append({

                    "source":
                        file_name,

                    "chunk":
                        chunk_number

                })


                chunk_number += 1


        # ====================================================
        # 저장
        # ====================================================

        if documents:

            self.collection.upsert(

                documents=documents,

                ids=ids,

                metadatas=metadatas

            )


        print(
            f"{len(documents)}개의 "
            f"문서 chunk를 RAG DB에 저장했습니다."
        )


    # ========================================================
    # 검색
    # ========================================================

    def search(
        self,
        query,
        n_results=5
    ):

        count = self.collection.count()


        if count == 0:

            print(
                "RAG DB에 저장된 문서가 없습니다."
            )

            return []


        n_results = min(
            n_results,
            count
        )


        result = self.collection.query(

            query_texts=[
                query
            ],

            n_results=n_results

        )


        documents = (
            result
            .get(
                "documents",
                [[]]
            )[0]
        )


        metadatas = (
            result
            .get(
                "metadatas",
                [[]]
            )[0]
        )


        formatted_documents = []


        for document, metadata in zip(
            documents,
            metadatas
        ):

            metadata = (
                metadata
                if metadata
                else {}
            )


            source = metadata.get(
                "source",
                "출처 없음"
            )


            chunk = metadata.get(
                "chunk",
                "-"
            )


            # =================================================
            # 중요
            #
            # Chunk 번호는 내부적으로 유지하지만
            # 반환되는 문자열에는 넣지 않는다.
            # =================================================

            formatted_documents.append({

                "source":
                    source,

                "chunk":
                    chunk,

                "content":
                    document

            })


        return formatted_documents