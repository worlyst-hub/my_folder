import os
import joblib
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix
)


# ============================================================
# 프로젝트 경로
# ============================================================

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)


# ============================================================
# 데이터 / 모델 경로
# ============================================================

CSV_PATH = os.path.join(
    BASE_DIR,
    "data",
    "financial_dataset.csv"
)

MODEL_PATH = os.path.join(
    BASE_DIR,
    "data",
    "aml_random_forest.pkl"
)


# ============================================================
# Feature
# ============================================================

FEATURE_COLUMNS = [

    "country",
    "amount",
    "frequency",
    "frequency_7d",
    "purpose",
    "occupation",
    "monthly_income",
    "account_age_days",
    "recipient_country",
    "transaction_type",
    "previous_amount_30d",
    "previous_count_30d",
    "split_transaction",
    "high_risk_country"

]


TARGET_COLUMN = "suspicious_label"


# ============================================================
# 모델 학습
# ============================================================

def train_model():

    print("=" * 60)
    print("Random Forest AML 모델 학습")
    print("=" * 60)

    df = pd.read_csv(
        CSV_PATH
    )

    print(
        f"전체 데이터: {len(df):,}건"
    )

    # --------------------------------------------------------
    # Feature / Label
    # --------------------------------------------------------

    X = df[
        FEATURE_COLUMNS
    ]

    y = df[
        TARGET_COLUMN
    ]

    print(
        f"정상 거래: {(y == 0).sum():,}건"
    )

    print(
        f"의심 거래: {(y == 1).sum():,}건"
    )

    # --------------------------------------------------------
    # Train / Test
    # --------------------------------------------------------

    X_train, X_test, y_train, y_test = train_test_split(

        X,
        y,

        test_size=0.2,

        random_state=42,

        stratify=y

    )

    # --------------------------------------------------------
    # Feature 종류
    # --------------------------------------------------------

    categorical_features = [

        "country",
        "frequency",
        "purpose",
        "occupation",
        "recipient_country",
        "transaction_type"

    ]

    numerical_features = [

        "amount",
        "frequency_7d",
        "monthly_income",
        "account_age_days",
        "previous_amount_30d",
        "previous_count_30d",
        "split_transaction",
        "high_risk_country"

    ]

    # --------------------------------------------------------
    # 전처리
    # --------------------------------------------------------

    preprocessor = ColumnTransformer(

        transformers=[

            (
                "categorical",

                OneHotEncoder(
                    handle_unknown="ignore"
                ),

                categorical_features

            ),

            (
                "numerical",

                "passthrough",

                numerical_features

            )

        ]

    )

    # --------------------------------------------------------
    # Random Forest
    # --------------------------------------------------------

    model = RandomForestClassifier(

        n_estimators=200,

        max_depth=10,

        min_samples_split=5,

        min_samples_leaf=2,

        random_state=42,

        class_weight="balanced",

        n_jobs=-1

    )

    # --------------------------------------------------------
    # Pipeline
    # --------------------------------------------------------

    pipeline = Pipeline(

        steps=[

            (
                "preprocessor",
                preprocessor
            ),

            (
                "classifier",
                model
            )

        ]

    )

    # --------------------------------------------------------
    # 학습
    # --------------------------------------------------------

    print("\n모델 학습 중...")

    pipeline.fit(
        X_train,
        y_train
    )

    print(
        "모델 학습 완료!"
    )

    # --------------------------------------------------------
    # 평가
    # --------------------------------------------------------

    y_pred = pipeline.predict(
        X_test
    )

    accuracy = accuracy_score(
        y_test,
        y_pred
    )

    print("\n")
    print("=" * 60)
    print("ML 모델 평가")
    print("=" * 60)

    print(
        f"\nAccuracy: {accuracy:.4f}"
    )

    print("\nClassification Report:")

    print(
        classification_report(
            y_test,
            y_pred,
            target_names=[
                "정상",
                "의심"
            ]
        )
    )

    print("\nConfusion Matrix:")

    print(
        confusion_matrix(
            y_test,
            y_pred
        )
    )

    # --------------------------------------------------------
    # 저장
    # --------------------------------------------------------

    os.makedirs(
        os.path.dirname(MODEL_PATH),
        exist_ok=True
    )

    joblib.dump(
        pipeline,
        MODEL_PATH
    )

    print(
        f"\n모델 저장 완료:"
        f"\n{MODEL_PATH}"
    )

    return pipeline


# ============================================================
# 모델 불러오기
# ============================================================

def load_model():

    if not os.path.exists(
        MODEL_PATH
    ):

        print(
            "저장된 ML 모델이 없습니다."
        )

        return train_model()

    return joblib.load(
        MODEL_PATH
    )


# ============================================================
# 거래 하나 예측
# ============================================================

def predict_transaction(
    transaction
):

    model = load_model()

    data = pd.DataFrame(
        [transaction]
    )

    data = data[
        FEATURE_COLUMNS
    ]

    prediction = model.predict(
        data
    )[0]

    probabilities = model.predict_proba(
        data
    )[0]

    suspicious_probability = probabilities[1]

    if prediction == 1:

        prediction_label = "SUSPICIOUS"

    else:

        prediction_label = "NORMAL"

    return {

        "ml_prediction":
            prediction_label,

        "ml_probability":
            round(
                float(
                    suspicious_probability
                ),
                4
            )

    }


# ============================================================
# 직접 실행
# ============================================================

if __name__ == "__main__":

    train_model()