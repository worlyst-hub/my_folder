import pandas as pd


# ============================================================
# 문자열 형태의 True / False 변환
# ============================================================

def to_bool(value):

    if isinstance(value, bool):
        return value

    if value is None:
        return False

    value = str(value).strip().lower()

    return value in [
        "true",
        "1",
        "yes",
        "y",
        "예",
        "네"
    ]


# ============================================================
# 안전한 숫자 변환
# ============================================================

def to_float(value, default=0):

    try:
        return float(value)

    except (ValueError, TypeError):

        return default


def to_int(value, default=0):

    try:
        return int(float(value))

    except (ValueError, TypeError):

        return default


# ============================================================
# Rule Engine
# ============================================================

def calculate_risk(row):
    """
    Rule Engine 기반 AML 위험도 계산

    판단 기준

    1. 고액 거래
    2. 단기간 반복 거래
    3. 거래 목적 불명확
    4. 고위험 국가
    5. 분할 거래
    6. 소득 대비 과도한 거래
    7. 최근 30일 누적 거래 규모
    8. 연초 이후 누적 거래 규모
    9. 거래 빈도
    10. 신규 계좌의 고액 거래

    주의:
    suspicious_label은 정답 라벨이므로
    Rule Engine 판단에는 사용하지 않는다.
    """

    score = 0
    reasons = []


    # ========================================================
    # 데이터 추출
    # ========================================================

    amount = to_float(
        row.get("amount", 0)
    )

    amount_since_jan1 = to_float(
        row.get("amount_since_jan1", 0)
    )

    frequency = str(
        row.get("frequency", "")
    ).strip().lower()

    frequency_7d = to_int(
        row.get("frequency_7d", 0)
    )

    previous_amount_30d = to_float(
        row.get("previous_amount_30d", 0)
    )

    previous_count_30d = to_int(
        row.get("previous_count_30d", 0)
    )

    monthly_income = to_float(
        row.get("monthly_income", 0)
    )

    account_age_days = to_int(
        row.get("account_age_days", 0)
    )

    high_risk_country = to_bool(
        row.get(
            "high_risk_country",
            False
        )
    )

    split_transaction = to_bool(
        row.get(
            "split_transaction",
            False
        )
    )

    purpose = str(
        row.get("purpose", "")
    ).strip().lower()

    transaction_type = str(
        row.get("transaction_type", "")
    ).strip().lower()


    # ========================================================
    # 1. 고액 거래
    # ========================================================

    if amount >= 50_000:

        score += 25

        reasons.append(
            "고액 거래"
        )


    # ========================================================
    # 2. 단기간 반복 거래
    # ========================================================

    if frequency_7d >= 10:

        score += 25

        reasons.append(
            "최근 7일 단기간 반복 거래"
        )

    elif frequency_7d >= 5:

        score += 15

        reasons.append(
            "최근 7일 거래 빈도 높음"
        )

    elif previous_count_30d >= 20:

        score += 20

        reasons.append(
            "최근 30일 거래 빈도 높음"
        )

    elif previous_count_30d >= 10:

        score += 10

        reasons.append(
            "최근 30일 반복 거래"
        )


    # ========================================================
    # 3. 거래 빈도 유형
    # ========================================================

    if frequency in [
        "daily",
        "매일",
        "일일"
    ]:

        score += 5

        reasons.append(
            "일일 거래 패턴"
        )


    # ========================================================
    # 4. 거래 목적 불명확
    # ========================================================

    if purpose in [
        "",
        "unknown",
        "불명",
        "기타",
        "other"
    ]:

        score += 15

        reasons.append(
            "거래 목적 불명확"
        )


    # ========================================================
    # 5. 고위험 국가
    # ========================================================

    if high_risk_country:

        score += 25

        reasons.append(
            "고위험 국가 거래"
        )


    # ========================================================
    # 6. 분할 거래
    # ========================================================

    if split_transaction:

        score += 20

        reasons.append(
            "분할 거래 패턴"
        )


    # ========================================================
    # 7. 소득 대비 과도한 거래
    # ========================================================

    if (
        monthly_income > 0
        and amount >= monthly_income * 3
    ):

        score += 20

        reasons.append(
            "월소득 대비 과도한 거래 금액"
        )


    # ========================================================
    # 8. 최근 30일 누적 거래액
    # ========================================================

    if previous_amount_30d >= 100_000:

        score += 20

        reasons.append(
            "최근 30일 누적 거래액이 매우 높음"
        )

    elif previous_amount_30d >= 50_000:

        score += 10

        reasons.append(
            "최근 30일 누적 거래액이 높음"
        )


    # ========================================================
    # 9. 연초 이후 누적 거래액
    #
    # amount_since_jan1을 새롭게 반영
    # ========================================================

    if amount_since_jan1 >= 500_000:

        score += 20

        reasons.append(
            "연초 이후 누적 거래액이 매우 높음"
        )

    elif amount_since_jan1 >= 200_000:

        score += 10

        reasons.append(
            "연초 이후 누적 거래액이 높음"
        )


    # ========================================================
    # 10. 신규 계좌 + 고액 거래
    #
    # 계좌 개설 후 90일 이내인데
    # 고액 거래가 발생한 경우
    # ========================================================

    if (
        account_age_days <= 90
        and amount >= 30_000
    ):

        score += 15

        reasons.append(
            "신규 계좌에서 고액 거래 발생"
        )


    # ========================================================
    # 11. 해외송금 거래
    #
    # transaction_type을 거래 맥락으로 활용
    # ========================================================

    if transaction_type in [
        "remittance",
        "송금",
        "해외송금",
        "international_remittance"
    ]:

        # 해외송금 자체를 위험거래로 판단하지 않고
        # 다른 위험요인과 함께 거래 맥락으로 사용한다.

        if amount >= 50_000:

            if "고액 거래" not in reasons:

                score += 10

                reasons.append(
                    "고액 해외송금"
                )


    # ========================================================
    # 위험도 결정
    # ========================================================

    if score >= 70:

        level = "HIGH"

    elif score >= 40:

        level = "MEDIUM"

    else:

        level = "LOW"


    # ========================================================
    # 결과 반환
    # ========================================================

    return {

        "risk_score": score,

        "risk_level": level,

        "reasons": reasons

    }


# ============================================================
# 전체 거래 탐지
# ============================================================

def detect_transactions(df):

    results = []

    for _, row in df.iterrows():

        result = calculate_risk(
            row
        )

        results.append({

            "user_id":
                row.get("user_id"),

            "risk_score":
                result["risk_score"],

            "risk_level":
                result["risk_level"],

            "reasons":
                result["reasons"]
        })

    return pd.DataFrame(
        results
    )