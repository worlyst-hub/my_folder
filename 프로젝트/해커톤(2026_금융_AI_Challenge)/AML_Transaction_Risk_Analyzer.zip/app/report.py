import os

from dotenv import load_dotenv
from ollama import Client


# ============================================================
# 프로젝트 경로
# ============================================================

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)


# ============================================================
# .env
# ============================================================

ENV_PATH = os.path.join(
    BASE_DIR,
    ".env"
)

load_dotenv(
    ENV_PATH
)


# ============================================================
# Ollama Cloud API Key
# ============================================================

OLLAMA_API_KEY = os.getenv(
    "OLLAMA_API_KEY"
)

if not OLLAMA_API_KEY:

    raise ValueError(
        "OLLAMA_API_KEY가 .env에 없습니다."
    )


# ============================================================
# Ollama Cloud Client
# ============================================================

client = Client(

    host="https://ollama.com",

    headers={
        "Authorization":
            f"Bearer {OLLAMA_API_KEY}"
    }

)


# ============================================================
# 모델
# ============================================================

MODEL = "gpt-oss:120b-cloud"


# ============================================================
# 국가 코드 → 한국어
# ============================================================

COUNTRY_MAP = {

    "KR": "대한민국",
    "US": "미국",
    "JP": "일본",
    "CN": "중국",
    "GB": "영국",
    "DE": "독일",
    "FR": "프랑스",
    "CA": "캐나다",
    "AU": "호주",
    "SG": "싱가포르",
    "HK": "홍콩",
    "IN": "인도",
    "VN": "베트남",
    "TH": "태국",
    "PH": "필리핀",
    "ID": "인도네시아",
    "MY": "말레이시아",
    "RU": "러시아",
    "KP": "북한",
    "AE": "아랍에미리트",
    "SA": "사우디아라비아",
    "BR": "브라질",
    "MX": "멕시코",
    "ES": "스페인",
    "IT": "이탈리아",
    "NL": "네덜란드"

}


# ============================================================
# 거래 목적 → 한국어
# ============================================================

PURPOSE_MAP = {

    "food": "식비",
    "shopping": "쇼핑",
    "education": "교육",
    "medical": "의료",
    "travel": "여행",
    "remittance": "해외송금",
    "investment": "투자",
    "business": "사업",
    "salary": "급여",
    "living": "생활비",
    "rent": "임대료",
    "other": "기타",
    "unknown": "미상"

}


# ============================================================
# 직업 → 한국어
# ============================================================

OCCUPATION_MAP = {

    "designer": "디자이너",
    "developer": "개발자",
    "engineer": "엔지니어",
    "student": "학생",
    "teacher": "교사",
    "doctor": "의사",
    "nurse": "간호사",
    "lawyer": "변호사",
    "accountant": "회계사",
    "manager": "관리자",
    "sales": "영업직",
    "self_employed": "자영업자",
    "business_owner": "사업자",
    "researcher": "연구원",
    "office_worker": "사무직",
    "government": "공무원",
    "freelancer": "프리랜서",
    "unemployed": "무직",
    "other": "기타"

}


# ============================================================
# 거래 빈도 → 한국어
# ============================================================

FREQUENCY_MAP = {

    "daily": "매일",
    "weekly": "매주",
    "monthly": "매월",
    "irregular": "비정기적",
    "rare": "드문 거래"

}


# ============================================================
# 거래 유형 → 한국어
# ============================================================

TRANSACTION_TYPE_MAP = {

    "remittance": "해외송금",
    "transfer": "계좌이체",
    "payment": "지급",
    "withdrawal": "출금",
    "deposit": "입금",
    "exchange": "환전",
    "card": "카드 거래",
    "other": "기타"

}


# ============================================================
# 국가 변환
# ============================================================

def map_country(value):

    value = str(value).strip()

    return COUNTRY_MAP.get(
        value,
        value
    )


# ============================================================
# 거래 목적 변환
# ============================================================

def map_purpose(value):

    value = str(value).strip().lower()

    return PURPOSE_MAP.get(
        value,
        value
    )


# ============================================================
# 직업 변환
# ============================================================

def map_occupation(value):

    value = str(value).strip().lower()

    return OCCUPATION_MAP.get(
        value,
        value
    )


# ============================================================
# 거래 빈도 변환
# ============================================================

def map_frequency(value):

    value = str(value).strip().lower()

    return FREQUENCY_MAP.get(
        value,
        value
    )


# ============================================================
# 거래 유형 변환
# ============================================================

def map_transaction_type(value):

    value = str(value).strip().lower()

    return TRANSACTION_TYPE_MAP.get(
        value,
        value
    )


# ============================================================
# True / False → 한국어
# ============================================================

def map_bool(value):

    if isinstance(value, bool):

        return "예" if value else "아니오"

    value = str(
        value
    ).strip().lower()

    if value in [
        "true",
        "1",
        "yes",
        "y",
        "예"
    ]:

        return "예"

    return "아니오"


# ============================================================
# RAG 검색 결과 정리
# ============================================================
#
# rag.py의 search()가
#
# 1. 문자열
# 2. dict
#
# 어느 형태를 반환하더라도 처리할 수 있도록 한다.
#
# Chunk 정보는 제거한다.
# ============================================================

def normalize_rag_documents(
    retrieved_documents
):

    if not retrieved_documents:

        return "검색된 RAG 문서가 없습니다."


    normalized_documents = []


    for index, document in enumerate(
        retrieved_documents,
        start=1
    ):

        # ----------------------------------------------------
        # 문자열 형태
        # ----------------------------------------------------

        if isinstance(
            document,
            str
        ):

            text = document

            # Chunk 정보 제거
            lines = text.splitlines()

            filtered_lines = []

            for line in lines:

                if line.startswith(
                    "[Chunk:"
                ):
                    continue

                filtered_lines.append(
                    line
                )

            text = "\n".join(
                filtered_lines
            ).strip()

            normalized_documents.append(

                f"[검색 문서 {index}]\n"
                f"{text}"

            )


        # ----------------------------------------------------
        # dict 형태
        # ----------------------------------------------------

        elif isinstance(
            document,
            dict
        ):

            source = document.get(
                "source",
                document.get(
                    "metadata",
                    {}
                ).get(
                    "source",
                    "출처 없음"
                )
                if isinstance(
                    document.get(
                        "metadata",
                        {}
                    ),
                    dict
                )
                else "출처 없음"
            )

            content = document.get(
                "content",
                document.get(
                    "document",
                    document.get(
                        "text",
                        ""
                    )
                )
            )

            # content가 없으면 document 자체를 확인
            if not content:

                content = str(
                    document
                )


            normalized_documents.append(

                f"[검색 문서 {index}]\n"
                f"문서 출처: {source}\n"
                f"{content}"

            )


        # ----------------------------------------------------
        # 기타 형태
        # ----------------------------------------------------

        else:

            normalized_documents.append(

                f"[검색 문서 {index}]\n"
                f"{str(document)}"

            )


    if not normalized_documents:

        return "검색된 RAG 문서가 없습니다."


    return "\n\n".join(
        normalized_documents
    )


# ============================================================
# RAG Query 생성
# ============================================================

def build_query(
    transaction,
    detection_result
):

    reasons = detection_result.get(
        "reasons",
        []
    )

    risk_level = detection_result.get(
        "risk_level",
        "LOW"
    )

    risk_score = detection_result.get(
        "risk_score",
        0
    )


    # --------------------------------------------------------
    # 위험요인
    # --------------------------------------------------------

    if reasons:

        reason_text = "\n".join(

            f"- {reason}"

            for reason in reasons

        )

    else:

        reason_text = (
            "- 현재 탐지된 위험요인이 없습니다."
        )


    # --------------------------------------------------------
    # 사용자에게 출력되는 Query
    # --------------------------------------------------------

    query = f"""
금융 거래의 이상 여부와 관련 규정을 검토합니다.

[거래 정보]

사용자 ID:
{transaction.get("user_id", "확인되지 않음")}

거래일:
{transaction.get("transaction_date", "확인되지 않음")}

고객 국가:
{map_country(transaction.get("country", ""))}

거래 금액:
{transaction.get("amount", 0)} USD

1월 1일 이후 누적 거래액:
{transaction.get("amount_since_jan1", 0)} USD

거래 빈도:
{map_frequency(transaction.get("frequency", ""))}

최근 7일 거래 횟수:
{transaction.get("frequency_7d", 0)}회

거래 목적:
{map_purpose(transaction.get("purpose", ""))}

직업:
{map_occupation(transaction.get("occupation", ""))}

월소득:
{transaction.get("monthly_income", 0)} USD

계좌 개설 후 기간:
{transaction.get("account_age_days", 0)}일

수취인 국가:
{map_country(transaction.get("recipient_country", ""))}

거래 유형:
{map_transaction_type(transaction.get("transaction_type", ""))}

최근 30일 누적 거래액:
{transaction.get("previous_amount_30d", 0)} USD

최근 30일 거래 횟수:
{transaction.get("previous_count_30d", 0)}회

분할 거래 여부:
{map_bool(transaction.get("split_transaction", False))}

고위험 국가 여부:
{map_bool(transaction.get("high_risk_country", False))}


[Rule Engine 탐지 결과]

위험도:
{risk_level}

위험 점수:
{risk_score}

위험요인:
{reason_text}


[검색 목적]

위 거래의 특성과 관련하여
외국환거래법 및 외국환거래규정에서
검토할 필요가 있는 관련 규정과 근거를 확인합니다.

특히 다음 항목과 관련된 내용을 우선적으로 확인합니다.

- 해외 지급 및 수령
- 외국환거래
- 지급 및 수령 방법
- 신고 및 보고
- 거래 증빙 및 사후관리
- 자본거래
- 반복 거래 및 분할 거래
- 외국환업무취급기관 관련 규정

검색 결과는 제공된 RAG 문서를 근거로 합니다.
"""

    return query.strip()


# ============================================================
# AML 분석 보고서 생성
# ============================================================

def generate_report(
    transaction,
    detection_result,
    retrieved_documents,
    ml_result=None
):

    # ========================================================
    # RAG 문서 정리
    # ========================================================

    context = normalize_rag_documents(
        retrieved_documents
    )


    # ========================================================
    # ML 결과
    # ========================================================

    if ml_result:

        ml_prediction = ml_result.get(
            "ml_prediction",
            "확인되지 않음"
        )

        ml_probability = ml_result.get(
            "ml_probability",
            0
        )

    else:

        ml_prediction = "확인되지 않음"

        ml_probability = 0


    # ========================================================
    # 거래 정보
    #
    # suspicious_label은 제외
    # ========================================================

    transaction_text = f"""
사용자 ID:
{transaction.get("user_id", "확인되지 않음")}

거래일:
{transaction.get("transaction_date", "확인되지 않음")}

고객 국가:
{map_country(transaction.get("country", ""))}

거래 금액:
{transaction.get("amount", 0)} USD

1월 1일 이후 누적 거래액:
{transaction.get("amount_since_jan1", 0)} USD

거래 빈도:
{map_frequency(transaction.get("frequency", ""))}

최근 7일 거래 횟수:
{transaction.get("frequency_7d", 0)}회

거래 목적:
{map_purpose(transaction.get("purpose", ""))}

직업:
{map_occupation(transaction.get("occupation", ""))}

월소득:
{transaction.get("monthly_income", 0)} USD

계좌 개설 후 기간:
{transaction.get("account_age_days", 0)}일

수취인 ID:
{transaction.get("recipient_id", "확인되지 않음")}

수취인 국가:
{map_country(transaction.get("recipient_country", ""))}

거래 유형:
{map_transaction_type(transaction.get("transaction_type", ""))}

최근 30일 누적 거래액:
{transaction.get("previous_amount_30d", 0)} USD

최근 30일 거래 횟수:
{transaction.get("previous_count_30d", 0)}회

분할 거래 여부:
{map_bool(transaction.get("split_transaction", False))}

고위험 국가 여부:
{map_bool(transaction.get("high_risk_country", False))}
"""


    # ========================================================
    # AI Prompt
    # ========================================================

    prompt = f"""
당신은 금융기관의 AML 분석을 지원하는 AI입니다.

다음 원칙을 반드시 준수합니다.

1. 최종적인 법률 판단을 내리지 않습니다.
2. 제공된 RAG 문서에 존재하지 않는 법률 조항을 생성하지 않습니다.
3. 제공된 RAG 문서에 존재하지 않는 사례를 생성하지 않습니다.
4. 근거가 부족한 경우 반드시 "근거 부족"이라고 표시합니다.
5. Rule Engine 결과와 ML 결과를 구분하여 설명합니다.
6. RAG 문서에 포함된 법령명과 조문 정보를 가능한 경우 정확하게 표시합니다.
7. suspicious_label은 합성 데이터 또는 ML 학습용 라벨이므로 법령상 의심거래 확정 결과로 사용하지 않습니다.
8. suspicious_label을 최종 분석 결과에 표시하지 않습니다.
9. RAG 문서와 직접 관련이 없는 법령이나 사례를 추가하지 않습니다.
10. 모든 설명은 정중한 존댓말로 작성합니다.
11. 법령의 적용 여부가 명확하지 않은 경우 담당자의 추가 검토가 필요하다고 설명합니다.
12. RAG 검색 문서에 실제로 존재하지 않는 조문 번호를 추측하여 작성하지 않습니다.


[거래 정보]

{transaction_text}


[Rule Engine 결과]

위험도:
{detection_result.get("risk_level", "확인되지 않음")}

위험 점수:
{detection_result.get("risk_score", 0)}

위험요인:
{detection_result.get("reasons", [])}


[Random Forest ML 결과]

예측:
{ml_prediction}

의심거래 확률:
{ml_probability}


[RAG 검색 문서]

{context}


위 정보를 바탕으로 다음 형식으로 작성합니다.


위험도:
Rule Engine 위험 점수:

ML 예측:
ML 의심거래 확률:

탐지 이유:

1.
2.
3.

관련 규정 및 근거:

- 문서명:
- 조문:
- 관련 내용:
- 거래와의 관련성:

유사 사례:

- 사례:
- 거래와의 유사점:

Rule Engine과 ML 결과 종합:

권고사항:

1.
2.

주의사항:

- RAG 문서에서 확인할 수 있는 근거만 사용합니다.
- RAG 문서에 관련 근거가 충분하지 않은 경우 "근거 부족"이라고 표시합니다.
- 본 분석은 AML 업무 지원을 위한 참고 결과입니다.
- 법률적 최종 판단은 담당자가 수행해야 합니다.
"""


    # ========================================================
    # Ollama Cloud
    # ========================================================

    try:

        response = client.chat(

            model=MODEL,

            messages=[
                {
                    "role": "user",
                    "content": prompt
                }
            ]

        )

        return response[
            "message"
        ][
            "content"
        ]


    except Exception as e:

        print(
            "AI AML 분석 리포트 생성 중 오류가 발생했습니다."
        )

        print(
            e
        )

        return (
            "AI AML 분석 리포트를 생성하지 못했습니다."
        )