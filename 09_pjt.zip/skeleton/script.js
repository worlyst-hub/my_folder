/**
 * 제공 코드
 */
// 기본 작가, 분류, 도서 데이터 (JavaScript Array)
const categories = categoryRawData
const authors = authorRawData
const books = bookRawData

// 데이터 확인
console.log(categories.length)
console.log(categories[0])
console.log(authors.length)
console.log(authors[0])
console.log(books.length)
console.log(books[0])

// F901 — 제공된 도서를 Bootstrap 카드로 출력
const bookListRow = document.querySelector('#book-list-row')
const favoriteListRow = document.querySelector('#favorite-list-row')
const favorites = new Set()
let homeBooks = books
let activeTab = 'home'

function renderBooks(bookList, target, emptyMessage) {
  target.replaceChildren()

  if (bookList.length === 0) {
    const message = document.createElement('p')
    message.textContent = emptyMessage
    target.append(message)
    return
  }

  for (const book of bookList) {
    const column = document.createElement('div')
    column.className = 'col-12 col-sm-6 col-md-4 col-lg-3'

    const card = document.createElement('article')
    card.className = 'card h-100'

    const image = document.createElement('img')
    image.className = 'card-img-top object-fit-contain'
    image.style.height = '220px'
    image.src = book.cover || './stack-of-books.png'
    image.alt = `${book.title} 표지`

    const body = document.createElement('div')
    body.className = 'card-body'

    const title = document.createElement('h3')
    title.className = 'card-title h5'
    title.textContent = book.title

    const description = document.createElement('p')
    description.className = 'card-text overflow-auto'
    description.style.maxHeight = '8rem'
    description.textContent = book.description

    const favoriteButton = document.createElement('button')
    favoriteButton.type = 'button'
    const isFavorite = favorites.has(book)
    favoriteButton.className = isFavorite ? 'btn btn-warning' : 'btn btn-outline-warning'
    favoriteButton.textContent = isFavorite ? '즐겨찾기 해제' : '즐겨찾기 추가'
    favoriteButton.setAttribute('aria-pressed', String(isFavorite))
    favoriteButton.addEventListener('click', () => toggleFavorite(book))

    body.append(title, description, favoriteButton)
    card.append(image, body)
    column.append(card)
    target.append(column)
  }
}

// F902 — 검색 조건에 맞는 도서만 출력
const searchForm = document.querySelector('#search-form')
const searchField = document.querySelector('#search-field')
const searchInput = document.querySelector('#search-input')

function getSearchValue(book, field) {
  if (field === 'author') {
    return authors.find(author => author.id === book.authorId)?.name ?? ''
  }

  if (field === 'category') {
    return categories.find(category => category.id === book.categoryId)?.name ?? ''
  }

  return book.title
}

searchForm.addEventListener('submit', event => {
  event.preventDefault()

  const keyword = searchInput.value.trim()
  if (keyword === '') {
    alert('검색어를 입력하세요.')
    return
  }

  const field = searchField.value
  homeBooks = books.filter(book => getSearchValue(book, field).includes(keyword))
  renderHome()
})

document.querySelector('#search-reset').addEventListener('click', () => {
  searchForm.reset()
  homeBooks = books
  renderHome()
})

// F903 — Home과 Create 화면 전환
const homeContainer = document.querySelector('#home-container')
const createContainer = document.querySelector('#create-container')
const favoritesContainer = document.querySelector('#favorites-container')

function showTab(tab) {
  activeTab = tab
  homeContainer.classList.toggle('d-none', tab !== 'home')
  createContainer.classList.toggle('d-none', tab !== 'create')
  favoritesContainer.classList.toggle('d-none', tab !== 'favorites')

  if (tab === 'home') {
    renderHome()
  } else if (tab === 'favorites') {
    renderFavorites()
  }
}

document.querySelector('#home-nav').addEventListener('click', () => showTab('home'))
document.querySelector('#create-nav').addEventListener('click', () => showTab('create'))
document.querySelector('#favorites-nav').addEventListener('click', () => showTab('favorites'))

// F905 — 카드 버튼과 즐겨찾기 목록 동기화
function renderHome() {
  renderBooks(homeBooks, bookListRow, '검색 결과가 없습니다.')
}

function renderFavorites() {
  renderBooks([...favorites], favoriteListRow, '즐겨찾기한 도서가 없습니다.')
}

function toggleFavorite(book) {
  if (favorites.has(book)) {
    favorites.delete(book)
  } else {
    favorites.add(book)
  }

  if (activeTab === 'home') {
    renderHome()
  } else if (favorites.size === 0) {
    showTab('home')
  } else {
    renderFavorites()
  }
}

// F904 — 입력값 검증 및 도서 등록
const createForm = document.querySelector('#create-form')
const createErrors = document.querySelector('#create-book-errors')

function getOrAddId(items, name) {
  const existingItem = items.find(item => item.name === name)
  if (existingItem) {
    return existingItem.id
  }

  const id = Math.max(0, ...items.map(item => item.id)) + 1
  items.push({ id, name })
  return id
}

createForm.addEventListener('submit', event => {
  event.preventDefault()
  createErrors.replaceChildren()

  const title = createForm.querySelector('#title-input').value.trim()
  const author = createForm.querySelector('#author-input').value.trim()
  const imageUrl = createForm.querySelector('#img-input').value.trim()
  const description = createForm.querySelector('#desc-input').value.trim()
  const category = createForm.querySelector('#category-input').value.trim()

  const requiredFields = [
    ['제목', title],
    ['작가', author],
    ['소개', description],
    ['분류', category],
  ]

  for (const [label, value] of requiredFields) {
    if (value === '') {
      const error = document.createElement('li')
      error.textContent = `${label} 항목을 입력하세요.`
      createErrors.append(error)
    }
  }

  if (createErrors.childElementCount > 0) {
    return
  }

  const newBook = {
    title,
    description,
    cover: imageUrl.startsWith('http') ? imageUrl : '',
    authorId: getOrAddId(authors, author),
    categoryId: getOrAddId(categories, category),
  }

  books.unshift(newBook)
  createForm.reset()
  searchForm.reset()
  homeBooks = books
  showTab('home')
})

renderHome()
